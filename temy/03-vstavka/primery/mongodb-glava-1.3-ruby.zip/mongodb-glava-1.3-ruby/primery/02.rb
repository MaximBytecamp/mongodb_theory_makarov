# Глава 1.3 · Вставка: insert_one и insert_many
# Пример 2 из 6 · §3 Что возвращает вставка · разбор результата
# В начале — код из блока «вставка одного документа»: в главе он стоит прямо перед этим примером.
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/02.rb
#   cd primery, затем ruby 02.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
result = box.insert_one({
  "sku" => "SKU-AC-022",
  "title" => "Коврик для мыши XL",
  "brand" => "OEM",
  "category" => "аксессуары",
  "price" => 1290
})
puts "подтверждено: #{result.acknowledged?}"
puts "присвоенный _id: #{result.inserted_id}"
puts "тип: #{result.inserted_id.class}"
