# Глава 1.3 · Вставка: insert_one и insert_many
# Пример 3 из 6 · §4 insert_many: пачка документов · вставка списка
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/03.rb
#   cd primery, затем ruby 03.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
many = box.insert_many([
  { "_id" => "p-101", "title" => "Подставка для ноутбука",
    "category" => "аксессуары", "price" => 2490 },
  { "_id" => "p-102", "title" => "Чехол для планшета",
    "category" => "аксессуары", "price" => 1890 }
])

puts "вставлено: #{many.inserted_count} → #{many.inserted_ids}"
puts "документов в песочнице: #{box.count_documents({})}"
