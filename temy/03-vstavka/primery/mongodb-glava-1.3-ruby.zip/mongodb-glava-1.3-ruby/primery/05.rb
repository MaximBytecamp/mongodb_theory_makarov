# Глава 1.3 · Вставка: insert_one и insert_many
# Пример 5 из 6 · §6 Порядок вставки: ordered · загрузка с пропуском сбойных
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/05.rb
#   cd primery, затем ruby 05.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
batch = [
  { "_id" => "p-103", "title" => "Кабель HDMI 2 м", "category" => "аксессуары", "price" => 690 },
  { "_id" => "p-101", "title" => "Подставка — повтор" },   # такой _id уже есть
  { "_id" => "p-104", "title" => "Салфетки для экрана", "category" => "аксессуары", "price" => 390 },
]

begin
  box.insert_many(batch, ordered: false)
rescue Mongo::Error::BulkWriteError => error
  failed = error.result["writeErrors"]
  puts "не вставлено: #{failed.size} из #{batch.size}"
end

puts "документов в песочнице: #{box.count_documents({})}"
