# Глава 1.3 · Вставка: insert_one и insert_many
# Пример 4 из 6 · §5 Свой _id и его уникальность · повторный ключ
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/04.rb
#   cd primery, затем ruby 04.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
begin
  box.insert_one({ "_id" => "p-101", "title" => "Ещё одна подставка" })
rescue Mongo::Error::OperationFailure => error
  puts error.class
  puts error.message
end
