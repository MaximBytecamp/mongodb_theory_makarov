# Глава 1.3 · Вставка: insert_one и insert_many
# Пример 1 из 6 · §1 Песочница: где мы работаем · подключение к песочнице
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/01.rb
#   cd primery, затем ruby 01.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
require "mongo"

client = Mongo::Client.new("mongodb://localhost:27017/")
box = client.use("sandbox").database[:products]   # здесь можно ломать

puts box.count_documents({})                     # 21
