# Глава 1.3 · Вставка: insert_one и insert_many
# Пример 6 из 6 · §8 Загрузка файла целиком · тот же файл из кода
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/06.rb
#   cd primery, затем ruby 06.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
# BSON::ExtJSON понимает {"$date": …} в файле, обычный JSON.parse — нет
docs = BSON::ExtJSON.parse(File.read("../stend/seed/sandbox.products.json"))

box.delete_many({})             # повтор без задвоения
box.insert_many(docs)
puts "документов в песочнице: #{box.count_documents({})}"
