//go:build ignore

// Глава 1.3 · Вставка: insert_one и insert_many
// Пример 2 из 6 · §3 Что возвращает вставка · разбор результата
// В начале — код из блока «вставка одного документа»: в главе он стоит прямо перед этим примером.
//
// Запуск из папки архива:
//   docker compose run --rm go primery/02.go
//   cd primery, затем go run 02.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	products := db.Collection("products")
	orders := db.Collection("orders")
	box := client.Database("sandbox").Collection("products") // песочница: здесь можно менять
	_, _, _, _ = db, products, orders, box

	{
		// ── пример из главы ──────────────────────────────────────
		res, err := box.InsertOne(ctx, bson.D{
		    {Key: "sku", Value: "SKU-AC-022"},
		    {Key: "title", Value: "Коврик для мыши XL"},
		    {Key: "brand", Value: "OEM"},
		    {Key: "category", Value: "аксессуары"},
		    {Key: "price", Value: 1290},
		})
		// подтверждение в Go — это отсутствие ошибки
		if err != nil {
		    log.Fatal(err)
		}
		fmt.Println("присвоенный _id:", res.InsertedID)
	}
}
