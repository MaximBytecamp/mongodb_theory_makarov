//go:build ignore

// Глава 1.3 · Вставка: insert_one и insert_many
// Пример 3 из 6 · §4 insert_many: пачка документов · вставка списка
//
// Запуск из папки архива:
//   docker compose run --rm go primery/03.go
//   cd primery, затем go run 03.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	products := db.Collection("products")
	orders := db.Collection("orders")
	box := client.Database("sandbox").Collection("products") // песочница: здесь можно менять
	_, _, _, _ = db, products, orders, box

	{
		// ── пример из главы ──────────────────────────────────────
		many, err := box.InsertMany(ctx, []any{
		    bson.D{{Key: "_id", Value: "p-101"}, {Key: "title", Value: "Подставка для ноутбука"},
		        {Key: "category", Value: "аксессуары"}, {Key: "price", Value: 2490}},
		    bson.D{{Key: "_id", Value: "p-102"}, {Key: "title", Value: "Чехол для планшета"},
		        {Key: "category", Value: "аксессуары"}, {Key: "price", Value: 1890}},
		})
		if err != nil {
		    log.Fatal(err)
		}

		fmt.Println("вставлено:", len(many.InsertedIDs), "→", many.InsertedIDs)
		count, _ := box.CountDocuments(ctx, bson.D{})
		fmt.Println("документов в песочнице:", count)
	}
}
