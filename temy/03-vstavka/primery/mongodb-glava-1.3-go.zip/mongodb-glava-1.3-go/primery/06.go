//go:build ignore

// Глава 1.3 · Вставка: insert_one и insert_many
// Пример 6 из 6 · §8 Загрузка файла целиком · тот же файл из кода
//
// Запуск из папки архива:
//   docker compose run --rm go primery/06.go
//   cd primery, затем go run 06.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────

var docs []any

func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	products := db.Collection("products")
	orders := db.Collection("orders")
	box := client.Database("sandbox").Collection("products") // песочница: здесь можно менять
	_, _, _, _ = db, products, orders, box

	{
		// ── пример из главы ──────────────────────────────────────
		raw, _ := os.ReadFile("../stend/seed/sandbox.products.json")

		bson.UnmarshalExtJSON(raw, false, &docs)

		box.DeleteMany(ctx, bson.D{})      // повтор без задвоения
		box.InsertMany(ctx, docs)
		count, _ := box.CountDocuments(ctx, bson.D{})
		fmt.Println("документов в песочнице:", count)
	}
}
