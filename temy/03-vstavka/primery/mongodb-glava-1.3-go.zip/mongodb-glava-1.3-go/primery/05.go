//go:build ignore

// Глава 1.3 · Вставка: insert_one и insert_many
// Пример 5 из 6 · §6 Порядок вставки: ordered · загрузка с пропуском сбойных
//
// Запуск из папки архива:
//   docker compose run --rm go primery/05.go
//   cd primery, затем go run 05.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────

var bulkErr mongo.BulkWriteException

func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	products := db.Collection("products")
	orders := db.Collection("orders")
	box := client.Database("sandbox").Collection("products") // песочница: здесь можно менять
	_, _, _, _ = db, products, orders, box

	{
		// ── пример из главы ──────────────────────────────────────
		batch := []any{
		    bson.D{{Key: "_id", Value: "p-103"}, {Key: "title", Value: "Кабель HDMI 2 м"}, {Key: "category", Value: "аксессуары"}, {Key: "price", Value: 690}},
		    bson.D{{Key: "_id", Value: "p-101"}, {Key: "title", Value: "Подставка — повтор"}}, // такой _id уже есть
		    bson.D{{Key: "_id", Value: "p-104"}, {Key: "title", Value: "Салфетки для экрана"}, {Key: "category", Value: "аксессуары"}, {Key: "price", Value: 390}},
		}

		options := options.InsertMany().SetOrdered(false)

		_, err := box.InsertMany(ctx, batch, options)
		if errors.As(err, &bulkErr) {
		    fmt.Printf("не вставлено: %d из %d\n", len(bulkErr.WriteErrors), len(batch))
		}

		count, _ := box.CountDocuments(ctx, bson.D{})
		fmt.Println("документов в песочнице:", count)
	}
}
