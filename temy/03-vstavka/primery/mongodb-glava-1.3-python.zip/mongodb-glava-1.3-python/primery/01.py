# Глава 1.3 · Вставка: insert_one и insert_many
# Пример 1 из 6 · §1 Песочница: где мы работаем · подключение к песочнице
#
# Запуск из папки архива:
#   docker compose run --rm python primery/01.py
#   cd primery, затем python 01.py (Windows) или python3 01.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017/")
box = client["sandbox"]["products"]     # здесь можно ломать

print(box.count_documents({}))          # 21
