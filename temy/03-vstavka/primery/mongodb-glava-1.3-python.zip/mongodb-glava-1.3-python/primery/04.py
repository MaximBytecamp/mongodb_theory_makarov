# Глава 1.3 · Вставка: insert_one и insert_many
# Пример 4 из 6 · §5 Свой _id и его уникальность · повторный ключ
#
# Запуск из папки архива:
#   docker compose run --rm python primery/04.py
#   cd primery, затем python 04.py (Windows) или python3 04.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
from pymongo.errors import DuplicateKeyError

try:
    box.insert_one({"_id": "p-101", "title": "Ещё одна подставка"})
except DuplicateKeyError as error:
    print(type(error).__name__)
    print(error.details["errmsg"])
