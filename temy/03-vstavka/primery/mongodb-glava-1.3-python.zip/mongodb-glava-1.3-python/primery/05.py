# Глава 1.3 · Вставка: insert_one и insert_many
# Пример 5 из 6 · §6 Порядок вставки: ordered · загрузка с пропуском сбойных
#
# Запуск из папки архива:
#   docker compose run --rm python primery/05.py
#   cd primery, затем python 05.py (Windows) или python3 05.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
from pymongo.errors import BulkWriteError

batch = [
    {"_id": "p-103", "title": "Кабель HDMI 2 м", "category": "аксессуары", "price": 690},
    {"_id": "p-101", "title": "Подставка — повтор"},   # такой _id уже есть
    {"_id": "p-104", "title": "Салфетки для экрана", "category": "аксессуары", "price": 390},
]

try:
    box.insert_many(batch, ordered=False)
except BulkWriteError as error:
    failed = error.details["writeErrors"]
    print(f"не вставлено: {len(failed)} из {len(batch)}")

print("документов в песочнице:", box.count_documents({}))
