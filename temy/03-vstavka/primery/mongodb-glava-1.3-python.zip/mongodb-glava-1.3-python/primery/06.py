# Глава 1.3 · Вставка: insert_one и insert_many
# Пример 6 из 6 · §8 Загрузка файла целиком · тот же файл из кода
#
# Запуск из папки архива:
#   docker compose run --rm python primery/06.py
#   cd primery, затем python 06.py (Windows) или python3 06.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
from bson import json_util      # понимает {"$date": …} в файле

with open("../stend/seed/sandbox.products.json", encoding="utf-8") as handle:
    docs = json_util.loads(handle.read())

box.delete_many({})           # повтор без задвоения
box.insert_many(docs)
print("документов в песочнице:", box.count_documents({}))
