# Глава 1.3 · Вставка: insert_one и insert_many
# Пример 3 из 6 · §4 insert_many: пачка документов · вставка списка
#
# Запуск из папки архива:
#   docker compose run --rm python primery/03.py
#   cd primery, затем python 03.py (Windows) или python3 03.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
many = box.insert_many([
    {"_id": "p-101", "title": "Подставка для ноутбука",
     "category": "аксессуары", "price": 2490},
    {"_id": "p-102", "title": "Чехол для планшета",
     "category": "аксессуары", "price": 1890},
])

print("вставлено:", len(many.inserted_ids), "→", many.inserted_ids)
print("документов в песочнице:", box.count_documents({}))
