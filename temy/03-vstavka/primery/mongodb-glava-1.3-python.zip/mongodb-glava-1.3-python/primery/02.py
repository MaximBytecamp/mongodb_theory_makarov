# Глава 1.3 · Вставка: insert_one и insert_many
# Пример 2 из 6 · §3 Что возвращает вставка · разбор результата
# В начале — код из блока «вставка одного документа»: в главе он стоит прямо перед этим примером.
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
result = box.insert_one({
    "sku": "SKU-AC-022",
    "title": "Коврик для мыши XL",
    "brand": "OEM",
    "category": "аксессуары",
    "price": 1290,
})
print("подтверждено:", result.acknowledged)
print("присвоенный _id:", result.inserted_id)
print("тип:", type(result.inserted_id).__name__)
