// Глава 1.3 · Вставка: insert_one и insert_many
// Пример 6 из 6 · §8 Загрузка файла целиком · тот же файл из кода
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/06.cpp
//   cd primery, затем g++ -std=c++17 06.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto products = db["products"];
    auto orders = db["orders"];
    auto box = client["sandbox"]["products"];   // песочница: здесь можно менять

    {
        // ── пример из главы ──────────────────────────────────────
        std::ifstream file{"../stend/seed/sandbox.products.json"};
        std::stringstream buffer;
        buffer << file.rdbuf();

        auto array = bsoncxx::from_json(buffer.str());
        std::vector<bsoncxx::document::value> docs;
        for (const auto& item : array.view())
            docs.push_back(bsoncxx::document::value{item.get_document().value});

        box.delete_many(make_document());   // повтор без задвоения
        box.insert_many(docs);
        std::cout << "документов в песочнице: " << box.count_documents(make_document()) << std::endl;
    }
}
