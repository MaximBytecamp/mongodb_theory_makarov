// Глава 1.3 · Вставка: insert_one и insert_many
// Пример 5 из 6 · §6 Порядок вставки: ordered · загрузка с пропуском сбойных
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/05.cpp
//   cd primery, затем g++ -std=c++17 05.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto products = db["products"];
    auto orders = db["orders"];
    auto box = client["sandbox"]["products"];   // песочница: здесь можно менять

    {
        // ── пример из главы ──────────────────────────────────────
        std::vector<bsoncxx::document::value> batch;
        batch.push_back(make_document(kvp("_id", "p-103"), kvp("title", "Кабель HDMI 2 м"),
                                       kvp("category", "аксессуары"), kvp("price", 690)));
        batch.push_back(make_document(kvp("_id", "p-101"), kvp("title", "Подставка — повтор")));  // такой _id уже есть
        batch.push_back(make_document(kvp("_id", "p-104"), kvp("title", "Салфетки для экрана"),
                                       kvp("category", "аксессуары"), kvp("price", 390)));

        mongocxx::options::insert options;
        options.ordered(false);

        try {
            box.insert_many(batch, options);
        } catch (const mongocxx::bulk_write_exception& error) {
            std::cout << "часть документов не прошла: "
                      << error.what() << std::endl;
        }

        std::cout << "документов в песочнице: " << box.count_documents(make_document()) << std::endl;
    }
}
