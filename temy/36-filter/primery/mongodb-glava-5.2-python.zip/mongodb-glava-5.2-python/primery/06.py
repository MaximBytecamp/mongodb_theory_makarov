# Глава 5.2 · $filter: отбор элементов массива
# Пример 6 из 10 · §6 $filter внутри $match · $filter в $match и фильтр по массиву
#
# Запуск из папки архива:
#   docker compose run --rm python primery/06.py
#   cd primery, затем python 06.py (Windows) или python3 06.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
by_filter = [
    {"$match": {"$expr": {"$gt": [
        {"$size": {"$filter": {
            "input": "$items",
            "cond": {"$eq": ["$$this.category", "периферия"]},
        }}},
        0,
    ]}}},
    {"$count": "orders"},
]

by_path = [
    {"$match": {"items.category": "периферия"}},
    {"$count": "orders"},
]

by_filter_qty = [
    {"$match": {"$expr": {"$gt": [
        {"$size": {"$filter": {
            "input": "$items",
            "cond": {"$and": [
                {"$eq": ["$$this.category", "периферия"]},
                {"$gte": ["$$this.qty", 2]},
            ]},
        }}},
        0,
    ]}}},
    {"$count": "orders"},
]

by_elem = [
    {"$match": {"items": {"$elemMatch": {"category": "периферия", "qty": {"$gte": 2}}}}},
    {"$count": "orders"},
]

print("── $expr и $filter: есть периферия")
for doc in orders.aggregate(by_filter):
    print(doc)

print("── фильтр по items.category")
for doc in orders.aggregate(by_path):
    print(doc)

print("── $expr и $filter: периферия от 2 штук")
for doc in orders.aggregate(by_filter_qty):
    print(doc)

print("── $elemMatch: периферия от 2 штук")
for doc in orders.aggregate(by_elem):
    print(doc)
