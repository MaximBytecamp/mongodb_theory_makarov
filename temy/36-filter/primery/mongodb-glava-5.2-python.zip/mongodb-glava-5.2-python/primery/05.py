# Глава 5.2 · $filter: отбор элементов массива
# Пример 5 из 10 · §5 Число отобранных как ключ группы · заказы по числу позиций периферии
#
# Запуск из папки архива:
#   docker compose run --rm python primery/05.py
#   cd primery, затем python 05.py (Windows) или python3 05.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$group": {
        "_id": {"$size": {"$filter": {
            "input": "$items",
            "cond": {"$eq": ["$$this.category", "периферия"]},
        }}},
        "orders": {"$sum": 1},
    }},
    {"$sort": {"_id": 1}},
]

for doc in orders.aggregate(pipeline):
    print(doc)
