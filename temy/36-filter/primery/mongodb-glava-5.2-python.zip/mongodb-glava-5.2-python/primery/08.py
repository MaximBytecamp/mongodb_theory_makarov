# Глава 5.2 · $filter: отбор элементов массива
# Пример 8 из 10 · §8 Один знак $ вместо двух · $this вместо $$this
#
# Запуск из папки архива:
#   docker compose run --rm python primery/08.py
#   cd primery, затем python 08.py (Windows) или python3 08.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": "o-0002"}},
    {"$project": {
        "_id": 0,
        "wrong": {"$filter": {
            "input": "$items",
            "cond": {"$eq": ["$this.category", "периферия"]},
        }},
        "right": {"$size": {"$filter": {
            "input": "$items",
            "cond": {"$eq": ["$$this.category", "периферия"]},
        }}},
    }},
]

for doc in orders.aggregate(pipeline):
    print(doc)
