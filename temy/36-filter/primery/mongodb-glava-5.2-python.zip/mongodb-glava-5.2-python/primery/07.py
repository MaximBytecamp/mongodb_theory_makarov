# Глава 5.2 · $filter: отбор элементов массива
# Пример 7 из 10 · §7 Склады с остатком · склады с ненулевым остатком
#
# Запуск из папки архива:
#   docker compose run --rm python primery/07.py
#   cd primery, затем python 07.py (Windows) или python3 07.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$project": {
        "_id": 0,
        "title": 1,
        "stock": 1,
        "in_stock": {"$filter": {"input": "$stock", "cond": {"$gt": ["$$this.qty", 0]}}},
    }},
    {"$match": {"$expr": {"$lt": [{"$size": "$in_stock"}, {"$size": "$stock"}]}}},
]

for doc in products.aggregate(pipeline):
    print(doc)
