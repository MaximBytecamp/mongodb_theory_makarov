# Глава 5.2 · $filter: отбор элементов массива
# Пример 10 из 10 · §10 Параметры, которые сервер не принимает · параметры $filter, которые сервер не принимает
#
# Запуск из папки архива:
#   docker compose run --rm python primery/10.py
#   cd primery, затем python 10.py (Windows) или python3 10.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
from pymongo.errors import OperationFailure

string_input = [
    {"$match": {"_id": "o-0002"}},
    {"$project": {"x": {"$filter": {"input": "$promo", "cond": True}}}},
]

no_cond = [
    {"$match": {"_id": "o-0002"}},
    {"$project": {"x": {"$filter": {"input": "$items"}}}},
]

as_and_this = [
    {"$match": {"_id": "o-0002"}},
    {"$project": {"x": {"$filter": {
        "input": "$items",
        "as": "item",
        "cond": {"$eq": ["$$this.category", "периферия"]},
    }}}},
]

print("── input — строка")
try:
    for doc in orders.aggregate(string_input):
        print(doc)
except OperationFailure as e:
    print("код", e.code)
    print(e.details["errmsg"])

print("── нет cond")
try:
    for doc in orders.aggregate(no_cond):
        print(doc)
except OperationFailure as e:
    print("код", e.code)
    print(e.details["errmsg"])

print("── as задан, в условии $$this")
try:
    for doc in orders.aggregate(as_and_this):
        print(doc)
except OperationFailure as e:
    print("код", e.code)
    print(e.details["errmsg"])
