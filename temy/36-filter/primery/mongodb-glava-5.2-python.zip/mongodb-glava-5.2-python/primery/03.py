# Глава 5.2 · $filter: отбор элементов массива
# Пример 3 из 10 · §3 Несколько условий · $filter с двумя условиями
#
# Запуск из папки архива:
#   docker compose run --rm python primery/03.py
#   cd primery, затем python 03.py (Windows) или python3 03.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": "o-0004"}},
    {"$project": {
        "_id": 0,
        "number": 1,
        "cheap_many": {"$filter": {
            "input": "$items",
            "cond": {"$and": [
                {"$gte": ["$$this.qty", 2]},
                {"$lt": ["$$this.price", 10000]},
            ]},
        }},
    }},
]

for doc in orders.aggregate(pipeline):
    print(doc)
