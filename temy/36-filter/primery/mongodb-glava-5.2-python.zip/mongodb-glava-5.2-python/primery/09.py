# Глава 5.2 · $filter: отбор элементов массива
# Пример 9 из 10 · §9 Документ без массива · $filter по полю, которого нет
#
# Запуск из папки архива:
#   docker compose run --rm python primery/09.py
#   cd primery, затем python 09.py (Windows) или python3 09.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": "o-0002"}},
    {"$project": {
        "_id": 0,
        "gifts": {"$filter": {"input": "$gifts", "cond": True}},
        "gifts_or": {"$filter": {"input": {"$ifNull": ["$gifts", []]}, "cond": True}},
    }},
]

for doc in orders.aggregate(pipeline):
    print(doc)
