# Глава 5.2 · $filter: отбор элементов массива
# Пример 4 из 10 · §4 Первые подходящие: limit · $filter с limit
#
# Запуск из папки архива:
#   docker compose run --rm python primery/04.py
#   cd primery, затем python 04.py (Windows) или python3 04.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": "o-0004"}},
    {"$project": {
        "_id": 0,
        "number": 1,
        "first_periphery": {"$filter": {
            "input": "$items",
            "cond": {"$eq": ["$$this.category", "периферия"]},
            "limit": 1,
        }},
    }},
]

for doc in orders.aggregate(pipeline):
    print(doc)
