// Глава 5.2 · $filter: отбор элементов массива
// Пример 10 из 10 · §10 Параметры, которые сервер не принимает · параметры $filter, которые сервер не принимает
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/10.cpp
//   cd primery, затем g++ -std=c++17 10.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto orders = db["orders"];
    auto products = db["products"];
    auto customers = db["customers"];
    auto sandbox = client["sandbox"];

    {
        // ── пример из главы ──────────────────────────────────────
        mongocxx::pipeline string_input;
        string_input.match(make_document(kvp("_id", "o-0002")));
        string_input.project(make_document(
            kvp("x", make_document(kvp("$filter", make_document(kvp("input", "$promo"), kvp("cond", true)))))));

        mongocxx::pipeline no_cond;
        no_cond.match(make_document(kvp("_id", "o-0002")));
        no_cond.project(make_document(
            kvp("x", make_document(kvp("$filter", make_document(kvp("input", "$items")))))));

        mongocxx::pipeline as_and_this;
        as_and_this.match(make_document(kvp("_id", "o-0002")));
        as_and_this.project(make_document(
            kvp("x", make_document(
                kvp("$filter", make_document(
                    kvp("input", "$items"),
                    kvp("as", "item"),
                    kvp("cond", make_document(kvp("$eq", make_array("$$this.category", "периферия"))))))))));

        std::cout << "── input — строка" << std::endl;
        try {
            for (auto&& doc : orders.aggregate(string_input)) {
                std::cout << bsoncxx::to_json(doc) << std::endl;
            }
        } catch (const mongocxx::operation_exception& e) {
            std::cout << "код " << e.code().value() << std::endl;
            std::cout << e.what() << std::endl;
        }

        std::cout << "── нет cond" << std::endl;
        try {
            for (auto&& doc : orders.aggregate(no_cond)) {
                std::cout << bsoncxx::to_json(doc) << std::endl;
            }
        } catch (const mongocxx::operation_exception& e) {
            std::cout << "код " << e.code().value() << std::endl;
            std::cout << e.what() << std::endl;
        }

        std::cout << "── as задан, в условии $$this" << std::endl;
        try {
            for (auto&& doc : orders.aggregate(as_and_this)) {
                std::cout << bsoncxx::to_json(doc) << std::endl;
            }
        } catch (const mongocxx::operation_exception& e) {
            std::cout << "код " << e.code().value() << std::endl;
            std::cout << e.what() << std::endl;
        }
    }
}
