// Глава 5.2 · $filter: отбор элементов массива
// Пример 6 из 10 · §6 $filter внутри $match · $filter в $match и фильтр по массиву
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/06.cpp
//   cd primery, затем g++ -std=c++17 06.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto orders = db["orders"];
    auto products = db["products"];
    auto customers = db["customers"];
    auto sandbox = client["sandbox"];

    {
        // ── пример из главы ──────────────────────────────────────
        mongocxx::pipeline by_filter;
        by_filter.match(make_document(
            kvp("$expr", make_document(
                kvp("$gt", make_array(
                    make_document(
                        kvp("$size", make_document(
                            kvp("$filter", make_document(
                                kvp("input", "$items"),
                                kvp("cond", make_document(
                                    kvp("$eq", make_array("$$this.category", "периферия"))))))))),
                    0))))));
        by_filter.count("orders");

        mongocxx::pipeline by_path;
        by_path.match(make_document(kvp("items.category", "периферия")));
        by_path.count("orders");

        mongocxx::pipeline by_filter_qty;
        by_filter_qty.match(make_document(
            kvp("$expr", make_document(
                kvp("$gt", make_array(
                    make_document(
                        kvp("$size", make_document(
                            kvp("$filter", make_document(
                                kvp("input", "$items"),
                                kvp("cond", make_document(
                                    kvp("$and", make_array(
                                        make_document(
                                            kvp("$eq", make_array("$$this.category", "периферия"))),
                                        make_document(kvp("$gte", make_array("$$this.qty", 2)))))))))))),
                    0))))));
        by_filter_qty.count("orders");

        mongocxx::pipeline by_elem;
        by_elem.match(make_document(
            kvp("items", make_document(
                kvp("$elemMatch", make_document(
                    kvp("category", "периферия"),
                    kvp("qty", make_document(kvp("$gte", 2)))))))));
        by_elem.count("orders");

        std::cout << "── $expr и $filter: есть периферия" << std::endl;
        for (auto&& doc : orders.aggregate(by_filter)) {
            std::cout << bsoncxx::to_json(doc, bsoncxx::ExtendedJsonMode::k_relaxed) << std::endl;
        }

        std::cout << "── фильтр по items.category" << std::endl;
        for (auto&& doc : orders.aggregate(by_path)) {
            std::cout << bsoncxx::to_json(doc, bsoncxx::ExtendedJsonMode::k_relaxed) << std::endl;
        }

        std::cout << "── $expr и $filter: периферия от 2 штук" << std::endl;
        for (auto&& doc : orders.aggregate(by_filter_qty)) {
            std::cout << bsoncxx::to_json(doc, bsoncxx::ExtendedJsonMode::k_relaxed) << std::endl;
        }

        std::cout << "── $elemMatch: периферия от 2 штук" << std::endl;
        for (auto&& doc : orders.aggregate(by_elem)) {
            std::cout << bsoncxx::to_json(doc, bsoncxx::ExtendedJsonMode::k_relaxed) << std::endl;
        }
    }
}
