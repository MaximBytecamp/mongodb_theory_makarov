// Глава 5.2 · $filter: отбор элементов массива
// Пример 4 из 10 · §4 Первые подходящие: limit · $filter с limit
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/04.cpp
//   cd primery, затем g++ -std=c++17 04.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto orders = db["orders"];
    auto products = db["products"];
    auto customers = db["customers"];
    auto sandbox = client["sandbox"];

    {
        // ── пример из главы ──────────────────────────────────────
        mongocxx::pipeline pipeline;
        pipeline.match(make_document(kvp("_id", "o-0004")));
        pipeline.project(make_document(
            kvp("_id", 0),
            kvp("number", 1),
            kvp("first_periphery", make_document(
                kvp("$filter", make_document(
                    kvp("input", "$items"),
                    kvp("cond", make_document(kvp("$eq", make_array("$$this.category", "периферия")))),
                    kvp("limit", 1)))))));

        for (auto&& doc : orders.aggregate(pipeline)) {
            std::cout << bsoncxx::to_json(doc, bsoncxx::ExtendedJsonMode::k_relaxed) << std::endl;
        }
    }
}
