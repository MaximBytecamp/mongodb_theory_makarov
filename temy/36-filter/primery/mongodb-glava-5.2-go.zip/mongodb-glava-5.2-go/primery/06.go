//go:build ignore

// Глава 5.2 · $filter: отбор элементов массива
// Пример 6 из 10 · §6 $filter внутри $match · $filter в $match и фильтр по массиву
//
// Запуск из папки архива:
//   docker compose run --rm go primery/06.go
//   cd primery, затем go run 06.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	orders := db.Collection("orders")
	products := db.Collection("products")
	customers := db.Collection("customers")
	sandbox := client.Database("sandbox")
	_, _, _, _, _ = db, orders, products, customers, sandbox

	{
		// ── пример из главы ──────────────────────────────────────
		byFilter := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{
		        {Key: "$expr", Value: bson.D{
		            {Key: "$gt", Value: bson.A{
		                bson.D{
		                    {Key: "$size", Value: bson.D{
		                        {Key: "$filter", Value: bson.D{
		                            {Key: "input", Value: "$items"},
		                            {Key: "cond", Value: bson.D{
		                                {Key: "$eq", Value: bson.A{"$$this.category", "периферия"}}}}}}}}},
		                0}}}}}}},
		    {{Key: "$count", Value: "orders"}},
		}

		byPath := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{{Key: "items.category", Value: "периферия"}}}},
		    {{Key: "$count", Value: "orders"}},
		}

		byFilterQty := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{
		        {Key: "$expr", Value: bson.D{
		            {Key: "$gt", Value: bson.A{
		                bson.D{
		                    {Key: "$size", Value: bson.D{
		                        {Key: "$filter", Value: bson.D{
		                            {Key: "input", Value: "$items"},
		                            {Key: "cond", Value: bson.D{
		                                {Key: "$and", Value: bson.A{
		                                    bson.D{
		                                        {Key: "$eq", Value: bson.A{"$$this.category", "периферия"}}},
		                                    bson.D{{Key: "$gte", Value: bson.A{"$$this.qty", 2}}}}}}}}}}}},
		                0}}}}}}},
		    {{Key: "$count", Value: "orders"}},
		}

		byElem := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{
		        {Key: "items", Value: bson.D{
		            {Key: "$elemMatch", Value: bson.D{
		                {Key: "category", Value: "периферия"},
		                {Key: "qty", Value: bson.D{{Key: "$gte", Value: 2}}}}}}}}}},
		    {{Key: "$count", Value: "orders"}},
		}

		fmt.Println("── $expr и $filter: есть периферия")
		cursor, _ := orders.Aggregate(ctx, byFilter)
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}

		fmt.Println("── фильтр по items.category")
		cursor, _ = orders.Aggregate(ctx, byPath)
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}

		fmt.Println("── $expr и $filter: периферия от 2 штук")
		cursor, _ = orders.Aggregate(ctx, byFilterQty)
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}

		fmt.Println("── $elemMatch: периферия от 2 штук")
		cursor, _ = orders.Aggregate(ctx, byElem)
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}
	}
}
