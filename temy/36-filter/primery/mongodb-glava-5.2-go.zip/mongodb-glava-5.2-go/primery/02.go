//go:build ignore

// Глава 5.2 · $filter: отбор элементов массива
// Пример 2 из 10 · §2 Переменная $$this и длина отобранного · $$this и $size отобранного
//
// Запуск из папки архива:
//   docker compose run --rm go primery/02.go
//   cd primery, затем go run 02.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	orders := db.Collection("orders")
	products := db.Collection("products")
	customers := db.Collection("customers")
	sandbox := client.Database("sandbox")
	_, _, _, _, _ = db, orders, products, customers, sandbox

	{
		// ── пример из главы ──────────────────────────────────────
		pipeline := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{{Key: "_id", Value: "o-0004"}}}},
		    {{Key: "$project", Value: bson.D{
		        {Key: "_id", Value: 0},
		        {Key: "number", Value: 1},
		        {Key: "lines", Value: bson.D{{Key: "$size", Value: "$items"}}},
		        {Key: "periphery", Value: bson.D{
		            {Key: "$filter", Value: bson.D{
		                {Key: "input", Value: "$items"},
		                {Key: "cond", Value: bson.D{
		                    {Key: "$eq", Value: bson.A{"$$this.category", "периферия"}}}}}}}},
		        {Key: "periphery_lines", Value: bson.D{
		            {Key: "$size", Value: bson.D{
		                {Key: "$filter", Value: bson.D{
		                    {Key: "input", Value: "$items"},
		                    {Key: "cond", Value: bson.D{
		                        {Key: "$eq", Value: bson.A{"$$this.category", "периферия"}}}}}}}}}}}}},
		}

		cursor, _ := orders.Aggregate(ctx, pipeline)
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}
	}
}
