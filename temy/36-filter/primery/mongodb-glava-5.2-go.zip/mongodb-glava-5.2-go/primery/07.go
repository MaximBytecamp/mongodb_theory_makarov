//go:build ignore

// Глава 5.2 · $filter: отбор элементов массива
// Пример 7 из 10 · §7 Склады с остатком · склады с ненулевым остатком
//
// Запуск из папки архива:
//   docker compose run --rm go primery/07.go
//   cd primery, затем go run 07.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	orders := db.Collection("orders")
	products := db.Collection("products")
	customers := db.Collection("customers")
	sandbox := client.Database("sandbox")
	_, _, _, _, _ = db, orders, products, customers, sandbox

	{
		// ── пример из главы ──────────────────────────────────────
		pipeline := mongo.Pipeline{
		    {{Key: "$project", Value: bson.D{
		        {Key: "_id", Value: 0},
		        {Key: "title", Value: 1},
		        {Key: "stock", Value: 1},
		        {Key: "in_stock", Value: bson.D{
		            {Key: "$filter", Value: bson.D{
		                {Key: "input", Value: "$stock"},
		                {Key: "cond", Value: bson.D{{Key: "$gt", Value: bson.A{"$$this.qty", 0}}}}}}}}}}},
		    {{Key: "$match", Value: bson.D{
		        {Key: "$expr", Value: bson.D{
		            {Key: "$lt", Value: bson.A{
		                bson.D{{Key: "$size", Value: "$in_stock"}},
		                bson.D{{Key: "$size", Value: "$stock"}}}}}}}}},
		}

		cursor, _ := products.Aggregate(ctx, pipeline)
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}
	}
}
