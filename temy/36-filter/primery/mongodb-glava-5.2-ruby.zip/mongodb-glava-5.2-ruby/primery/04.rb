# Глава 5.2 · $filter: отбор элементов массива
# Пример 4 из 10 · §4 Первые подходящие: limit · $filter с limit
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/04.rb
#   cd primery, затем ruby 04.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => "o-0004" } },
  { "$project" => {
    "_id" => 0,
    "number" => 1,
    "first_periphery" => { "$filter" => {
      "input" => "$items",
      "cond" => { "$eq" => ["$$this.category", "периферия"] },
      "limit" => 1,
    } },
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
