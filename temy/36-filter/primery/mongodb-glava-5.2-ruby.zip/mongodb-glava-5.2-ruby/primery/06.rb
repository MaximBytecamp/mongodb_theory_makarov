# Глава 5.2 · $filter: отбор элементов массива
# Пример 6 из 10 · §6 $filter внутри $match · $filter в $match и фильтр по массиву
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/06.rb
#   cd primery, затем ruby 06.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
by_filter = [
  { "$match" => { "$expr" => { "$gt" => [
    { "$size" => { "$filter" => {
      "input" => "$items",
      "cond" => { "$eq" => ["$$this.category", "периферия"] },
    } } },
    0,
  ] } } },
  { "$count" => "orders" },
]

by_path = [
  { "$match" => { "items.category" => "периферия" } },
  { "$count" => "orders" },
]

by_filter_qty = [
  { "$match" => { "$expr" => { "$gt" => [
    { "$size" => { "$filter" => {
      "input" => "$items",
      "cond" => { "$and" => [
        { "$eq" => ["$$this.category", "периферия"] },
        { "$gte" => ["$$this.qty", 2] },
      ] },
    } } },
    0,
  ] } } },
  { "$count" => "orders" },
]

by_elem = [
  { "$match" => { "items" => { "$elemMatch" => {
    "category" => "периферия",
    "qty" => { "$gte" => 2 },
  } } } },
  { "$count" => "orders" },
]

puts "── $expr и $filter: есть периферия"
orders.aggregate(by_filter).each { |doc| puts doc.inspect }

puts "── фильтр по items.category"
orders.aggregate(by_path).each { |doc| puts doc.inspect }

puts "── $expr и $filter: периферия от 2 штук"
orders.aggregate(by_filter_qty).each { |doc| puts doc.inspect }

puts "── $elemMatch: периферия от 2 штук"
orders.aggregate(by_elem).each { |doc| puts doc.inspect }
