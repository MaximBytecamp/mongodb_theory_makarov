# Глава 5.2 · $filter: отбор элементов массива
# Пример 9 из 10 · §9 Документ без массива · $filter по полю, которого нет
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/09.rb
#   cd primery, затем ruby 09.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => "o-0002" } },
  { "$project" => {
    "_id" => 0,
    "gifts" => { "$filter" => { "input" => "$gifts", "cond" => true } },
    "gifts_or" => { "$filter" => {
      "input" => { "$ifNull" => ["$gifts", []] },
      "cond" => true,
    } },
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
