# Глава 5.2 · $filter: отбор элементов массива
# Пример 10 из 10 · §10 Параметры, которые сервер не принимает · параметры $filter, которые сервер не принимает
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/10.rb
#   cd primery, затем ruby 10.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
string_input = [
  { "$match" => { "_id" => "o-0002" } },
  { "$project" => { "x" => { "$filter" => { "input" => "$promo", "cond" => true } } } },
]

no_cond = [
  { "$match" => { "_id" => "o-0002" } },
  { "$project" => { "x" => { "$filter" => { "input" => "$items" } } } },
]

as_and_this = [
  { "$match" => { "_id" => "o-0002" } },
  { "$project" => { "x" => { "$filter" => {
    "input" => "$items",
    "as" => "item",
    "cond" => { "$eq" => ["$$this.category", "периферия"] },
  } } } },
]

puts "── input — строка"
begin
  orders.aggregate(string_input).each { |doc| puts doc.inspect }
rescue Mongo::Error::OperationFailure => e
  puts "код #{e.code}"
  puts e.document["errmsg"]
end

puts "── нет cond"
begin
  orders.aggregate(no_cond).each { |doc| puts doc.inspect }
rescue Mongo::Error::OperationFailure => e
  puts "код #{e.code}"
  puts e.document["errmsg"]
end

puts "── as задан, в условии $$this"
begin
  orders.aggregate(as_and_this).each { |doc| puts doc.inspect }
rescue Mongo::Error::OperationFailure => e
  puts "код #{e.code}"
  puts e.document["errmsg"]
end
