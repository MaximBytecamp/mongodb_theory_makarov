# Глава 5.2 · $filter: отбор элементов массива
# Пример 7 из 10 · §7 Склады с остатком · склады с ненулевым остатком
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/07.rb
#   cd primery, затем ruby 07.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$project" => {
    "_id" => 0,
    "title" => 1,
    "stock" => 1,
    "in_stock" => { "$filter" => {
      "input" => "$stock",
      "cond" => { "$gt" => ["$$this.qty", 0] },
    } },
  } },
  { "$match" => { "$expr" => { "$lt" => [
    { "$size" => "$in_stock" },
    { "$size" => "$stock" },
  ] } } },
]

products.aggregate(pipeline).each { |doc| puts doc.inspect }
