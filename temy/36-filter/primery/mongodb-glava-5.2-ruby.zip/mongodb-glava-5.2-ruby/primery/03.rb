# Глава 5.2 · $filter: отбор элементов массива
# Пример 3 из 10 · §3 Несколько условий · $filter с двумя условиями
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/03.rb
#   cd primery, затем ruby 03.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => "o-0004" } },
  { "$project" => {
    "_id" => 0,
    "number" => 1,
    "cheap_many" => { "$filter" => {
      "input" => "$items",
      "cond" => { "$and" => [
        { "$gte" => ["$$this.qty", 2] },
        { "$lt" => ["$$this.price", 10000] },
      ] },
    } },
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
