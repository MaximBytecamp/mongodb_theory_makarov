# Глава 5.2 · $filter: отбор элементов массива
# Пример 8 из 10 · §8 Один знак $ вместо двух · $this вместо $$this
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/08.rb
#   cd primery, затем ruby 08.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => "o-0002" } },
  { "$project" => {
    "_id" => 0,
    "wrong" => { "$filter" => {
      "input" => "$items",
      "cond" => { "$eq" => ["$this.category", "периферия"] },
    } },
    "right" => { "$size" => { "$filter" => {
      "input" => "$items",
      "cond" => { "$eq" => ["$$this.category", "периферия"] },
    } } },
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
