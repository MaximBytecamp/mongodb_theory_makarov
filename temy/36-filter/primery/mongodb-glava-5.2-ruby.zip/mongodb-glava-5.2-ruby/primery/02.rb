# Глава 5.2 · $filter: отбор элементов массива
# Пример 2 из 10 · §2 Переменная $$this и длина отобранного · $$this и $size отобранного
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/02.rb
#   cd primery, затем ruby 02.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => "o-0004" } },
  { "$project" => {
    "_id" => 0,
    "number" => 1,
    "lines" => { "$size" => "$items" },
    "periphery" => { "$filter" => {
      "input" => "$items",
      "cond" => { "$eq" => ["$$this.category", "периферия"] },
    } },
    "periphery_lines" => { "$size" => { "$filter" => {
      "input" => "$items",
      "cond" => { "$eq" => ["$$this.category", "периферия"] },
    } } },
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
