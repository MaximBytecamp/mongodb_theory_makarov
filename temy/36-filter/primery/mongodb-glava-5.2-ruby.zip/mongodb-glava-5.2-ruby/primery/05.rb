# Глава 5.2 · $filter: отбор элементов массива
# Пример 5 из 10 · §5 Число отобранных как ключ группы · заказы по числу позиций периферии
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/05.rb
#   cd primery, затем ruby 05.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$group" => {
    "_id" => { "$size" => { "$filter" => {
      "input" => "$items",
      "cond" => { "$eq" => ["$$this.category", "периферия"] },
    } } },
    "orders" => { "$sum" => 1 },
  } },
  { "$sort" => { "_id" => 1 } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
