//go:build ignore

// Глава 2.2 · Сравнение: $eq $ne $gt $gte $lt $lte
// Пример 5 из 8 · §4 Даты · собеседования за неделю
//
// Запуск из папки архива:
//   docker compose run --rm go primery/05.go
//   cd primery, затем go run 05.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"time"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = fmt.Sprint
var _ = time.Now
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("hh")
	resumes := db.Collection("resumes")
	vacancies := db.Collection("vacancies")
	companies := db.Collection("companies")
	interviews := db.Collection("interviews")
	box := client.Database("sandbox").Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, resumes, vacancies, companies, interviews, box

	{
		// ── пример из главы ──────────────────────────────────────
		sep21 := time.Date(2026, 9, 21, 0, 0, 0, 0, time.UTC)
		sep27 := time.Date(2026, 9, 27, 0, 0, 0, 0, time.UTC)
		sep28 := time.Date(2026, 9, 28, 0, 0, 0, 0, time.UTC)

		poluinterval, _ := interviews.CountDocuments(ctx, bson.D{{Key: "when", Value: bson.D{{Key: "$gte", Value: sep21}, {Key: "$lt", Value: sep28}}}})
		otrezok, _ := interviews.CountDocuments(ctx, bson.D{{Key: "when", Value: bson.D{{Key: "$gte", Value: sep21}, {Key: "$lte", Value: sep27}}}})

		fmt.Println("с 21.09 до 28.09 ($lt): ", poluinterval)
		fmt.Println("с 21.09 по 27.09 ($lte):", otrezok)
	}
}
