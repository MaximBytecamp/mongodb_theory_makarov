//go:build ignore

// Глава 2.2 · Сравнение: $eq $ne $gt $gte $lt $lte
// Пример 8 из 8 · §7 $eq: равенство, записанное явно · явное и неявное равенство
//
// Запуск из папки архива:
//   docker compose run --rm go primery/08.go
//   cd primery, затем go run 08.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"time"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = fmt.Sprint
var _ = time.Now
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("hh")
	resumes := db.Collection("resumes")
	vacancies := db.Collection("vacancies")
	companies := db.Collection("companies")
	interviews := db.Collection("interviews")
	box := client.Database("sandbox").Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, resumes, vacancies, companies, interviews, box

	{
		// ── пример из главы ──────────────────────────────────────
		neyavno, _ := resumes.CountDocuments(ctx, bson.D{{Key: "city", Value: "Москва"}})
		yavno, _ := resumes.CountDocuments(ctx, bson.D{{Key: "city", Value: bson.D{{Key: "$eq", Value: "Москва"}}}})
		operator, _ := resumes.CountDocuments(ctx, bson.D{{Key: "fio", Value: bson.D{{Key: "$ne", Value: nil}}}})
		bukvalno, _ := resumes.CountDocuments(ctx, bson.D{{Key: "fio", Value: bson.D{{Key: "$eq", Value: bson.D{{Key: "$ne", Value: nil}}}}}})

		fmt.Println("город Москва:       ", neyavno)
		fmt.Println("город $eq Москва:   ", yavno)
		fmt.Println("fio {$ne: null}:    ", operator)
		fmt.Println("fio $eq {$ne: null}:", bukvalno)
	}
}
