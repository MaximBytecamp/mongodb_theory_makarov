# Глава 2.2 · Сравнение: $eq $ne $gt $gte $lt $lte — примеры на Python

Архив к «Справочнику по MongoDB»: все примеры главы готовыми программами, учебные базы и стенд в Docker.
Глава: https://maximbytecamp.github.io/mongodb_theory_makarov/temy/10-sravnenie/index.html

Язык: **Python** · драйвер PyMongo · сервер MongoDB 7.

## Что в архиве

```text
mongodb-glava-2.2-python/
  README.md         эта инструкция
  primery/          примеры главы — по программе на пример
    01.py … 08.py
  compose.yaml      стенд в Docker: сервер, базы, mongo-express, Python
  docker/           образ с драйвером Python и скрипт запуска run.sh
  stend/seed/       учебные данные: 12 файлов JSON
  stend/load.ps1    загрузка данных на установленный сервер — Windows
  stend/load.sh     то же — macOS и Linux
requirements.txt  драйвер PyMongo для pip и для образа Docker
```

## Порядок работы

1. **Базы.** Глава **только читает** данные — сбрасывать базы не нужно.
2. **Примеры — по порядку, каждый один раз.** Пример в главе рассчитан на данные, которые оставил
   предыдущий. Если запустить пример дважды или пропустить, числа разойдутся с книгой — тогда
   сбросьте базы и начните с `01.py`.
3. **Сверка.** Что должна напечатать каждая программа — в разделе «Примеры и выводы» ниже.
   Отличаться могут только `_id`, которые выдаёт сервер, текущие дата и время и порядок
   в списке коллекций: сервер отдаёт их имена в произвольном порядке. У документа, который
   создан обновлением с `upsert`, поля тоже могут идти в другом порядке — значения при этом те же.

Подойдёт любой из двух способов. Адрес сервера в обоих — `mongodb://localhost:27017`, код примеров
одинаковый.

| Способ | Что нужно | Когда подходит |
|---|---|---|
| **1. Docker** | Docker Desktop | Compass и сервер не установились или не подключаются; ничего, кроме Docker, ставить не нужно |
| **2. Сервер и Compass** | MongoDB Server, Compass, Python с драйвером | сервер и Compass уже стоят и подключаются |

## Способ 1. Docker

Docker Desktop — с [docker.com](https://www.docker.com/products/docker-desktop/); на Linux — Docker Engine.
Перед командами Docker Desktop должен быть запущен. Команды одинаковые в PowerShell, cmd и терминале
macOS/Linux; выполняйте их **из папки архива** — там, где лежит `compose.yaml`.

1. Поднять сервер и загрузить учебные базы:

   ```bash
   docker compose up -d
   ```

2. Запустить пример — путь к файлу пишется от папки архива:

   ```bash
   docker compose run --rm python primery/01.py
   ```

   При первом запуске Docker соберёт образ с драйвером Python — это пара минут.
   Дальше запуск идёт за секунды.

3. Все примеры главы подряд, по порядку, одной командой:

   ```bash
   docker compose run --rm python primery
   ```

   Перед каждой программой печатается её имя: `── primery/01.py ──`.

**Смотреть данные.** Compass не нужен: в браузере откройте http://localhost:8081, логин `student`,
пароль `student` — это mongo-express, в нём видны базы, коллекции и документы. Если Compass
установлен, он подключается к этому же серверу по адресу `mongodb://localhost:27017`.

**Консоль сервера:** `docker compose exec mongo mongosh`.

**Остановить и удалить:**

```bash
docker compose stop        # остановить; данные останутся
docker compose down        # удалить контейнеры; данные останутся
docker compose down -v     # удалить всё вместе с данными
```

Архивы всех глав пользуются одним и тем же сервером и данными: после этой главы можно распаковать
архив следующей и работать там, не удаляя стенд.

## Способ 2. Установленный сервер MongoDB и Compass

Нужны MongoDB Server 7 или 8 и MongoDB Compass — установка по шагам в
[главе 1.0а](https://maximbytecamp.github.io/mongodb_theory_makarov/temy/00a-windows-10-mongodb-7/index.html).
Проверка: Compass подключается к `mongodb://localhost:27017`.

### Шаг 1. Загрузить учебные базы

Windows, PowerShell, из папки архива — нужен `mongoimport` из MongoDB Command Line Database Tools:

```powershell
powershell -ExecutionPolicy Bypass -File stend\load.ps1
```

macOS и Linux (`mongoimport`: `brew tap mongodb/brew && brew install mongodb-database-tools`):

```bash
bash stend/load.sh
```

Скрипт пересоздаёт коллекции целиком, поэтому он же сбрасывает базы: повторный запуск ничего не двоит.

**Без `mongoimport` — через Compass.** Подключитесь к `mongodb://localhost:27017`, нажмите **Create database**,
затем в коллекции **Add data → Import JSON or CSV file** и выберите файл из `stend/seed`. Имя файла
подсказывает, куда класть: `shop.orders.json` — база `shop`, коллекция `orders`. Так загружаются все
12 файлов; пошагово с кадрами — [глава 1.0, §7](https://maximbytecamp.github.io/mongodb_theory_makarov/temy/00-uchebnye-bazy/index.html#s7).

После загрузки в Compass нажмите **Refresh**: в списке должны быть базы `shop`, `hh`, `logs`, `org`
и `sandbox`. В `shop.products` — 21 документ, в `shop.orders` — 120.

### Шаг 2. Драйвер Python и запуск

Python 3.10 или новее — с [python.org](https://www.python.org/downloads/). На Windows в установщике
отметьте **Add python.exe to PATH**.

Windows, PowerShell, из папки архива:

```powershell
python -m pip install -r requirements.txt
cd primery
python 01.py
```

macOS и Linux — драйвер ставится в виртуальное окружение: системный Python не даёт ставить пакеты напрямую.

```bash
python3 -m venv .venv
source .venv/bin/activate          # в каждом новом терминале снова
pip install -r requirements.txt
cd primery
python3 01.py
```

Если `venv` не найден на Linux: `sudo apt install python3-venv`.

Остальные примеры запускаются так же: `02.py`, `03.py` и далее. Если сервер слушает другой адрес,
задайте его переменной `MONGO_URI` — программы глав 1.2–1.8 читают её при подключении.

## Примеры и выводы

| Файл | Параграф главы | Что делает |
|---|---|---|
| `01.py` | §1 Оператор в фильтре | компании от 500 сотрудников |
| `02.py` | §2 $eq: равенство, записанное явно | явное и неявное равенство |
| `03.py` | §3 Диапазон на одном поле | зарплата от 70 до 100 тысяч |
| `04.py` | §4 Сравнение вложенных полей | вилка, в которую попадает 120 000 |
| `05.py` | §5 Даты | дата и строка с датой |
| `06.py` | §5 Даты | собеседования за неделю |
| `07.py` | §6 Строки | названия раньше кириллической «А» |
| `08.py` | §7 $ne и отсутствующее поле | не равно и отсутствующее поле |

### 01.py · §1 Оператор в фильтре

Компании от 500 сотрудников.

```text
{'name': 'Мосэнергосвязь', 'employees': 900}
{'name': 'Яндекс', 'employees': 25000}
{'name': 'Тензор', 'employees': 4200}
{'name': 'Ozon Tech', 'employees': 11000}
```

### 02.py · §2 $eq: равенство, записанное явно

Явное и неявное равенство.

```text
город Москва:        1
город $eq Москва:    1
fio {$ne: null}:     9
fio $eq {$ne: null}: 0
```

### 03.py · §3 Диапазон на одном поле

Зарплата от 70 до 100 тысяч.

```text
$gte 70000 и $lte 100000: 4
$gt 70000 и $lte 100000:  3
{'fio': 'Пётр Ковалёв', 'salary': 70000}
{'fio': 'Марк Ефремов', 'salary': 75000}
{'fio': 'Дарья Нечаева', 'salary': 80000}
{'fio': 'Ксения Лапина', 'salary': 90000}
```

### 04.py · §4 Сравнение вложенных полей

Вилка, в которую попадает 120 000.

```text
{'title': 'Backend-разработчик .NET', 'salary': {'from': 100000, 'to': 150000}}
{'title': 'Frontend-разработчик', 'salary': {'from': 90000, 'to': 140000}}
{'title': 'Инженер сопровождения БД', 'salary': {'from': 80000, 'to': 120000}}
{'title': 'Администратор баз данных', 'salary': {'from': 110000, 'to': 160000}}
{'title': 'Аналитик данных', 'salary': {'from': 120000, 'to': 180000}}
```

### 05.py · §5 Даты

Дата и строка с датой.

```text
updated $gte дата:   5
updated $gte строка: 0
```

### 06.py · §5 Даты

Собеседования за неделю.

```text
с 21.09 до 28.09 ($lt):  22
с 21.09 по 27.09 ($lte): 18
```

### 07.py · §6 Строки

Названия раньше кириллической «А».

```text
{'name': 'Retail Lab'}
{'name': 'Ozon Tech'}
```

### 08.py · §7 $ne и отсутствующее поле

Не равно и отсутствующее поле.

```text
ready_to_move $ne true: 5
ready_to_move false:    4
ready_to_move $lt true: 4
{'fio': 'Анна Белова'}
{'fio': 'Пётр Ковалёв', 'ready_to_move': False}
{'fio': 'Игорь Самойлов', 'ready_to_move': False}
{'fio': 'Тимур Валиев', 'ready_to_move': False}
{'fio': 'Ольга Пирогова', 'ready_to_move': False}
```

## Частые ошибки

| Что видно | Причина | Что сделать |
|---|---|---|
| `port is already allocated`, `address already in use` на `docker compose up -d` | порт 27017 занят: уже работает установленный MongoDB или стенд `mongodb-practice` | остановите тот сервер или создайте рядом с `compose.yaml` файл `.env` со строкой `MONGO_PORT=27018`: в PowerShell — `Set-Content .env "MONGO_PORT=27018"`, в bash — `echo "MONGO_PORT=27018" > .env`. Программы в Docker это не затрагивает, Compass подключайте к `localhost:27018` |
| `Cannot connect to the Docker daemon`, `error during connect` | Docker Desktop не запущен | запустите Docker Desktop и дождитесь зелёного статуса Engine running |
| `ServerSelectionTimeoutError`, `Connection refused`, `No server available` | сервер не запущен | Docker: `docker compose up -d`; способ 2 — запустите службу MongoDB |
| `Файл не найден: …` | путь написан не от папки архива или команда выполнена в другой папке | перейдите в папку, где лежит `compose.yaml`, и пишите путь `primery/01.py` |
| числа в выводе не совпадают с README | пример запускали дважды, пропустили или базы не сброшены | сбросьте базы и запустите примеры с первого по порядку |

В PowerShell не используйте `echo … > .env`: Windows PowerShell 5 пишет такой файл в UTF-16, и Docker
Compose его не прочитает.
