# Глава 2.2 · Сравнение: $eq $ne $gt $gte $lt $lte
# Пример 3 из 8 · §3 Сравнение вложенных полей · вилка, в которую попадает 120 000
#
# Запуск из папки архива:
#   docker compose run --rm python primery/03.py
#   cd primery, затем python 03.py (Windows) или python3 03.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
filtr = {"salary.from": {"$lte": 120000},
         "salary.to": {"$gte": 120000}}

for doc in vacancies.find(filtr, {"_id": 0, "title": 1, "salary": 1}):
    print(doc)
