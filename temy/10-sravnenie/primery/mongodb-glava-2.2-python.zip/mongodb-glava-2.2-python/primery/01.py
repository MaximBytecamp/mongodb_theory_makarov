# Глава 2.2 · Сравнение: $eq $ne $gt $gte $lt $lte
# Пример 1 из 8 · §1 Оператор в фильтре · компании от 500 сотрудников
#
# Запуск из папки архива:
#   docker compose run --rm python primery/01.py
#   cd primery, затем python 01.py (Windows) или python3 01.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
for doc in companies.find({"employees": {"$gte": 500}}, {"_id": 0, "name": 1, "employees": 1}):
    print(doc)
