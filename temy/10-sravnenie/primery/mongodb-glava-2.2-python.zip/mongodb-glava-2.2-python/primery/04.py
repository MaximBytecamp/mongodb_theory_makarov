# Глава 2.2 · Сравнение: $eq $ne $gt $gte $lt $lte
# Пример 4 из 8 · §4 Даты · дата и строка с датой
#
# Запуск из папки архива:
#   docker compose run --rm python primery/04.py
#   cd primery, затем python 04.py (Windows) или python3 04.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
from datetime import datetime

sep01 = datetime(2026, 9, 1)

print("updated $gte дата:  ", resumes.count_documents({"updated": {"$gte": sep01}}))
print("updated $gte строка:", resumes.count_documents({"updated": {"$gte": "2026-09-01"}}))
