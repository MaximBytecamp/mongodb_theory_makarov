# Глава 2.2 · Сравнение: $eq $ne $gt $gte $lt $lte
# Пример 2 из 8 · §2 Диапазон на одном поле · зарплата от 70 до 100 тысяч
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
print("$gte 70000 и $lte 100000:", resumes.count_documents({"salary": {"$gte": 70000, "$lte": 100000}}))
print("$gt 70000 и $lte 100000: ", resumes.count_documents({"salary": {"$gt": 70000, "$lte": 100000}}))

for doc in resumes.find({"salary": {"$gte": 70000, "$lte": 100000}}, {"_id": 0, "fio": 1, "salary": 1}).sort("salary", 1):
    print(doc)
