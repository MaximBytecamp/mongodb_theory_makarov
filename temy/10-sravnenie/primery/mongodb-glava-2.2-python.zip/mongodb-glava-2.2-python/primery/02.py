# Глава 2.2 · Сравнение: $eq $ne $gt $gte $lt $lte
# Пример 2 из 8 · §2 $eq: равенство, записанное явно · явное и неявное равенство
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
print("город Москва:       ", resumes.count_documents({"city": "Москва"}))
print("город $eq Москва:   ", resumes.count_documents({"city": {"$eq": "Москва"}}))
print("fio {$ne: null}:    ", resumes.count_documents({"fio": {"$ne": None}}))
print("fio $eq {$ne: null}:", resumes.count_documents({"fio": {"$eq": {"$ne": None}}}))
