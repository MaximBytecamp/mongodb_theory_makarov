# Глава 2.2 · Сравнение: $eq $ne $gt $gte $lt $lte
# Пример 6 из 8 · §5 Даты · собеседования за неделю
#
# Запуск из папки архива:
#   docker compose run --rm python primery/06.py
#   cd primery, затем python 06.py (Windows) или python3 06.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
from datetime import datetime

sep21 = datetime(2026, 9, 21)
sep27 = datetime(2026, 9, 27)
sep28 = datetime(2026, 9, 28)

print("с 21.09 до 28.09 ($lt): ", interviews.count_documents({"when": {"$gte": sep21, "$lt": sep28}}))
print("с 21.09 по 27.09 ($lte):", interviews.count_documents({"when": {"$gte": sep21, "$lte": sep27}}))
