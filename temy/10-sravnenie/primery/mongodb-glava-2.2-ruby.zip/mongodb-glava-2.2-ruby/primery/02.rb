# Глава 2.2 · Сравнение: $eq $ne $gt $gte $lt $lte
# Пример 2 из 8 · §2 $eq: равенство, записанное явно · явное и неявное равенство
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/02.rb
#   cd primery, затем ruby 02.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
puts "город Москва:        " + resumes.count_documents({ "city" => "Москва" }).to_s
puts "город $eq Москва:    " + resumes.count_documents({ "city" => { "$eq" => "Москва" } }).to_s
puts "fio {$ne: null}:     " + resumes.count_documents({ "fio" => { "$ne" => nil } }).to_s
puts "fio $eq {$ne: null}: " + resumes.count_documents({ "fio" => { "$eq" => { "$ne" => nil } } }).to_s
