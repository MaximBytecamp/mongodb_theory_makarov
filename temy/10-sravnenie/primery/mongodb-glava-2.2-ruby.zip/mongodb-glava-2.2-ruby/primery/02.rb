# Глава 2.2 · Сравнение: $eq $ne $gt $gte $lt $lte
# Пример 2 из 8 · §2 Диапазон на одном поле · зарплата от 70 до 100 тысяч
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/02.rb
#   cd primery, затем ruby 02.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
puts "$gte 70000 и $lte 100000: " + resumes.count_documents({ "salary" => { "$gte" => 70000, "$lte" => 100000 } }).to_s
puts "$gt 70000 и $lte 100000:  " + resumes.count_documents({ "salary" => { "$gt" => 70000, "$lte" => 100000 } }).to_s

resumes.find({ "salary" => { "$gte" => 70000, "$lte" => 100000 } }, projection: { "_id" => 0, "fio" => 1, "salary" => 1 })
       .sort({ "salary" => 1 })
       .each { |doc| puts doc.inspect }
