# Глава 2.2 · Сравнение: $eq $ne $gt $gte $lt $lte
# Пример 3 из 8 · §3 Сравнение вложенных полей · вилка, в которую попадает 120 000
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/03.rb
#   cd primery, затем ruby 03.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
filtr = { "salary.from" => { "$lte" => 120000 },
          "salary.to" => { "$gte" => 120000 } }

vacancies.find(filtr, projection: { "_id" => 0, "title" => 1, "salary" => 1 })
         .each { |doc| puts doc.inspect }
