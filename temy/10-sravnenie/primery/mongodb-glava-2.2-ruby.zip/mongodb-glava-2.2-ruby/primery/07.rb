# Глава 2.2 · Сравнение: $eq $ne $gt $gte $lt $lte
# Пример 7 из 8 · §6 Строки · названия раньше кириллической «А»
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/07.rb
#   cd primery, затем ruby 07.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
companies.find({ "name" => { "$lt" => "А" } }, projection: { "_id" => 0, "name" => 1 })
         .each { |doc| puts doc.inspect }
