# Глава 2.2 · Сравнение: $eq $ne $gt $gte $lt $lte
# Пример 5 из 8 · §4 Даты · собеседования за неделю
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/05.rb
#   cd primery, затем ruby 05.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
sep21 = Time.utc(2026, 9, 21)
sep27 = Time.utc(2026, 9, 27)
sep28 = Time.utc(2026, 9, 28)

puts "с 21.09 до 28.09 ($lt):  " + interviews.count_documents({ "when" => { "$gte" => sep21, "$lt" => sep28 } }).to_s
puts "с 21.09 по 27.09 ($lte): " + interviews.count_documents({ "when" => { "$gte" => sep21, "$lte" => sep27 } }).to_s
