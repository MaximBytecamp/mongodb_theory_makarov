# Глава 2.2 · Сравнение: $eq $ne $gt $gte $lt $lte
# Пример 5 из 8 · §5 Даты · дата и строка с датой
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/05.rb
#   cd primery, затем ruby 05.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
sep01 = Time.utc(2026, 9, 1)

puts "updated $gte дата:   " + resumes.count_documents({ "updated" => { "$gte" => sep01 } }).to_s
puts "updated $gte строка: " + resumes.count_documents({ "updated" => { "$gte" => "2026-09-01" } }).to_s
