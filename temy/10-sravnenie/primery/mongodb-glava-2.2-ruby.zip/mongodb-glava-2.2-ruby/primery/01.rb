# Глава 2.2 · Сравнение: $eq $ne $gt $gte $lt $lte
# Пример 1 из 8 · §1 Оператор в фильтре · компании от 500 сотрудников
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/01.rb
#   cd primery, затем ruby 01.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
companies.find({ "employees" => { "$gte" => 500 } }, projection: { "_id" => 0, "name" => 1, "employees" => 1 })
         .each { |doc| puts doc.inspect }
