# Глава 1.5 · Проекция: какие поля вернуть
# Пример 5 из 5 · §6 Вложенные поля в проекции · город доставки и сумма
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/05.rb
#   cd primery, затем ruby 05.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
orders.find(
  { "status" => "доставлен" },
  projection: { "_id" => 0, "number" => 1,
                "total" => 1, "delivery.city" => 1 }
).first(3).each { |doc| puts doc.inspect }
