# Глава 1.5 · Проекция: какие поля вернуть
# Пример 4 из 5 · §5 Смешивать нельзя · Ruby
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/04.rb
#   cd primery, затем ruby 04.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
products.find({}, projection: { "title" => 1, "stock" => 0 }).first
