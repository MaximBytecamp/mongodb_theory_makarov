# Глава 1.5 · Проекция: какие поля вернуть
# Пример 2 из 5 · §3 Как убрать _id · без ключа
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/02.rb
#   cd primery, затем ruby 02.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
products.find(
  { "category" => "ноутбуки" },
  projection: { "_id" => 0, "title" => 1, "price" => 1 }
).first(2).each { |doc| puts doc.inspect }
