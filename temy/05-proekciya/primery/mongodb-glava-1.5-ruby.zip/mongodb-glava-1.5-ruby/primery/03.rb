# Глава 1.5 · Проекция: какие поля вернуть
# Пример 3 из 5 · §4 Исключающая проекция · всё, кроме трёх полей
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/03.rb
#   cd primery, затем ruby 03.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
doc = products.find(
  { "_id" => "p-020" },
  projection: { "stock" => 0, "specs" => 0, "added" => 0 }
).first
puts doc.inspect
