# Глава 1.5 · Проекция: какие поля вернуть
# Пример 1 из 5 · §2 Включающая проекция · только название и цена
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/01.rb
#   cd primery, затем ruby 01.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
products.find(
  { "category" => "ноутбуки" },
  projection: { "title" => 1, "price" => 1 }
).each { |doc| puts doc.inspect }
