//go:build ignore

// Глава 1.5 · Проекция: какие поля вернуть
// Пример 5 из 5 · §6 Вложенные поля в проекции · город доставки и сумма
//
// Запуск из папки архива:
//   docker compose run --rm go primery/05.go
//   cd primery, затем go run 05.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────

// Product — поля товара, которые читают примеры. Тип объявлен в главе 1.4.
type Product struct {
	ID       string `bson:"_id"`
	SKU      string `bson:"sku"`
	Title    string `bson:"title"`
	Category string `bson:"category"`
	Price    int    `bson:"price"`
}

var rows []bson.D

func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	products := db.Collection("products")
	orders := db.Collection("orders")
	box := client.Database("sandbox").Collection("products") // песочница: здесь можно менять
	_, _, _, _ = db, products, orders, box

	{
		// ── пример из главы ──────────────────────────────────────
		cursor, _ := orders.Find(ctx,
		    bson.D{{Key: "status", Value: "доставлен"}},
		    options.Find().SetProjection(bson.D{
		        {Key: "_id", Value: 0}, {Key: "number", Value: 1},
		        {Key: "total", Value: 1}, {Key: "delivery.city", Value: 1}}).SetLimit(3))

		cursor.All(ctx, &rows)
		for _, doc := range rows {
		    fmt.Println(doc)
		}
	}
}
