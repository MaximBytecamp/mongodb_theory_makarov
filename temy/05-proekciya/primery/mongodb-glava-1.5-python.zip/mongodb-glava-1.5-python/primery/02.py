# Глава 1.5 · Проекция: какие поля вернуть
# Пример 2 из 5 · §3 Как убрать _id · без ключа
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
for doc in products.find(
        {"category": "ноутбуки"},
        {"_id": 0, "title": 1, "price": 1}).limit(2):
    print(doc)
