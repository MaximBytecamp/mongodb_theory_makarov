# Глава 1.5 · Проекция: какие поля вернуть
# Пример 3 из 5 · §4 Исключающая проекция · всё, кроме трёх полей
#
# Запуск из папки архива:
#   docker compose run --rm python primery/03.py
#   cd primery, затем python 03.py (Windows) или python3 03.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
doc = products.find_one(
    {"_id": "p-020"},
    {"stock": 0, "specs": 0, "added": 0})
print(doc)
