# Глава 1.5 · Проекция: какие поля вернуть
# Пример 5 из 5 · §6 Вложенные поля в проекции · город доставки и сумма
#
# Запуск из папки архива:
#   docker compose run --rm python primery/05.py
#   cd primery, затем python 05.py (Windows) или python3 05.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
for doc in orders.find(
        {"status": "доставлен"},
        {"_id": 0, "number": 1, "total": 1, "delivery.city": 1}).limit(3):
    print(doc)
