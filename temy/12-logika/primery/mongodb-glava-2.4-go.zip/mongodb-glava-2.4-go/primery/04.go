//go:build ignore

// Глава 2.4 · Логика: $and $or $not $nor
// Пример 4 из 6 · §4 $and: «и», записанное явно · два условия «или» сразу
//
// Запуск из папки архива:
//   docker compose run --rm go primery/04.go
//   cd primery, затем go run 04.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"time"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = fmt.Sprint
var _ = time.Now
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("hh")
	resumes := db.Collection("resumes")
	vacancies := db.Collection("vacancies")
	companies := db.Collection("companies")
	interviews := db.Collection("interviews")
	box := client.Database("sandbox").Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, resumes, vacancies, companies, interviews, box

	{
		// ── пример из главы ──────────────────────────────────────
		dostupen := bson.D{{Key: "$or", Value: bson.A{
		    bson.D{{Key: "city", Value: "Ярославль"}},
		    bson.D{{Key: "ready_to_move", Value: true}}}}}
		kvalif := bson.D{{Key: "$or", Value: bson.A{
		    bson.D{{Key: "education.level", Value: "Высшее"}},
		    bson.D{{Key: "experience.months", Value: bson.D{{Key: "$gte", Value: 10}}}}}}}

		nDostupen, _ := resumes.CountDocuments(ctx, dostupen)
		nKvalif, _ := resumes.CountDocuments(ctx, kvalif)

		fmt.Println("доступен для Ярославля:", nDostupen)
		fmt.Println("есть квалификация:     ", nKvalif)

		cursor, _ := resumes.Find(ctx, bson.D{{Key: "$and", Value: bson.A{dostupen, kvalif}}},
		    options.Find().SetProjection(bson.D{{Key: "_id", Value: 0}, {Key: "fio", Value: 1}}))
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}
	}
}
