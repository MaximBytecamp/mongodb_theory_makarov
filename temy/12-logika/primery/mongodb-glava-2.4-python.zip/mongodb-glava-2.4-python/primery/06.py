# Глава 2.4 · Логика: $and $or $not $nor
# Пример 6 из 6 · §6 $nor: ни одно из условий · ни одно из условий
#
# Запуск из папки архива:
#   docker compose run --rm python primery/06.py
#   cd primery, затем python 06.py (Windows) или python3 06.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
filtr = {"$nor": [{"city": "Москва"}, {"ready_to_move": True}]}

for doc in resumes.find(filtr, {"_id": 0, "fio": 1, "city": 1, "ready_to_move": 1}):
    print(doc)
