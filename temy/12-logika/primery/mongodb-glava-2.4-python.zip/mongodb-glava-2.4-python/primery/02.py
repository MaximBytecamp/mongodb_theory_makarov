# Глава 2.4 · Логика: $and $or $not $nor
# Пример 2 из 6 · §2 $or на одном поле и $in · $or на одном поле и $in
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
print("$or:", vacancies.count_documents({"$or": [{"city": "Москва"}, {"city": "Казань"}]}))
print("$in:", vacancies.count_documents({"city": {"$in": ["Москва", "Казань"]}}))
