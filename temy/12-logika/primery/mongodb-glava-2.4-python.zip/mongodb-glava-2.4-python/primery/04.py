# Глава 2.4 · Логика: $and $or $not $nor
# Пример 4 из 6 · §4 $and: «и», записанное явно · два условия «или» сразу
#
# Запуск из папки архива:
#   docker compose run --rm python primery/04.py
#   cd primery, затем python 04.py (Windows) или python3 04.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
dostupen = {"$or": [{"city": "Ярославль"}, {"ready_to_move": True}]}
kvalif = {"$or": [{"education.level": "Высшее"}, {"experience.months": {"$gte": 10}}]}

print("доступен для Ярославля:", resumes.count_documents(dostupen))
print("есть квалификация:     ", resumes.count_documents(kvalif))

for doc in resumes.find({"$and": [dostupen, kvalif]}, {"_id": 0, "fio": 1}):
    print(doc)
