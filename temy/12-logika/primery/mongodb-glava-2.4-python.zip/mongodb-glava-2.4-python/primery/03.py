# Глава 2.4 · Логика: $and $or $not $nor
# Пример 3 из 6 · §3 «И» вместе с «или» · условие на зарплату и «или»
#
# Запуск из папки архива:
#   docker compose run --rm python primery/03.py
#   cd primery, затем python 03.py (Windows) или python3 03.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
filtr = {"salary": {"$lte": 90000},
         "$or": [{"city": "Ярославль"},
                 {"ready_to_move": True}]}

for doc in resumes.find(filtr, {"_id": 0, "fio": 1, "salary": 1, "city": 1, "ready_to_move": 1}):
    print(doc)
