# Глава 2.4 · Логика: $and $or $not $nor
# Пример 1 из 6 · §1 $or: хотя бы одно условие · из Ярославля или готов к переезду
#
# Запуск из папки архива:
#   docker compose run --rm python primery/01.py
#   cd primery, затем python 01.py (Windows) или python3 01.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
print("из Ярославля:      ", resumes.count_documents({"city": "Ярославль"}))
print("готов к переезду:  ", resumes.count_documents({"ready_to_move": True}))
print("одно из двух ($or):", resumes.count_documents({"$or": [{"city": "Ярославль"}, {"ready_to_move": True}]}))

for doc in resumes.find({"$or": [{"city": "Ярославль"}, {"ready_to_move": True}]}, {"_id": 0, "fio": 1, "city": 1, "ready_to_move": 1}):
    print(doc)
