# Глава 2.4 · Логика: $and $or $not $nor
# Пример 5 из 6 · §5 $not: отрицание условия · отрицание условия
#
# Запуск из папки архива:
#   docker compose run --rm python primery/05.py
#   cd primery, затем python 05.py (Windows) или python3 05.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
from datetime import datetime

sep01 = datetime(2026, 9, 1)

print("$not $gte 01.09:", resumes.count_documents({"updated": {"$not": {"$gte": sep01}}}))
print("$lt 01.09:      ", resumes.count_documents({"updated": {"$lt": sep01}}))

for doc in resumes.find({"updated": {"$not": {"$gte": sep01}}}, {"_id": 0, "fio": 1, "updated": 1}):
    print(doc)
