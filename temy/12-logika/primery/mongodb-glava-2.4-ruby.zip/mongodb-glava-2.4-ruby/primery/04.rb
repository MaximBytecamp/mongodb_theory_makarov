# Глава 2.4 · Логика: $and $or $not $nor
# Пример 4 из 6 · §4 $and: «и», записанное явно · два условия «или» сразу
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/04.rb
#   cd primery, затем ruby 04.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
dostupen = { "$or" => [{ "city" => "Ярославль" }, { "ready_to_move" => true }] }
kvalif = { "$or" => [{ "education.level" => "Высшее" },
                     { "experience.months" => { "$gte" => 10 } }] }

puts "доступен для Ярославля: " + resumes.count_documents(dostupen).to_s
puts "есть квалификация:      " + resumes.count_documents(kvalif).to_s

resumes.find({ "$and" => [dostupen, kvalif] }, projection: { "_id" => 0, "fio" => 1 })
       .each { |doc| puts doc.inspect }
