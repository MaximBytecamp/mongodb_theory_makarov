# Глава 2.4 · Логика: $and $or $not $nor
# Пример 5 из 6 · §5 $not: отрицание условия · отрицание условия
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/05.rb
#   cd primery, затем ruby 05.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
sep01 = Time.utc(2026, 9, 1)

puts "$not $gte 01.09: " + resumes.count_documents({ "updated" => { "$not" => { "$gte" => sep01 } } }).to_s
puts "$lt 01.09:       " + resumes.count_documents({ "updated" => { "$lt" => sep01 } }).to_s

resumes.find({ "updated" => { "$not" => { "$gte" => sep01 } } }, projection: { "_id" => 0, "fio" => 1, "updated" => 1 })
       .each { |doc| puts doc.inspect }
