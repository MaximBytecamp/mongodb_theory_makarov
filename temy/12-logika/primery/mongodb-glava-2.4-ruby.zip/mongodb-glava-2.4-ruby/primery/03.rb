# Глава 2.4 · Логика: $and $or $not $nor
# Пример 3 из 6 · §3 «И» вместе с «или» · условие на зарплату и «или»
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/03.rb
#   cd primery, затем ruby 03.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
filtr = { "salary" => { "$lte" => 90000 },
          "$or" => [{ "city" => "Ярославль" },
                    { "ready_to_move" => true }] }

resumes.find(filtr, projection: { "_id" => 0, "fio" => 1, "salary" => 1, "city" => 1, "ready_to_move" => 1 })
       .each { |doc| puts doc.inspect }
