# Глава 2.4 · Логика: $and $or $not $nor
# Пример 1 из 6 · §1 $or: хотя бы одно условие · из Ярославля или готов к переезду
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/01.rb
#   cd primery, затем ruby 01.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
puts "из Ярославля:       " + resumes.count_documents({ "city" => "Ярославль" }).to_s
puts "готов к переезду:   " + resumes.count_documents({ "ready_to_move" => true }).to_s
puts "одно из двух ($or): " + resumes.count_documents({ "$or" => [{ "city" => "Ярославль" }, { "ready_to_move" => true }] }).to_s

resumes.find({ "$or" => [{ "city" => "Ярославль" }, { "ready_to_move" => true }] }, projection: { "_id" => 0, "fio" => 1, "city" => 1, "ready_to_move" => 1 })
       .each { |doc| puts doc.inspect }
