# Глава 2.4 · Логика: $and $or $not $nor
# Пример 2 из 6 · §2 $or на одном поле и $in · $or на одном поле и $in
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/02.rb
#   cd primery, затем ruby 02.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
puts "$or: " + vacancies.count_documents({ "$or" => [{ "city" => "Москва" }, { "city" => "Казань" }] }).to_s
puts "$in: " + vacancies.count_documents({ "city" => { "$in" => ["Москва", "Казань"] } }).to_s
