# Глава 4.5 · $skip, $count, $sortByCount и память сортировки
# Пример 7 из 7 · §6 Память сортировки · план сортировки с $limit и без
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/07.rb
#   cd primery, затем ruby 07.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# Печатает у каждого документа поля fields в строку через « | »; вложенные — через точку.
def show(docs, *fields)
  count = 0
  docs.each do |doc|
    cells = fields.map do |path|
      value = path.split(".").reduce(doc) { |v, key| v.is_a?(Hash) ? v[key] : nil }
      value = value.utc.strftime("%Y-%m-%d %H:%M") if value.is_a?(Time)
      value.nil? ? "—" : value.to_s
    end
    puts cells.join(" | ")
    count += 1
  end
  puts "документов: #{count}"
end

# ── пример из главы ───────────────────────────────────────────
sorted_all = [
  { "$match" => { "status" => "в пути" } },
  { "$sort" => { "total" => -1 } },
]
top3 = sorted_all + [{ "$limit" => 3 }]

[["без $limit", sorted_all], ["с $limit 3", top3]].each do |name, stages|
  info = db.command(explain: { aggregate: "orders", pipeline: stages, cursor: {} },
                    verbosity: "queryPlanner").first
  plan = info["queryPlanner"]["winningPlan"]
  puts "#{name} | #{plan["stage"]} | memLimit #{plan["memLimit"]} | limitAmount #{plan["limitAmount"] || "—"}"
end
