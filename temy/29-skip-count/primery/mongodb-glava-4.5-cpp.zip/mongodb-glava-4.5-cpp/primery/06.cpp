// Глава 4.5 · $skip, $count, $sortByCount и память сортировки
// Пример 6 из 7 · §5 Стадия $sortByCount · $sortByCount и $group с $sort
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/06.cpp
//   cd primery, затем g++ -std=c++17 06.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────

#include <ctime>
#include <mongocxx/pipeline.hpp>

// show — у каждого документа поля fields в строку через « | »; вложенные — через точку.
void show(mongocxx::cursor&& cursor, const std::vector<std::string>& fields) {
    int count = 0;
    for (auto&& doc : cursor) {
        std::string line;
        for (std::size_t i = 0; i < fields.size(); ++i) {
            bsoncxx::document::view level = doc;
            bsoncxx::document::element value;
            std::stringstream path(fields[i]);
            std::string key;
            while (std::getline(path, key, '.')) {
                value = level[key];
                if (!value) break;
                if (value.type() == bsoncxx::type::k_document) level = value.get_document().value;
            }
            std::string cell = "—";
            if (value) {
                switch (value.type()) {
                    case bsoncxx::type::k_string: cell = std::string(value.get_string().value); break;
                    case bsoncxx::type::k_int32: cell = std::to_string(value.get_int32().value); break;
                    case bsoncxx::type::k_int64: cell = std::to_string(value.get_int64().value); break;
                    case bsoncxx::type::k_double: {
                        std::ostringstream out;
                        out << value.get_double().value;
                        cell = out.str();
                        break;
                    }
                    case bsoncxx::type::k_bool: cell = value.get_bool().value ? "true" : "false"; break;
                    case bsoncxx::type::k_date: {
                        std::time_t t = value.get_date().to_int64() / 1000;
                        std::ostringstream out;
                        out << std::put_time(std::gmtime(&t), "%Y-%m-%d %H:%M");
                        cell = out.str();
                        break;
                    }
                    case bsoncxx::type::k_null: break;
                    default: cell = "{…}";
                }
            }
            line += (i ? " | " : "") + cell;
        }
        std::cout << line << std::endl;
        ++count;
    }
    std::cout << "документов: " << count << std::endl;
}


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto orders = db["orders"];
    auto products = db["products"];
    auto customers = db["customers"];
    auto sandbox = client["sandbox"];

    {
        // ── пример из главы ──────────────────────────────────────
        mongocxx::pipeline by_count;
        by_count.sort_by_count("$status");

        mongocxx::pipeline group_sort;
        group_sort.group(make_document(kvp("_id", "$status"), kvp("count", make_document(kvp("$sum", 1)))));
        group_sort.sort(make_document(kvp("count", -1)));

        std::cout << "── $sortByCount" << std::endl;
        for (auto&& doc : orders.aggregate(by_count)) {
            std::cout << bsoncxx::to_json(doc, bsoncxx::ExtendedJsonMode::k_relaxed) << std::endl;
        }

        std::cout << "── $group и $sort" << std::endl;
        for (auto&& doc : orders.aggregate(group_sort)) {
            std::cout << bsoncxx::to_json(doc, bsoncxx::ExtendedJsonMode::k_relaxed) << std::endl;
        }
    }
}
