# Глава 4.5 · $skip, $count, $sortByCount и память сортировки
# Пример 7 из 7 · §6 Память сортировки · план сортировки с $limit и без
#
# Запуск из папки архива:
#   docker compose run --rm python primery/07.py
#   cd primery, затем python 07.py (Windows) или python3 07.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

from datetime import datetime


def show(docs, *fields):
    """Печатает у каждого документа поля fields в строку через « | »; вложенные — через точку."""
    count = 0
    for doc in docs:
        cells = []
        for path in fields:
            value = doc
            for key in path.split("."):
                value = value.get(key) if isinstance(value, dict) else None
            if isinstance(value, datetime):
                value = value.strftime("%Y-%m-%d %H:%M")
            if isinstance(value, bool):
                value = str(value).lower()
            cells.append("—" if value is None else str(value))
        print(" | ".join(cells))
        count += 1
    print("документов:", count)

# ── пример из главы ───────────────────────────────────────────
sorted_all = [
    {"$match": {"status": "в пути"}},
    {"$sort": {"total": -1}},
]
top3 = sorted_all + [{"$limit": 3}]

for name, stages in [("без $limit", sorted_all), ("с $limit 3", top3)]:
    info = db.command("explain", {"aggregate": "orders", "pipeline": stages, "cursor": {}},
                      verbosity="queryPlanner")
    plan = info["queryPlanner"]["winningPlan"]
    print(name, "|", plan["stage"], "| memLimit", plan["memLimit"],
          "| limitAmount", plan.get("limitAmount", "—"))
