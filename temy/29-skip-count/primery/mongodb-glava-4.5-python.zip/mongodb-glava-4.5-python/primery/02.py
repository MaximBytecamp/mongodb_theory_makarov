# Глава 4.5 · $skip, $count, $sortByCount и память сортировки
# Пример 2 из 7 · §2 Порядок $skip и $limit · $skip и $limit в двух порядках
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

from datetime import datetime


def show(docs, *fields):
    """Печатает у каждого документа поля fields в строку через « | »; вложенные — через точку."""
    count = 0
    for doc in docs:
        cells = []
        for path in fields:
            value = doc
            for key in path.split("."):
                value = value.get(key) if isinstance(value, dict) else None
            if isinstance(value, datetime):
                value = value.strftime("%Y-%m-%d %H:%M")
            if isinstance(value, bool):
                value = str(value).lower()
            cells.append("—" if value is None else str(value))
        print(" | ".join(cells))
        count += 1
    print("документов:", count)

# ── пример из главы ───────────────────────────────────────────
limit_then_skip = [
    {"$match": {"status": "в пути"}},
    {"$sort": {"total": -1}},
    {"$limit": 10},
    {"$skip": 5},
]

skip_then_limit = [
    {"$match": {"status": "в пути"}},
    {"$sort": {"total": -1}},
    {"$skip": 5},
    {"$limit": 10},
]

print("── $limit 10, затем $skip 5")
show(orders.aggregate(limit_then_skip), "number", "total")

print("── $skip 5, затем $limit 10")
show(orders.aggregate(skip_then_limit), "number", "total")
