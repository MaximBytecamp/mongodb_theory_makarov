//go:build ignore

// Глава 4.5 · $skip, $count, $sortByCount и память сортировки
// Пример 2 из 7 · §2 Порядок $skip и $limit · $skip и $limit в двух порядках
//
// Запуск из папки архива:
//   docker compose run --rm go primery/02.go
//   cd primery, затем go run 02.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"strings"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = fmt.Sprint
var _ = strings.Join
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────

// show — у каждого документа поля fields в строку через « | »; вложенные — через точку.
func show(cursor *mongo.Cursor, fields ...string) {
	ctx := context.Background()
	count := 0
	for cursor.Next(ctx) {
		cells := make([]string, len(fields))
		for i, path := range fields {
			value, err := cursor.Current.LookupErr(strings.Split(path, ".")...)
			switch {
			case err != nil || value.Type == bson.TypeNull:
				cells[i] = "—"
			case value.Type == bson.TypeString:
				cells[i] = value.StringValue()
			case value.Type == bson.TypeInt32:
				cells[i] = fmt.Sprint(value.Int32())
			case value.Type == bson.TypeInt64:
				cells[i] = fmt.Sprint(value.Int64())
			case value.Type == bson.TypeDouble:
				cells[i] = fmt.Sprint(value.Double())
			case value.Type == bson.TypeBoolean:
				cells[i] = fmt.Sprint(value.Boolean())
			case value.Type == bson.TypeDateTime:
				cells[i] = value.Time().UTC().Format("2006-01-02 15:04")
			default:
				cells[i] = value.String()
			}
		}
		fmt.Println(strings.Join(cells, " | "))
		count++
	}
	fmt.Println("документов:", count)
}


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	orders := db.Collection("orders")
	products := db.Collection("products")
	customers := db.Collection("customers")
	sandbox := client.Database("sandbox")
	_, _, _, _, _ = db, orders, products, customers, sandbox

	{
		// ── пример из главы ──────────────────────────────────────
		limitThenSkip := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{{Key: "status", Value: "в пути"}}}},
		    {{Key: "$sort", Value: bson.D{{Key: "total", Value: -1}}}},
		    {{Key: "$limit", Value: 10}},
		    {{Key: "$skip", Value: 5}},
		}

		skipThenLimit := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{{Key: "status", Value: "в пути"}}}},
		    {{Key: "$sort", Value: bson.D{{Key: "total", Value: -1}}}},
		    {{Key: "$skip", Value: 5}},
		    {{Key: "$limit", Value: 10}},
		}

		fmt.Println("── $limit 10, затем $skip 5")
		cursor, _ := orders.Aggregate(ctx, limitThenSkip)
		show(cursor, "number", "total")

		fmt.Println("── $skip 5, затем $limit 10")
		cursor, _ = orders.Aggregate(ctx, skipThenLimit)
		show(cursor, "number", "total")
	}
}
