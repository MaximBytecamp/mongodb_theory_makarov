# Глава 4.1 · Конвейер агрегации: $match, $sort, $limit
# Пример 2 из 6 · §3 Документы от стадии к стадии · три стадии и счёт после каждой
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

from datetime import datetime


def show(docs, *fields):
    """Печатает у каждого документа поля fields в строку через « | »; вложенные — через точку."""
    count = 0
    for doc in docs:
        cells = []
        for path in fields:
            value = doc
            for key in path.split("."):
                value = value.get(key) if isinstance(value, dict) else None
            if isinstance(value, datetime):
                value = value.strftime("%Y-%m-%d %H:%M")
            if isinstance(value, bool):
                value = str(value).lower()
            cells.append("—" if value is None else str(value))
        print(" | ".join(cells))
        count += 1
    print("документов:", count)

# ── пример из главы ───────────────────────────────────────────
stages = [
    {"$match": {"status": "доставлен"}},
    {"$match": {"delivery.city": {"$in": ["Москва", "Санкт-Петербург"]}}},
    {"$match": {"total": {"$gte": 200000}}},
]

print("на входе:", orders.count_documents({}))
for i in range(1, len(stages) + 1):
    count = len(list(orders.aggregate(stages[:i])))
    print(f"после стадии {i}:", count)

show(orders.aggregate(stages), "number", "status", "delivery.city", "total")
