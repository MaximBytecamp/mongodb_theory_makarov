# Глава 4.1 · Конвейер агрегации: $match, $sort, $limit
# Пример 5 из 6 · §6 Порядок стадий · порядок стадий
#
# Запуск из папки архива:
#   docker compose run --rm python primery/05.py
#   cd primery, затем python 05.py (Windows) или python3 05.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

from datetime import datetime


def show(docs, *fields):
    """Печатает у каждого документа поля fields в строку через « | »; вложенные — через точку."""
    count = 0
    for doc in docs:
        cells = []
        for path in fields:
            value = doc
            for key in path.split("."):
                value = value.get(key) if isinstance(value, dict) else None
            if isinstance(value, datetime):
                value = value.strftime("%Y-%m-%d %H:%M")
            if isinstance(value, bool):
                value = str(value).lower()
            cells.append("—" if value is None else str(value))
        print(" | ".join(cells))
        count += 1
    print("документов:", count)

# ── пример из главы ───────────────────────────────────────────
last_first = [
    {"$sort": {"created": -1}},
    {"$limit": 5},
    {"$match": {"status": "доставлен"}},
]

match_first = [
    {"$match": {"status": "доставлен"}},
    {"$sort": {"created": -1}},
    {"$limit": 5},
]

print("── $limit до $match")
show(orders.aggregate(last_first), "number", "created", "status")

print("── $match до $limit")
show(orders.aggregate(match_first), "number", "created", "status")
