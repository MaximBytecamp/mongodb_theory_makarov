# Глава 1.7 · Обновление: $set, $inc, $unset
# Пример 8 из 9 · §6 upsert: обновить или создать · документа ещё нет
#
# Запуск из папки архива:
#   docker compose run --rm python primery/08.py
#   cd primery, затем python 08.py (Windows) или python3 08.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# Товары, которые добавлялись в песочницу в главе 1.3. Если песочницу
# сбрасывали, заготовка добавит их снова — обновлять будет что.
if box.count_documents({"_id": "p-101"}) == 0:
    box.insert_many([
        {"_id": "p-101", "title": "Подставка для ноутбука", "category": "аксессуары", "price": 2490},
        {"_id": "p-102", "title": "Чехол для планшета", "category": "аксессуары", "price": 1890},
        {"sku": "SKU-AC-022", "title": "Коврик для мыши XL", "brand": "OEM",
         "category": "аксессуары", "price": 1290},
    ])

orders_box = client["sandbox"]["orders"]      # копия заказов: их можно менять
if orders_box.count_documents({}) == 0:
    orders_box.insert_many(orders.find())

stats = client["sandbox"]["product_stats"]    # счётчики просмотров для §6
stats.drop()                                  # каждый запуск заготовки считает с нуля
from datetime import date
today = date.today().isoformat()

# ── пример из главы ───────────────────────────────────────────
res = box.update_one(
    {"_id": "p-999"},
    {"$set": {"title": "Товар из upsert", "price": 100}},
    upsert=True)

print("matched:", res.matched_count,
      "modified:", res.modified_count,
      "upserted_id:", res.upserted_id)
