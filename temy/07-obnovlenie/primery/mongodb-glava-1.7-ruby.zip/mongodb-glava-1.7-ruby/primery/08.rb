# Глава 1.7 · Обновление: $set, $inc, $unset
# Пример 8 из 9 · §6 upsert: обновить или создать · документа ещё нет
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/08.rb
#   cd primery, затем ruby 08.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# Товары, которые добавлялись в песочницу в главе 1.3. Если песочницу
# сбрасывали, заготовка добавит их снова — обновлять будет что.
if box.count_documents({ "_id" => "p-101" }).zero?
  box.insert_many([
    { "_id" => "p-101", "title" => "Подставка для ноутбука", "category" => "аксессуары", "price" => 2490 },
    { "_id" => "p-102", "title" => "Чехол для планшета", "category" => "аксессуары", "price" => 1890 },
    { "sku" => "SKU-AC-022", "title" => "Коврик для мыши XL", "brand" => "OEM",
      "category" => "аксессуары", "price" => 1290 },
  ])
end

orders_box = client.use("sandbox").database[:orders]   # копия заказов: их можно менять
orders_box.insert_many(orders.find.to_a) if orders_box.count_documents({}).zero?

stats = client.use("sandbox").database[:product_stats] # счётчики просмотров для §6
stats.drop                                             # каждый запуск заготовки считает с нуля
require "date"
today = Date.today.iso8601

# ── пример из главы ───────────────────────────────────────────
res = box.update_one(
  { "_id" => "p-999" },
  { "$set" => { "title" => "Товар из upsert", "price" => 100 } },
  upsert: true
)

puts "matched: #{res.matched_count} modified: #{res.modified_count} " \
     "upserted_id: #{res.upserted_id}"
