// Глава 3.2 · Индексы: одиночные, составные, уникальные
// Пример 5 из 7 · §5 Уникальный индекс · уникальный индекс
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/05.cpp
//   cd primery, затем g++ -std=c++17 05.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────

// plan — стадии плана, который выбрал сервер, сверху вниз: FETCH → IXSCAN service_1.
std::string plan(mongocxx::database& db, const std::string& coll, bsoncxx::document::view filtr,
                 bsoncxx::document::view sort = bsoncxx::document::view{}) {
    bsoncxx::builder::basic::document cmd;
    cmd.append(kvp("find", coll), kvp("filter", filtr));
    if (!sort.empty()) cmd.append(kvp("sort", sort));
    auto res = db.run_command(make_document(kvp("explain", cmd.view())));
    auto stage = res.view()["queryPlanner"]["winningPlan"].get_document().value;
    if (stage["queryPlan"]) stage = stage["queryPlan"].get_document().value;   // MongoDB 7 кладёт план во вложенное поле
    std::string steps;
    while (true) {
        steps += std::string{stage["stage"].get_string().value};
        if (stage["indexName"]) steps += " " + std::string{stage["indexName"].get_string().value};
        if (!stage["inputStage"]) break;
        steps += " → ";
        stage = stage["inputStage"].get_document().value;
    }
    return steps;
}


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto products = db["products"];
    auto orders = db["orders"];
    auto events = client["logs"]["events"];
    auto sandbox = client["sandbox"];
    auto box = sandbox["products"];   // песочница: здесь можно менять

    auto journal = sandbox["events"];      // копия журнала: на ней строятся индексы главы
    auto clients = sandbox["customers"];   // копия покупателей: уникальный индекс, §5–§7

    {
        // ── пример из главы ──────────────────────────────────────
        clients.drop();
        std::vector<bsoncxx::document::value> all;
        for (auto&& doc : db["customers"].find(make_document())) all.emplace_back(doc);
        clients.insert_many(all);
        mongocxx::options::index unique;
        unique.unique(true);
        auto created = clients.create_index(make_document(kvp("email", 1)), unique);
        std::cout << "создан индекс: " << created.view()["name"].get_string().value << std::endl;

        try {
            clients.insert_one(make_document(kvp("_id", "c-101"), kvp("name", "Ольга Кравец"),
                                             kvp("email", "user01@example.com"), kvp("city", "Ярославль")));
            std::cout << "Ольга Кравец записана" << std::endl;
        } catch (const mongocxx::operation_exception& e) {
            std::cout << "Ольга Кравец отклонена, код " << e.code().value() << " — уже есть "
                      << bsoncxx::to_json(e.raw_server_error()->view()["writeErrors"][0]["keyValue"].get_document().value,
                                          bsoncxx::ExtendedJsonMode::k_relaxed) << std::endl;
        }
        std::cout << "покупателей: " << clients.count_documents(make_document()) << std::endl;
    }
}
