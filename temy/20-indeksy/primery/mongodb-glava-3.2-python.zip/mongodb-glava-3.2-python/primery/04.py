# Глава 3.2 · Индексы: одиночные, составные, уникальные
# Пример 4 из 7 · §4 Удаление индекса · удаление лишнего индекса
#
# Запуск из папки архива:
#   docker compose run --rm python primery/04.py
#   cd primery, затем python 04.py (Windows) или python3 04.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
events = client["logs"]["events"]
sandbox = client["sandbox"]
box = sandbox["products"]        # песочница: здесь можно менять

journal = sandbox["events"]       # копия журнала: на ней строятся индексы главы
clients = sandbox["customers"]    # копия покупателей: уникальный индекс, §5–§7


def plan(coll, filtr, sort=None):
    """Стадии плана, который выбрал сервер, сверху вниз: FETCH → IXSCAN service_1."""
    cursor = coll.find(filtr)
    if sort:
        cursor = cursor.sort(sort)
    stage = cursor.explain()["queryPlanner"]["winningPlan"]
    stage = stage.get("queryPlan", stage)     # MongoDB 7 кладёт план во вложенное поле
    steps = []
    while stage:
        steps.append(stage["stage"] + (" " + stage["indexName"] if "indexName" in stage else ""))
        stage = stage.get("inputStage")
    return " → ".join(steps)

# ── пример из главы ───────────────────────────────────────────
journal.drop_index("service_1")
for ix in journal.list_indexes():
    print("индекс", ix["name"], dict(ix["key"]))

print("только service:        ", plan(journal, {"service": "payments"}))
print("service, порядок по ts:", plan(journal, {"service": "payments"}, [("ts", -1)]))
