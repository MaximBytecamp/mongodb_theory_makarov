# Глава 3.2 · Индексы: одиночные, составные, уникальные
# Пример 7 из 7 · §7 Документ без поля и частичный индекс · документ без поля и частичный индекс
#
# Запуск из папки архива:
#   docker compose run --rm python primery/07.py
#   cd primery, затем python 07.py (Windows) или python3 07.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
events = client["logs"]["events"]
sandbox = client["sandbox"]
box = sandbox["products"]        # песочница: здесь можно менять

journal = sandbox["events"]       # копия журнала: на ней строятся индексы главы
clients = sandbox["customers"]    # копия покупателей: уникальный индекс, §5–§7


def plan(coll, filtr, sort=None):
    """Стадии плана, который выбрал сервер, сверху вниз: FETCH → IXSCAN service_1."""
    cursor = coll.find(filtr)
    if sort:
        cursor = cursor.sort(sort)
    stage = cursor.explain()["queryPlanner"]["winningPlan"]
    stage = stage.get("queryPlan", stage)     # MongoDB 7 кладёт план во вложенное поле
    steps = []
    while stage:
        steps.append(stage["stage"] + (" " + stage["indexName"] if "indexName" in stage else ""))
        stage = stage.get("inputStage")
    return " → ".join(steps)

# ── пример из главы ───────────────────────────────────────────
from pymongo.errors import DuplicateKeyError

clients.insert_one({"_id": "c-102", "name": "Андрей Носов", "city": "Казань"})
try:
    clients.insert_one({"_id": "c-103", "name": "Вера Лосева", "city": "Казань"})
    print("второй покупатель без почты записан")
except DuplicateKeyError as e:
    print("второй покупатель без почты отклонён — уже есть", e.details["keyValue"])

clients.drop_index("email_1")
clients.create_index("email", unique=True, partialFilterExpression={"email": {"$exists": True}})

clients.insert_one({"_id": "c-103", "name": "Вера Лосева", "city": "Казань"})
print("покупателей без почты:", clients.count_documents({"email": {"$exists": False}}))
try:
    clients.insert_one({"_id": "c-104", "name": "Ольга Кравец", "email": "user01@example.com"})
except DuplicateKeyError as e:
    print("повтор почты отклонён — уже есть", e.details["keyValue"])
