# Глава 3.2 · Индексы: одиночные, составные, уникальные
# Пример 7 из 7 · §7 Документ без поля и частичный индекс · документ без поля и частичный индекс
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/07.rb
#   cd primery, затем ruby 07.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
events = client.use("logs").database[:events]
sandbox = client.use("sandbox").database
box = sandbox[:products]   # песочница: здесь можно менять

journal = sandbox[:events]        # копия журнала: на ней строятся индексы главы
clients = sandbox[:customers]     # копия покупателей: уникальный индекс, §5–§7

# Стадии плана, который выбрал сервер, сверху вниз: FETCH → IXSCAN service_1.
def plan(coll, filtr, sort = nil)
  view = coll.find(filtr)
  view = view.sort(sort) if sort
  stage = view.explain["queryPlanner"]["winningPlan"]
  stage = stage["queryPlan"] || stage     # MongoDB 7 кладёт план во вложенное поле
  steps = []
  while stage
    steps << stage["stage"] + (stage["indexName"] ? " " + stage["indexName"] : "")
    stage = stage["inputStage"]
  end
  steps.join(" → ")
end

# ── пример из главы ───────────────────────────────────────────
clients.insert_one({ "_id" => "c-102", "name" => "Андрей Носов", "city" => "Казань" })
begin
  clients.insert_one({ "_id" => "c-103", "name" => "Вера Лосева", "city" => "Казань" })
  puts "второй покупатель без почты записан"
rescue Mongo::Error::OperationFailure => e
  puts "второй покупатель без почты отклонён — уже есть #{e.document["writeErrors"][0]["keyValue"]}"
end

clients.indexes.drop_one("email_1")
clients.indexes.create_one({ "email" => 1 }, unique: true,
                           partial_filter_expression: { "email" => { "$exists" => true } })

clients.insert_one({ "_id" => "c-103", "name" => "Вера Лосева", "city" => "Казань" })
puts "покупателей без почты: " + clients.count_documents({ "email" => { "$exists" => false } }).to_s
begin
  clients.insert_one({ "_id" => "c-104", "name" => "Ольга Кравец", "email" => "user01@example.com" })
rescue Mongo::Error::OperationFailure => e
  puts "повтор почты отклонён — уже есть #{e.document["writeErrors"][0]["keyValue"]}"
end
