# Глава 3.2 · Индексы: одиночные, составные, уникальные
# Пример 5 из 7 · §5 Уникальный индекс · уникальный индекс
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/05.rb
#   cd primery, затем ruby 05.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
events = client.use("logs").database[:events]
sandbox = client.use("sandbox").database
box = sandbox[:products]   # песочница: здесь можно менять

journal = sandbox[:events]        # копия журнала: на ней строятся индексы главы
clients = sandbox[:customers]     # копия покупателей: уникальный индекс, §5–§7

# Стадии плана, который выбрал сервер, сверху вниз: FETCH → IXSCAN service_1.
def plan(coll, filtr, sort = nil)
  view = coll.find(filtr)
  view = view.sort(sort) if sort
  stage = view.explain["queryPlanner"]["winningPlan"]
  stage = stage["queryPlan"] || stage     # MongoDB 7 кладёт план во вложенное поле
  steps = []
  while stage
    steps << stage["stage"] + (stage["indexName"] ? " " + stage["indexName"] : "")
    stage = stage["inputStage"]
  end
  steps.join(" → ")
end

# ── пример из главы ───────────────────────────────────────────
clients.drop
clients.insert_many(db[:customers].find.to_a)
clients.indexes.create_one({ "email" => 1 }, unique: true)
puts "создан индекс: " + clients.indexes.get({ "email" => 1 })["name"]

begin
  clients.insert_one({ "_id" => "c-101", "name" => "Ольга Кравец", "email" => "user01@example.com", "city" => "Ярославль" })
  puts "Ольга Кравец записана"
rescue Mongo::Error::OperationFailure => e
  puts "Ольга Кравец отклонена, код #{e.code} — уже есть #{e.document["writeErrors"][0]["keyValue"]}"
end
puts "покупателей: " + clients.count_documents({}).to_s
