# Глава 3.2 · Индексы: одиночные, составные, уникальные
# Пример 1 из 7 · §1 Как сервер ищет без индекса · копия журнала и её индексы
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/01.rb
#   cd primery, затем ruby 01.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
events = client.use("logs").database[:events]
sandbox = client.use("sandbox").database
box = sandbox[:products]   # песочница: здесь можно менять

journal = sandbox[:events]        # копия журнала: на ней строятся индексы главы
clients = sandbox[:customers]     # копия покупателей: уникальный индекс, §5–§7

# Стадии плана, который выбрал сервер, сверху вниз: FETCH → IXSCAN service_1.
def plan(coll, filtr, sort = nil)
  view = coll.find(filtr)
  view = view.sort(sort) if sort
  stage = view.explain["queryPlanner"]["winningPlan"]
  stage = stage["queryPlan"] || stage     # MongoDB 7 кладёт план во вложенное поле
  steps = []
  while stage
    steps << stage["stage"] + (stage["indexName"] ? " " + stage["indexName"] : "")
    stage = stage["inputStage"]
  end
  steps.join(" → ")
end

# ── пример из главы ───────────────────────────────────────────
journal.drop
journal.insert_many(events.find.to_a)
puts "событий в копии: " + journal.count_documents({}).to_s

journal.indexes.each { |ix| puts "индекс " + ix["name"] + " " + ix["key"].to_s }
