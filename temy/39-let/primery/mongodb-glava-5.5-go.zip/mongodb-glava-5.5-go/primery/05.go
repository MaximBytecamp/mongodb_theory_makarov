//go:build ignore

// Глава 5.5 · $let: переменные внутри выражения
// Пример 5 из 8 · §5 Переменная $let внутри $map · $let снаружи, $map внутри: скидка по позициям
//
// Запуск из папки архива:
//   docker compose run --rm go primery/05.go
//   cd primery, затем go run 05.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	orders := db.Collection("orders")
	products := db.Collection("products")
	customers := db.Collection("customers")
	sandbox := client.Database("sandbox")
	_, _, _, _, _ = db, orders, products, customers, sandbox

	{
		// ── пример из главы ──────────────────────────────────────
		pipeline := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{{Key: "_id", Value: "o-0003"}}}},
		    {{Key: "$project", Value: bson.D{
		        {Key: "_id", Value: 0},
		        {Key: "number", Value: 1},
		        {Key: "promo", Value: 1},
		        {Key: "lines", Value: bson.D{
		            {Key: "$let", Value: bson.D{
		                {Key: "vars", Value: bson.D{
		                    {Key: "pct", Value: bson.D{
		                        {Key: "$switch", Value: bson.D{
		                            {Key: "branches", Value: bson.A{
		                                bson.D{
		                                    {Key: "case", Value: bson.D{
		                                        {Key: "$eq", Value: bson.A{"$promo", "SPRING10"}}}},
		                                    {Key: "then", Value: 10}},
		                                bson.D{
		                                    {Key: "case", Value: bson.D{
		                                        {Key: "$eq", Value: bson.A{"$promo", "LOYAL15"}}}},
		                                    {Key: "then", Value: 15}},
		                                bson.D{
		                                    {Key: "case", Value: bson.D{
		                                        {Key: "$eq", Value: bson.A{"$promo", "FIRST5"}}}},
		                                    {Key: "then", Value: 5}}}},
		                            {Key: "default", Value: 0}}}}}}},
		                {Key: "in", Value: bson.D{
		                    {Key: "$map", Value: bson.D{
		                        {Key: "input", Value: "$items"},
		                        {Key: "in", Value: bson.D{
		                            {Key: "title", Value: "$$this.title"},
		                            {Key: "pay", Value: bson.D{
		                                {Key: "$divide", Value: bson.A{
		                                    bson.D{
		                                        {Key: "$multiply", Value: bson.A{
		                                            "$$this.qty",
		                                            "$$this.price",
		                                            bson.D{{Key: "$subtract", Value: bson.A{100, "$$pct"}}}}}},
		                                    100}}}}}}}}}}}}}}}}},
		}

		cursor, _ := orders.Aggregate(ctx, pipeline)
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}
	}
}
