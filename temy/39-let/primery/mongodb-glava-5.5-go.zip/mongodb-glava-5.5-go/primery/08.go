//go:build ignore

// Глава 5.5 · $let: переменные внутри выражения
// Пример 8 из 8 · §8 Где переменная не видна · переменные, которые сервер не принимает
//
// Запуск из папки архива:
//   docker compose run --rm go primery/08.go
//   cd primery, затем go run 08.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────

var ce mongo.CommandError

func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	orders := db.Collection("orders")
	products := db.Collection("products")
	customers := db.Collection("customers")
	sandbox := client.Database("sandbox")
	_, _, _, _, _ = db, orders, products, customers, sandbox

	{
		// ── пример из главы ──────────────────────────────────────
		sameVars := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{{Key: "_id", Value: "o-0002"}}}},
		    {{Key: "$project", Value: bson.D{
		        {Key: "x", Value: bson.D{
		            {Key: "$let", Value: bson.D{
		                {Key: "vars", Value: bson.D{
		                    {Key: "pct", Value: 10},
		                    {Key: "discount", Value: bson.D{
		                        {Key: "$divide", Value: bson.A{
		                            bson.D{{Key: "$multiply", Value: bson.A{"$total", "$$pct"}}},
		                            100}}}}}},
		                {Key: "in", Value: "$$discount"}}}}}}}},
		}

		outside := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{{Key: "_id", Value: "o-0002"}}}},
		    {{Key: "$project", Value: bson.D{
		        {Key: "x", Value: bson.D{
		            {Key: "$let", Value: bson.D{
		                {Key: "vars", Value: bson.D{{Key: "pct", Value: 10}}},
		                {Key: "in", Value: "$$pct"}}}}},
		        {Key: "y", Value: "$$pct"}}}},
		}

		capital := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{{Key: "_id", Value: "o-0002"}}}},
		    {{Key: "$project", Value: bson.D{
		        {Key: "x", Value: bson.D{
		            {Key: "$let", Value: bson.D{
		                {Key: "vars", Value: bson.D{{Key: "Pct", Value: 10}}},
		                {Key: "in", Value: "$$Pct"}}}}}}}},
		}

		fmt.Println("── переменная из того же vars")
		_, err := orders.Aggregate(ctx, sameVars)
		if errors.As(err, &ce) {
		    fmt.Println("код", ce.Code)
		    fmt.Println(ce.Message)
		}

		fmt.Println("── переменная вне in")
		_, err = orders.Aggregate(ctx, outside)
		if errors.As(err, &ce) {
		    fmt.Println("код", ce.Code)
		    fmt.Println(ce.Message)
		}

		fmt.Println("── имя с заглавной буквы")
		_, err = orders.Aggregate(ctx, capital)
		if errors.As(err, &ce) {
		    fmt.Println("код", ce.Code)
		    fmt.Println(ce.Message)
		}
	}
}
