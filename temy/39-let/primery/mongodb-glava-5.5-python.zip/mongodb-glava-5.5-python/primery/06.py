# Глава 5.5 · $let: переменные внутри выражения
# Пример 6 из 8 · §6 Переменная из переменной · вложенный $let: переменная из переменной
#
# Запуск из папки архива:
#   docker compose run --rm python primery/06.py
#   cd primery, затем python 06.py (Windows) или python3 06.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": "o-0004"}},
    {"$project": {
        "_id": 0,
        "number": 1,
        "total": 1,
        "check": {"$let": {
            "vars": {"pct": {"$switch": {
                "branches": [
                    {"case": {"$eq": ["$promo", "SPRING10"]}, "then": 10},
                    {"case": {"$eq": ["$promo", "LOYAL15"]}, "then": 15},
                    {"case": {"$eq": ["$promo", "FIRST5"]}, "then": 5},
                ],
                "default": 0,
            }}},
            "in": {"$let": {
                "vars": {"discount": {"$divide": [
                    {"$multiply": ["$total", "$$pct"]},
                    100,
                ]}},
                "in": {
                    "discount": "$$discount",
                    "pay": {"$subtract": ["$total", "$$discount"]},
                },
            }},
        }},
    }},
]

for doc in orders.aggregate(pipeline):
    print(doc)
