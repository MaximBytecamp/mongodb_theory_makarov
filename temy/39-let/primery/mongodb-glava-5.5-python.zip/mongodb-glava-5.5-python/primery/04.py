# Глава 5.5 · $let: переменные внутри выражения
# Пример 4 из 8 · §4 Переменная внутри $group · скидки по каждому промокоду
#
# Запуск из папки архива:
#   docker compose run --rm python primery/04.py
#   cd primery, затем python 04.py (Windows) или python3 04.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"promo": {"$exists": True}}},
    {"$group": {
        "_id": "$promo",
        "orders": {"$sum": 1},
        "total": {"$sum": "$total"},
        "discount": {"$sum": {"$let": {
            "vars": {"pct": {"$switch": {
                "branches": [
                    {"case": {"$eq": ["$promo", "SPRING10"]}, "then": 10},
                    {"case": {"$eq": ["$promo", "LOYAL15"]}, "then": 15},
                    {"case": {"$eq": ["$promo", "FIRST5"]}, "then": 5},
                ],
                "default": 0,
            }}},
            "in": {"$divide": [{"$multiply": ["$total", "$$pct"]}, 100]},
        }}},
    }},
    {"$sort": {"_id": 1}},
]

for doc in orders.aggregate(pipeline):
    print(doc)
