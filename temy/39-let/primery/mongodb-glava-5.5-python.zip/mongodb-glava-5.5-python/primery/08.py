# Глава 5.5 · $let: переменные внутри выражения
# Пример 8 из 8 · §8 Где переменная не видна · переменные, которые сервер не принимает
#
# Запуск из папки архива:
#   docker compose run --rm python primery/08.py
#   cd primery, затем python 08.py (Windows) или python3 08.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
from pymongo.errors import OperationFailure

same_vars = [
    {"$match": {"_id": "o-0002"}},
    {"$project": {"x": {"$let": {
        "vars": {
            "pct": 10,
            "discount": {"$divide": [{"$multiply": ["$total", "$$pct"]}, 100]},
        },
        "in": "$$discount",
    }}}},
]

outside = [
    {"$match": {"_id": "o-0002"}},
    {"$project": {"x": {"$let": {"vars": {"pct": 10}, "in": "$$pct"}}, "y": "$$pct"}},
]

capital = [
    {"$match": {"_id": "o-0002"}},
    {"$project": {"x": {"$let": {"vars": {"Pct": 10}, "in": "$$Pct"}}}},
]

print("── переменная из того же vars")
try:
    for doc in orders.aggregate(same_vars):
        print(doc)
except OperationFailure as e:
    print("код", e.code)
    print(e.details["errmsg"])

print("── переменная вне in")
try:
    for doc in orders.aggregate(outside):
        print(doc)
except OperationFailure as e:
    print("код", e.code)
    print(e.details["errmsg"])

print("── имя с заглавной буквы")
try:
    for doc in orders.aggregate(capital):
        print(doc)
except OperationFailure as e:
    print("код", e.code)
    print(e.details["errmsg"])
