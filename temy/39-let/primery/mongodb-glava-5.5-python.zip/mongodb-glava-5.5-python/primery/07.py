# Глава 5.5 · $let: переменные внутри выражения
# Пример 7 из 8 · §7 Переменная и поле с одним именем · переменная total и поле total
#
# Запуск из папки архива:
#   docker compose run --rm python primery/07.py
#   cd primery, затем python 07.py (Windows) или python3 07.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": "o-0002"}},
    {"$project": {
        "_id": 0,
        "both": {"$let": {"vars": {"total": 1}, "in": ["$total", "$$total"]}},
    }},
]

for doc in orders.aggregate(pipeline):
    print(doc)
