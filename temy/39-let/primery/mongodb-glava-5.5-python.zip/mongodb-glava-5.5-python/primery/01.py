# Глава 5.5 · $let: переменные внутри выражения
# Пример 1 из 8 · §1 Выражение $let · $let: средняя сумма позиции
#
# Запуск из папки архива:
#   docker compose run --rm python primery/01.py
#   cd primery, затем python 01.py (Windows) или python3 01.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": {"$in": ["o-0001", "o-0002", "o-0003", "o-0004", "o-0005"]}}},
    {"$project": {
        "_id": 0,
        "number": 1,
        "avg_line": {"$let": {
            "vars": {
                "sum": {"$sum": {"$map": {
                    "input": "$items",
                    "in": {"$multiply": ["$$this.qty", "$$this.price"]},
                }}},
                "lines": {"$size": "$items"},
            },
            "in": {"$divide": ["$$sum", "$$lines"]},
        }},
    }},
]

for doc in orders.aggregate(pipeline):
    print(doc)
