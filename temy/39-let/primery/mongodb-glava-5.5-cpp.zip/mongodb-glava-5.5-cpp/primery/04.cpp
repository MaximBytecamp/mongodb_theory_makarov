// Глава 5.5 · $let: переменные внутри выражения
// Пример 4 из 8 · §4 Переменная внутри $group · скидки по каждому промокоду
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/04.cpp
//   cd primery, затем g++ -std=c++17 04.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto orders = db["orders"];
    auto products = db["products"];
    auto customers = db["customers"];
    auto sandbox = client["sandbox"];

    {
        // ── пример из главы ──────────────────────────────────────
        mongocxx::pipeline pipeline;
        pipeline.match(make_document(kvp("promo", make_document(kvp("$exists", true)))));
        pipeline.group(make_document(
            kvp("_id", "$promo"),
            kvp("orders", make_document(kvp("$sum", 1))),
            kvp("total", make_document(kvp("$sum", "$total"))),
            kvp("discount", make_document(
                kvp("$sum", make_document(
                    kvp("$let", make_document(
                        kvp("vars", make_document(
                            kvp("pct", make_document(
                                kvp("$switch", make_document(
                                    kvp("branches", make_array(
                                        make_document(
                                            kvp("case", make_document(
                                                kvp("$eq", make_array("$promo", "SPRING10")))),
                                            kvp("then", 10)),
                                        make_document(
                                            kvp("case", make_document(
                                                kvp("$eq", make_array("$promo", "LOYAL15")))),
                                            kvp("then", 15)),
                                        make_document(
                                            kvp("case", make_document(
                                                kvp("$eq", make_array("$promo", "FIRST5")))),
                                            kvp("then", 5)))),
                                    kvp("default", 0))))))),
                        kvp("in", make_document(
                            kvp("$divide", make_array(
                                make_document(kvp("$multiply", make_array("$total", "$$pct"))),
                                100))))))))))));
        pipeline.sort(make_document(kvp("_id", 1)));

        for (auto&& doc : orders.aggregate(pipeline)) {
            std::cout << bsoncxx::to_json(doc, bsoncxx::ExtendedJsonMode::k_relaxed) << std::endl;
        }
    }
}
