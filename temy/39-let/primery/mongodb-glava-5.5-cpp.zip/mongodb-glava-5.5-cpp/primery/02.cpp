// Глава 5.5 · $let: переменные внутри выражения
// Пример 2 из 8 · §2 Выбор значения: $switch · $switch: процент скидки по промокоду
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/02.cpp
//   cd primery, затем g++ -std=c++17 02.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto orders = db["orders"];
    auto products = db["products"];
    auto customers = db["customers"];
    auto sandbox = client["sandbox"];

    {
        // ── пример из главы ──────────────────────────────────────
        mongocxx::pipeline pipeline;
        pipeline.match(make_document(
            kvp("_id", make_document(
                kvp("$in", make_array("o-0001", "o-0002", "o-0003", "o-0004", "o-0005"))))));
        pipeline.project(make_document(
            kvp("_id", 0),
            kvp("number", 1),
            kvp("promo", 1),
            kvp("pct", make_document(
                kvp("$switch", make_document(
                    kvp("branches", make_array(
                        make_document(
                            kvp("case", make_document(kvp("$eq", make_array("$promo", "SPRING10")))),
                            kvp("then", 10)),
                        make_document(
                            kvp("case", make_document(kvp("$eq", make_array("$promo", "LOYAL15")))),
                            kvp("then", 15)),
                        make_document(
                            kvp("case", make_document(kvp("$eq", make_array("$promo", "FIRST5")))),
                            kvp("then", 5)))),
                    kvp("default", 0)))))));

        for (auto&& doc : orders.aggregate(pipeline)) {
            std::cout << bsoncxx::to_json(doc, bsoncxx::ExtendedJsonMode::k_relaxed) << std::endl;
        }
    }
}
