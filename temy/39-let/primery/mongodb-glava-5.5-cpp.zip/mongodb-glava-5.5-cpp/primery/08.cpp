// Глава 5.5 · $let: переменные внутри выражения
// Пример 8 из 8 · §8 Где переменная не видна · переменные, которые сервер не принимает
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/08.cpp
//   cd primery, затем g++ -std=c++17 08.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto orders = db["orders"];
    auto products = db["products"];
    auto customers = db["customers"];
    auto sandbox = client["sandbox"];

    {
        // ── пример из главы ──────────────────────────────────────
        mongocxx::pipeline same_vars;
        same_vars.match(make_document(kvp("_id", "o-0002")));
        same_vars.project(make_document(
            kvp("x", make_document(
                kvp("$let", make_document(
                    kvp("vars", make_document(
                        kvp("pct", 10),
                        kvp("discount", make_document(
                            kvp("$divide", make_array(
                                make_document(kvp("$multiply", make_array("$total", "$$pct"))),
                                100)))))),
                    kvp("in", "$$discount")))))));

        mongocxx::pipeline outside;
        outside.match(make_document(kvp("_id", "o-0002")));
        outside.project(make_document(
            kvp("x", make_document(
                kvp("$let", make_document(kvp("vars", make_document(kvp("pct", 10))), kvp("in", "$$pct"))))),
            kvp("y", "$$pct")));

        mongocxx::pipeline capital;
        capital.match(make_document(kvp("_id", "o-0002")));
        capital.project(make_document(
            kvp("x", make_document(
                kvp("$let", make_document(kvp("vars", make_document(kvp("Pct", 10))), kvp("in", "$$Pct")))))));

        std::cout << "── переменная из того же vars" << std::endl;
        try {
            for (auto&& doc : orders.aggregate(same_vars)) {
                std::cout << bsoncxx::to_json(doc) << std::endl;
            }
        } catch (const mongocxx::operation_exception& e) {
            std::cout << "код " << e.code().value() << std::endl;
            std::cout << e.what() << std::endl;
        }

        std::cout << "── переменная вне in" << std::endl;
        try {
            for (auto&& doc : orders.aggregate(outside)) {
                std::cout << bsoncxx::to_json(doc) << std::endl;
            }
        } catch (const mongocxx::operation_exception& e) {
            std::cout << "код " << e.code().value() << std::endl;
            std::cout << e.what() << std::endl;
        }

        std::cout << "── имя с заглавной буквы" << std::endl;
        try {
            for (auto&& doc : orders.aggregate(capital)) {
                std::cout << bsoncxx::to_json(doc) << std::endl;
            }
        } catch (const mongocxx::operation_exception& e) {
            std::cout << "код " << e.code().value() << std::endl;
            std::cout << e.what() << std::endl;
        }
    }
}
