# Глава 5.5 · $let: переменные внутри выражения
# Пример 5 из 8 · §5 Переменная $let внутри $map · $let снаружи, $map внутри: скидка по позициям
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/05.rb
#   cd primery, затем ruby 05.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => "o-0003" } },
  { "$project" => {
    "_id" => 0,
    "number" => 1,
    "promo" => 1,
    "lines" => { "$let" => {
      "vars" => { "pct" => { "$switch" => {
        "branches" => [
          { "case" => { "$eq" => ["$promo", "SPRING10"] }, "then" => 10 },
          { "case" => { "$eq" => ["$promo", "LOYAL15"] }, "then" => 15 },
          { "case" => { "$eq" => ["$promo", "FIRST5"] }, "then" => 5 },
        ],
        "default" => 0,
      } } },
      "in" => { "$map" => {
        "input" => "$items",
        "in" => {
          "title" => "$$this.title",
          "pay" => { "$divide" => [
            { "$multiply" => [
              "$$this.qty",
              "$$this.price",
              { "$subtract" => [100, "$$pct"] },
            ] },
            100,
          ] },
        },
      } },
    } },
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
