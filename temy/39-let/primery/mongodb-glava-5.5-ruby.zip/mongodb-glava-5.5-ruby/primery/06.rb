# Глава 5.5 · $let: переменные внутри выражения
# Пример 6 из 8 · §6 Переменная из переменной · вложенный $let: переменная из переменной
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/06.rb
#   cd primery, затем ruby 06.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => "o-0004" } },
  { "$project" => {
    "_id" => 0,
    "number" => 1,
    "total" => 1,
    "check" => { "$let" => {
      "vars" => { "pct" => { "$switch" => {
        "branches" => [
          { "case" => { "$eq" => ["$promo", "SPRING10"] }, "then" => 10 },
          { "case" => { "$eq" => ["$promo", "LOYAL15"] }, "then" => 15 },
          { "case" => { "$eq" => ["$promo", "FIRST5"] }, "then" => 5 },
        ],
        "default" => 0,
      } } },
      "in" => { "$let" => {
        "vars" => { "discount" => { "$divide" => [
          { "$multiply" => ["$total", "$$pct"] },
          100,
        ] } },
        "in" => {
          "discount" => "$$discount",
          "pay" => { "$subtract" => ["$total", "$$discount"] },
        },
      } },
    } },
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
