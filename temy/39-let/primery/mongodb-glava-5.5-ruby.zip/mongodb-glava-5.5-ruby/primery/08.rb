# Глава 5.5 · $let: переменные внутри выражения
# Пример 8 из 8 · §8 Где переменная не видна · переменные, которые сервер не принимает
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/08.rb
#   cd primery, затем ruby 08.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
same_vars = [
  { "$match" => { "_id" => "o-0002" } },
  { "$project" => { "x" => { "$let" => {
    "vars" => {
      "pct" => 10,
      "discount" => { "$divide" => [{ "$multiply" => ["$total", "$$pct"] }, 100] },
    },
    "in" => "$$discount",
  } } } },
]

outside = [
  { "$match" => { "_id" => "o-0002" } },
  { "$project" => {
    "x" => { "$let" => { "vars" => { "pct" => 10 }, "in" => "$$pct" } },
    "y" => "$$pct",
  } },
]

capital = [
  { "$match" => { "_id" => "o-0002" } },
  { "$project" => { "x" => { "$let" => { "vars" => { "Pct" => 10 }, "in" => "$$Pct" } } } },
]

puts "── переменная из того же vars"
begin
  orders.aggregate(same_vars).each { |doc| puts doc.inspect }
rescue Mongo::Error::OperationFailure => e
  puts "код #{e.code}"
  puts e.document["errmsg"]
end

puts "── переменная вне in"
begin
  orders.aggregate(outside).each { |doc| puts doc.inspect }
rescue Mongo::Error::OperationFailure => e
  puts "код #{e.code}"
  puts e.document["errmsg"]
end

puts "── имя с заглавной буквы"
begin
  orders.aggregate(capital).each { |doc| puts doc.inspect }
rescue Mongo::Error::OperationFailure => e
  puts "код #{e.code}"
  puts e.document["errmsg"]
end
