# Глава 5.5 · $let: переменные внутри выражения
# Пример 1 из 8 · §1 Выражение $let · $let: средняя сумма позиции
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/01.rb
#   cd primery, затем ruby 01.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => { "$in" => ["o-0001", "o-0002", "o-0003", "o-0004", "o-0005"] } } },
  { "$project" => {
    "_id" => 0,
    "number" => 1,
    "avg_line" => { "$let" => {
      "vars" => {
        "sum" => { "$sum" => { "$map" => {
          "input" => "$items",
          "in" => { "$multiply" => ["$$this.qty", "$$this.price"] },
        } } },
        "lines" => { "$size" => "$items" },
      },
      "in" => { "$divide" => ["$$sum", "$$lines"] },
    } },
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
