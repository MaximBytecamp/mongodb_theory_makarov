# Глава 5.5 · $let: переменные внутри выражения
# Пример 7 из 8 · §7 Переменная и поле с одним именем · переменная total и поле total
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/07.rb
#   cd primery, затем ruby 07.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => "o-0002" } },
  { "$project" => {
    "_id" => 0,
    "both" => { "$let" => { "vars" => { "total" => 1 }, "in" => ["$total", "$$total"] } },
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
