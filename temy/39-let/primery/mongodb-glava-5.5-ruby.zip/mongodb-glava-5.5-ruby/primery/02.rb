# Глава 5.5 · $let: переменные внутри выражения
# Пример 2 из 8 · §2 Выбор значения: $switch · $switch: процент скидки по промокоду
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/02.rb
#   cd primery, затем ruby 02.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => { "$in" => ["o-0001", "o-0002", "o-0003", "o-0004", "o-0005"] } } },
  { "$project" => {
    "_id" => 0,
    "number" => 1,
    "promo" => 1,
    "pct" => { "$switch" => {
      "branches" => [
        { "case" => { "$eq" => ["$promo", "SPRING10"] }, "then" => 10 },
        { "case" => { "$eq" => ["$promo", "LOYAL15"] }, "then" => 15 },
        { "case" => { "$eq" => ["$promo", "FIRST5"] }, "then" => 5 },
      ],
      "default" => 0,
    } },
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
