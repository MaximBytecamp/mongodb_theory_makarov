# Глава 5.5 · $let: переменные внутри выражения
# Пример 4 из 8 · §4 Переменная внутри $group · скидки по каждому промокоду
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/04.rb
#   cd primery, затем ruby 04.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "promo" => { "$exists" => true } } },
  { "$group" => {
    "_id" => "$promo",
    "orders" => { "$sum" => 1 },
    "total" => { "$sum" => "$total" },
    "discount" => { "$sum" => { "$let" => {
      "vars" => { "pct" => { "$switch" => {
        "branches" => [
          { "case" => { "$eq" => ["$promo", "SPRING10"] }, "then" => 10 },
          { "case" => { "$eq" => ["$promo", "LOYAL15"] }, "then" => 15 },
          { "case" => { "$eq" => ["$promo", "FIRST5"] }, "then" => 5 },
        ],
        "default" => 0,
      } } },
      "in" => { "$divide" => [{ "$multiply" => ["$total", "$$pct"] }, 100] },
    } } },
  } },
  { "$sort" => { "_id" => 1 } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
