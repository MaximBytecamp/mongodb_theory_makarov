# Глава 5.1 · $arrayElemAt, $slice и $size
# Пример 3 из 11 · §3 Номер за границей массива · четвёртая позиция у заказов разной длины
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/03.rb
#   cd primery, затем ruby 03.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => { "$in" => ["o-0001", "o-0002", "o-0003", "o-0004", "o-0005"] } } },
  { "$project" => {
    "_id" => 0,
    "number" => 1,
    "fourth" => { "$arrayElemAt" => ["$items.title", 3] },
    "fourth_or" => { "$ifNull" => [{ "$arrayElemAt" => ["$items.title", 3] }, "нет"] },
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
