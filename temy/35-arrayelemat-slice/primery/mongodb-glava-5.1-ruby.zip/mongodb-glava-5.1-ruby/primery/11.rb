# Глава 5.1 · $arrayElemAt, $slice и $size
# Пример 11 из 11 · §9 Аргументы, которые сервер не принимает · аргументы, которые сервер не принимает
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/11.rb
#   cd primery, затем ruby 11.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
half_index = [
  { "$match" => { "_id" => "o-0002" } },
  { "$project" => { "x" => { "$arrayElemAt" => ["$items", 1.5] } } },
]

not_array = [
  { "$match" => { "_id" => "o-0002" } },
  { "$project" => { "x" => { "$arrayElemAt" => ["$promo", 0] } } },
]

slice_zero = [
  { "$match" => { "_id" => "o-0002" } },
  { "$project" => { "x" => { "$slice" => ["$items", 1, 0] } } },
]

size_string = [
  { "$match" => { "_id" => "o-0002" } },
  { "$project" => { "x" => { "$size" => "$promo" } } },
]

puts "── номер 1.5"
begin
  orders.aggregate(half_index).each { |doc| puts doc.inspect }
rescue Mongo::Error::OperationFailure => e
  puts "код #{e.code}"
  puts e.document["errmsg"]
end

puts "── строка вместо массива"
begin
  orders.aggregate(not_array).each { |doc| puts doc.inspect }
rescue Mongo::Error::OperationFailure => e
  puts "код #{e.code}"
  puts e.document["errmsg"]
end

puts "── $slice с числом 0"
begin
  orders.aggregate(slice_zero).each { |doc| puts doc.inspect }
rescue Mongo::Error::OperationFailure => e
  puts "код #{e.code}"
  puts e.document["errmsg"]
end

puts "── $size от строки"
begin
  orders.aggregate(size_string).each { |doc| puts doc.inspect }
rescue Mongo::Error::OperationFailure => e
  puts "код #{e.code}"
  puts e.document["errmsg"]
end
