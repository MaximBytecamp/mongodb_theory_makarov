# Глава 5.1 · $arrayElemAt, $slice и $size
# Пример 1 из 11 · §1 Номер элемента: $arrayElemAt · $arrayElemAt: первая и последняя позиция
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/01.rb
#   cd primery, затем ruby 01.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => "o-0002" } },
  { "$project" => {
    "_id" => 0,
    "number" => 1,
    "titles" => "$items.title",
    "first" => { "$arrayElemAt" => ["$items.title", 0] },
    "last" => { "$arrayElemAt" => ["$items.title", -1] },
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
