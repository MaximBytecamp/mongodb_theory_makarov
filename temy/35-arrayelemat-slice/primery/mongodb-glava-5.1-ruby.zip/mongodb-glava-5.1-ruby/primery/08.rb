# Глава 5.1 · $arrayElemAt, $slice и $size
# Пример 8 из 11 · §7 Часть массива: $slice · $slice: часть массива
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/08.rb
#   cd primery, затем ruby 08.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => "o-0002" } },
  { "$project" => {
    "_id" => 0,
    "first_two" => { "$slice" => ["$items.title", 2] },
    "last_one" => { "$slice" => ["$items.title", -1] },
    "from_1" => { "$slice" => ["$items.title", 1, 2] },
    "last_elem" => { "$arrayElemAt" => ["$items.title", -1] },
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
