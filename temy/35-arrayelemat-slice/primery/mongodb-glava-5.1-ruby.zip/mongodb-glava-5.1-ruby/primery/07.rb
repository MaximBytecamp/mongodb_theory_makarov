# Глава 5.1 · $arrayElemAt, $slice и $size
# Пример 7 из 11 · §6 $first и $last над массивом · $first и $last как выражения
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/07.rb
#   cd primery, затем ruby 07.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => { "$in" => ["o-0001", "o-0002", "o-0003", "o-0004", "o-0005"] } } },
  { "$project" => {
    "_id" => 0,
    "number" => 1,
    "first" => { "$first" => "$items.title" },
    "last" => { "$last" => "$items.title" },
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
