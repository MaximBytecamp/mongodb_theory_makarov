# Глава 5.1 · $arrayElemAt, $slice и $size
# Пример 2 из 11 · §2 Элемент-документ и путь с номером · элемент-документ и путь с номером
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/02.rb
#   cd primery, затем ruby 02.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => "o-0002" } },
  { "$project" => {
    "_id" => 0,
    "first_item" => { "$arrayElemAt" => ["$items", 0] },
    "by_path" => "$items.0.title",
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
