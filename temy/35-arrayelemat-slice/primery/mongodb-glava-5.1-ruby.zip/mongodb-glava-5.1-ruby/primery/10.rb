# Глава 5.1 · $arrayElemAt, $slice и $size
# Пример 10 из 11 · §8 Массивы товаров · диагональ и склады ноутбуков
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/10.rb
#   cd primery, затем ruby 10.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "category" => "ноутбуки" } },
  { "$project" => {
    "_id" => 0,
    "title" => 1,
    "screen" => { "$arrayElemAt" => ["$specs", 0] },
    "warehouses" => { "$size" => "$stock" },
    "first_two" => { "$slice" => ["$stock.warehouse", 2] },
  } },
]

products.aggregate(pipeline).each { |doc| puts doc.inspect }
