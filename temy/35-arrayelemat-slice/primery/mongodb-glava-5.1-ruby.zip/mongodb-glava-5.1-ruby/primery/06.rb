# Глава 5.1 · $arrayElemAt, $slice и $size
# Пример 6 из 11 · §5 Элемент массива как ключ группы · категория первой позиции
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/06.rb
#   cd primery, затем ruby 06.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$group" => {
    "_id" => { "$arrayElemAt" => ["$items.category", 0] },
    "orders" => { "$sum" => 1 },
  } },
  { "$sort" => { "orders" => -1, "_id" => 1 } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
