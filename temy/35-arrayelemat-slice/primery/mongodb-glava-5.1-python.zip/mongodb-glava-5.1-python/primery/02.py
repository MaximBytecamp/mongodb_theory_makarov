# Глава 5.1 · $arrayElemAt, $slice и $size
# Пример 2 из 11 · §2 Элемент-документ и путь с номером · элемент-документ и путь с номером
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": "o-0002"}},
    {"$project": {
        "_id": 0,
        "first_item": {"$arrayElemAt": ["$items", 0]},
        "by_path": "$items.0.title",
    }},
]

for doc in orders.aggregate(pipeline):
    print(doc)
