# Глава 5.1 · $arrayElemAt, $slice и $size
# Пример 6 из 11 · §5 Элемент массива как ключ группы · категория первой позиции
#
# Запуск из папки архива:
#   docker compose run --rm python primery/06.py
#   cd primery, затем python 06.py (Windows) или python3 06.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$group": {"_id": {"$arrayElemAt": ["$items.category", 0]}, "orders": {"$sum": 1}}},
    {"$sort": {"orders": -1, "_id": 1}},
]

for doc in orders.aggregate(pipeline):
    print(doc)
