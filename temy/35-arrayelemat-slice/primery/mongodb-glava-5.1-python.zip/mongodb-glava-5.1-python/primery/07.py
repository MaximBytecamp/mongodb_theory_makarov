# Глава 5.1 · $arrayElemAt, $slice и $size
# Пример 7 из 11 · §6 $first и $last над массивом · $first и $last как выражения
#
# Запуск из папки архива:
#   docker compose run --rm python primery/07.py
#   cd primery, затем python 07.py (Windows) или python3 07.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": {"$in": ["o-0001", "o-0002", "o-0003", "o-0004", "o-0005"]}}},
    {"$project": {
        "_id": 0,
        "number": 1,
        "first": {"$first": "$items.title"},
        "last": {"$last": "$items.title"},
    }},
]

for doc in orders.aggregate(pipeline):
    print(doc)
