# Глава 5.1 · $arrayElemAt, $slice и $size
# Пример 9 из 11 · §7 Часть массива: $slice · $slice за границей массива
#
# Запуск из папки архива:
#   docker compose run --rm python primery/09.py
#   cd primery, затем python 09.py (Windows) или python3 09.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": "o-0002"}},
    {"$project": {
        "_id": 0,
        "from_5": {"$slice": ["$items.title", 5, 2]},
        "last_5": {"$slice": ["$items.title", -5]},
    }},
]

for doc in orders.aggregate(pipeline):
    print(doc)
