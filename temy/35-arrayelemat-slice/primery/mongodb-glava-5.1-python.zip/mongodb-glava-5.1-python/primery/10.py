# Глава 5.1 · $arrayElemAt, $slice и $size
# Пример 10 из 11 · §8 Массивы товаров · диагональ и склады ноутбуков
#
# Запуск из папки архива:
#   docker compose run --rm python primery/10.py
#   cd primery, затем python 10.py (Windows) или python3 10.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"category": "ноутбуки"}},
    {"$project": {
        "_id": 0,
        "title": 1,
        "screen": {"$arrayElemAt": ["$specs", 0]},
        "warehouses": {"$size": "$stock"},
        "first_two": {"$slice": ["$stock.warehouse", 2]},
    }},
]

for doc in products.aggregate(pipeline):
    print(doc)
