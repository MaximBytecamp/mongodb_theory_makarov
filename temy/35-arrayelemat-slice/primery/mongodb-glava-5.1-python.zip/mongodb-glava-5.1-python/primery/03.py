# Глава 5.1 · $arrayElemAt, $slice и $size
# Пример 3 из 11 · §3 Номер за границей массива · четвёртая позиция у заказов разной длины
#
# Запуск из папки архива:
#   docker compose run --rm python primery/03.py
#   cd primery, затем python 03.py (Windows) или python3 03.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": {"$in": ["o-0001", "o-0002", "o-0003", "o-0004", "o-0005"]}}},
    {"$project": {
        "_id": 0,
        "number": 1,
        "fourth": {"$arrayElemAt": ["$items.title", 3]},
        "fourth_or": {"$ifNull": [{"$arrayElemAt": ["$items.title", 3]}, "нет"]},
    }},
]

for doc in orders.aggregate(pipeline):
    print(doc)
