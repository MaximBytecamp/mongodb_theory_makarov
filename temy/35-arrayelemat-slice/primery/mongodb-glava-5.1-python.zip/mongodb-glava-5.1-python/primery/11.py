# Глава 5.1 · $arrayElemAt, $slice и $size
# Пример 11 из 11 · §9 Аргументы, которые сервер не принимает · аргументы, которые сервер не принимает
#
# Запуск из папки архива:
#   docker compose run --rm python primery/11.py
#   cd primery, затем python 11.py (Windows) или python3 11.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
from pymongo.errors import OperationFailure

half_index = [
    {"$match": {"_id": "o-0002"}},
    {"$project": {"x": {"$arrayElemAt": ["$items", 1.5]}}},
]

not_array = [
    {"$match": {"_id": "o-0002"}},
    {"$project": {"x": {"$arrayElemAt": ["$promo", 0]}}},
]

slice_zero = [
    {"$match": {"_id": "o-0002"}},
    {"$project": {"x": {"$slice": ["$items", 1, 0]}}},
]

size_string = [
    {"$match": {"_id": "o-0002"}},
    {"$project": {"x": {"$size": "$promo"}}},
]

print("── номер 1.5")
try:
    for doc in orders.aggregate(half_index):
        print(doc)
except OperationFailure as e:
    print("код", e.code)
    print(e.details["errmsg"])

print("── строка вместо массива")
try:
    for doc in orders.aggregate(not_array):
        print(doc)
except OperationFailure as e:
    print("код", e.code)
    print(e.details["errmsg"])

print("── $slice с числом 0")
try:
    for doc in orders.aggregate(slice_zero):
        print(doc)
except OperationFailure as e:
    print("код", e.code)
    print(e.details["errmsg"])

print("── $size от строки")
try:
    for doc in orders.aggregate(size_string):
        print(doc)
except OperationFailure as e:
    print("код", e.code)
    print(e.details["errmsg"])
