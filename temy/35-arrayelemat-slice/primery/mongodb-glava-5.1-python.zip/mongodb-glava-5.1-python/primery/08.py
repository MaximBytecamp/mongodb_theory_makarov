# Глава 5.1 · $arrayElemAt, $slice и $size
# Пример 8 из 11 · §7 Часть массива: $slice · $slice: часть массива
#
# Запуск из папки архива:
#   docker compose run --rm python primery/08.py
#   cd primery, затем python 08.py (Windows) или python3 08.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": "o-0002"}},
    {"$project": {
        "_id": 0,
        "first_two": {"$slice": ["$items.title", 2]},
        "last_one": {"$slice": ["$items.title", -1]},
        "from_1": {"$slice": ["$items.title", 1, 2]},
        "last_elem": {"$arrayElemAt": ["$items.title", -1]},
    }},
]

for doc in orders.aggregate(pipeline):
    print(doc)
