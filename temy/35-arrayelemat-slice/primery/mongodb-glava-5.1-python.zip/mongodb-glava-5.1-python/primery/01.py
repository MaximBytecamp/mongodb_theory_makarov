# Глава 5.1 · $arrayElemAt, $slice и $size
# Пример 1 из 11 · §1 Номер элемента: $arrayElemAt · $arrayElemAt: первая и последняя позиция
#
# Запуск из папки архива:
#   docker compose run --rm python primery/01.py
#   cd primery, затем python 01.py (Windows) или python3 01.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": "o-0002"}},
    {"$project": {
        "_id": 0,
        "number": 1,
        "titles": "$items.title",
        "first": {"$arrayElemAt": ["$items.title", 0]},
        "last": {"$arrayElemAt": ["$items.title", -1]},
    }},
]

for doc in orders.aggregate(pipeline):
    print(doc)
