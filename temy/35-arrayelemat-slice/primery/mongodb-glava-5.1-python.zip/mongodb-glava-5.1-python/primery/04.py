# Глава 5.1 · $arrayElemAt, $slice и $size
# Пример 4 из 11 · §4 Длина массива: $size · $size: число позиций
#
# Запуск из папки архива:
#   docker compose run --rm python primery/04.py
#   cd primery, затем python 04.py (Windows) или python3 04.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": {"$in": ["o-0001", "o-0002", "o-0003", "o-0004", "o-0005"]}}},
    {"$project": {
        "_id": 0,
        "number": 1,
        "lines": {"$size": "$items"},
        "last_by_size": {"$arrayElemAt": [
            "$items.title",
            {"$subtract": [{"$size": "$items"}, 1]},
        ]},
    }},
]

for doc in orders.aggregate(pipeline):
    print(doc)
