# Глава 5.1 · $arrayElemAt, $slice и $size — примеры на Python

Архив к «Справочнику по MongoDB»: все примеры главы готовыми программами, данные баз и стенд в Docker.
Глава: https://maximbytecamp.github.io/mongodb_theory_makarov/temy/35-arrayelemat-slice/index.html

Язык: **Python** · драйвер PyMongo · сервер MongoDB 7.

## Что в архиве

```text
mongodb-glava-5.1-python/
  README.md         эта инструкция
  primery/          примеры главы — по программе на пример
    01.py … 11.py
  compose.yaml      стенд в Docker: сервер, базы, mongo-express, Python
  docker/           образ с драйвером Python и скрипт запуска run.sh
  stend/seed/       данные баз: 12 файлов JSON
  stend/load.ps1    загрузка данных на установленный сервер — Windows
  stend/load.sh     то же — macOS и Linux
requirements.txt  драйвер PyMongo для pip и для образа Docker
```

## Порядок работы

1. **Базы.** Глава **только читает** данные — сбрасывать базы не нужно.
2. **Примеры — по порядку, каждый один раз.** Пример в главе рассчитан на данные, которые оставил
   предыдущий. Если запустить пример дважды или пропустить, числа разойдутся с книгой — тогда
   сбросьте базы и начните с `01.py`.
3. **Сверка.** Что должна напечатать каждая программа — в разделе «Примеры и выводы» ниже.
   Отличаться могут только `_id`, которые выдаёт сервер, текущие дата и время и порядок
   в списке коллекций: сервер отдаёт их имена в произвольном порядке. У документа, который
   создан обновлением с `upsert`, поля тоже могут идти в другом порядке — значения при этом те же.

Подойдёт любой из двух способов. Адрес сервера в обоих — `mongodb://localhost:27017`, код примеров
одинаковый.

| Способ | Что нужно | Когда подходит |
|---|---|---|
| **1. Docker** | Docker Desktop | Compass и сервер не установились или не подключаются; ничего, кроме Docker, ставить не нужно |
| **2. Сервер и Compass** | MongoDB Server, Compass, Python с драйвером | сервер и Compass уже стоят и подключаются |

## Способ 1. Docker

Docker Desktop — с [docker.com](https://www.docker.com/products/docker-desktop/); на Linux — Docker Engine.
Перед командами Docker Desktop должен быть запущен. Команды одинаковые в PowerShell, cmd и терминале
macOS/Linux; выполняйте их **из папки архива** — там, где лежит `compose.yaml`.

1. Поднять сервер и загрузить базы курса:

   ```bash
   docker compose up -d
   ```

2. Запустить пример — путь к файлу пишется от папки архива:

   ```bash
   docker compose run --rm python primery/01.py
   ```

   При первом запуске Docker соберёт образ с драйвером Python — это пара минут.
   Дальше запуск идёт за секунды.

3. Все примеры главы подряд, по порядку, одной командой:

   ```bash
   docker compose run --rm python primery
   ```

   Перед каждой программой печатается её имя: `── primery/01.py ──`.

**Смотреть данные.** Compass не нужен: в браузере откройте http://localhost:8081, логин `student`,
пароль `student` — это mongo-express, в нём видны базы, коллекции и документы. Если Compass
установлен, он подключается к этому же серверу по адресу `mongodb://localhost:27017`.

**Консоль сервера:** `docker compose exec mongo mongosh`.

**Остановить и удалить:**

```bash
docker compose stop        # остановить; данные останутся
docker compose down        # удалить контейнеры; данные останутся
docker compose down -v     # удалить всё вместе с данными
```

Архивы всех глав пользуются одним и тем же сервером и данными: после этой главы можно распаковать
архив следующей и работать там, не удаляя стенд.

## Способ 2. Установленный сервер MongoDB и Compass

Нужны MongoDB Server 7 или 8 и MongoDB Compass — установка по шагам в
[главе 1.0а](https://maximbytecamp.github.io/mongodb_theory_makarov/temy/00a-windows-10-mongodb-7/index.html).
Проверка: Compass подключается к `mongodb://localhost:27017`.

### Шаг 1. Загрузить базы курса

Windows, PowerShell, из папки архива — нужен `mongoimport` из MongoDB Command Line Database Tools:

```powershell
powershell -ExecutionPolicy Bypass -File stend\load.ps1
```

macOS и Linux (`mongoimport`: `brew tap mongodb/brew && brew install mongodb-database-tools`):

```bash
bash stend/load.sh
```

Скрипт пересоздаёт коллекции целиком, поэтому он же сбрасывает базы: повторный запуск ничего не двоит.

**Без `mongoimport` — через Compass.** Подключитесь к `mongodb://localhost:27017`, нажмите **Create database**,
затем в коллекции **Add data → Import JSON or CSV file** и выберите файл из `stend/seed`. Имя файла
подсказывает, куда класть: `shop.orders.json` — база `shop`, коллекция `orders`. Так загружаются все
12 файлов; пошагово с кадрами — [глава 1.0, §7](https://maximbytecamp.github.io/mongodb_theory_makarov/temy/00-uchebnye-bazy/index.html#s7).

После загрузки в Compass нажмите **Refresh**: в списке должны быть базы `shop`, `hh`, `logs`, `org`
и `sandbox`. В `shop.products` — 21 документ, в `shop.orders` — 120.

### Шаг 2. Драйвер Python и запуск

Python 3.10 или новее — с [python.org](https://www.python.org/downloads/). На Windows в установщике
отметьте **Add python.exe to PATH**.

Windows, PowerShell, из папки архива:

```powershell
python -m pip install -r requirements.txt
cd primery
python 01.py
```

macOS и Linux — драйвер ставится в виртуальное окружение: системный Python не даёт ставить пакеты напрямую.

```bash
python3 -m venv .venv
source .venv/bin/activate          # в каждом новом терминале снова
pip install -r requirements.txt
cd primery
python3 01.py
```

Если `venv` не найден на Linux: `sudo apt install python3-venv`.

Остальные примеры запускаются так же: `02.py`, `03.py` и далее. Если сервер слушает другой адрес,
задайте его переменной `MONGO_URI` — программы глав 1.2–1.8 читают её при подключении.

## Примеры и выводы

| Файл | Параграф главы | Что делает |
|---|---|---|
| `01.py` | §1 Номер элемента: $arrayElemAt | $arrayElemAt: первая и последняя позиция |
| `02.py` | §2 Элемент-документ и путь с номером | элемент-документ и путь с номером |
| `03.py` | §3 Номер за границей массива | четвёртая позиция у заказов разной длины |
| `04.py` | §4 Длина массива: $size | $size: число позиций |
| `05.py` | §4 Длина массива: $size | заказы по числу позиций |
| `06.py` | §5 Элемент массива как ключ группы | категория первой позиции |
| `07.py` | §6 $first и $last над массивом | $first и $last как выражения |
| `08.py` | §7 Часть массива: $slice | $slice: часть массива |
| `09.py` | §7 Часть массива: $slice | $slice за границей массива |
| `10.py` | §8 Массивы товаров | диагональ и склады ноутбуков |
| `11.py` | §9 Аргументы, которые сервер не принимает | аргументы, которые сервер не принимает |

### 01.py · §1 Номер элемента: $arrayElemAt

$arrayElemAt: первая и последняя позиция.

```text
{'number': '2026-0002', 'titles': ['Ноутбук ASUS VivoBook 15', 'Веб-камера Logitech C920', 'Наушники Sony WH-1000XM5'], 'first': 'Ноутбук ASUS VivoBook 15', 'last': 'Наушники Sony WH-1000XM5'}
```

### 02.py · §2 Элемент-документ и путь с номером

Элемент-документ и путь с номером.

```text
{'first_item': {'sku': 'SKU-NB-002', 'title': 'Ноутбук ASUS VivoBook 15', 'category': 'ноутбуки', 'qty': 1, 'price': 51490}, 'by_path': []}
```

### 03.py · §3 Номер за границей массива

Четвёртая позиция у заказов разной длины.

```text
{'number': '2026-0001', 'fourth_or': 'нет'}
{'number': '2026-0002', 'fourth_or': 'нет'}
{'number': '2026-0003', 'fourth_or': 'нет'}
{'number': '2026-0004', 'fourth': 'Powerbank Anker 20000 мА·ч', 'fourth_or': 'Powerbank Anker 20000 мА·ч'}
{'number': '2026-0005', 'fourth_or': 'нет'}
```

### 04.py · §4 Длина массива: $size

$size: число позиций.

```text
{'number': '2026-0001', 'lines': 1, 'last_by_size': 'Рюкзак для ноутбука Xiaomi'}
{'number': '2026-0002', 'lines': 3, 'last_by_size': 'Наушники Sony WH-1000XM5'}
{'number': '2026-0003', 'lines': 2, 'last_by_size': 'Мышь Logitech MX Master 3S'}
{'number': '2026-0004', 'lines': 4, 'last_by_size': 'Powerbank Anker 20000 мА·ч'}
{'number': '2026-0005', 'lines': 1, 'last_by_size': 'Смартфон Xiaomi Redmi Note 13'}
```

### 05.py · §4 Длина массива: $size

Заказы по числу позиций.

```text
{'_id': 1, 'orders': 39}
{'_id': 2, 'orders': 34}
{'_id': 3, 'orders': 24}
{'_id': 4, 'orders': 23}
```

### 06.py · §5 Элемент массива как ключ группы

Категория первой позиции.

```text
{'_id': 'ноутбуки', 'orders': 32}
{'_id': 'периферия', 'orders': 26}
{'_id': 'комплектующие', 'orders': 25}
{'_id': 'смартфоны', 'orders': 25}
{'_id': 'аксессуары', 'orders': 12}
```

### 07.py · §6 $first и $last над массивом

$first и $last как выражения.

```text
{'number': '2026-0001', 'first': 'Рюкзак для ноутбука Xiaomi', 'last': 'Рюкзак для ноутбука Xiaomi'}
{'number': '2026-0002', 'first': 'Ноутбук ASUS VivoBook 15', 'last': 'Наушники Sony WH-1000XM5'}
{'number': '2026-0003', 'first': 'Ноутбук HP Pavilion 14', 'last': 'Мышь Logitech MX Master 3S'}
{'number': '2026-0004', 'first': 'Веб-камера Logitech C920', 'last': 'Powerbank Anker 20000 мА·ч'}
{'number': '2026-0005', 'first': 'Смартфон Xiaomi Redmi Note 13', 'last': 'Смартфон Xiaomi Redmi Note 13'}
```

### 08.py · §7 Часть массива: $slice

$slice: часть массива.

```text
{'first_two': ['Ноутбук ASUS VivoBook 15', 'Веб-камера Logitech C920'], 'last_one': ['Наушники Sony WH-1000XM5'], 'from_1': ['Веб-камера Logitech C920', 'Наушники Sony WH-1000XM5'], 'last_elem': 'Наушники Sony WH-1000XM5'}
```

### 09.py · §7 Часть массива: $slice

$slice за границей массива.

```text
{'from_5': [], 'last_5': ['Ноутбук ASUS VivoBook 15', 'Веб-камера Logitech C920', 'Наушники Sony WH-1000XM5']}
```

### 10.py · §8 Массивы товаров

Диагональ и склады ноутбуков.

```text
{'title': 'Ноутбук Lenovo IdeaPad 3', 'screen': '15.6"', 'warehouses': 1, 'first_two': ['Санкт-Петербург']}
{'title': 'Ноутбук ASUS VivoBook 15', 'screen': '15.6"', 'warehouses': 3, 'first_two': ['Санкт-Петербург', 'Москва-1']}
{'title': 'Ноутбук HP Pavilion 14', 'screen': '14"', 'warehouses': 1, 'first_two': ['Москва-2']}
{'title': 'Ноутбук Apple MacBook Air 13', 'screen': '13.6"', 'warehouses': 2, 'first_two': ['Москва-2', 'Екатеринбург']}
{'title': 'Ноутбук Acer Nitro V15', 'screen': '15.6"', 'warehouses': 2, 'first_two': ['Москва-2', 'Екатеринбург']}
```

### 11.py · §9 Аргументы, которые сервер не принимает

Аргументы, которые сервер не принимает.

```text
── номер 1.5
код 28691
PlanExecutor error during aggregation :: caused by :: $arrayElemAt's second argument must be representable as a 32-bit integer: 1.5
── строка вместо массива
код 28689
PlanExecutor error during aggregation :: caused by :: $arrayElemAt's first argument must be an array, but is string
── $slice с числом 0
код 28729
PlanExecutor error during aggregation :: caused by :: Third argument to $slice must be positive: 0
── $size от строки
код 17124
PlanExecutor error during aggregation :: caused by :: The argument to $size must be an array, but was of type: string
```

## Частые ошибки

| Что видно | Причина | Что сделать |
|---|---|---|
| `port is already allocated`, `address already in use` на `docker compose up -d` | порт 27017 занят: уже работает установленный MongoDB или стенд `mongodb-practice` | остановите тот сервер или создайте рядом с `compose.yaml` файл `.env` со строкой `MONGO_PORT=27018`: в PowerShell — `Set-Content .env "MONGO_PORT=27018"`, в bash — `echo "MONGO_PORT=27018" > .env`. Программы в Docker это не затрагивает, Compass подключайте к `localhost:27018` |
| `Cannot connect to the Docker daemon`, `error during connect` | Docker Desktop не запущен | запустите Docker Desktop и дождитесь зелёного статуса Engine running |
| `ServerSelectionTimeoutError`, `Connection refused`, `No server available` | сервер не запущен | Docker: `docker compose up -d`; способ 2 — запустите службу MongoDB |
| `Файл не найден: …` | путь написан не от папки архива или команда выполнена в другой папке | перейдите в папку, где лежит `compose.yaml`, и пишите путь `primery/01.py` |
| числа в выводе не совпадают с README | пример запускали дважды, пропустили или базы не сброшены | сбросьте базы и запустите примеры с первого по порядку |

В PowerShell не используйте `echo … > .env`: Windows PowerShell 5 пишет такой файл в UTF-16, и Docker
Compose его не прочитает.
