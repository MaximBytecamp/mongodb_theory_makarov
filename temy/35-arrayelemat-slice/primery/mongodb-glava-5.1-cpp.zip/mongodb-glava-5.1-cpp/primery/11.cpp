// Глава 5.1 · $arrayElemAt, $slice и $size
// Пример 11 из 11 · §9 Аргументы, которые сервер не принимает · аргументы, которые сервер не принимает
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/11.cpp
//   cd primery, затем g++ -std=c++17 11.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto orders = db["orders"];
    auto products = db["products"];
    auto customers = db["customers"];
    auto sandbox = client["sandbox"];

    {
        // ── пример из главы ──────────────────────────────────────
        mongocxx::pipeline half_index;
        half_index.match(make_document(kvp("_id", "o-0002")));
        half_index.project(make_document(
            kvp("x", make_document(kvp("$arrayElemAt", make_array("$items", 1.5))))));

        mongocxx::pipeline not_array;
        not_array.match(make_document(kvp("_id", "o-0002")));
        not_array.project(make_document(
            kvp("x", make_document(kvp("$arrayElemAt", make_array("$promo", 0))))));

        mongocxx::pipeline slice_zero;
        slice_zero.match(make_document(kvp("_id", "o-0002")));
        slice_zero.project(make_document(kvp("x", make_document(kvp("$slice", make_array("$items", 1, 0))))));

        mongocxx::pipeline size_string;
        size_string.match(make_document(kvp("_id", "o-0002")));
        size_string.project(make_document(kvp("x", make_document(kvp("$size", "$promo")))));

        std::cout << "── номер 1.5" << std::endl;
        try {
            for (auto&& doc : orders.aggregate(half_index)) {
                std::cout << bsoncxx::to_json(doc) << std::endl;
            }
        } catch (const mongocxx::operation_exception& e) {
            std::cout << "код " << e.code().value() << std::endl;
            std::cout << e.what() << std::endl;
        }

        std::cout << "── строка вместо массива" << std::endl;
        try {
            for (auto&& doc : orders.aggregate(not_array)) {
                std::cout << bsoncxx::to_json(doc) << std::endl;
            }
        } catch (const mongocxx::operation_exception& e) {
            std::cout << "код " << e.code().value() << std::endl;
            std::cout << e.what() << std::endl;
        }

        std::cout << "── $slice с числом 0" << std::endl;
        try {
            for (auto&& doc : orders.aggregate(slice_zero)) {
                std::cout << bsoncxx::to_json(doc) << std::endl;
            }
        } catch (const mongocxx::operation_exception& e) {
            std::cout << "код " << e.code().value() << std::endl;
            std::cout << e.what() << std::endl;
        }

        std::cout << "── $size от строки" << std::endl;
        try {
            for (auto&& doc : orders.aggregate(size_string)) {
                std::cout << bsoncxx::to_json(doc) << std::endl;
            }
        } catch (const mongocxx::operation_exception& e) {
            std::cout << "код " << e.code().value() << std::endl;
            std::cout << e.what() << std::endl;
        }
    }
}
