//go:build ignore

// Глава 5.1 · $arrayElemAt, $slice и $size
// Пример 11 из 11 · §9 Аргументы, которые сервер не принимает · аргументы, которые сервер не принимает
//
// Запуск из папки архива:
//   docker compose run --rm go primery/11.go
//   cd primery, затем go run 11.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────

var ce mongo.CommandError

func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	orders := db.Collection("orders")
	products := db.Collection("products")
	customers := db.Collection("customers")
	sandbox := client.Database("sandbox")
	_, _, _, _, _ = db, orders, products, customers, sandbox

	{
		// ── пример из главы ──────────────────────────────────────
		halfIndex := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{{Key: "_id", Value: "o-0002"}}}},
		    {{Key: "$project", Value: bson.D{
		        {Key: "x", Value: bson.D{{Key: "$arrayElemAt", Value: bson.A{"$items", 1.5}}}}}}},
		}

		notArray := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{{Key: "_id", Value: "o-0002"}}}},
		    {{Key: "$project", Value: bson.D{
		        {Key: "x", Value: bson.D{{Key: "$arrayElemAt", Value: bson.A{"$promo", 0}}}}}}},
		}

		sliceZero := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{{Key: "_id", Value: "o-0002"}}}},
		    {{Key: "$project", Value: bson.D{
		        {Key: "x", Value: bson.D{{Key: "$slice", Value: bson.A{"$items", 1, 0}}}}}}},
		}

		sizeString := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{{Key: "_id", Value: "o-0002"}}}},
		    {{Key: "$project", Value: bson.D{{Key: "x", Value: bson.D{{Key: "$size", Value: "$promo"}}}}}},
		}

		fmt.Println("── номер 1.5")
		_, err := orders.Aggregate(ctx, halfIndex)
		if errors.As(err, &ce) {
		    fmt.Println("код", ce.Code)
		    fmt.Println(ce.Message)
		}

		fmt.Println("── строка вместо массива")
		_, err = orders.Aggregate(ctx, notArray)
		if errors.As(err, &ce) {
		    fmt.Println("код", ce.Code)
		    fmt.Println(ce.Message)
		}

		fmt.Println("── $slice с числом 0")
		_, err = orders.Aggregate(ctx, sliceZero)
		if errors.As(err, &ce) {
		    fmt.Println("код", ce.Code)
		    fmt.Println(ce.Message)
		}

		fmt.Println("── $size от строки")
		_, err = orders.Aggregate(ctx, sizeString)
		if errors.As(err, &ce) {
		    fmt.Println("код", ce.Code)
		    fmt.Println(ce.Message)
		}
	}
}
