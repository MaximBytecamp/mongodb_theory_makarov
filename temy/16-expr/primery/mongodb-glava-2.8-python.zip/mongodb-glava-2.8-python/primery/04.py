# Глава 2.8 · Сравнение полей между собой: $expr
# Пример 4 из 6 · §4 Вычисления внутри $expr · ширина вилки от 50 000
#
# Запуск из папки архива:
#   docker compose run --rm python primery/04.py
#   cd primery, затем python 04.py (Windows) или python3 04.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
filtr = {"$expr": {"$gte": [{"$subtract": ["$salary.to", "$salary.from"]}, 50000]}}

for doc in vacancies.find(filtr, {"_id": 0, "title": 1, "salary": 1}):
    print(doc)
