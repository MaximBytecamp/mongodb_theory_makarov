# Глава 2.8 · Сравнение полей между собой: $expr
# Пример 5 из 6 · §5 $expr вместе с обычными условиями · $expr вместе с обычным условием
#
# Запуск из папки архива:
#   docker compose run --rm python primery/05.py
#   cd primery, затем python 05.py (Windows) или python3 05.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
filtr = {"city": "Москва",
         "$expr": {"$gte": [{"$subtract": ["$salary.to", "$salary.from"]}, 50000]}}

for doc in vacancies.find(filtr, {"_id": 0, "title": 1, "city": 1, "salary": 1}):
    print(doc)
