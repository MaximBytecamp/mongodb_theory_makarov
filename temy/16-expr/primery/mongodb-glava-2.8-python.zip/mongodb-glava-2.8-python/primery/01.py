# Глава 2.8 · Сравнение полей между собой: $expr
# Пример 1 из 6 · §1 Задача, которую фильтр не решает · имя поля вместо значения
#
# Запуск из папки архива:
#   docker compose run --rm python primery/01.py
#   cd primery, затем python 01.py (Windows) или python3 01.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
print("всего вакансий:              ", vacancies.count_documents({}))
print("salary.from $lt \"$salary.to\":", vacancies.count_documents({"salary.from": {"$lt": "$salary.to"}}))
