# Глава 2.8 · Сравнение полей между собой: $expr
# Пример 2 из 6 · §2 $expr: выражение вместо условия · два поля одного документа
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
print("нижняя граница меньше верхней:", vacancies.count_documents({"$expr": {"$lt": ["$salary.from", "$salary.to"]}}))
print("нижняя граница больше верхней:", vacancies.count_documents({"$expr": {"$gt": ["$salary.from", "$salary.to"]}}))
