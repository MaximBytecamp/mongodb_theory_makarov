# Глава 2.8 · Сравнение полей между собой: $expr
# Пример 6 из 6 · §6 Типы и отсутствующее поле в выражении · типы и отсутствующее поле в $expr
#
# Запуск из папки архива:
#   docker compose run --rm python primery/06.py
#   cd primery, затем python 06.py (Windows) или python3 06.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
from datetime import datetime

sep01 = datetime(2026, 9, 1)

print("vacancies: $expr salary > 100000:", vacancies.count_documents({"$expr": {"$gt": ["$salary", 100000]}}))
print("vacancies: salary $gt 100000:    ", vacancies.count_documents({"salary": {"$gt": 100000}}))
print("resumes: $expr updated < 01.09:  ", resumes.count_documents({"$expr": {"$lt": ["$updated", sep01]}}))
print("resumes: updated $lt 01.09:      ", resumes.count_documents({"updated": {"$lt": sep01}}))
