# Глава 2.8 · Сравнение полей между собой: $expr
# Пример 3 из 6 · §3 Проверка данных: перевёрнутая вилка · проверка черновиков вакансий
#
# Запуск из папки архива:
#   docker compose run --rm python primery/03.py
#   cd primery, затем python 03.py (Windows) или python3 03.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
# черновики вакансий: коллекция создаётся заново при каждом запуске
drafts = client["sandbox"]["vacancy_drafts"]
drafts.drop()
drafts.insert_one({"_id": "v-901",
                   "title": "Стажёр-аналитик",
                   "salary": {"from": 50000, "to": 70000}})
drafts.insert_one({"_id": "v-902",
                   "title": "Тестировщик",
                   "salary": {"from": 90000, "to": 60000}})

print("черновиков:       ", drafts.count_documents({}))
print("вилка перевёрнута:", drafts.count_documents({"$expr": {"$gt": ["$salary.from", "$salary.to"]}}))

for doc in drafts.find({"$expr": {"$gt": ["$salary.from", "$salary.to"]}}, {"title": 1, "salary": 1}):
    print(doc)
