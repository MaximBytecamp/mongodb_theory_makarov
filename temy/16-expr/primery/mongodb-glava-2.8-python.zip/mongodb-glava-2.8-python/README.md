# Глава 2.8 · Сравнение полей между собой: $expr — примеры на Python

Архив к «Справочнику по MongoDB»: все примеры главы готовыми программами, учебные базы и стенд в Docker.
Глава: https://maximbytecamp.github.io/mongodb_theory_makarov/temy/16-expr/index.html

Язык: **Python** · драйвер PyMongo · сервер MongoDB 7.

## Что в архиве

```text
mongodb-glava-2.8-python/
  README.md         эта инструкция
  primery/          примеры главы — по программе на пример
    01.py … 06.py
  compose.yaml      стенд в Docker: сервер, базы, mongo-express, Python
  docker/           образ с драйвером Python и скрипт запуска run.sh
  stend/seed/       учебные данные: 12 файлов JSON
  stend/load.ps1    загрузка данных на установленный сервер — Windows
  stend/load.sh     то же — macOS и Linux
requirements.txt  драйвер PyMongo для pip и для образа Docker
```

## Порядок работы

1. **Базы.** Глава **меняет песочницу** — базу `sandbox`. Перед первым примером верните базы в исходное состояние, иначе числа в выводах разойдутся с книгой. Команда сброса — в описании способа, которым вы пользуетесь.
2. **Примеры — по порядку, каждый один раз.** Пример в главе рассчитан на данные, которые оставил
   предыдущий. Если запустить пример дважды или пропустить, числа разойдутся с книгой — тогда
   сбросьте базы и начните с `01.py`.
3. **Сверка.** Что должна напечатать каждая программа — в разделе «Примеры и выводы» ниже.
   Отличаться могут только `_id`, которые выдаёт сервер, текущие дата и время и порядок
   в списке коллекций: сервер отдаёт их имена в произвольном порядке. У документа, который
   создан обновлением с `upsert`, поля тоже могут идти в другом порядке — значения при этом те же.

Подойдёт любой из двух способов. Адрес сервера в обоих — `mongodb://localhost:27017`, код примеров
одинаковый.

| Способ | Что нужно | Когда подходит |
|---|---|---|
| **1. Docker** | Docker Desktop | Compass и сервер не установились или не подключаются; ничего, кроме Docker, ставить не нужно |
| **2. Сервер и Compass** | MongoDB Server, Compass, Python с драйвером | сервер и Compass уже стоят и подключаются |

## Способ 1. Docker

Docker Desktop — с [docker.com](https://www.docker.com/products/docker-desktop/); на Linux — Docker Engine.
Перед командами Docker Desktop должен быть запущен. Команды одинаковые в PowerShell, cmd и терминале
macOS/Linux; выполняйте их **из папки архива** — там, где лежит `compose.yaml`.

1. Поднять сервер и загрузить учебные базы:

   ```bash
   docker compose up -d
   ```

2. Вернуть базы в исходное состояние — глава меняет песочницу:

   ```bash
   docker compose run --rm reset
   ```

3. Запустить пример — путь к файлу пишется от папки архива:

   ```bash
   docker compose run --rm python primery/01.py
   ```

   При первом запуске Docker соберёт образ с драйвером Python — это пара минут.
   Дальше запуск идёт за секунды.

4. Все примеры главы подряд, по порядку, одной командой:

   ```bash
   docker compose run --rm python primery
   ```

   Перед каждой программой печатается её имя: `── primery/01.py ──`.

**Смотреть данные.** Compass не нужен: в браузере откройте http://localhost:8081, логин `student`,
пароль `student` — это mongo-express, в нём видны базы, коллекции и документы. Если Compass
установлен, он подключается к этому же серверу по адресу `mongodb://localhost:27017`.

**Консоль сервера:** `docker compose exec mongo mongosh`.

**Остановить и удалить:**

```bash
docker compose stop        # остановить; данные останутся
docker compose down        # удалить контейнеры; данные останутся
docker compose down -v     # удалить всё вместе с данными
```

Архивы всех глав пользуются одним и тем же сервером и данными: после этой главы можно распаковать
архив следующей и работать там, не удаляя стенд.

## Способ 2. Установленный сервер MongoDB и Compass

Нужны MongoDB Server 7 или 8 и MongoDB Compass — установка по шагам в
[главе 1.0а](https://maximbytecamp.github.io/mongodb_theory_makarov/temy/00a-windows-10-mongodb-7/index.html).
Проверка: Compass подключается к `mongodb://localhost:27017`.

### Шаг 1. Загрузить учебные базы

Windows, PowerShell, из папки архива — нужен `mongoimport` из MongoDB Command Line Database Tools:

```powershell
powershell -ExecutionPolicy Bypass -File stend\load.ps1
```

macOS и Linux (`mongoimport`: `brew tap mongodb/brew && brew install mongodb-database-tools`):

```bash
bash stend/load.sh
```

Скрипт пересоздаёт коллекции целиком, поэтому он же сбрасывает базы: повторный запуск ничего не двоит.

**Без `mongoimport` — через Compass.** Подключитесь к `mongodb://localhost:27017`, нажмите **Create database**,
затем в коллекции **Add data → Import JSON or CSV file** и выберите файл из `stend/seed`. Имя файла
подсказывает, куда класть: `shop.orders.json` — база `shop`, коллекция `orders`. Так загружаются все
12 файлов; пошагово с кадрами — [глава 1.0, §7](https://maximbytecamp.github.io/mongodb_theory_makarov/temy/00-uchebnye-bazy/index.html#s7).

**Сброс в Compass.** Главы меняют только песочницу, поэтому достаточно пересоздать её: у базы `sandbox`
в левой панели нажмите **⋯ → Drop database**, затем создайте базу `sandbox` заново и импортируйте в неё
`sandbox.products.json` (коллекция `products`) и `sandbox.warehouse.json` (коллекция `warehouse`).
Импорт в непустую коллекцию документы не заменяет — поэтому сначала удаление.

После загрузки в Compass нажмите **Refresh**: в списке должны быть базы `shop`, `hh`, `logs`, `org`
и `sandbox`. В `shop.products` — 21 документ, в `shop.orders` — 120.

### Шаг 2. Драйвер Python и запуск

Python 3.10 или новее — с [python.org](https://www.python.org/downloads/). На Windows в установщике
отметьте **Add python.exe to PATH**.

Windows, PowerShell, из папки архива:

```powershell
python -m pip install -r requirements.txt
cd primery
python 01.py
```

macOS и Linux — драйвер ставится в виртуальное окружение: системный Python не даёт ставить пакеты напрямую.

```bash
python3 -m venv .venv
source .venv/bin/activate          # в каждом новом терминале снова
pip install -r requirements.txt
cd primery
python3 01.py
```

Если `venv` не найден на Linux: `sudo apt install python3-venv`.

Остальные примеры запускаются так же: `02.py`, `03.py` и далее. Если сервер слушает другой адрес,
задайте его переменной `MONGO_URI` — программы глав 1.2–1.8 читают её при подключении.

## Примеры и выводы

| Файл | Параграф главы | Что делает |
|---|---|---|
| `01.py` | §1 Задача, которую фильтр не решает | имя поля вместо значения |
| `02.py` | §2 $expr: выражение вместо условия | два поля одного документа |
| `03.py` | §3 Проверка данных: перевёрнутая вилка | проверка черновиков вакансий |
| `04.py` | §4 Вычисления внутри $expr | ширина вилки от 50 000 |
| `05.py` | §5 $expr вместе с обычными условиями | $expr вместе с обычным условием |
| `06.py` | §6 Типы и отсутствующее поле в выражении | типы и отсутствующее поле в $expr |

### 01.py · §1 Задача, которую фильтр не решает

Имя поля вместо значения.

```text
всего вакансий:               8
salary.from $lt "$salary.to": 0
```

### 02.py · §2 $expr: выражение вместо условия

Два поля одного документа.

```text
нижняя граница меньше верхней: 8
нижняя граница больше верхней: 0
```

### 03.py · §3 Проверка данных: перевёрнутая вилка

Проверка черновиков вакансий.

```text
черновиков:        2
вилка перевёрнута: 1
{'_id': 'v-902', 'title': 'Тестировщик', 'salary': {'from': 90000, 'to': 60000}}
```

### 04.py · §4 Вычисления внутри $expr

Ширина вилки от 50 000.

```text
{'title': 'Backend-разработчик .NET', 'salary': {'from': 100000, 'to': 150000}}
{'title': 'Frontend-разработчик', 'salary': {'from': 90000, 'to': 140000}}
{'title': 'Администратор баз данных', 'salary': {'from': 110000, 'to': 160000}}
{'title': 'Аналитик данных', 'salary': {'from': 120000, 'to': 180000}}
{'title': 'Data-инженер', 'salary': {'from': 140000, 'to': 200000}}
```

### 05.py · §5 $expr вместе с обычными условиями

$expr вместе с обычным условием.

```text
{'title': 'Администратор баз данных', 'city': 'Москва', 'salary': {'from': 110000, 'to': 160000}}
{'title': 'Аналитик данных', 'city': 'Москва', 'salary': {'from': 120000, 'to': 180000}}
{'title': 'Data-инженер', 'city': 'Москва', 'salary': {'from': 140000, 'to': 200000}}
```

### 06.py · §6 Типы и отсутствующее поле в выражении

Типы и отсутствующее поле в $expr.

```text
vacancies: $expr salary > 100000: 8
vacancies: salary $gt 100000:     0
resumes: $expr updated < 01.09:   4
resumes: updated $lt 01.09:       3
```

## Частые ошибки

| Что видно | Причина | Что сделать |
|---|---|---|
| `port is already allocated`, `address already in use` на `docker compose up -d` | порт 27017 занят: уже работает установленный MongoDB или стенд `mongodb-practice` | остановите тот сервер или создайте рядом с `compose.yaml` файл `.env` со строкой `MONGO_PORT=27018`: в PowerShell — `Set-Content .env "MONGO_PORT=27018"`, в bash — `echo "MONGO_PORT=27018" > .env`. Программы в Docker это не затрагивает, Compass подключайте к `localhost:27018` |
| `Cannot connect to the Docker daemon`, `error during connect` | Docker Desktop не запущен | запустите Docker Desktop и дождитесь зелёного статуса Engine running |
| `ServerSelectionTimeoutError`, `Connection refused`, `No server available` | сервер не запущен | Docker: `docker compose up -d`; способ 2 — запустите службу MongoDB |
| `Файл не найден: …` | путь написан не от папки архива или команда выполнена в другой папке | перейдите в папку, где лежит `compose.yaml`, и пишите путь `primery/01.py` |
| числа в выводе не совпадают с README | пример запускали дважды, пропустили или базы не сброшены | сбросьте базы и запустите примеры с первого по порядку |

В PowerShell не используйте `echo … > .env`: Windows PowerShell 5 пишет такой файл в UTF-16, и Docker
Compose его не прочитает.
