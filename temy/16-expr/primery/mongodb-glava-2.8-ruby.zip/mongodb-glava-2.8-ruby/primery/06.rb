# Глава 2.8 · Сравнение полей между собой: $expr
# Пример 6 из 6 · §6 Типы и отсутствующее поле в выражении · типы и отсутствующее поле в $expr
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/06.rb
#   cd primery, затем ruby 06.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
sep01 = Time.utc(2026, 9, 1)

puts "vacancies: $expr salary > 100000: " + vacancies.count_documents({ "$expr" => { "$gt" => ["$salary", 100000] } }).to_s
puts "vacancies: salary $gt 100000:     " + vacancies.count_documents({ "salary" => { "$gt" => 100000 } }).to_s
puts "resumes: $expr updated < 01.09:   " + resumes.count_documents({ "$expr" => { "$lt" => ["$updated", sep01] } }).to_s
puts "resumes: updated $lt 01.09:       " + resumes.count_documents({ "updated" => { "$lt" => sep01 } }).to_s
