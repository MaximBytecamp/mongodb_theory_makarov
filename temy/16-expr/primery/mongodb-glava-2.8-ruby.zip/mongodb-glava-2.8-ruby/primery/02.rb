# Глава 2.8 · Сравнение полей между собой: $expr
# Пример 2 из 6 · §2 $expr: выражение вместо условия · два поля одного документа
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/02.rb
#   cd primery, затем ruby 02.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
puts "нижняя граница меньше верхней: " + vacancies.count_documents({ "$expr" => { "$lt" => ["$salary.from", "$salary.to"] } }).to_s
puts "нижняя граница больше верхней: " + vacancies.count_documents({ "$expr" => { "$gt" => ["$salary.from", "$salary.to"] } }).to_s
