# Глава 2.8 · Сравнение полей между собой: $expr
# Пример 1 из 6 · §1 Задача, которую фильтр не решает · имя поля вместо значения
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/01.rb
#   cd primery, затем ruby 01.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
puts "всего вакансий:               " + vacancies.count_documents({}).to_s
puts "salary.from $lt \"$salary.to\": " + vacancies.count_documents({ "salary.from" => { "$lt" => "$salary.to" } }).to_s
