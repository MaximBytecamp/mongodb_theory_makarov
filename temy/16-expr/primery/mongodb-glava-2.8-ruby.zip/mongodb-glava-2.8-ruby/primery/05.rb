# Глава 2.8 · Сравнение полей между собой: $expr
# Пример 5 из 6 · §5 $expr вместе с обычными условиями · $expr вместе с обычным условием
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/05.rb
#   cd primery, затем ruby 05.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
filtr = { "city" => "Москва",
          "$expr" => { "$gte" => [{ "$subtract" => ["$salary.to", "$salary.from"] }, 50000] } }

vacancies.find(filtr, projection: { "_id" => 0, "title" => 1, "city" => 1, "salary" => 1 })
         .each { |doc| puts doc.inspect }
