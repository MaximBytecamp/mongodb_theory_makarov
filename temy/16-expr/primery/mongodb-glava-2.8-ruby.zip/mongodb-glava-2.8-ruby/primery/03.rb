# Глава 2.8 · Сравнение полей между собой: $expr
# Пример 3 из 6 · §3 Проверка данных: перевёрнутая вилка · проверка черновиков вакансий
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/03.rb
#   cd primery, затем ruby 03.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
# черновики вакансий: коллекция создаётся заново при каждом запуске
drafts = client.use("sandbox").database[:vacancy_drafts]
drafts.drop
drafts.insert_one({ "_id" => "v-901",
                    "title" => "Стажёр-аналитик",
                    "salary" => { "from" => 50000, "to" => 70000 } })
drafts.insert_one({ "_id" => "v-902",
                    "title" => "Тестировщик",
                    "salary" => { "from" => 90000, "to" => 60000 } })

puts "черновиков:        " + drafts.count_documents({}).to_s
puts "вилка перевёрнута: " + drafts.count_documents({ "$expr" => { "$gt" => ["$salary.from", "$salary.to"] } }).to_s

drafts.find({ "$expr" => { "$gt" => ["$salary.from", "$salary.to"] } }, projection: { "title" => 1, "salary" => 1 })
      .each { |doc| puts doc.inspect }
