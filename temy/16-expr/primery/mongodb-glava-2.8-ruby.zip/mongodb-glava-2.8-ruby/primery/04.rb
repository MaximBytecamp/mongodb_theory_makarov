# Глава 2.8 · Сравнение полей между собой: $expr
# Пример 4 из 6 · §4 Вычисления внутри $expr · ширина вилки от 50 000
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/04.rb
#   cd primery, затем ruby 04.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
filtr = { "$expr" => { "$gte" => [{ "$subtract" => ["$salary.to", "$salary.from"] }, 50000] } }

vacancies.find(filtr, projection: { "_id" => 0, "title" => 1, "salary" => 1 })
         .each { |doc| puts doc.inspect }
