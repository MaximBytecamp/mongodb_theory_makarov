//go:build ignore

// Глава 2.8 · Сравнение полей между собой: $expr
// Пример 1 из 6 · §1 Задача, которую фильтр не решает · имя поля вместо значения
//
// Запуск из папки архива:
//   docker compose run --rm go primery/01.go
//   cd primery, затем go run 01.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"time"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = fmt.Sprint
var _ = time.Now
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("hh")
	resumes := db.Collection("resumes")
	vacancies := db.Collection("vacancies")
	companies := db.Collection("companies")
	interviews := db.Collection("interviews")
	box := client.Database("sandbox").Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, resumes, vacancies, companies, interviews, box

	{
		// ── пример из главы ──────────────────────────────────────
		vsego, _ := vacancies.CountDocuments(ctx, bson.D{})
		strokoy, _ := vacancies.CountDocuments(ctx, bson.D{{Key: "salary.from", Value: bson.D{{Key: "$lt", Value: "$salary.to"}}}})

		fmt.Println("всего вакансий:              ", vsego)
		fmt.Println("salary.from $lt \"$salary.to\":", strokoy)
	}
}
