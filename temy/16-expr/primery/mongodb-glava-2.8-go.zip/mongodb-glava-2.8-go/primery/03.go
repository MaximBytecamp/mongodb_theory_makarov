//go:build ignore

// Глава 2.8 · Сравнение полей между собой: $expr
// Пример 3 из 6 · §3 Проверка данных: перевёрнутая вилка · проверка черновиков вакансий
//
// Запуск из папки архива:
//   docker compose run --rm go primery/03.go
//   cd primery, затем go run 03.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"time"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = fmt.Sprint
var _ = time.Now
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("hh")
	resumes := db.Collection("resumes")
	vacancies := db.Collection("vacancies")
	companies := db.Collection("companies")
	interviews := db.Collection("interviews")
	box := client.Database("sandbox").Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, resumes, vacancies, companies, interviews, box

	{
		// ── пример из главы ──────────────────────────────────────
		// черновики вакансий: коллекция создаётся заново при каждом запуске
		drafts := client.Database("sandbox").Collection("vacancy_drafts")
		drafts.Drop(ctx)
		drafts.InsertOne(ctx, bson.D{
		    {Key: "_id", Value: "v-901"},
		    {Key: "title", Value: "Стажёр-аналитик"},
		    {Key: "salary", Value: bson.D{{Key: "from", Value: 50000}, {Key: "to", Value: 70000}}}})
		drafts.InsertOne(ctx, bson.D{
		    {Key: "_id", Value: "v-902"},
		    {Key: "title", Value: "Тестировщик"},
		    {Key: "salary", Value: bson.D{{Key: "from", Value: 90000}, {Key: "to", Value: 60000}}}})

		vsego, _ := drafts.CountDocuments(ctx, bson.D{})
		perevernuta, _ := drafts.CountDocuments(ctx, bson.D{{Key: "$expr", Value: bson.D{{Key: "$gt", Value: bson.A{"$salary.from", "$salary.to"}}}}})

		fmt.Println("черновиков:       ", vsego)
		fmt.Println("вилка перевёрнута:", perevernuta)

		cursor, _ := drafts.Find(ctx, bson.D{{Key: "$expr", Value: bson.D{{Key: "$gt", Value: bson.A{"$salary.from", "$salary.to"}}}}},
		    options.Find().SetProjection(bson.D{{Key: "title", Value: 1}, {Key: "salary", Value: 1}}))
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}
	}
}
