# Глава 6.5 · $merge и $out: результат конвейера в коллекцию
# Пример 2 из 7 · §2 Повторный запуск: whenMatched · повторный запуск: whenMatched merge и replace
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
city_sales = sandbox["city_sales"]
city_sales.drop()

showcase = [
    {"$match": {"status": "доставлен"}},
    {"$group": {
        "_id": "$delivery.city",
        "orders": {"$sum": 1},
        "revenue": {"$sum": "$total"},
    }},
    {"$merge": {"into": {"db": "sandbox", "coll": "city_sales"}}},
]

add_transit = [
    {"$match": {"status": "в пути"}},
    {"$group": {"_id": "$delivery.city", "in_transit": {"$sum": 1}}},
    {"$merge": {
        "into": {"db": "sandbox", "coll": "city_sales"},
        "whenMatched": "merge",
        "whenNotMatched": "discard",
    }},
]

replace_transit = [
    {"$match": {"status": "в пути"}},
    {"$group": {"_id": "$delivery.city", "in_transit": {"$sum": 1}}},
    {"$merge": {
        "into": {"db": "sandbox", "coll": "city_sales"},
        "whenMatched": "replace",
        "whenNotMatched": "discard",
    }},
]

orders.aggregate(showcase)

print("── whenMatched merge: поле в пути добавлено")
orders.aggregate(add_transit)

for doc in city_sales.find().sort("_id", 1):
    print(doc)

print("── whenMatched replace: документы заменены")
orders.aggregate(replace_transit)

for doc in city_sales.find().sort("_id", 1):
    print(doc)
