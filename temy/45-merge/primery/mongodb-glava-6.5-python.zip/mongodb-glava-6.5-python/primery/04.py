# Глава 6.5 · $merge и $out: результат конвейера в коллекцию
# Пример 4 из 7 · §4 Связь по своему полю: on · поле on: связь по city и уникальный индекс
#
# Запуск из папки архива:
#   docker compose run --rm python primery/04.py
#   cd primery, затем python 04.py (Windows) или python3 04.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
from pymongo.errors import OperationFailure

city_stats = sandbox["city_stats"]
city_stats.drop()

by_city_name = [
    {"$match": {"status": "доставлен"}},
    {"$group": {"_id": "$delivery.city", "orders": {"$sum": 1}}},
    {"$project": {"_id": 0, "city": "$_id", "orders": 1}},
    {"$merge": {"into": {"db": "sandbox", "coll": "city_stats"}, "on": "city"}},
]

print("── on: city без индекса")
try:
    for doc in orders.aggregate(by_city_name):
        print(doc)
except OperationFailure as e:
    print("код", e.code)
    print(e.details["errmsg"])

print("── on: city с уникальным индексом")
city_stats.create_index("city", unique=True)
orders.aggregate(by_city_name)
for doc in city_stats.find({}, {"_id": 0}).sort("city", 1):
    print(doc)
