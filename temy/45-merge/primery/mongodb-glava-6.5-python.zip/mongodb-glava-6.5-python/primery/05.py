# Глава 6.5 · $merge и $out: результат конвейера в коллекцию
# Пример 5 из 7 · §5 Только новые документы: fail · whenMatched fail: запись только новых документов
#
# Запуск из папки архива:
#   docker compose run --rm python primery/05.py
#   cd primery, затем python 05.py (Windows) или python3 05.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
from pymongo.errors import OperationFailure

city_sales = sandbox["city_sales"]
city_sales.drop()

showcase = [
    {"$match": {"status": "доставлен"}},
    {"$group": {
        "_id": "$delivery.city",
        "orders": {"$sum": 1},
        "revenue": {"$sum": "$total"},
    }},
    {"$merge": {"into": {"db": "sandbox", "coll": "city_sales"}}},
]

again_fail = [
    {"$match": {"status": "доставлен"}},
    {"$group": {
        "_id": "$delivery.city",
        "orders": {"$sum": 1},
        "revenue": {"$sum": "$total"},
    }},
    {"$sort": {"_id": 1}},
    {"$merge": {"into": {"db": "sandbox", "coll": "city_sales"}, "whenMatched": "fail"}},
]

orders.aggregate(showcase)

print("── повторный запуск с fail")
try:
    for doc in orders.aggregate(again_fail):
        print(doc)
except OperationFailure as e:
    print("код", e.code)
    print(e.details["errmsg"])
