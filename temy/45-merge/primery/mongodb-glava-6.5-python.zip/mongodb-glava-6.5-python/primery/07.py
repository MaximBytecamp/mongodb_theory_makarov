# Глава 6.5 · $merge и $out: результат конвейера в коллекцию
# Пример 7 из 7 · §7 $merge только в конце · $merge не последней стадией
#
# Запуск из папки архива:
#   docker compose run --rm python primery/07.py
#   cd primery, затем python 07.py (Windows) или python3 07.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
from pymongo.errors import OperationFailure

not_last = [
    {"$merge": {"into": {"db": "sandbox", "coll": "tmp"}}},
    {"$limit": 1},
]

print("── $merge перед $limit")
try:
    for doc in orders.aggregate(not_last):
        print(doc)
except OperationFailure as e:
    print("код", e.code)
    print(e.details["errmsg"])
