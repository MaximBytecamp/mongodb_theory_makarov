# Глава 6.5 · $merge и $out: результат конвейера в коллекцию
# Пример 1 из 7 · §1 Витрина: стадия $merge · $merge: витрина продаж по городам
#
# Запуск из папки архива:
#   docker compose run --rm python primery/01.py
#   cd primery, затем python 01.py (Windows) или python3 01.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
city_sales = sandbox["city_sales"]
city_sales.drop()

showcase = [
    {"$match": {"status": "доставлен"}},
    {"$group": {
        "_id": "$delivery.city",
        "orders": {"$sum": 1},
        "revenue": {"$sum": "$total"},
    }},
    {"$merge": {"into": {"db": "sandbox", "coll": "city_sales"}}},
]

orders.aggregate(showcase)

for doc in city_sales.find().sort("_id", 1):
    print(doc)
