//go:build ignore

// Глава 6.5 · $merge и $out: результат конвейера в коллекцию
// Пример 1 из 7 · §1 Витрина: стадия $merge · $merge: витрина продаж по городам
//
// Запуск из папки архива:
//   docker compose run --rm go primery/01.go
//   cd primery, затем go run 01.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	orders := db.Collection("orders")
	customers := db.Collection("customers")
	products := db.Collection("products")
	hh := client.Database("hh")
	companies := hh.Collection("companies")
	vacancies := hh.Collection("vacancies")
	resumes := hh.Collection("resumes")
	org := client.Database("org")
	employees := org.Collection("employees")
	categories := org.Collection("categories")
	sandbox := client.Database("sandbox")
	_, _, _, _, _, _, _, _, _, _, _, _ = db, orders, customers, products, hh, companies, vacancies, resumes, org, employees, categories, sandbox

	{
		// ── пример из главы ──────────────────────────────────────
		citySales := sandbox.Collection("city_sales")
		citySales.Drop(ctx)

		showcase := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{{Key: "status", Value: "доставлен"}}}},
		    {{Key: "$group", Value: bson.D{
		        {Key: "_id", Value: "$delivery.city"},
		        {Key: "orders", Value: bson.D{{Key: "$sum", Value: 1}}},
		        {Key: "revenue", Value: bson.D{{Key: "$sum", Value: "$total"}}}}}},
		    {{Key: "$merge", Value: bson.D{
		        {Key: "into", Value: bson.D{
		            {Key: "db", Value: "sandbox"},
		            {Key: "coll", Value: "city_sales"}}}}}},
		}

		orders.Aggregate(ctx, showcase)

		cursor, _ := citySales.Find(ctx, bson.D{}, options.Find().SetSort(bson.D{{Key: "_id", Value: 1}}))
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}
	}
}
