//go:build ignore

// Глава 6.5 · $merge и $out: результат конвейера в коллекцию
// Пример 2 из 7 · §2 Повторный запуск: whenMatched · повторный запуск: whenMatched merge и replace
//
// Запуск из папки архива:
//   docker compose run --rm go primery/02.go
//   cd primery, затем go run 02.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	orders := db.Collection("orders")
	customers := db.Collection("customers")
	products := db.Collection("products")
	hh := client.Database("hh")
	companies := hh.Collection("companies")
	vacancies := hh.Collection("vacancies")
	resumes := hh.Collection("resumes")
	org := client.Database("org")
	employees := org.Collection("employees")
	categories := org.Collection("categories")
	sandbox := client.Database("sandbox")
	_, _, _, _, _, _, _, _, _, _, _, _ = db, orders, customers, products, hh, companies, vacancies, resumes, org, employees, categories, sandbox

	{
		// ── пример из главы ──────────────────────────────────────
		citySales := sandbox.Collection("city_sales")
		citySales.Drop(ctx)

		showcase := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{{Key: "status", Value: "доставлен"}}}},
		    {{Key: "$group", Value: bson.D{
		        {Key: "_id", Value: "$delivery.city"},
		        {Key: "orders", Value: bson.D{{Key: "$sum", Value: 1}}},
		        {Key: "revenue", Value: bson.D{{Key: "$sum", Value: "$total"}}}}}},
		    {{Key: "$merge", Value: bson.D{
		        {Key: "into", Value: bson.D{
		            {Key: "db", Value: "sandbox"},
		            {Key: "coll", Value: "city_sales"}}}}}},
		}

		addTransit := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{{Key: "status", Value: "в пути"}}}},
		    {{Key: "$group", Value: bson.D{
		        {Key: "_id", Value: "$delivery.city"},
		        {Key: "in_transit", Value: bson.D{{Key: "$sum", Value: 1}}}}}},
		    {{Key: "$merge", Value: bson.D{
		        {Key: "into", Value: bson.D{
		            {Key: "db", Value: "sandbox"},
		            {Key: "coll", Value: "city_sales"}}},
		        {Key: "whenMatched", Value: "merge"},
		        {Key: "whenNotMatched", Value: "discard"}}}},
		}

		replaceTransit := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{{Key: "status", Value: "в пути"}}}},
		    {{Key: "$group", Value: bson.D{
		        {Key: "_id", Value: "$delivery.city"},
		        {Key: "in_transit", Value: bson.D{{Key: "$sum", Value: 1}}}}}},
		    {{Key: "$merge", Value: bson.D{
		        {Key: "into", Value: bson.D{
		            {Key: "db", Value: "sandbox"},
		            {Key: "coll", Value: "city_sales"}}},
		        {Key: "whenMatched", Value: "replace"},
		        {Key: "whenNotMatched", Value: "discard"}}}},
		}

		orders.Aggregate(ctx, showcase)

		fmt.Println("── whenMatched merge: поле в пути добавлено")
		orders.Aggregate(ctx, addTransit)

		cursor, _ := citySales.Find(ctx, bson.D{}, options.Find().SetSort(bson.D{{Key: "_id", Value: 1}}))
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}

		fmt.Println("── whenMatched replace: документы заменены")
		orders.Aggregate(ctx, replaceTransit)

		cursor, _ = citySales.Find(ctx, bson.D{}, options.Find().SetSort(bson.D{{Key: "_id", Value: 1}}))
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}
	}
}
