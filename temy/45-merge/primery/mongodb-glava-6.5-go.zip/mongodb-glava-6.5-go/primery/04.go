//go:build ignore

// Глава 6.5 · $merge и $out: результат конвейера в коллекцию
// Пример 4 из 7 · §4 Связь по своему полю: on · поле on: связь по city и уникальный индекс
//
// Запуск из папки архива:
//   docker compose run --rm go primery/04.go
//   cd primery, затем go run 04.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────

var ce mongo.CommandError

func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	orders := db.Collection("orders")
	customers := db.Collection("customers")
	products := db.Collection("products")
	hh := client.Database("hh")
	companies := hh.Collection("companies")
	vacancies := hh.Collection("vacancies")
	resumes := hh.Collection("resumes")
	org := client.Database("org")
	employees := org.Collection("employees")
	categories := org.Collection("categories")
	sandbox := client.Database("sandbox")
	_, _, _, _, _, _, _, _, _, _, _, _ = db, orders, customers, products, hh, companies, vacancies, resumes, org, employees, categories, sandbox

	{
		// ── пример из главы ──────────────────────────────────────
		cityStats := sandbox.Collection("city_stats")
		cityStats.Drop(ctx)

		byCityName := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{{Key: "status", Value: "доставлен"}}}},
		    {{Key: "$group", Value: bson.D{
		        {Key: "_id", Value: "$delivery.city"},
		        {Key: "orders", Value: bson.D{{Key: "$sum", Value: 1}}}}}},
		    {{Key: "$project", Value: bson.D{
		        {Key: "_id", Value: 0},
		        {Key: "city", Value: "$_id"},
		        {Key: "orders", Value: 1}}}},
		    {{Key: "$merge", Value: bson.D{
		        {Key: "into", Value: bson.D{
		            {Key: "db", Value: "sandbox"},
		            {Key: "coll", Value: "city_stats"}}},
		        {Key: "on", Value: "city"}}}},
		}

		fmt.Println("── on: city без индекса")
		_, err := orders.Aggregate(ctx, byCityName)
		if errors.As(err, &ce) {
		    fmt.Println("код", ce.Code)
		    fmt.Println(ce.Message)
		}

		fmt.Println("── on: city с уникальным индексом")
		cityStats.Indexes().CreateOne(ctx, mongo.IndexModel{
		    Keys:    bson.D{{Key: "city", Value: 1}},
		    Options: options.Index().SetUnique(true),
		})
		orders.Aggregate(ctx, byCityName)
		opts := options.Find().SetProjection(bson.D{{Key: "_id", Value: 0}}).SetSort(bson.D{{Key: "city", Value: 1}})
		cursor, _ := cityStats.Find(ctx, bson.D{}, opts)
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}
	}
}
