# Глава 6.5 · $merge и $out: результат конвейера в коллекцию
# Пример 7 из 7 · §7 $merge только в конце · $merge не последней стадией
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/07.rb
#   cd primery, затем ruby 07.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
not_last = [
  { "$merge" => { "into" => { "db" => "sandbox", "coll" => "tmp" } } },
  { "$limit" => 1 },
]

puts "── $merge перед $limit"
begin
  orders.aggregate(not_last).each { |doc| puts doc.inspect }
rescue Mongo::Error::OperationFailure => e
  puts "код #{e.code}"
  puts e.document["errmsg"]
end
