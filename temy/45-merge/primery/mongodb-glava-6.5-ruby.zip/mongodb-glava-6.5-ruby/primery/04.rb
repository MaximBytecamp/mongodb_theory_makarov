# Глава 6.5 · $merge и $out: результат конвейера в коллекцию
# Пример 4 из 7 · §4 Связь по своему полю: on · поле on: связь по city и уникальный индекс
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/04.rb
#   cd primery, затем ruby 04.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
city_stats = sandbox[:city_stats]
city_stats.drop

by_city_name = [
  { "$match" => { "status" => "доставлен" } },
  { "$group" => { "_id" => "$delivery.city", "orders" => { "$sum" => 1 } } },
  { "$project" => { "_id" => 0, "city" => "$_id", "orders" => 1 } },
  { "$merge" => {
    "into" => { "db" => "sandbox", "coll" => "city_stats" },
    "on" => "city",
  } },
]

puts "── on: city без индекса"
begin
  orders.aggregate(by_city_name).each { |doc| puts doc.inspect }
rescue Mongo::Error::OperationFailure => e
  puts "код #{e.code}"
  puts e.document["errmsg"]
end

puts "── on: city с уникальным индексом"
city_stats.indexes.create_one({ city: 1 }, unique: true)
orders.aggregate(by_city_name).to_a
city_stats.find.projection(_id: 0).sort(city: 1).each { |doc| puts doc.inspect }
