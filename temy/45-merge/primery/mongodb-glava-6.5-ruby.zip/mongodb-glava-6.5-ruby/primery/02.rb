# Глава 6.5 · $merge и $out: результат конвейера в коллекцию
# Пример 2 из 7 · §2 Повторный запуск: whenMatched · повторный запуск: whenMatched merge и replace
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/02.rb
#   cd primery, затем ruby 02.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
city_sales = sandbox[:city_sales]
city_sales.drop

showcase = [
  { "$match" => { "status" => "доставлен" } },
  { "$group" => {
    "_id" => "$delivery.city",
    "orders" => { "$sum" => 1 },
    "revenue" => { "$sum" => "$total" },
  } },
  { "$merge" => { "into" => { "db" => "sandbox", "coll" => "city_sales" } } },
]

add_transit = [
  { "$match" => { "status" => "в пути" } },
  { "$group" => { "_id" => "$delivery.city", "in_transit" => { "$sum" => 1 } } },
  { "$merge" => {
    "into" => { "db" => "sandbox", "coll" => "city_sales" },
    "whenMatched" => "merge",
    "whenNotMatched" => "discard",
  } },
]

replace_transit = [
  { "$match" => { "status" => "в пути" } },
  { "$group" => { "_id" => "$delivery.city", "in_transit" => { "$sum" => 1 } } },
  { "$merge" => {
    "into" => { "db" => "sandbox", "coll" => "city_sales" },
    "whenMatched" => "replace",
    "whenNotMatched" => "discard",
  } },
]

orders.aggregate(showcase).to_a

puts "── whenMatched merge: поле в пути добавлено"
orders.aggregate(add_transit).to_a

city_sales.find.sort(_id: 1).each { |doc| puts doc.inspect }

puts "── whenMatched replace: документы заменены"
orders.aggregate(replace_transit).to_a

city_sales.find.sort(_id: 1).each { |doc| puts doc.inspect }
