# Глава 6.5 · $merge и $out: результат конвейера в коллекцию
# Пример 1 из 7 · §1 Витрина: стадия $merge · $merge: витрина продаж по городам
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/01.rb
#   cd primery, затем ruby 01.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
city_sales = sandbox[:city_sales]
city_sales.drop

showcase = [
  { "$match" => { "status" => "доставлен" } },
  { "$group" => {
    "_id" => "$delivery.city",
    "orders" => { "$sum" => 1 },
    "revenue" => { "$sum" => "$total" },
  } },
  { "$merge" => { "into" => { "db" => "sandbox", "coll" => "city_sales" } } },
]

orders.aggregate(showcase).to_a

city_sales.find.sort(_id: 1).each { |doc| puts doc.inspect }
