// Глава 6.5 · $merge и $out: результат конвейера в коллекцию
// Пример 7 из 7 · §7 $merge только в конце · $merge не последней стадией
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/07.cpp
//   cd primery, затем g++ -std=c++17 07.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto orders = db["orders"];
    auto customers = db["customers"];
    auto products = db["products"];
    auto hh = client["hh"];
    auto companies = hh["companies"];
    auto vacancies = hh["vacancies"];
    auto resumes = hh["resumes"];
    auto org = client["org"];
    auto employees = org["employees"];
    auto categories = org["categories"];
    auto sandbox = client["sandbox"];

    {
        // ── пример из главы ──────────────────────────────────────
        mongocxx::pipeline not_last;
        not_last.append_stage(make_document(kvp("$merge", make_document(
            kvp("into", make_document(kvp("db", "sandbox"), kvp("coll", "tmp")))))));
        not_last.limit(1);

        std::cout << "── $merge перед $limit" << std::endl;
        try {
            for (auto&& doc : orders.aggregate(not_last)) {
                std::cout << bsoncxx::to_json(doc) << std::endl;
            }
        } catch (const mongocxx::operation_exception& e) {
            std::cout << "код " << e.code().value() << std::endl;
            std::cout << e.what() << std::endl;
        }
    }
}
