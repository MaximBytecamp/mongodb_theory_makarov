// Глава 6.5 · $merge и $out: результат конвейера в коллекцию
// Пример 3 из 7 · §3 Накопление итогов · whenMatched с конвейером: прибавить новые заказы
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/03.cpp
//   cd primery, затем g++ -std=c++17 03.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto orders = db["orders"];
    auto customers = db["customers"];
    auto products = db["products"];
    auto hh = client["hh"];
    auto companies = hh["companies"];
    auto vacancies = hh["vacancies"];
    auto resumes = hh["resumes"];
    auto org = client["org"];
    auto employees = org["employees"];
    auto categories = org["categories"];
    auto sandbox = client["sandbox"];

    {
        // ── пример из главы ──────────────────────────────────────
        auto city_sales = sandbox["city_sales"];
        city_sales.drop();

        mongocxx::pipeline showcase;
        showcase.match(make_document(kvp("status", "доставлен")));
        showcase.group(make_document(
            kvp("_id", "$delivery.city"),
            kvp("orders", make_document(kvp("$sum", 1))),
            kvp("revenue", make_document(kvp("$sum", "$total")))));
        showcase.append_stage(make_document(kvp("$merge", make_document(
            kvp("into", make_document(kvp("db", "sandbox"), kvp("coll", "city_sales")))))));

        mongocxx::pipeline add_assembling;
        add_assembling.match(make_document(kvp("status", "собирается")));
        add_assembling.group(make_document(
            kvp("_id", "$delivery.city"),
            kvp("orders", make_document(kvp("$sum", 1))),
            kvp("revenue", make_document(kvp("$sum", "$total")))));
        add_assembling.append_stage(make_document(kvp("$merge", make_document(
            kvp("into", make_document(kvp("db", "sandbox"), kvp("coll", "city_sales"))),
            kvp("whenMatched", make_array(
                make_document(
                    kvp("$set", make_document(
                        kvp("orders", make_document(kvp("$add", make_array("$orders", "$$new.orders")))),
                        kvp("revenue", make_document(kvp("$add", make_array("$revenue", "$$new.revenue")))))))))))));

        for (auto&& doc : orders.aggregate(showcase)) {}

        std::cout << "── прибавлены заказы, которые собираются" << std::endl;
        for (auto&& doc : orders.aggregate(add_assembling)) {}

        mongocxx::options::find opts;
        opts.sort(make_document(kvp("_id", 1)));
        for (auto&& doc : city_sales.find({}, opts)) {
            std::cout << bsoncxx::to_json(doc, bsoncxx::ExtendedJsonMode::k_relaxed) << std::endl;
        }
    }
}
