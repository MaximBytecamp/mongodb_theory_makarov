# Глава 6.5 · $merge и $out: результат конвейера в коллекцию — примеры на C++

Архив к «Справочнику по MongoDB»: все примеры главы готовыми программами, данные баз и стенд в Docker.
Глава: https://maximbytecamp.github.io/mongodb_theory_makarov/temy/45-merge/index.html

Язык: **C++** · драйвер mongocxx 4.5 · сервер MongoDB 7.

## Что в архиве

```text
mongodb-glava-6.5-cpp/
  README.md         эта инструкция
  primery/          примеры главы — по программе на пример
    01.cpp … 07.cpp
  compose.yaml      стенд в Docker: сервер, базы, mongo-express, C++
  docker/           образ с драйвером C++ и скрипт запуска run.sh
  stend/seed/       данные баз: 12 файлов JSON
  stend/load.ps1    загрузка данных на установленный сервер — Windows
  stend/load.sh     то же — macOS и Linux
```

## Порядок работы

1. **Базы.** Глава **меняет песочницу** — базу `sandbox`. Перед первым примером верните базы в исходное состояние, иначе числа в выводах разойдутся с книгой. Команда сброса — в описании способа, которым вы пользуетесь.
2. **Примеры — по порядку, каждый один раз.** Пример в главе рассчитан на данные, которые оставил
   предыдущий. Если запустить пример дважды или пропустить, числа разойдутся с книгой — тогда
   сбросьте базы и начните с `01.cpp`.
3. **Сверка.** Что должна напечатать каждая программа — в разделе «Примеры и выводы» ниже.
   Отличаться могут только `_id`, которые выдаёт сервер, текущие дата и время и порядок
   в списке коллекций: сервер отдаёт их имена в произвольном порядке. У документа, который
   создан обновлением с `upsert`, поля тоже могут идти в другом порядке — значения при этом те же.

Подойдёт любой из двух способов. Адрес сервера в обоих — `mongodb://localhost:27017`, код примеров
одинаковый.

| Способ | Что нужно | Когда подходит |
|---|---|---|
| **1. Docker** | Docker Desktop | Compass и сервер не установились или не подключаются; ничего, кроме Docker, ставить не нужно |
| **2. Сервер и Compass** | MongoDB Server, Compass, C++ с драйвером | сервер и Compass уже стоят и подключаются |

## Способ 1. Docker

Docker Desktop — с [docker.com](https://www.docker.com/products/docker-desktop/); на Linux — Docker Engine.
Перед командами Docker Desktop должен быть запущен. Команды одинаковые в PowerShell, cmd и терминале
macOS/Linux; выполняйте их **из папки архива** — там, где лежит `compose.yaml`.

1. Поднять сервер и загрузить базы курса:

   ```bash
   docker compose up -d
   ```

2. Вернуть базы в исходное состояние — глава меняет песочницу:

   ```bash
   docker compose run --rm reset
   ```

3. Запустить пример — путь к файлу пишется от папки архива:

   ```bash
   docker compose run --rm cpp primery/01.cpp
   ```

   При первом запуске Docker соберёт образ с драйвером C++ — это несколько минут: драйвер C++ собирается из исходников.
   Дальше запуск идёт за секунды.

4. Все примеры главы подряд, по порядку, одной командой:

   ```bash
   docker compose run --rm cpp primery
   ```

   Перед каждой программой печатается её имя: `── primery/01.cpp ──`.

**Смотреть данные.** Compass не нужен: в браузере откройте http://localhost:8081, логин `student`,
пароль `student` — это mongo-express, в нём видны базы, коллекции и документы. Если Compass
установлен, он подключается к этому же серверу по адресу `mongodb://localhost:27017`.

**Консоль сервера:** `docker compose exec mongo mongosh`.

**Остановить и удалить:**

```bash
docker compose stop        # остановить; данные останутся
docker compose down        # удалить контейнеры; данные останутся
docker compose down -v     # удалить всё вместе с данными
```

Архивы всех глав пользуются одним и тем же сервером и данными: после этой главы можно распаковать
архив следующей и работать там, не удаляя стенд.

## Способ 2. Установленный сервер MongoDB и Compass

Нужны MongoDB Server 7 или 8 и MongoDB Compass — установка по шагам в
[главе 1.0а](https://maximbytecamp.github.io/mongodb_theory_makarov/temy/00a-windows-10-mongodb-7/index.html).
Проверка: Compass подключается к `mongodb://localhost:27017`.

### Шаг 1. Загрузить базы курса

Windows, PowerShell, из папки архива — нужен `mongoimport` из MongoDB Command Line Database Tools:

```powershell
powershell -ExecutionPolicy Bypass -File stend\load.ps1
```

macOS и Linux (`mongoimport`: `brew tap mongodb/brew && brew install mongodb-database-tools`):

```bash
bash stend/load.sh
```

Скрипт пересоздаёт коллекции целиком, поэтому он же сбрасывает базы: повторный запуск ничего не двоит.

**Без `mongoimport` — через Compass.** Подключитесь к `mongodb://localhost:27017`, нажмите **Create database**,
затем в коллекции **Add data → Import JSON or CSV file** и выберите файл из `stend/seed`. Имя файла
подсказывает, куда класть: `shop.orders.json` — база `shop`, коллекция `orders`. Так загружаются все
12 файлов; пошагово с кадрами — [глава 1.0, §7](https://maximbytecamp.github.io/mongodb_theory_makarov/temy/00-uchebnye-bazy/index.html#s7).

**Сброс в Compass.** Главы меняют только песочницу, поэтому достаточно пересоздать её: у базы `sandbox`
в левой панели нажмите **⋯ → Drop database**, затем создайте базу `sandbox` заново и импортируйте в неё
`sandbox.products.json` (коллекция `products`) и `sandbox.warehouse.json` (коллекция `warehouse`).
Импорт в непустую коллекцию документы не заменяет — поэтому сначала удаление.

После загрузки в Compass нажмите **Refresh**: в списке должны быть базы `shop`, `hh`, `logs`, `org`
и `sandbox`. В `shop.products` — 21 документ, в `shop.orders` — 120.

### Шаг 2. Драйвер C++ и запуск

Драйвер C++ на Windows и Linux собирается из исходников долго и с зависимостями, поэтому
там примеры запускаются **только в Docker** — способ 1. Если сервер MongoDB уже установлен и занимает порт
27017, остановите службу MongoDB или перед `docker compose up -d` создайте файл `.env` (см. «Частые ошибки»).

На macOS драйвер ставится из Homebrew:

```bash
brew install mongo-cxx-driver
cd primery
g++ -std=c++17 01.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
```

Остальные примеры запускаются так же: `02.cpp`, `03.cpp` и далее. Если сервер слушает другой адрес,
задайте его переменной `MONGO_URI` — программы глав 1.2–1.8 читают её при подключении.

## Примеры и выводы

| Файл | Параграф главы | Что делает |
|---|---|---|
| `01.cpp` | §1 Витрина: стадия $merge | $merge: витрина продаж по городам |
| `02.cpp` | §2 Повторный запуск: whenMatched | повторный запуск: whenMatched merge и replace |
| `03.cpp` | §3 Накопление итогов | whenMatched с конвейером: прибавить новые заказы |
| `04.cpp` | §4 Связь по своему полю: on | поле on: связь по city и уникальный индекс |
| `05.cpp` | §5 Только новые документы: fail | whenMatched fail: запись только новых документов |
| `06.cpp` | §6 Полная замена: $out | $out: коллекция заменяется целиком |
| `07.cpp` | §7 $merge только в конце | $merge не последней стадией |

### 01.cpp · §1 Витрина: стадия $merge

$merge: витрина продаж по городам.

```text
{ "_id" : "Екатеринбург", "orders" : 16, "revenue" : 1390470 }
{ "_id" : "Москва", "orders" : 12, "revenue" : 1387760 }
{ "_id" : "Новосибирск", "orders" : 17, "revenue" : 2536840 }
{ "_id" : "Санкт-Петербург", "orders" : 10, "revenue" : 1169540 }
{ "_id" : "Ярославль", "orders" : 14, "revenue" : 2048020 }
```

### 02.cpp · §2 Повторный запуск: whenMatched

Повторный запуск: whenMatched merge и replace.

```text
── whenMatched merge: поле в пути добавлено
{ "_id" : "Екатеринбург", "orders" : 16, "revenue" : 1390470, "in_transit" : 4 }
{ "_id" : "Москва", "orders" : 12, "revenue" : 1387760, "in_transit" : 1 }
{ "_id" : "Новосибирск", "orders" : 17, "revenue" : 2536840, "in_transit" : 5 }
{ "_id" : "Санкт-Петербург", "orders" : 10, "revenue" : 1169540 }
{ "_id" : "Ярославль", "orders" : 14, "revenue" : 2048020, "in_transit" : 3 }
── whenMatched replace: документы заменены
{ "_id" : "Екатеринбург", "in_transit" : 4 }
{ "_id" : "Москва", "in_transit" : 1 }
{ "_id" : "Новосибирск", "in_transit" : 5 }
{ "_id" : "Санкт-Петербург", "orders" : 10, "revenue" : 1169540 }
{ "_id" : "Ярославль", "in_transit" : 3 }
```

### 03.cpp · §3 Накопление итогов

WhenMatched с конвейером: прибавить новые заказы.

```text
── прибавлены заказы, которые собираются
{ "_id" : "Екатеринбург", "orders" : 20, "revenue" : 2154700 }
{ "_id" : "Москва", "orders" : 13, "revenue" : 1459950 }
{ "_id" : "Новосибирск", "orders" : 25, "revenue" : 3512320 }
{ "_id" : "Санкт-Петербург", "orders" : 12, "revenue" : 1512460 }
{ "_id" : "Ярославль", "orders" : 17, "revenue" : 2742570 }
```

### 04.cpp · §4 Связь по своему полю: on

Поле on: связь по city и уникальный индекс.

```text
── on: city без индекса
код 51183
Cannot find index to verify that join fields will be unique: server error code 51183: generic server error
── on: city с уникальным индексом
{ "city" : "Екатеринбург", "orders" : 16 }
{ "city" : "Москва", "orders" : 12 }
{ "city" : "Новосибирск", "orders" : 17 }
{ "city" : "Санкт-Петербург", "orders" : 10 }
{ "city" : "Ярославль", "orders" : 14 }
```

### 05.cpp · §5 Только новые документы: fail

WhenMatched fail: запись только новых документов.

```text
── повторный запуск с fail
код 11000
PlanExecutor error during aggregation :: caused by :: $merge with whenMatched: fail found an existing document with the same values for the 'on' fields :: caused by :: E11000 duplicate key error collection: sandbox.city_sales index: _id_ dup key: { _id: "Екатеринбург" }: server error code 11000: generic server error
```

### 06.cpp · §6 Полная замена: $out

$out: коллекция заменяется целиком.

```text
── после $out: отменённые заказы по городам
{ "_id" : "Екатеринбург", "cancelled" : 4 }
{ "_id" : "Москва", "cancelled" : 4 }
{ "_id" : "Новосибирск", "cancelled" : 5 }
{ "_id" : "Санкт-Петербург", "cancelled" : 6 }
{ "_id" : "Ярославль", "cancelled" : 1 }
```

### 07.cpp · §7 $merge только в конце

$merge не последней стадией.

```text
── $merge перед $limit
код 40601
$merge can only be the final stage in the pipeline: server error code 40601: generic server error
```

## Частые ошибки

| Что видно | Причина | Что сделать |
|---|---|---|
| `port is already allocated`, `address already in use` на `docker compose up -d` | порт 27017 занят: уже работает установленный MongoDB или стенд `mongodb-practice` | остановите тот сервер или создайте рядом с `compose.yaml` файл `.env` со строкой `MONGO_PORT=27018`: в PowerShell — `Set-Content .env "MONGO_PORT=27018"`, в bash — `echo "MONGO_PORT=27018" > .env`. Программы в Docker это не затрагивает, Compass подключайте к `localhost:27018` |
| `Cannot connect to the Docker daemon`, `error during connect` | Docker Desktop не запущен | запустите Docker Desktop и дождитесь зелёного статуса Engine running |
| `ServerSelectionTimeoutError`, `Connection refused`, `No server available` | сервер не запущен | Docker: `docker compose up -d`; способ 2 — запустите службу MongoDB |
| `Файл не найден: …` | путь написан не от папки архива или команда выполнена в другой папке | перейдите в папку, где лежит `compose.yaml`, и пишите путь `primery/01.cpp` |
| числа в выводе не совпадают с README | пример запускали дважды, пропустили или базы не сброшены | сбросьте базы и запустите примеры с первого по порядку |

В PowerShell не используйте `echo … > .env`: Windows PowerShell 5 пишет такой файл в UTF-16, и Docker
Compose его не прочитает.
