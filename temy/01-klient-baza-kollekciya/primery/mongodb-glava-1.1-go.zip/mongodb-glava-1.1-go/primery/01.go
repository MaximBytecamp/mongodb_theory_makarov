//go:build ignore

// Глава 1.1 · Сервер, база, коллекция
// Пример 1 из 5 · §4 MongoClient: создание клиента · клиент
//
// Запуск из папки архива:
//   docker compose run --rm go primery/01.go
//   cd primery, затем go run 01.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

var _ = fmt.Sprint
var _ = log.Fatal
var _ = os.Getenv
var _ = bson.D{}
var _ = mongo.Connect
var _ = options.Client


func main() {
	ctx := context.Background()
	_ = ctx
	{
		// Локальный сервер учебного стенда
		client, err := mongo.Connect(options.Client().
		    ApplyURI("mongodb://localhost:27017"))
		if err != nil {
		    log.Fatal(err)
		}
		defer client.Disconnect(context.Background())

		// Атлас: ApplyURI("mongodb+srv://user:pass@cluster0.mongodb.net")
	}
}
