//go:build ignore

// Глава 1.1 · Сервер, база, коллекция
// Пример 4 из 5 · §8 Один клиент на программу · Go
//
// Запуск из папки архива:
//   docker compose run --rm go primery/04.go
//   cd primery, затем go run 04.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

var _ = fmt.Sprint
var _ = log.Fatal
var _ = os.Getenv
var _ = bson.D{}
var _ = mongo.Connect
var _ = options.Client

// создаётся один раз при старте программы
var products *mongo.Collection
func init() {
    client, _ := mongo.Connect(options.Client().
        ApplyURI("mongodb://localhost:27017"))
    products = client.Database("shop").Collection("products")
}
func countAll(ctx context.Context) (int64, error) {
    return products.CountDocuments(ctx, bson.D{})
}

func main() {
	ctx := context.Background()
	_ = ctx
	{

	}
}
