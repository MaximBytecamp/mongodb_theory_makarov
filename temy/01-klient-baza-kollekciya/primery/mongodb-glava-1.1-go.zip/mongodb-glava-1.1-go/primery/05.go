//go:build ignore

// Глава 1.1 · Сервер, база, коллекция
// Пример 5 из 5 · §8 Один клиент на программу · Go
//
// Запуск из папки архива:
//   docker compose run --rm go primery/05.go
//   cd primery, затем go run 05.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

var _ = fmt.Sprint
var _ = log.Fatal
var _ = os.Getenv
var _ = bson.D{}
var _ = mongo.Connect
var _ = options.Client

func countAll(ctx context.Context) int64 {
    // новый пул соединений на каждый вызов
    client, _ := mongo.Connect(options.Client().
        ApplyURI("mongodb://localhost:27017"))
    defer client.Disconnect(ctx)

    count, _ := client.Database("shop").Collection("products").
        CountDocuments(ctx, bson.D{})
    return count
}

func main() {
	ctx := context.Background()
	_ = ctx
	{

	}
}
