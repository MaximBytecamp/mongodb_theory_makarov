//go:build ignore

// Глава 1.1 · Сервер, база, коллекция
// Пример 2 из 5 · §5 Выбор базы и коллекции · спуск по трём уровням
//
// Запуск из папки архива:
//   docker compose run --rm go primery/02.go
//   cd primery, затем go run 02.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

var _ = fmt.Sprint
var _ = log.Fatal
var _ = os.Getenv
var _ = bson.D{}
var _ = mongo.Connect
var _ = options.Client


func main() {
	ctx := context.Background()
	_ = ctx
	{
		client, _ := mongo.Connect(options.Client().
		    ApplyURI("mongodb://localhost:27017"))          // сервер
		db := client.Database("shop")                         // база
		collection := db.Collection("products")              // коллекция

		// Имя из переменной подставляется так же: Database(name)

		fmt.Printf("Тип client: %T | тип db: %T | тип collection: %T\n", client, db, collection)
	}
}
