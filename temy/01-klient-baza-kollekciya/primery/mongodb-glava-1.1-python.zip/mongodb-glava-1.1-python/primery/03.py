# Глава 1.1 · Сервер, база, коллекция
# Пример 3 из 5 · §6 Что уже есть на сервере · осмотр сервера
# В начале — код из блока «клиент»: в главе он стоит прямо перед этим примером.
#
# Запуск из папки архива:
#   docker compose run --rm python primery/03.py
#   cd primery, затем python 03.py (Windows) или python3 03.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

from pymongo import MongoClient

from pymongo import MongoClient

# Локальный сервер учебного стенда
client = MongoClient("mongodb://localhost:27017/")

# Облачный Atlas — другая схема и обязательный пароль
# client = MongoClient("mongodb+srv://user:pass@cluster0.mongodb.net/")
print("Базы данных:", client.list_database_names())

db = client["shop"]
print("Коллекции shop:", db.list_collection_names())

collection = db["products"]
print("Документов:", collection.count_documents({}))
