# Глава 1.1 · Сервер, база, коллекция
# Пример 4 из 5 · §8 Один клиент на программу · Python
#
# Запуск из папки архива:
#   docker compose run --rm python primery/04.py
#   cd primery, затем python 04.py (Windows) или python3 04.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

from pymongo import MongoClient

# создаётся один раз при старте программы
client = MongoClient("mongodb://localhost:27017/")
products = client["shop"]["products"]

def count_all():
    return products.count_documents({})
