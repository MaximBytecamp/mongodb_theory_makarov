# Глава 1.1 · Сервер, база, коллекция
# Пример 5 из 5 · §8 Один клиент на программу · Python
#
# Запуск из папки архива:
#   docker compose run --rm python primery/05.py
#   cd primery, затем python 05.py (Windows) или python3 05.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

from pymongo import MongoClient

def count_all():
    # новый пул соединений на каждый вызов
    client = MongoClient("mongodb://localhost:27017/")
    return client["shop"]["products"].count_documents({})
