# Глава 1.1 · Сервер, база, коллекция
# Пример 1 из 5 · §4 MongoClient: создание клиента · клиент
#
# Запуск из папки архива:
#   docker compose run --rm python primery/01.py
#   cd primery, затем python 01.py (Windows) или python3 01.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

from pymongo import MongoClient

from pymongo import MongoClient

# Локальный сервер учебного стенда
client = MongoClient("mongodb://localhost:27017/")

# Облачный Atlas — другая схема и обязательный пароль
# client = MongoClient("mongodb+srv://user:pass@cluster0.mongodb.net/")
