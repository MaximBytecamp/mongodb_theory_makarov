# Глава 1.1 · Сервер, база, коллекция
# Пример 2 из 5 · §5 Выбор базы и коллекции · спуск по трём уровням
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017/")   # сервер
db = client["shop"]                                # база
collection = db["products"]                         # коллекция

# Тот же смысл через методы — так пишут, когда имя лежит в переменной
db = client.get_database("shop")
collection = db.get_collection("products")

print("Тип client:", type(client).__name__, "| тип db:", type(db).__name__,
      "| тип collection:", type(collection).__name__)
