# Глава 1.1 · Сервер, база, коллекция
# Пример 3 из 5 · §6 Что уже есть на сервере · осмотр сервера
# В начале — код из блока «клиент»: в главе он стоит прямо перед этим примером.
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/03.rb
#   cd primery, затем ruby 03.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

require "mongo"

# Локальный сервер учебного стенда
client = Mongo::Client.new("mongodb://localhost:27017/")

# Облачный Atlas — другая схема и обязательный пароль
# client = Mongo::Client.new("mongodb+srv://user:pass@cluster0.mongodb.net/")
puts "Базы данных: #{client.database_names}"

db = client.use("shop").database
puts "Коллекции shop: #{db.collection_names}"

collection = db[:products]
puts "Документов: #{collection.count_documents({})}"
