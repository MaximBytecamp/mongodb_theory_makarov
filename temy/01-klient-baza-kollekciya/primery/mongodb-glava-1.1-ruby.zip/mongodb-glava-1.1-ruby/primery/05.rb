# Глава 1.1 · Сервер, база, коллекция
# Пример 5 из 5 · §8 Один клиент на программу · Ruby
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/05.rb
#   cd primery, затем ruby 05.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

def count_all
  # новый пул соединений на каждый вызов
  client = Mongo::Client.new("mongodb://localhost:27017/")
  client.use("shop").database[:products].count_documents({})
end
