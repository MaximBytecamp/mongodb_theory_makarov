# Глава 1.1 · Сервер, база, коллекция
# Пример 4 из 5 · §8 Один клиент на программу · Ruby
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/04.rb
#   cd primery, затем ruby 04.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

# создаётся один раз при старте программы
CLIENT = Mongo::Client.new("mongodb://localhost:27017/")
PRODUCTS = CLIENT.use("shop").database[:products]

def count_all
  PRODUCTS.count_documents({})
end
