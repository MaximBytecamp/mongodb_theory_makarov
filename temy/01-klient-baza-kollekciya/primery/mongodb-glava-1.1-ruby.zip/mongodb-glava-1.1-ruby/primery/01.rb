# Глава 1.1 · Сервер, база, коллекция
# Пример 1 из 5 · §4 MongoClient: создание клиента · клиент
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/01.rb
#   cd primery, затем ruby 01.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

require "mongo"

# Локальный сервер учебного стенда
client = Mongo::Client.new("mongodb://localhost:27017/")

# Облачный Atlas — другая схема и обязательный пароль
# client = Mongo::Client.new("mongodb+srv://user:pass@cluster0.mongodb.net/")
