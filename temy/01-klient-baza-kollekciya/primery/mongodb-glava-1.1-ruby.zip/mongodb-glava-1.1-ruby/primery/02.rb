# Глава 1.1 · Сервер, база, коллекция
# Пример 2 из 5 · §5 Выбор базы и коллекции · спуск по трём уровням
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/02.rb
#   cd primery, затем ruby 02.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new("mongodb://localhost:27017/")  # сервер
db = client.use("shop").database                        # база
collection = db[:products]                              # коллекция

# Имя из переменной: db[name.to_sym] или db.collection(name)
collection = db.collection("products")

puts "Тип client: #{client.class} | тип db: #{db.class} | тип collection: #{collection.class}"
