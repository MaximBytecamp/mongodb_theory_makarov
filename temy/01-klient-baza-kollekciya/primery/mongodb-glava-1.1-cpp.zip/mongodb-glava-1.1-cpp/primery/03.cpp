// Глава 1.1 · Сервер, база, коллекция
// Пример 3 из 5 · §6 Что уже есть на сервере · осмотр сервера
// В начале — код из блока «клиент»: в главе он стоит прямо перед этим примером.
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/03.cpp
//   cd primery, затем g++ -std=c++17 03.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────

#include <mongocxx/client.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/uri.hpp>
mongocxx::instance instance{};   // ровно один на программу
// Локальный сервер учебного стенда
mongocxx::client client{mongocxx::uri{"mongodb://localhost:27017"}};

int main() {
    {
        // Атлас: mongocxx::uri{"mongodb+srv://user:pass@cluster0.mongodb.net"}
        std::cout << "Базы данных:";
        for (const auto& name : client.list_database_names())
            std::cout << " " << name;
        std::cout << std::endl;

        auto db = client["shop"];
        std::cout << "Коллекции shop:";
        for (const auto& name : db.list_collection_names())
            std::cout << " " << name;
        std::cout << std::endl;

        auto collection = db["products"];
        std::cout << "Документов: " << collection.count_documents(make_document()) << std::endl;
    }
}
