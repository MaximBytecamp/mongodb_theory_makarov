// Глава 1.1 · Сервер, база, коллекция
// Пример 4 из 5 · §8 Один клиент на программу · C++
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/04.cpp
//   cd primery, затем g++ -std=c++17 04.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────

// один пул на программу: клиент живёт рядом с приложением
mongocxx::instance instance{};
mongocxx::client client{mongocxx::uri{"mongodb://localhost:27017"}};
auto products = client["shop"]["products"];
auto count_all() {
    return products.count_documents(make_document());
}

int main() {
    {

    }
}
