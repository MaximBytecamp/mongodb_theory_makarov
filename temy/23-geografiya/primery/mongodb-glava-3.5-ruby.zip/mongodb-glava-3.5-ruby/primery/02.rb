# Глава 3.5 · География: 2dsphere, $near, $geoWithin, $geoIntersects
# Пример 2 из 5 · §2 Ближайшие точки: $near · ближайшие пункты: $near
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/02.rb
#   cd primery, затем ruby 02.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
events = client.use("logs").database[:events]
sandbox = client.use("sandbox").database
box = sandbox[:products]   # песочница: здесь можно менять

pickup = sandbox[:pickup]         # пункты выдачи: точки на карте
zones = sandbox[:zones]           # зоны доставки: многоугольники

# Покупатель в центре Ярославля: долгота, затем широта.
here = { "type" => "Point", "coordinates" => [39.8875, 57.6300] }

# ── пример из главы ───────────────────────────────────────────
near = { "location" => { "$near" => { "$geometry" => here, "$maxDistance" => 3500 } } }
pickup.find(near).each { |doc| puts "до 3,5 км: " + doc["name"] }

puts "все по расстоянию:"
pickup.find({ "location" => { "$near" => { "$geometry" => here } } }).each { |doc| puts "   " + doc["name"] }
