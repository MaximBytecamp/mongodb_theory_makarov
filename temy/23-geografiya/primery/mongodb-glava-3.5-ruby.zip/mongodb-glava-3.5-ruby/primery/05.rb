# Глава 3.5 · География: 2dsphere, $near, $geoWithin, $geoIntersects
# Пример 5 из 5 · §5 Долгота и широта · порядок: долгота, потом широта
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/05.rb
#   cd primery, затем ruby 05.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
events = client.use("logs").database[:events]
sandbox = client.use("sandbox").database
box = sandbox[:products]   # песочница: здесь можно менять

pickup = sandbox[:pickup]         # пункты выдачи: точки на карте
zones = sandbox[:zones]           # зоны доставки: многоугольники

# Покупатель в центре Ярославля: долгота, затем широта.
here = { "type" => "Point", "coordinates" => [39.8875, 57.6300] }

# ── пример из главы ───────────────────────────────────────────
pickup.insert_one({ "_id" => "pv-7", "name" => "Пункт 7, координаты перепутаны",
                    "location" => { "type" => "Point", "coordinates" => [57.6261, 39.8938] } })
puts "по расстоянию: " + pickup.find({ "location" => { "$near" => { "$geometry" => here } } }).map { |doc| doc["_id"] }.to_s
circle = { "location" => { "$geoWithin" => { "$centerSphere" => [[39.8875, 57.6300], 5 / 6378.1] } } }
puts "в круге 5 км:  " + pickup.find(circle).sort({ "_id" => 1 }).map { |doc| doc["_id"] }.to_s

begin
  pickup.insert_one({ "_id" => "pv-8", "name" => "Пункт 8, Владивосток, координаты перепутаны",
                      "location" => { "type" => "Point", "coordinates" => [43.1155, 131.8855] } })
rescue Mongo::Error::OperationFailure => e
  puts "широта 131.8855 отклонена, код #{e.code}"
end
