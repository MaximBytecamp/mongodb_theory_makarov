# Глава 3.5 · География: 2dsphere, $near, $geoWithin, $geoIntersects
# Пример 4 из 5 · §4 В какую зону попадает точка: $geoIntersects · в какую зону попадает точка: $geoIntersects
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/04.rb
#   cd primery, затем ruby 04.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
events = client.use("logs").database[:events]
sandbox = client.use("sandbox").database
box = sandbox[:products]   # песочница: здесь можно менять

pickup = sandbox[:pickup]         # пункты выдачи: точки на карте
zones = sandbox[:zones]           # зоны доставки: многоугольники

# Покупатель в центре Ярославля: долгота, затем широта.
here = { "type" => "Point", "coordinates" => [39.8875, 57.6300] }

# ── пример из главы ───────────────────────────────────────────
zones.drop
zones.insert_many([
  { "_id" => "z-centr", "name" => "Зона центр", "days" => 1,
    "area" => { "type" => "Polygon", "coordinates" => [[[39.85, 57.61], [39.93, 57.61], [39.93, 57.65], [39.85, 57.65], [39.85, 57.61]]] } },
  { "_id" => "z-sever", "name" => "Зона север", "days" => 2,
    "area" => { "type" => "Polygon", "coordinates" => [[[39.78, 57.65], [39.98, 57.65], [39.98, 57.72], [39.78, 57.72], [39.78, 57.65]]] } },
])
zones.indexes.create_one({ "area" => "2dsphere" })

[["покупатель", here],
 ["Брагино", { "type" => "Point", "coordinates" => [39.8178, 57.6929] }],
 ["Москва", { "type" => "Point", "coordinates" => [37.6056, 55.7650] }]].each do |label, point|
  zone = zones.find({ "area" => { "$geoIntersects" => { "$geometry" => point } } }).first
  puts label + ": " + (zone ? "#{zone["name"]}, доставка #{zone["days"]} дн." : "вне зон доставки")
end
