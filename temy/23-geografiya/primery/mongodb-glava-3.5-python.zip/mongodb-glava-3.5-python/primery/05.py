# Глава 3.5 · География: 2dsphere, $near, $geoWithin, $geoIntersects
# Пример 5 из 5 · §5 Долгота и широта · порядок: долгота, потом широта
#
# Запуск из папки архива:
#   docker compose run --rm python primery/05.py
#   cd primery, затем python 05.py (Windows) или python3 05.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
events = client["logs"]["events"]
sandbox = client["sandbox"]
box = sandbox["products"]        # песочница: здесь можно менять

pickup = sandbox["pickup"]        # пункты выдачи: точки на карте
zones = sandbox["zones"]          # зоны доставки: многоугольники

# Покупатель в центре Ярославля: долгота, затем широта.
here = {"type": "Point", "coordinates": [39.8875, 57.6300]}

# ── пример из главы ───────────────────────────────────────────
from pymongo.errors import WriteError

pickup.insert_one({"_id": "pv-7", "name": "Пункт 7, координаты перепутаны",
                   "location": {"type": "Point", "coordinates": [57.6261, 39.8938]}})
print("по расстоянию:", [doc["_id"] for doc in pickup.find({"location": {"$near": {"$geometry": here}}})])
circle = {"location": {"$geoWithin": {"$centerSphere": [[39.8875, 57.6300], 5 / 6378.1]}}}
print("в круге 5 км: ", [doc["_id"] for doc in pickup.find(circle).sort("_id", 1)])

try:
    pickup.insert_one({"_id": "pv-8", "name": "Пункт 8, Владивосток, координаты перепутаны",
                       "location": {"type": "Point", "coordinates": [43.1155, 131.8855]}})
except WriteError as e:
    print("широта 131.8855 отклонена, код", e.code)
