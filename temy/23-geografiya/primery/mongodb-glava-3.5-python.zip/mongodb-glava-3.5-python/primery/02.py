# Глава 3.5 · География: 2dsphere, $near, $geoWithin, $geoIntersects
# Пример 2 из 5 · §2 Ближайшие точки: $near · ближайшие пункты: $near
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
events = client["logs"]["events"]
sandbox = client["sandbox"]
box = sandbox["products"]        # песочница: здесь можно менять

pickup = sandbox["pickup"]        # пункты выдачи: точки на карте
zones = sandbox["zones"]          # зоны доставки: многоугольники

# Покупатель в центре Ярославля: долгота, затем широта.
here = {"type": "Point", "coordinates": [39.8875, 57.6300]}

# ── пример из главы ───────────────────────────────────────────
near = {"location": {"$near": {"$geometry": here, "$maxDistance": 3500}}}
for doc in pickup.find(near):
    print("до 3,5 км:", doc["name"])

print("все по расстоянию:")
for doc in pickup.find({"location": {"$near": {"$geometry": here}}}):
    print("  ", doc["name"])
