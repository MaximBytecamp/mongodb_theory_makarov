# Глава 3.5 · География: 2dsphere, $near, $geoWithin, $geoIntersects
# Пример 1 из 5 · §1 Точка на карте: GeoJSON и индекс 2dsphere · точки на карте и индекс 2dsphere
#
# Запуск из папки архива:
#   docker compose run --rm python primery/01.py
#   cd primery, затем python 01.py (Windows) или python3 01.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
events = client["logs"]["events"]
sandbox = client["sandbox"]
box = sandbox["products"]        # песочница: здесь можно менять

pickup = sandbox["pickup"]        # пункты выдачи: точки на карте
zones = sandbox["zones"]          # зоны доставки: многоугольники

# Покупатель в центре Ярославля: долгота, затем широта.
here = {"type": "Point", "coordinates": [39.8875, 57.6300]}

# ── пример из главы ───────────────────────────────────────────
from pymongo.errors import OperationFailure

points = [
    ("pv-1", "Пункт 1, центр", 39.8938, 57.6261),
    ("pv-2", "Пункт 2, вокзал", 39.8370, 57.6337),
    ("pv-3", "Пункт 3, Брагино", 39.8178, 57.6929),
    ("pv-4", "Пункт 4, Фрунзенский район", 39.9050, 57.5848),
    ("pv-5", "Пункт 5, Заволжье", 39.9500, 57.6650),
    ("pv-6", "Пункт 6, Москва", 37.6056, 55.7650),
]
pickup.drop()
pickup.insert_many({"_id": pid, "name": name, "location": {"type": "Point", "coordinates": [lng, lat]}}
                   for pid, name, lng, lat in points)
print("пунктов выдачи:", pickup.count_documents({}))

try:
    list(pickup.find({"location": {"$near": {"$geometry": here}}}))
except OperationFailure as e:
    print("$near без индекса: ошибка", e.code)

print("создан индекс:", pickup.create_index([("location", "2dsphere")]))
