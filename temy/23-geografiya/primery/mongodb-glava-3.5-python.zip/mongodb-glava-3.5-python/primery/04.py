# Глава 3.5 · География: 2dsphere, $near, $geoWithin, $geoIntersects
# Пример 4 из 5 · §4 В какую зону попадает точка: $geoIntersects · в какую зону попадает точка: $geoIntersects
#
# Запуск из папки архива:
#   docker compose run --rm python primery/04.py
#   cd primery, затем python 04.py (Windows) или python3 04.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
events = client["logs"]["events"]
sandbox = client["sandbox"]
box = sandbox["products"]        # песочница: здесь можно менять

pickup = sandbox["pickup"]        # пункты выдачи: точки на карте
zones = sandbox["zones"]          # зоны доставки: многоугольники

# Покупатель в центре Ярославля: долгота, затем широта.
here = {"type": "Point", "coordinates": [39.8875, 57.6300]}

# ── пример из главы ───────────────────────────────────────────
zones.drop()
zones.insert_many([
    {"_id": "z-centr", "name": "Зона центр", "days": 1,
     "area": {"type": "Polygon", "coordinates": [[[39.85, 57.61], [39.93, 57.61], [39.93, 57.65], [39.85, 57.65], [39.85, 57.61]]]}},
    {"_id": "z-sever", "name": "Зона север", "days": 2,
     "area": {"type": "Polygon", "coordinates": [[[39.78, 57.65], [39.98, 57.65], [39.98, 57.72], [39.78, 57.72], [39.78, 57.65]]]}},
])
zones.create_index([("area", "2dsphere")])

for label, point in [("покупатель", here),
                     ("Брагино", {"type": "Point", "coordinates": [39.8178, 57.6929]}),
                     ("Москва", {"type": "Point", "coordinates": [37.6056, 55.7650]})]:
    zone = zones.find_one({"area": {"$geoIntersects": {"$geometry": point}}})
    print(label + ":", f"{zone['name']}, доставка {zone['days']} дн." if zone else "вне зон доставки")
