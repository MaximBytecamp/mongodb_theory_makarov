# Глава 3.5 · География: 2dsphere, $near, $geoWithin, $geoIntersects
# Пример 3 из 5 · §3 Точки внутри области: $geoWithin · точки внутри области: $geoWithin
#
# Запуск из папки архива:
#   docker compose run --rm python primery/03.py
#   cd primery, затем python 03.py (Windows) или python3 03.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
events = client["logs"]["events"]
sandbox = client["sandbox"]
box = sandbox["products"]        # песочница: здесь можно менять

pickup = sandbox["pickup"]        # пункты выдачи: точки на карте
zones = sandbox["zones"]          # зоны доставки: многоугольники

# Покупатель в центре Ярославля: долгота, затем широта.
here = {"type": "Point", "coordinates": [39.8875, 57.6300]}

# ── пример из главы ───────────────────────────────────────────
circle = {"location": {"$geoWithin": {"$centerSphere": [[39.8875, 57.6300], 5 / 6378.1]}}}
print("в круге 5 км:    ", [doc["_id"] for doc in pickup.find(circle).sort("_id", 1)])

square = {"type": "Polygon",
          "coordinates": [[[39.80, 57.60], [39.92, 57.60], [39.92, 57.70], [39.80, 57.70], [39.80, 57.60]]]}
inside = {"location": {"$geoWithin": {"$geometry": square}}}
print("в прямоугольнике:", [doc["_id"] for doc in pickup.find(inside).sort("_id", 1)])
