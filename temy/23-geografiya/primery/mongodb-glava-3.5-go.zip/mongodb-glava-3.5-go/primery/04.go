//go:build ignore

// Глава 3.5 · География: 2dsphere, $near, $geoWithin, $geoIntersects
// Пример 4 из 5 · §4 В какую зону попадает точка: $geoIntersects · в какую зону попадает точка: $geoIntersects
//
// Запуск из папки архива:
//   docker compose run --rm go primery/04.go
//   cd primery, затем go run 04.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	products := db.Collection("products")
	orders := db.Collection("orders")
	events := client.Database("logs").Collection("events")
	sandbox := client.Database("sandbox")
	box := sandbox.Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, products, orders, events, sandbox, box

	pickup := sandbox.Collection("pickup") // пункты выдачи: точки на карте
	zones := sandbox.Collection("zones")   // зоны доставки: многоугольники

	// Покупатель в центре Ярославля: долгота, затем широта.
	here := bson.D{{Key: "type", Value: "Point"}, {Key: "coordinates", Value: bson.A{39.8875, 57.6300}}}
	_, _, _ = pickup, zones, here

	{
		// ── пример из главы ──────────────────────────────────────
		zones.Drop(ctx)
		zones.InsertMany(ctx, []any{
		    bson.D{{Key: "_id", Value: "z-centr"}, {Key: "name", Value: "Зона центр"}, {Key: "days", Value: 1},
		        {Key: "area", Value: bson.D{{Key: "type", Value: "Polygon"}, {Key: "coordinates", Value: bson.A{bson.A{bson.A{39.85, 57.61}, bson.A{39.93, 57.61}, bson.A{39.93, 57.65}, bson.A{39.85, 57.65}, bson.A{39.85, 57.61}}}}}}},
		    bson.D{{Key: "_id", Value: "z-sever"}, {Key: "name", Value: "Зона север"}, {Key: "days", Value: 2},
		        {Key: "area", Value: bson.D{{Key: "type", Value: "Polygon"}, {Key: "coordinates", Value: bson.A{bson.A{bson.A{39.78, 57.65}, bson.A{39.98, 57.65}, bson.A{39.98, 57.72}, bson.A{39.78, 57.72}, bson.A{39.78, 57.65}}}}}}}})
		zones.Indexes().CreateOne(ctx, mongo.IndexModel{Keys: bson.D{{Key: "area", Value: "2dsphere"}}})

		point := func(lng, lat float64) bson.D {
		    return bson.D{{Key: "type", Value: "Point"}, {Key: "coordinates", Value: bson.A{lng, lat}}}
		}
		for _, place := range []struct {
		    label string
		    where bson.D
		}{{"покупатель", here}, {"Брагино", point(39.8178, 57.6929)}, {"Москва", point(37.6056, 55.7650)}} {
		    var zone bson.M
		    err := zones.FindOne(ctx, bson.D{{Key: "area", Value: bson.D{{Key: "$geoIntersects", Value: bson.D{{Key: "$geometry", Value: place.where}}}}}}).Decode(&zone)
		    if err != nil {
		        fmt.Println(place.label + ": вне зон доставки")
		    } else {
		        fmt.Printf("%s: %s, доставка %d дн.\n", place.label, zone["name"], zone["days"])
		    }
		}
	}
}
