//go:build ignore

// Глава 3.5 · География: 2dsphere, $near, $geoWithin, $geoIntersects
// Пример 1 из 5 · §1 Точка на карте: GeoJSON и индекс 2dsphere · точки на карте и индекс 2dsphere
//
// Запуск из папки архива:
//   docker compose run --rm go primery/01.go
//   cd primery, затем go run 01.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────

var ce mongo.CommandError

func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	products := db.Collection("products")
	orders := db.Collection("orders")
	events := client.Database("logs").Collection("events")
	sandbox := client.Database("sandbox")
	box := sandbox.Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, products, orders, events, sandbox, box

	pickup := sandbox.Collection("pickup") // пункты выдачи: точки на карте
	zones := sandbox.Collection("zones")   // зоны доставки: многоугольники

	// Покупатель в центре Ярославля: долгота, затем широта.
	here := bson.D{{Key: "type", Value: "Point"}, {Key: "coordinates", Value: bson.A{39.8875, 57.6300}}}
	_, _, _ = pickup, zones, here

	{
		// ── пример из главы ──────────────────────────────────────
		points := []struct {
		    id, name string
		    lng, lat float64
		}{
		    {"pv-1", "Пункт 1, центр", 39.8938, 57.6261},
		    {"pv-2", "Пункт 2, вокзал", 39.8370, 57.6337},
		    {"pv-3", "Пункт 3, Брагино", 39.8178, 57.6929},
		    {"pv-4", "Пункт 4, Фрунзенский район", 39.9050, 57.5848},
		    {"pv-5", "Пункт 5, Заволжье", 39.9500, 57.6650},
		    {"pv-6", "Пункт 6, Москва", 37.6056, 55.7650},
		}
		pickup.Drop(ctx)
		docs := []any{}
		for _, p := range points {
		    docs = append(docs, bson.D{
		        {Key: "_id", Value: p.id},
		        {Key: "name", Value: p.name},
		        {Key: "location", Value: bson.D{{Key: "type", Value: "Point"}, {Key: "coordinates", Value: bson.A{p.lng, p.lat}}}}})
		}
		pickup.InsertMany(ctx, docs)
		n, _ := pickup.CountDocuments(ctx, bson.D{})
		fmt.Println("пунктов выдачи:", n)

		_, err := pickup.Find(ctx, bson.D{{Key: "location", Value: bson.D{{Key: "$near", Value: bson.D{{Key: "$geometry", Value: here}}}}}})
		if errors.As(err, &ce) {
		    fmt.Println("$near без индекса: ошибка", ce.Code)
		}

		name, _ := pickup.Indexes().CreateOne(ctx, mongo.IndexModel{Keys: bson.D{{Key: "location", Value: "2dsphere"}}})
		fmt.Println("создан индекс:", name)
	}
}
