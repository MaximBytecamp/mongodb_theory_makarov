//go:build ignore

// Глава 3.5 · География: 2dsphere, $near, $geoWithin, $geoIntersects
// Пример 2 из 5 · §2 Ближайшие точки: $near · ближайшие пункты: $near
//
// Запуск из папки архива:
//   docker compose run --rm go primery/02.go
//   cd primery, затем go run 02.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	products := db.Collection("products")
	orders := db.Collection("orders")
	events := client.Database("logs").Collection("events")
	sandbox := client.Database("sandbox")
	box := sandbox.Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, products, orders, events, sandbox, box

	pickup := sandbox.Collection("pickup") // пункты выдачи: точки на карте
	zones := sandbox.Collection("zones")   // зоны доставки: многоугольники

	// Покупатель в центре Ярославля: долгота, затем широта.
	here := bson.D{{Key: "type", Value: "Point"}, {Key: "coordinates", Value: bson.A{39.8875, 57.6300}}}
	_, _, _ = pickup, zones, here

	{
		// ── пример из главы ──────────────────────────────────────
		near := bson.D{{Key: "location", Value: bson.D{{Key: "$near", Value: bson.D{
		    {Key: "$geometry", Value: here}, {Key: "$maxDistance", Value: 3500}}}}}}
		cursor, _ := pickup.Find(ctx, near)
		for cursor.Next(ctx) {
		    fmt.Println("до 3,5 км:", cursor.Current.Lookup("name").StringValue())
		}

		fmt.Println("все по расстоянию:")
		all, _ := pickup.Find(ctx, bson.D{{Key: "location", Value: bson.D{{Key: "$near", Value: bson.D{{Key: "$geometry", Value: here}}}}}})
		for all.Next(ctx) {
		    fmt.Println("  ", all.Current.Lookup("name").StringValue())
		}
	}
}
