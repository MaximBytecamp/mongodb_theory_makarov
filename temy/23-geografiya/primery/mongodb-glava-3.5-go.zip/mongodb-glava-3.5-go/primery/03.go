//go:build ignore

// Глава 3.5 · География: 2dsphere, $near, $geoWithin, $geoIntersects
// Пример 3 из 5 · §3 Точки внутри области: $geoWithin · точки внутри области: $geoWithin
//
// Запуск из папки архива:
//   docker compose run --rm go primery/03.go
//   cd primery, затем go run 03.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	products := db.Collection("products")
	orders := db.Collection("orders")
	events := client.Database("logs").Collection("events")
	sandbox := client.Database("sandbox")
	box := sandbox.Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, products, orders, events, sandbox, box

	pickup := sandbox.Collection("pickup") // пункты выдачи: точки на карте
	zones := sandbox.Collection("zones")   // зоны доставки: многоугольники

	// Покупатель в центре Ярославля: долгота, затем широта.
	here := bson.D{{Key: "type", Value: "Point"}, {Key: "coordinates", Value: bson.A{39.8875, 57.6300}}}
	_, _, _ = pickup, zones, here

	{
		// ── пример из главы ──────────────────────────────────────
		ids := func(filtr bson.D) []string {
		    cursor, _ := pickup.Find(ctx, filtr, options.Find().SetSort(bson.D{{Key: "_id", Value: 1}}))
		    found := []string{}
		    for cursor.Next(ctx) {
		        found = append(found, cursor.Current.Lookup("_id").StringValue())
		    }
		    return found
		}

		circle := bson.D{{Key: "location", Value: bson.D{{Key: "$geoWithin", Value: bson.D{
		    {Key: "$centerSphere", Value: bson.A{bson.A{39.8875, 57.6300}, 5 / 6378.1}}}}}}}
		fmt.Println("в круге 5 км:    ", ids(circle))

		square := bson.D{{Key: "type", Value: "Polygon"}, {Key: "coordinates", Value: bson.A{bson.A{
		    bson.A{39.80, 57.60}, bson.A{39.92, 57.60}, bson.A{39.92, 57.70}, bson.A{39.80, 57.70}, bson.A{39.80, 57.60}}}}}
		inside := bson.D{{Key: "location", Value: bson.D{{Key: "$geoWithin", Value: bson.D{{Key: "$geometry", Value: square}}}}}}
		fmt.Println("в прямоугольнике:", ids(inside))
	}
}
