//go:build ignore

// Глава 3.5 · География: 2dsphere, $near, $geoWithin, $geoIntersects
// Пример 5 из 5 · §5 Долгота и широта · порядок: долгота, потом широта
//
// Запуск из папки архива:
//   docker compose run --rm go primery/05.go
//   cd primery, затем go run 05.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────

var we mongo.WriteException

func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	products := db.Collection("products")
	orders := db.Collection("orders")
	events := client.Database("logs").Collection("events")
	sandbox := client.Database("sandbox")
	box := sandbox.Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, products, orders, events, sandbox, box

	pickup := sandbox.Collection("pickup") // пункты выдачи: точки на карте
	zones := sandbox.Collection("zones")   // зоны доставки: многоугольники

	// Покупатель в центре Ярославля: долгота, затем широта.
	here := bson.D{{Key: "type", Value: "Point"}, {Key: "coordinates", Value: bson.A{39.8875, 57.6300}}}
	_, _, _ = pickup, zones, here

	{
		// ── пример из главы ──────────────────────────────────────
		pickup.InsertOne(ctx, bson.D{{Key: "_id", Value: "pv-7"}, {Key: "name", Value: "Пункт 7, координаты перепутаны"},
		    {Key: "location", Value: bson.D{{Key: "type", Value: "Point"}, {Key: "coordinates", Value: bson.A{57.6261, 39.8938}}}}})

		ids := func(cursor *mongo.Cursor) []string {
		    found := []string{}
		    for cursor.Next(ctx) {
		        found = append(found, cursor.Current.Lookup("_id").StringValue())
		    }
		    return found
		}
		byDistance, _ := pickup.Find(ctx, bson.D{{Key: "location", Value: bson.D{{Key: "$near", Value: bson.D{{Key: "$geometry", Value: here}}}}}})
		fmt.Println("по расстоянию:", ids(byDistance))
		circle := bson.D{{Key: "location", Value: bson.D{{Key: "$geoWithin", Value: bson.D{
		    {Key: "$centerSphere", Value: bson.A{bson.A{39.8875, 57.6300}, 5 / 6378.1}}}}}}}
		inCircle, _ := pickup.Find(ctx, circle, options.Find().SetSort(bson.D{{Key: "_id", Value: 1}}))
		fmt.Println("в круге 5 км: ", ids(inCircle))

		_, err := pickup.InsertOne(ctx, bson.D{{Key: "_id", Value: "pv-8"}, {Key: "name", Value: "Пункт 8, Владивосток, координаты перепутаны"},
		    {Key: "location", Value: bson.D{{Key: "type", Value: "Point"}, {Key: "coordinates", Value: bson.A{43.1155, 131.8855}}}}})
		if errors.As(err, &we) {
		    fmt.Println("широта 131.8855 отклонена, код", we.WriteErrors[0].Code)
		}
	}
}
