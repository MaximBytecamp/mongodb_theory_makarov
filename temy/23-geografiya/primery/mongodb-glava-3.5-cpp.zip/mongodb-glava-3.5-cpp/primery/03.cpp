// Глава 3.5 · География: 2dsphere, $near, $geoWithin, $geoIntersects
// Пример 3 из 5 · §3 Точки внутри области: $geoWithin · точки внутри области: $geoWithin
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/03.cpp
//   cd primery, затем g++ -std=c++17 03.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto products = db["products"];
    auto orders = db["orders"];
    auto events = client["logs"]["events"];
    auto sandbox = client["sandbox"];
    auto box = sandbox["products"];   // песочница: здесь можно менять

    auto pickup = sandbox["pickup"];   // пункты выдачи: точки на карте
    auto zones = sandbox["zones"];     // зоны доставки: многоугольники

    // Покупатель в центре Ярославля: долгота, затем широта.
    auto here = make_document(kvp("type", "Point"), kvp("coordinates", make_array(39.8875, 57.6300)));

    {
        // ── пример из главы ──────────────────────────────────────
        mongocxx::options::find by_id;
        by_id.sort(make_document(kvp("_id", 1)));
        auto ids = [&](bsoncxx::document::view filtr) {
            std::string found;
            for (auto&& doc : pickup.find(filtr, by_id)) {
                found += (found.empty() ? "" : " ") + std::string{doc["_id"].get_string().value};
            }
            return found;
        };

        auto circle = make_document(kvp("location", make_document(kvp("$geoWithin", make_document(
            kvp("$centerSphere", make_array(make_array(39.8875, 57.6300), 5 / 6378.1)))))));
        std::cout << "в круге 5 км:     " << ids(circle.view()) << std::endl;

        auto square = make_document(kvp("type", "Polygon"), kvp("coordinates", make_array(make_array(
            make_array(39.80, 57.60), make_array(39.92, 57.60), make_array(39.92, 57.70), make_array(39.80, 57.70), make_array(39.80, 57.60)))));
        auto inside = make_document(kvp("location", make_document(kvp("$geoWithin", make_document(kvp("$geometry", square.view()))))));
        std::cout << "в прямоугольнике: " << ids(inside.view()) << std::endl;
    }
}
