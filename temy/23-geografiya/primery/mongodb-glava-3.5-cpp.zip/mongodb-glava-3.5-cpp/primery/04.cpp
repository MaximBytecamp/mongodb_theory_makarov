// Глава 3.5 · География: 2dsphere, $near, $geoWithin, $geoIntersects
// Пример 4 из 5 · §4 В какую зону попадает точка: $geoIntersects · в какую зону попадает точка: $geoIntersects
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/04.cpp
//   cd primery, затем g++ -std=c++17 04.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto products = db["products"];
    auto orders = db["orders"];
    auto events = client["logs"]["events"];
    auto sandbox = client["sandbox"];
    auto box = sandbox["products"];   // песочница: здесь можно менять

    auto pickup = sandbox["pickup"];   // пункты выдачи: точки на карте
    auto zones = sandbox["zones"];     // зоны доставки: многоугольники

    // Покупатель в центре Ярославля: долгота, затем широта.
    auto here = make_document(kvp("type", "Point"), kvp("coordinates", make_array(39.8875, 57.6300)));

    {
        // ── пример из главы ──────────────────────────────────────
        zones.drop();
        std::vector<bsoncxx::document::value> areas;
        areas.push_back(make_document(kvp("_id", "z-centr"), kvp("name", "Зона центр"), kvp("days", 1),
            kvp("area", make_document(kvp("type", "Polygon"), kvp("coordinates", make_array(make_array(make_array(39.85, 57.61), make_array(39.93, 57.61), make_array(39.93, 57.65), make_array(39.85, 57.65), make_array(39.85, 57.61))))))));
        areas.push_back(make_document(kvp("_id", "z-sever"), kvp("name", "Зона север"), kvp("days", 2),
            kvp("area", make_document(kvp("type", "Polygon"), kvp("coordinates", make_array(make_array(make_array(39.78, 57.65), make_array(39.98, 57.65), make_array(39.98, 57.72), make_array(39.78, 57.72), make_array(39.78, 57.65))))))));
        zones.insert_many(areas);
        zones.create_index(make_document(kvp("area", "2dsphere")));

        auto point = [](double lng, double lat) {
            return make_document(kvp("type", "Point"), kvp("coordinates", make_array(lng, lat)));
        };
        std::vector<std::pair<std::string, bsoncxx::document::value>> places;
        places.emplace_back("покупатель", here);
        places.emplace_back("Брагино", point(39.8178, 57.6929));
        places.emplace_back("Москва", point(37.6056, 55.7650));
        for (const auto& [label, where] : places) {
            auto zone = zones.find_one(make_document(kvp("area", make_document(kvp("$geoIntersects", make_document(kvp("$geometry", where.view())))))));
            if (zone) {
                std::cout << label << ": " << zone->view()["name"].get_string().value
                          << ", доставка " << zone->view()["days"].get_int32().value << " дн." << std::endl;
            } else {
                std::cout << label << ": вне зон доставки" << std::endl;
            }
        }
    }
}
