// Глава 3.5 · География: 2dsphere, $near, $geoWithin, $geoIntersects
// Пример 5 из 5 · §5 Долгота и широта · порядок: долгота, потом широта
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/05.cpp
//   cd primery, затем g++ -std=c++17 05.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto products = db["products"];
    auto orders = db["orders"];
    auto events = client["logs"]["events"];
    auto sandbox = client["sandbox"];
    auto box = sandbox["products"];   // песочница: здесь можно менять

    auto pickup = sandbox["pickup"];   // пункты выдачи: точки на карте
    auto zones = sandbox["zones"];     // зоны доставки: многоугольники

    // Покупатель в центре Ярославля: долгота, затем широта.
    auto here = make_document(kvp("type", "Point"), kvp("coordinates", make_array(39.8875, 57.6300)));

    {
        // ── пример из главы ──────────────────────────────────────
        pickup.insert_one(make_document(kvp("_id", "pv-7"), kvp("name", "Пункт 7, координаты перепутаны"),
            kvp("location", make_document(kvp("type", "Point"), kvp("coordinates", make_array(57.6261, 39.8938))))));

        auto ids = [](mongocxx::cursor cursor) {
            std::string found;
            for (auto&& doc : cursor) found += (found.empty() ? "" : " ") + std::string{doc["_id"].get_string().value};
            return found;
        };
        std::cout << "по расстоянию: "
                  << ids(pickup.find(make_document(kvp("location", make_document(kvp("$near", make_document(kvp("$geometry", here.view())))))))) << std::endl;
        mongocxx::options::find by_id;
        by_id.sort(make_document(kvp("_id", 1)));
        auto circle = make_document(kvp("location", make_document(kvp("$geoWithin", make_document(
            kvp("$centerSphere", make_array(make_array(39.8875, 57.6300), 5 / 6378.1)))))));
        std::cout << "в круге 5 км:  " << ids(pickup.find(circle.view(), by_id)) << std::endl;

        try {
            pickup.insert_one(make_document(kvp("_id", "pv-8"), kvp("name", "Пункт 8, Владивосток, координаты перепутаны"),
                kvp("location", make_document(kvp("type", "Point"), kvp("coordinates", make_array(43.1155, 131.8855))))));
        } catch (const mongocxx::operation_exception& e) {
            std::cout << "широта 131.8855 отклонена, код " << e.code().value() << std::endl;
        }
    }
}
