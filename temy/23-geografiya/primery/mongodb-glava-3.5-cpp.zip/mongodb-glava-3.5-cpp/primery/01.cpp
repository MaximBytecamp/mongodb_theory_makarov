// Глава 3.5 · География: 2dsphere, $near, $geoWithin, $geoIntersects
// Пример 1 из 5 · §1 Точка на карте: GeoJSON и индекс 2dsphere · точки на карте и индекс 2dsphere
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/01.cpp
//   cd primery, затем g++ -std=c++17 01.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────

struct point { std::string id, name; double lng, lat; };

int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto products = db["products"];
    auto orders = db["orders"];
    auto events = client["logs"]["events"];
    auto sandbox = client["sandbox"];
    auto box = sandbox["products"];   // песочница: здесь можно менять

    auto pickup = sandbox["pickup"];   // пункты выдачи: точки на карте
    auto zones = sandbox["zones"];     // зоны доставки: многоугольники

    // Покупатель в центре Ярославля: долгота, затем широта.
    auto here = make_document(kvp("type", "Point"), kvp("coordinates", make_array(39.8875, 57.6300)));

    {
        // ── пример из главы ──────────────────────────────────────
        std::vector<point> points{
            {"pv-1", "Пункт 1, центр", 39.8938, 57.6261},
            {"pv-2", "Пункт 2, вокзал", 39.8370, 57.6337},
            {"pv-3", "Пункт 3, Брагино", 39.8178, 57.6929},
            {"pv-4", "Пункт 4, Фрунзенский район", 39.9050, 57.5848},
            {"pv-5", "Пункт 5, Заволжье", 39.9500, 57.6650},
            {"pv-6", "Пункт 6, Москва", 37.6056, 55.7650}};
        pickup.drop();
        std::vector<bsoncxx::document::value> docs;
        for (const auto& p : points) {
            docs.push_back(make_document(
                kvp("_id", p.id),
                kvp("name", p.name),
                kvp("location", make_document(kvp("type", "Point"), kvp("coordinates", make_array(p.lng, p.lat))))));
        }
        pickup.insert_many(docs);
        std::cout << "пунктов выдачи: " << pickup.count_documents(make_document()) << std::endl;

        try {
            for (auto&& doc : pickup.find(make_document(kvp("location", make_document(kvp("$near", make_document(kvp("$geometry", here.view())))))))) {
                (void)doc;
            }
        } catch (const mongocxx::operation_exception& e) {
            std::cout << "$near без индекса: ошибка " << e.code().value() << std::endl;
        }

        auto created = pickup.create_index(make_document(kvp("location", "2dsphere")));
        std::cout << "создан индекс: " << created.view()["name"].get_string().value << std::endl;
    }
}
