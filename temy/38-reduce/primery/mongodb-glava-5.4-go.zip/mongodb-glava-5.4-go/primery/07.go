//go:build ignore

// Глава 5.4 · $reduce: массив в одно значение
// Пример 7 из 7 · §7 Записи, которые сервер не принимает · записи $reduce, которые сервер не принимает
//
// Запуск из папки архива:
//   docker compose run --rm go primery/07.go
//   cd primery, затем go run 07.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────

var ce mongo.CommandError

func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	orders := db.Collection("orders")
	products := db.Collection("products")
	customers := db.Collection("customers")
	sandbox := client.Database("sandbox")
	_, _, _, _, _ = db, orders, products, customers, sandbox

	{
		// ── пример из главы ──────────────────────────────────────
		noInitial := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{{Key: "_id", Value: "o-0002"}}}},
		    {{Key: "$project", Value: bson.D{
		        {Key: "x", Value: bson.D{
		            {Key: "$reduce", Value: bson.D{
		                {Key: "input", Value: "$items"},
		                {Key: "in", Value: bson.D{{Key: "$add", Value: bson.A{"$$value", "$$this.qty"}}}}}}}}}}},
		}

		stringInitial := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{{Key: "_id", Value: "o-0002"}}}},
		    {{Key: "$project", Value: bson.D{
		        {Key: "x", Value: bson.D{
		            {Key: "$reduce", Value: bson.D{
		                {Key: "input", Value: "$items"},
		                {Key: "initialValue", Value: ""},
		                {Key: "in", Value: bson.D{{Key: "$add", Value: bson.A{"$$value", "$$this.qty"}}}}}}}}}}},
		}

		stringInput := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{{Key: "_id", Value: "o-0002"}}}},
		    {{Key: "$project", Value: bson.D{
		        {Key: "x", Value: bson.D{
		            {Key: "$reduce", Value: bson.D{
		                {Key: "input", Value: "$promo"},
		                {Key: "initialValue", Value: 0},
		                {Key: "in", Value: "$$value"}}}}}}}},
		}

		fmt.Println("── нет initialValue")
		_, err := orders.Aggregate(ctx, noInitial)
		if errors.As(err, &ce) {
		    fmt.Println("код", ce.Code)
		    fmt.Println(ce.Message)
		}

		fmt.Println("── initialValue — строка, in складывает числа")
		_, err = orders.Aggregate(ctx, stringInitial)
		if errors.As(err, &ce) {
		    fmt.Println("код", ce.Code)
		    fmt.Println(ce.Message)
		}

		fmt.Println("── input — строка")
		_, err = orders.Aggregate(ctx, stringInput)
		if errors.As(err, &ce) {
		    fmt.Println("код", ce.Code)
		    fmt.Println(ce.Message)
		}
	}
}
