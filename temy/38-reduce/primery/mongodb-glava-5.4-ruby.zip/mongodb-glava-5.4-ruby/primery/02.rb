# Глава 5.4 · $reduce: массив в одно значение
# Пример 2 из 7 · §2 Строка из элементов · $reduce: названия через запятую
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/02.rb
#   cd primery, затем ruby 02.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => "o-0004" } },
  { "$project" => {
    "_id" => 0,
    "number" => 1,
    "titles" => { "$reduce" => {
      "input" => "$items.title",
      "initialValue" => "",
      "in" => { "$cond" => [
        { "$eq" => ["$$value", ""] },
        "$$this",
        { "$concat" => ["$$value", ", ", "$$this"] },
      ] },
    } },
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
