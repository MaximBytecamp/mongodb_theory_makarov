# Глава 5.4 · $reduce: массив в одно значение
# Пример 7 из 7 · §7 Записи, которые сервер не принимает · записи $reduce, которые сервер не принимает
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/07.rb
#   cd primery, затем ruby 07.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
no_initial = [
  { "$match" => { "_id" => "o-0002" } },
  { "$project" => { "x" => { "$reduce" => {
    "input" => "$items",
    "in" => { "$add" => ["$$value", "$$this.qty"] },
  } } } },
]

string_initial = [
  { "$match" => { "_id" => "o-0002" } },
  { "$project" => { "x" => { "$reduce" => {
    "input" => "$items",
    "initialValue" => "",
    "in" => { "$add" => ["$$value", "$$this.qty"] },
  } } } },
]

string_input = [
  { "$match" => { "_id" => "o-0002" } },
  { "$project" => { "x" => { "$reduce" => {
    "input" => "$promo",
    "initialValue" => 0,
    "in" => "$$value",
  } } } },
]

puts "── нет initialValue"
begin
  orders.aggregate(no_initial).each { |doc| puts doc.inspect }
rescue Mongo::Error::OperationFailure => e
  puts "код #{e.code}"
  puts e.document["errmsg"]
end

puts "── initialValue — строка, in складывает числа"
begin
  orders.aggregate(string_initial).each { |doc| puts doc.inspect }
rescue Mongo::Error::OperationFailure => e
  puts "код #{e.code}"
  puts e.document["errmsg"]
end

puts "── input — строка"
begin
  orders.aggregate(string_input).each { |doc| puts doc.inspect }
rescue Mongo::Error::OperationFailure => e
  puts "код #{e.code}"
  puts e.document["errmsg"]
end
