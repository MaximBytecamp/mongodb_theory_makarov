# Глава 5.4 · $reduce: массив в одно значение
# Пример 4 из 7 · §4 Элемент с наибольшим полем · $reduce: самая дорогая позиция
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/04.rb
#   cd primery, затем ruby 04.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => "o-0004" } },
  { "$project" => {
    "_id" => 0,
    "number" => 1,
    "top" => { "$reduce" => {
      "input" => "$items",
      "initialValue" => { "price" => 0 },
      "in" => { "$cond" => [
        { "$gt" => ["$$this.price", "$$value.price"] },
        "$$this",
        "$$value",
      ] },
    } },
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
