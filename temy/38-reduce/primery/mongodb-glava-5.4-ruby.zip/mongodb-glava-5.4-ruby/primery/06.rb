# Глава 5.4 · $reduce: массив в одно значение
# Пример 6 из 7 · §6 Один знак $ у $$value · $value вместо $$value
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/06.rb
#   cd primery, затем ruby 06.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => "o-0002" } },
  { "$project" => {
    "_id" => 0,
    "wrong" => { "$reduce" => {
      "input" => "$items",
      "initialValue" => 0,
      "in" => { "$add" => ["$value", "$$this.qty"] },
    } },
    "right" => { "$reduce" => {
      "input" => "$items",
      "initialValue" => 0,
      "in" => { "$add" => ["$$value", "$$this.qty"] },
    } },
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
