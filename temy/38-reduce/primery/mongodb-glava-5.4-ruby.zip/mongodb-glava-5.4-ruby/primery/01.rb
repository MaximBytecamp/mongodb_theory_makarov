# Глава 5.4 · $reduce: массив в одно значение
# Пример 1 из 7 · §1 Выражение $reduce · $reduce: штуки в заказе
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/01.rb
#   cd primery, затем ruby 01.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => "o-0002" } },
  { "$project" => {
    "_id" => 0,
    "number" => 1,
    "units" => { "$reduce" => {
      "input" => "$items",
      "initialValue" => 0,
      "in" => { "$add" => ["$$value", "$$this.qty"] },
    } },
    "units_sum" => { "$sum" => "$items.qty" },
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
