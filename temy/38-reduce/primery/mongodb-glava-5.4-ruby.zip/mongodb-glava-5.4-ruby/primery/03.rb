# Глава 5.4 · $reduce: массив в одно значение
# Пример 3 из 7 · §3 Массив без повторов · $reduce и $concatArrays: категории без повторов
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/03.rb
#   cd primery, затем ruby 03.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => "o-0004" } },
  { "$project" => {
    "_id" => 0,
    "number" => 1,
    "categories" => "$items.category",
    "unique" => { "$reduce" => {
      "input" => "$items.category",
      "initialValue" => [],
      "in" => { "$cond" => [
        { "$in" => ["$$this", "$$value"] },
        "$$value",
        { "$concatArrays" => ["$$value", ["$$this"]] },
      ] },
    } },
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
