# Глава 5.4 · $reduce: массив в одно значение
# Пример 5 из 7 · §5 Накопленное значение как ключ группы · заказы по числу разных категорий
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/05.rb
#   cd primery, затем ruby 05.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$group" => {
    "_id" => { "$size" => { "$reduce" => {
      "input" => "$items.category",
      "initialValue" => [],
      "in" => { "$cond" => [
        { "$in" => ["$$this", "$$value"] },
        "$$value",
        { "$concatArrays" => ["$$value", ["$$this"]] },
      ] },
    } } },
    "orders" => { "$sum" => 1 },
  } },
  { "$sort" => { "_id" => 1 } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
