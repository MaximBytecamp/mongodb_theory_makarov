# Глава 5.4 · $reduce: массив в одно значение
# Пример 7 из 7 · §7 Записи, которые сервер не принимает · записи $reduce, которые сервер не принимает
#
# Запуск из папки архива:
#   docker compose run --rm python primery/07.py
#   cd primery, затем python 07.py (Windows) или python3 07.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
from pymongo.errors import OperationFailure

no_initial = [
    {"$match": {"_id": "o-0002"}},
    {"$project": {"x": {"$reduce": {
        "input": "$items",
        "in": {"$add": ["$$value", "$$this.qty"]},
    }}}},
]

string_initial = [
    {"$match": {"_id": "o-0002"}},
    {"$project": {"x": {"$reduce": {
        "input": "$items",
        "initialValue": "",
        "in": {"$add": ["$$value", "$$this.qty"]},
    }}}},
]

string_input = [
    {"$match": {"_id": "o-0002"}},
    {"$project": {"x": {"$reduce": {
        "input": "$promo",
        "initialValue": 0,
        "in": "$$value",
    }}}},
]

print("── нет initialValue")
try:
    for doc in orders.aggregate(no_initial):
        print(doc)
except OperationFailure as e:
    print("код", e.code)
    print(e.details["errmsg"])

print("── initialValue — строка, in складывает числа")
try:
    for doc in orders.aggregate(string_initial):
        print(doc)
except OperationFailure as e:
    print("код", e.code)
    print(e.details["errmsg"])

print("── input — строка")
try:
    for doc in orders.aggregate(string_input):
        print(doc)
except OperationFailure as e:
    print("код", e.code)
    print(e.details["errmsg"])
