# Глава 5.4 · $reduce: массив в одно значение
# Пример 6 из 7 · §6 Один знак $ у $$value · $value вместо $$value
#
# Запуск из папки архива:
#   docker compose run --rm python primery/06.py
#   cd primery, затем python 06.py (Windows) или python3 06.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": "o-0002"}},
    {"$project": {
        "_id": 0,
        "wrong": {"$reduce": {
            "input": "$items",
            "initialValue": 0,
            "in": {"$add": ["$value", "$$this.qty"]},
        }},
        "right": {"$reduce": {
            "input": "$items",
            "initialValue": 0,
            "in": {"$add": ["$$value", "$$this.qty"]},
        }},
    }},
]

for doc in orders.aggregate(pipeline):
    print(doc)
