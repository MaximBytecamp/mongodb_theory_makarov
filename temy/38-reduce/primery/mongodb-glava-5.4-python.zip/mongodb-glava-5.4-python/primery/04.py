# Глава 5.4 · $reduce: массив в одно значение
# Пример 4 из 7 · §4 Элемент с наибольшим полем · $reduce: самая дорогая позиция
#
# Запуск из папки архива:
#   docker compose run --rm python primery/04.py
#   cd primery, затем python 04.py (Windows) или python3 04.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": "o-0004"}},
    {"$project": {
        "_id": 0,
        "number": 1,
        "top": {"$reduce": {
            "input": "$items",
            "initialValue": {"price": 0},
            "in": {"$cond": [
                {"$gt": ["$$this.price", "$$value.price"]},
                "$$this",
                "$$value",
            ]},
        }},
    }},
]

for doc in orders.aggregate(pipeline):
    print(doc)
