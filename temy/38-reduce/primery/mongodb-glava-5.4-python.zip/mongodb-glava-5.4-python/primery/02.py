# Глава 5.4 · $reduce: массив в одно значение
# Пример 2 из 7 · §2 Строка из элементов · $reduce: названия через запятую
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": "o-0004"}},
    {"$project": {
        "_id": 0,
        "number": 1,
        "titles": {"$reduce": {
            "input": "$items.title",
            "initialValue": "",
            "in": {"$cond": [
                {"$eq": ["$$value", ""]},
                "$$this",
                {"$concat": ["$$value", ", ", "$$this"]},
            ]},
        }},
    }},
]

for doc in orders.aggregate(pipeline):
    print(doc)
