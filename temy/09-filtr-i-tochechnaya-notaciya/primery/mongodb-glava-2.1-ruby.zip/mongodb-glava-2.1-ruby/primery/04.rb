# Глава 2.1 · Фильтр — это документ. Точечная нотация
# Пример 4 из 6 · §5 Точечная нотация: поле внутри документа · поле внутри документа
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/04.rb
#   cd primery, затем ruby 04.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
vacancies.find({ "salary.from" => 60000 },
               projection: { "title" => 1, "salary" => 1, "_id" => 0 })
         .each { |doc| puts doc.inspect }

puts "выпускники СПО: " + resumes.count_documents({ "education.level" => "СПО" }).to_s
puts "собеседования в Москве: " + interviews.count_documents({ "company.city" => "Москва" }).to_s
