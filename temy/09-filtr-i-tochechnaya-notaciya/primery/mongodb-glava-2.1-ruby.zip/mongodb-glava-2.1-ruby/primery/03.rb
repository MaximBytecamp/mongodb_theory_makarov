# Глава 2.1 · Фильтр — это документ. Точечная нотация
# Пример 3 из 6 · §4 Значение должно совпасть точно · тип и регистр значения
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/03.rb
#   cd primery, затем ruby 03.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
puts "salary 70000 числом:   " + resumes.count_documents({ "salary" => 70000 }).to_s
puts "salary '70000' строкой:" + resumes.count_documents({ "salary" => "70000" }).to_s
puts "is_open true:          " + vacancies.count_documents({ "is_open" => true }).to_s
puts "is_open 'true':        " + vacancies.count_documents({ "is_open" => "true" }).to_s
puts "город с маленькой:     " + resumes.count_documents({ "city" => "ярославль" }).to_s
