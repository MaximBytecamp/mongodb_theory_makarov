# Глава 2.1 · Фильтр — это документ. Точечная нотация
# Пример 2 из 6 · §3 Несколько условий: все должны выполниться · город и должность
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/02.rb
#   cd primery, затем ruby 02.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
filtr = { "city" => "Ярославль",
          "position" => "Junior Python-разработчик" }

puts "город: " + resumes.count_documents({ "city" => "Ярославль" }).to_s
puts "город и должность: " + resumes.count_documents(filtr).to_s

resumes.find(filtr, projection: { "fio" => 1, "salary" => 1, "_id" => 0 })
       .each { |doc| puts doc.inspect }
