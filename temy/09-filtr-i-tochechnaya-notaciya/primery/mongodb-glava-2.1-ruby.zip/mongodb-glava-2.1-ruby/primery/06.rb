# Глава 2.1 · Фильтр — это документ. Точечная нотация
# Пример 6 из 6 · §7 Пустой фильтр · пустой фильтр
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/06.rb
#   cd primery, затем ruby 06.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
puts "всего резюме: " + resumes.count_documents({}).to_s
puts "всего собеседований: " + interviews.count_documents({}).to_s
