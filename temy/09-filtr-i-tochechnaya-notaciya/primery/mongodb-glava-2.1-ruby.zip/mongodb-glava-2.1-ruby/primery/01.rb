# Глава 2.1 · Фильтр — это документ. Точечная нотация
# Пример 1 из 6 · §2 Фильтр — это документ · резюме из одного города
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/01.rb
#   cd primery, затем ruby 01.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
resumes.find(
  { "city" => "Ярославль" },
  projection: { "fio" => 1, "position" => 1, "_id" => 0 }
).each { |doc| puts doc.inspect }
