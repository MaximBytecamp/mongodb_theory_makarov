# Глава 2.1 · Фильтр — это документ. Точечная нотация
# Пример 5 из 6 · §6 Точка и массивы · массив строк и массив документов
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/05.rb
#   cd primery, затем ruby 05.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
puts "знают Python: " + resumes.count_documents({ "skills" => "Python" }).to_s

resumes.find({ "experience.role" => "стажёр" },
             projection: { "fio" => 1, "_id" => 0 })
       .each { |doc| puts doc.inspect }
