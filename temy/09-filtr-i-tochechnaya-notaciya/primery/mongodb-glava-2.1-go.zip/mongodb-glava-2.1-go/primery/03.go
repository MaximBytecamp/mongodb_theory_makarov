//go:build ignore

// Глава 2.1 · Фильтр — это документ. Точечная нотация
// Пример 3 из 6 · §4 Значение должно совпасть точно · тип и регистр значения
//
// Запуск из папки архива:
//   docker compose run --rm go primery/03.go
//   cd primery, затем go run 03.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("hh")
	resumes := db.Collection("resumes")
	vacancies := db.Collection("vacancies")
	companies := db.Collection("companies")
	interviews := db.Collection("interviews")
	box := client.Database("sandbox").Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, resumes, vacancies, companies, interviews, box

	{
		// ── пример из главы ──────────────────────────────────────
		chislom, _ := resumes.CountDocuments(ctx, bson.D{{Key: "salary", Value: 70000}})
		strokoy, _ := resumes.CountDocuments(ctx, bson.D{{Key: "salary", Value: "70000"}})
		istina, _ := vacancies.CountDocuments(ctx, bson.D{{Key: "is_open", Value: true}})
		tekstom, _ := vacancies.CountDocuments(ctx, bson.D{{Key: "is_open", Value: "true"}})
		malenkoy, _ := resumes.CountDocuments(ctx, bson.D{{Key: "city", Value: "ярославль"}})

		fmt.Println("salary 70000 числом:  ", chislom)
		fmt.Println("salary '70000' строкой:", strokoy)
		fmt.Println("is_open true:          ", istina)
		fmt.Println("is_open 'true':        ", tekstom)
		fmt.Println("город с маленькой:     ", malenkoy)
	}
}
