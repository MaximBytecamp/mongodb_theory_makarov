//go:build ignore

// Глава 2.1 · Фильтр — это документ. Точечная нотация
// Пример 2 из 6 · §3 Несколько условий: все должны выполниться · город и должность
//
// Запуск из папки архива:
//   docker compose run --rm go primery/02.go
//   cd primery, затем go run 02.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("hh")
	resumes := db.Collection("resumes")
	vacancies := db.Collection("vacancies")
	companies := db.Collection("companies")
	interviews := db.Collection("interviews")
	box := client.Database("sandbox").Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, resumes, vacancies, companies, interviews, box

	{
		// ── пример из главы ──────────────────────────────────────
		filtr := bson.D{
		    {Key: "city", Value: "Ярославль"},
		    {Key: "position", Value: "Junior Python-разработчик"}}

		gorod, _ := resumes.CountDocuments(ctx, bson.D{{Key: "city", Value: "Ярославль"}})
		oba, _ := resumes.CountDocuments(ctx, filtr)
		fmt.Println("город:", gorod)
		fmt.Println("город и должность:", oba)

		cursor, _ := resumes.Find(ctx, filtr,
		    options.Find().SetProjection(bson.D{
		        {Key: "fio", Value: 1}, {Key: "salary", Value: 1}, {Key: "_id", Value: 0}}))
		for cursor.Next(ctx) {
		    var doc bson.M
		    cursor.Decode(&doc)
		    fmt.Println(doc)
		}
	}
}
