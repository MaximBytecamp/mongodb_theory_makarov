# Глава 3.1 · Правила на уровне базы: $jsonSchema
# Пример 6 из 7 · §6 Правило для коллекции с данными: collMod · правило для коллекции с данными
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/06.rb
#   cd primery, затем ruby 06.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
events = client.use("logs").database[:events]
sandbox = client.use("sandbox").database
box = sandbox[:products]   # песочница: здесь можно менять

catalog = sandbox[:catalog]                   # коллекция без правила, §1

# Правило товара (§2 главы): обязательные поля и типы значений.
schema = {
  "bsonType" => "object",
  "required" => ["sku", "title", "category", "price"],
  "properties" => {
    "sku" => { "bsonType" => "string" },
    "title" => { "bsonType" => "string" },
    "category" => { "bsonType" => "string" },
    "price" => { "bsonType" => "number", "minimum" => 1 },
  },
}

# ── пример из главы ───────────────────────────────────────────
box.insert_one({ "_id" => "p-901", "sku" => "SKU-AC-040", "title" => "Сумка для ноутбука",
                 "category" => "аксессуары", "price" => "1 290" })

sandbox.command(collMod: "products", validator: { "$jsonSchema" => schema }, validationLevel: "strict")
puts "товаров в песочнице:     " + box.count_documents({}).to_s
puts "не подходят под правило: " + box.count_documents({ "$nor" => [{ "$jsonSchema" => schema }] }).to_s

begin
  box.update_one({ "_id" => "p-901" }, { "$set" => { "brand" => "OEM" } })
  puts "strict: бренд сумки записан"
rescue Mongo::Error::OperationFailure => e
  puts "strict: бренд сумки не записан, код ошибки #{e.code}"
end

sandbox.command(collMod: "products", validationLevel: "moderate")
box.update_one({ "_id" => "p-901" }, { "$set" => { "brand" => "OEM" } })
puts "moderate: бренд сумки записан"

begin
  box.update_one({ "_id" => "p-001" }, { "$set" => { "price" => 0 } })
  puts "moderate: цена ноутбука 0 записана"
rescue Mongo::Error::OperationFailure => e
  puts "moderate: цена ноутбука 0 не записана, код ошибки #{e.code}"
end
