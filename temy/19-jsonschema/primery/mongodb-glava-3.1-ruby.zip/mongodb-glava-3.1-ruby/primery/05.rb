# Глава 3.1 · Правила на уровне базы: $jsonSchema
# Пример 5 из 7 · §5 Ключевые слова правила · ключевые слова правила
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/05.rb
#   cd primery, затем ruby 05.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
events = client.use("logs").database[:events]
sandbox = client.use("sandbox").database
box = sandbox[:products]   # песочница: здесь можно менять

catalog = sandbox[:catalog]                   # коллекция без правила, §1

# Правило товара (§2 главы): обязательные поля и типы значений.
schema = {
  "bsonType" => "object",
  "required" => ["sku", "title", "category", "price"],
  "properties" => {
    "sku" => { "bsonType" => "string" },
    "title" => { "bsonType" => "string" },
    "category" => { "bsonType" => "string" },
    "price" => { "bsonType" => "number", "minimum" => 1 },
  },
}

# ── пример из главы ───────────────────────────────────────────
full = {
  "bsonType" => "object",
  "required" => ["sku", "title", "category", "price"],
  "properties" => {
    "sku" => { "bsonType" => "string", "pattern" => "^SKU-[A-Z]{2}-[0-9]{3}$" },
    "title" => { "bsonType" => "string", "minLength" => 3 },
    "category" => { "enum" => ["ноутбуки", "смартфоны", "периферия", "комплектующие", "аксессуары"] },
    "price" => { "bsonType" => "number", "minimum" => 1 },
    "stock" => {
      "bsonType" => "array",
      "items" => {
        "bsonType" => "object",
        "required" => ["warehouse", "qty"],
        "properties" => { "qty" => { "bsonType" => "number", "minimum" => 0 } },
      },
    },
  },
}

sandbox[:checked].drop
checked = sandbox[:checked, validator: { "$jsonSchema" => full }]
checked.create

cable = { "sku" => "SKU-AC-034", "title" => "Кабель HDMI 2 м", "category" => "аксессуары", "price" => 990,
          "stock" => [{ "warehouse" => "Москва-1", "qty" => 15 }] }
candidates = [
  ["всё по правилу", cable],
  ["категория не из списка", cable.merge("category" => "кабели")],
  ["артикул не по шаблону", cable.merge("sku" => "AC-034")],
  ["название короче трёх знаков", cable.merge("title" => "ТВ")],
  ["на складе нет количества", cable.merge("stock" => [{ "warehouse" => "Москва-1" }])],
  ["количество меньше нуля", cable.merge("stock" => [{ "warehouse" => "Москва-1", "qty" => -2 }])],
  ["поле, которого нет в правиле", cable.merge("color" => "чёрный")],
]
candidates.each do |label, doc|
  begin
    checked.insert_one(doc)
    puts "принят:   " + label
  rescue Mongo::Error::OperationFailure
    puts "отклонён: " + label
  end
end
