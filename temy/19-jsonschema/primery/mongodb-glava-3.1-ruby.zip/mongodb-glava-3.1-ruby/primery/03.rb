# Глава 3.1 · Правила на уровне базы: $jsonSchema
# Пример 3 из 7 · §3 Коллекция с правилом: validator · коллекция с правилом
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/03.rb
#   cd primery, затем ruby 03.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
events = client.use("logs").database[:events]
sandbox = client.use("sandbox").database
box = sandbox[:products]   # песочница: здесь можно менять

catalog = sandbox[:catalog]                   # коллекция без правила, §1

# Правило товара (§2 главы): обязательные поля и типы значений.
schema = {
  "bsonType" => "object",
  "required" => ["sku", "title", "category", "price"],
  "properties" => {
    "sku" => { "bsonType" => "string" },
    "title" => { "bsonType" => "string" },
    "category" => { "bsonType" => "string" },
    "price" => { "bsonType" => "number", "minimum" => 1 },
  },
}

# ── пример из главы ───────────────────────────────────────────
sandbox[:checked].drop
checked = sandbox[:checked, validator: { "$jsonSchema" => schema }]
checked.create

checked.insert_one({ "sku" => "SKU-AC-030", "title" => "Чехол для ноутбука 15 дюймов",
                     "category" => "аксессуары", "price" => 1990 })
puts "чехол записан"

begin
  checked.insert_one({ "sku" => "SKU-AC-032", "category" => "аксессуары", "price" => -350 })
  puts "товар без названия записан"
rescue Mongo::Error::OperationFailure => e
  puts "товар без названия отклонён, код ошибки #{e.code}"
end

puts "документов в коллекции: " + checked.count_documents({}).to_s
