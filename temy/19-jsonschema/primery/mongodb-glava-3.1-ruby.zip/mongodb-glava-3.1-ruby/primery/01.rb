# Глава 3.1 · Правила на уровне базы: $jsonSchema
# Пример 1 из 7 · §1 Сервер принимает любой документ · три товара без правила
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/01.rb
#   cd primery, затем ruby 01.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
events = client.use("logs").database[:events]
sandbox = client.use("sandbox").database
box = sandbox[:products]   # песочница: здесь можно менять

catalog = sandbox[:catalog]                   # коллекция без правила, §1

# Правило товара (§2 главы): обязательные поля и типы значений.
schema = {
  "bsonType" => "object",
  "required" => ["sku", "title", "category", "price"],
  "properties" => {
    "sku" => { "bsonType" => "string" },
    "title" => { "bsonType" => "string" },
    "category" => { "bsonType" => "string" },
    "price" => { "bsonType" => "number", "minimum" => 1 },
  },
}

# ── пример из главы ───────────────────────────────────────────
catalog.drop
catalog.insert_one({ "sku" => "SKU-AC-030", "title" => "Чехол для ноутбука 15 дюймов",
                     "category" => "аксессуары", "price" => 1990 })
catalog.insert_one({ "sku" => "SKU-AC-031", "title" => "Подставка под монитор",
                     "category" => "аксессуары", "price" => "2 490" })
catalog.insert_one({ "sku" => "SKU-AC-032", "category" => "аксессуары", "price" => -350 })

puts "документов в коллекции: " + catalog.count_documents({}).to_s
catalog.find({}, projection: { "_id" => 0 }).each { |doc| puts doc.inspect }
