# Глава 3.1 · Правила на уровне базы: $jsonSchema
# Пример 7 из 7 · §7 validationAction: предупреждение вместо отказа · предупреждение вместо отказа
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/07.rb
#   cd primery, затем ruby 07.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
events = client.use("logs").database[:events]
sandbox = client.use("sandbox").database
box = sandbox[:products]   # песочница: здесь можно менять

catalog = sandbox[:catalog]                   # коллекция без правила, §1

# Правило товара (§2 главы): обязательные поля и типы значений.
schema = {
  "bsonType" => "object",
  "required" => ["sku", "title", "category", "price"],
  "properties" => {
    "sku" => { "bsonType" => "string" },
    "title" => { "bsonType" => "string" },
    "category" => { "bsonType" => "string" },
    "price" => { "bsonType" => "number", "minimum" => 1 },
  },
}

# ── пример из главы ───────────────────────────────────────────
sandbox.command(collMod: "products", validationAction: "warn")

box.insert_one({ "_id" => "p-902", "sku" => "SKU-AC-041", "title" => "Сумка-чехол",
                 "category" => "аксессуары", "price" => -1 })
puts "товар с ценой -1 записан"
puts "не подходят под правило: " + box.count_documents({ "$nor" => [{ "$jsonSchema" => schema }] }).to_s

info = sandbox.list_collections(filter: { name: "products" }).first
puts "validationLevel:  " + info["options"]["validationLevel"]
puts "validationAction: " + info["options"]["validationAction"]
