# Глава 3.1 · Правила на уровне базы: $jsonSchema
# Пример 4 из 7 · §4 Почему документ отклонён: errInfo · причины отказа из errInfo
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/04.rb
#   cd primery, затем ruby 04.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
events = client.use("logs").database[:events]
sandbox = client.use("sandbox").database
box = sandbox[:products]   # песочница: здесь можно менять

catalog = sandbox[:catalog]                   # коллекция без правила, §1

# Правило товара (§2 главы): обязательные поля и типы значений.
schema = {
  "bsonType" => "object",
  "required" => ["sku", "title", "category", "price"],
  "properties" => {
    "sku" => { "bsonType" => "string" },
    "title" => { "bsonType" => "string" },
    "category" => { "bsonType" => "string" },
    "price" => { "bsonType" => "number", "minimum" => 1 },
  },
}

# ── пример из главы ───────────────────────────────────────────
checked = sandbox[:checked]
begin
  checked.insert_one({ "sku" => "SKU-AC-031", "category" => "аксессуары", "price" => "2 490" })
rescue Mongo::Error::OperationFailure => e
  puts "подставка отклонена, причины:"
  e.details["details"]["schemaRulesNotSatisfied"].each do |rule|
    if rule["operatorName"] == "required"
      puts "  нет обязательных полей: #{rule["missingProperties"]}"
    end
    if rule["operatorName"] == "properties"
      rule["propertiesNotSatisfied"].each do |prop|
        prop["details"].each do |detail|
          puts "  поле #{prop["propertyName"]}: #{detail["operatorName"]} — #{detail["reason"]}"
        end
      end
    end
  end
end
