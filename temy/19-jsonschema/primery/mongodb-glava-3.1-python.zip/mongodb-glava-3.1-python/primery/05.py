# Глава 3.1 · Правила на уровне базы: $jsonSchema
# Пример 5 из 7 · §5 Ключевые слова правила · ключевые слова правила
#
# Запуск из папки архива:
#   docker compose run --rm python primery/05.py
#   cd primery, затем python 05.py (Windows) или python3 05.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
events = client["logs"]["events"]
sandbox = client["sandbox"]
box = sandbox["products"]        # песочница: здесь можно менять

catalog = sandbox["catalog"]                  # коллекция без правила, §1

# Правило товара (§2 главы): обязательные поля и типы значений.
schema = {
    "bsonType": "object",
    "required": ["sku", "title", "category", "price"],
    "properties": {
        "sku": {"bsonType": "string"},
        "title": {"bsonType": "string"},
        "category": {"bsonType": "string"},
        "price": {"bsonType": "number", "minimum": 1},
    },
}

# ── пример из главы ───────────────────────────────────────────
from pymongo.errors import WriteError

full = {
    "bsonType": "object",
    "required": ["sku", "title", "category", "price"],
    "properties": {
        "sku": {"bsonType": "string", "pattern": "^SKU-[A-Z]{2}-[0-9]{3}$"},
        "title": {"bsonType": "string", "minLength": 3},
        "category": {"enum": ["ноутбуки", "смартфоны", "периферия", "комплектующие", "аксессуары"]},
        "price": {"bsonType": "number", "minimum": 1},
        "stock": {
            "bsonType": "array",
            "items": {
                "bsonType": "object",
                "required": ["warehouse", "qty"],
                "properties": {"qty": {"bsonType": "number", "minimum": 0}},
            },
        },
    },
}

sandbox.drop_collection("checked")
checked = sandbox.create_collection("checked", validator={"$jsonSchema": full})

cable = {"sku": "SKU-AC-034", "title": "Кабель HDMI 2 м", "category": "аксессуары", "price": 990,
         "stock": [{"warehouse": "Москва-1", "qty": 15}]}
candidates = [
    ("всё по правилу", cable),
    ("категория не из списка", {**cable, "category": "кабели"}),
    ("артикул не по шаблону", {**cable, "sku": "AC-034"}),
    ("название короче трёх знаков", {**cable, "title": "ТВ"}),
    ("на складе нет количества", {**cable, "stock": [{"warehouse": "Москва-1"}]}),
    ("количество меньше нуля", {**cable, "stock": [{"warehouse": "Москва-1", "qty": -2}]}),
    ("поле, которого нет в правиле", {**cable, "color": "чёрный"}),
]
for label, doc in candidates:
    try:
        checked.insert_one(doc)
        print("принят:  ", label)
    except WriteError:
        print("отклонён:", label)
