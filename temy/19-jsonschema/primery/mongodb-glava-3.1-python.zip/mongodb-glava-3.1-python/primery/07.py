# Глава 3.1 · Правила на уровне базы: $jsonSchema
# Пример 7 из 7 · §7 validationAction: предупреждение вместо отказа · предупреждение вместо отказа
#
# Запуск из папки архива:
#   docker compose run --rm python primery/07.py
#   cd primery, затем python 07.py (Windows) или python3 07.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
events = client["logs"]["events"]
sandbox = client["sandbox"]
box = sandbox["products"]        # песочница: здесь можно менять

catalog = sandbox["catalog"]                  # коллекция без правила, §1

# Правило товара (§2 главы): обязательные поля и типы значений.
schema = {
    "bsonType": "object",
    "required": ["sku", "title", "category", "price"],
    "properties": {
        "sku": {"bsonType": "string"},
        "title": {"bsonType": "string"},
        "category": {"bsonType": "string"},
        "price": {"bsonType": "number", "minimum": 1},
    },
}

# ── пример из главы ───────────────────────────────────────────
sandbox.command("collMod", "products", validationAction="warn")

box.insert_one({"_id": "p-902", "sku": "SKU-AC-041", "title": "Сумка-чехол",
                "category": "аксессуары", "price": -1})
print("товар с ценой -1 записан")
print("не подходят под правило:", box.count_documents({"$nor": [{"$jsonSchema": schema}]}))

info = next(sandbox.list_collections(filter={"name": "products"}))
print("validationLevel: ", info["options"]["validationLevel"])
print("validationAction:", info["options"]["validationAction"])
