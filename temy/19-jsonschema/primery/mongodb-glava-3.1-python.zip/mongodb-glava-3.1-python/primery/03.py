# Глава 3.1 · Правила на уровне базы: $jsonSchema
# Пример 3 из 7 · §3 Коллекция с правилом: validator · коллекция с правилом
#
# Запуск из папки архива:
#   docker compose run --rm python primery/03.py
#   cd primery, затем python 03.py (Windows) или python3 03.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
events = client["logs"]["events"]
sandbox = client["sandbox"]
box = sandbox["products"]        # песочница: здесь можно менять

catalog = sandbox["catalog"]                  # коллекция без правила, §1

# Правило товара (§2 главы): обязательные поля и типы значений.
schema = {
    "bsonType": "object",
    "required": ["sku", "title", "category", "price"],
    "properties": {
        "sku": {"bsonType": "string"},
        "title": {"bsonType": "string"},
        "category": {"bsonType": "string"},
        "price": {"bsonType": "number", "minimum": 1},
    },
}

# ── пример из главы ───────────────────────────────────────────
from pymongo.errors import WriteError

sandbox.drop_collection("checked")
checked = sandbox.create_collection("checked", validator={"$jsonSchema": schema})

checked.insert_one({"sku": "SKU-AC-030", "title": "Чехол для ноутбука 15 дюймов",
                    "category": "аксессуары", "price": 1990})
print("чехол записан")

try:
    checked.insert_one({"sku": "SKU-AC-032", "category": "аксессуары", "price": -350})
    print("товар без названия записан")
except WriteError as e:
    print("товар без названия отклонён, код ошибки", e.code)

print("документов в коллекции:", checked.count_documents({}))
