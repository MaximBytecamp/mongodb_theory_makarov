# Глава 3.1 · Правила на уровне базы: $jsonSchema
# Пример 4 из 7 · §4 Почему документ отклонён: errInfo · причины отказа из errInfo
#
# Запуск из папки архива:
#   docker compose run --rm python primery/04.py
#   cd primery, затем python 04.py (Windows) или python3 04.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
events = client["logs"]["events"]
sandbox = client["sandbox"]
box = sandbox["products"]        # песочница: здесь можно менять

catalog = sandbox["catalog"]                  # коллекция без правила, §1

# Правило товара (§2 главы): обязательные поля и типы значений.
schema = {
    "bsonType": "object",
    "required": ["sku", "title", "category", "price"],
    "properties": {
        "sku": {"bsonType": "string"},
        "title": {"bsonType": "string"},
        "category": {"bsonType": "string"},
        "price": {"bsonType": "number", "minimum": 1},
    },
}

# ── пример из главы ───────────────────────────────────────────
from pymongo.errors import WriteError

checked = sandbox["checked"]
try:
    checked.insert_one({"sku": "SKU-AC-031", "category": "аксессуары", "price": "2 490"})
except WriteError as e:
    print("подставка отклонена, причины:")
    for rule in e.details["errInfo"]["details"]["schemaRulesNotSatisfied"]:
        if rule["operatorName"] == "required":
            print("  нет обязательных полей:", rule["missingProperties"])
        if rule["operatorName"] == "properties":
            for prop in rule["propertiesNotSatisfied"]:
                for detail in prop["details"]:
                    print("  поле " + prop["propertyName"] + ":", detail["operatorName"], "—", detail["reason"])
