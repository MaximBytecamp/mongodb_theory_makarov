# Глава 3.1 · Правила на уровне базы: $jsonSchema
# Пример 6 из 7 · §6 Правило для коллекции с данными: collMod · правило для коллекции с данными
#
# Запуск из папки архива:
#   docker compose run --rm python primery/06.py
#   cd primery, затем python 06.py (Windows) или python3 06.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
events = client["logs"]["events"]
sandbox = client["sandbox"]
box = sandbox["products"]        # песочница: здесь можно менять

catalog = sandbox["catalog"]                  # коллекция без правила, §1

# Правило товара (§2 главы): обязательные поля и типы значений.
schema = {
    "bsonType": "object",
    "required": ["sku", "title", "category", "price"],
    "properties": {
        "sku": {"bsonType": "string"},
        "title": {"bsonType": "string"},
        "category": {"bsonType": "string"},
        "price": {"bsonType": "number", "minimum": 1},
    },
}

# ── пример из главы ───────────────────────────────────────────
from pymongo.errors import WriteError

box.insert_one({"_id": "p-901", "sku": "SKU-AC-040", "title": "Сумка для ноутбука",
                "category": "аксессуары", "price": "1 290"})

sandbox.command("collMod", "products", validator={"$jsonSchema": schema}, validationLevel="strict")
print("товаров в песочнице:    ", box.count_documents({}))
print("не подходят под правило:", box.count_documents({"$nor": [{"$jsonSchema": schema}]}))

try:
    box.update_one({"_id": "p-901"}, {"$set": {"brand": "OEM"}})
    print("strict: бренд сумки записан")
except WriteError as e:
    print("strict: бренд сумки не записан, код ошибки", e.code)

sandbox.command("collMod", "products", validationLevel="moderate")
box.update_one({"_id": "p-901"}, {"$set": {"brand": "OEM"}})
print("moderate: бренд сумки записан")

try:
    box.update_one({"_id": "p-001"}, {"$set": {"price": 0}})
    print("moderate: цена ноутбука 0 записана")
except WriteError as e:
    print("moderate: цена ноутбука 0 не записана, код ошибки", e.code)
