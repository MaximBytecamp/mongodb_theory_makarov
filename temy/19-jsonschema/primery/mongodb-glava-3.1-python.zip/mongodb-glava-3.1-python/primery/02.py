# Глава 3.1 · Правила на уровне базы: $jsonSchema
# Пример 2 из 7 · §2 Правило $jsonSchema и проверка данных · правило как условие запроса
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
events = client["logs"]["events"]
sandbox = client["sandbox"]
box = sandbox["products"]        # песочница: здесь можно менять

catalog = sandbox["catalog"]                  # коллекция без правила, §1

# Правило товара (§2 главы): обязательные поля и типы значений.
schema = {
    "bsonType": "object",
    "required": ["sku", "title", "category", "price"],
    "properties": {
        "sku": {"bsonType": "string"},
        "title": {"bsonType": "string"},
        "category": {"bsonType": "string"},
        "price": {"bsonType": "number", "minimum": 1},
    },
}

# ── пример из главы ───────────────────────────────────────────
print("shop.products, подходят:  ", products.count_documents({"$jsonSchema": schema}))
print("sandbox.catalog, подходят:", catalog.count_documents({"$jsonSchema": schema}))

for doc in catalog.find({"$nor": [{"$jsonSchema": schema}]}, {"_id": 0, "sku": 1, "title": 1, "price": 1}):
    print("не подходит:", doc)
