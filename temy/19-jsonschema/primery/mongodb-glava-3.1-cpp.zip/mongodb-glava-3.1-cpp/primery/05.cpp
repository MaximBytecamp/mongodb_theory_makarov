// Глава 3.1 · Правила на уровне базы: $jsonSchema
// Пример 5 из 7 · §5 Ключевые слова правила · ключевые слова правила
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/05.cpp
//   cd primery, затем g++ -std=c++17 05.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto products = db["products"];
    auto orders = db["orders"];
    auto events = client["logs"]["events"];
    auto sandbox = client["sandbox"];
    auto box = sandbox["products"];   // песочница: здесь можно менять

    auto catalog = sandbox["catalog"];   // коллекция без правила, §1

    // Правило товара (§2 главы): обязательные поля и типы значений.
    auto schema = make_document(
        kvp("bsonType", "object"),
        kvp("required", make_array("sku", "title", "category", "price")),
        kvp("properties", make_document(
            kvp("sku", make_document(kvp("bsonType", "string"))),
            kvp("title", make_document(kvp("bsonType", "string"))),
            kvp("category", make_document(kvp("bsonType", "string"))),
            kvp("price", make_document(kvp("bsonType", "number"), kvp("minimum", 1))))));

    {
        // ── пример из главы ──────────────────────────────────────
        auto full = make_document(
            kvp("bsonType", "object"),
            kvp("required", make_array("sku", "title", "category", "price")),
            kvp("properties", make_document(
                kvp("sku", make_document(kvp("bsonType", "string"), kvp("pattern", "^SKU-[A-Z]{2}-[0-9]{3}$"))),
                kvp("title", make_document(kvp("bsonType", "string"), kvp("minLength", 3))),
                kvp("category", make_document(kvp("enum", make_array("ноутбуки", "смартфоны", "периферия", "комплектующие", "аксессуары")))),
                kvp("price", make_document(kvp("bsonType", "number"), kvp("minimum", 1))),
                kvp("stock", make_document(
                    kvp("bsonType", "array"),
                    kvp("items", make_document(
                        kvp("bsonType", "object"),
                        kvp("required", make_array("warehouse", "qty")),
                        kvp("properties", make_document(kvp("qty", make_document(kvp("bsonType", "number"), kvp("minimum", 0))))))))))));

        sandbox["checked"].drop();
        auto checked = sandbox.create_collection("checked",
            make_document(kvp("validator", make_document(kvp("$jsonSchema", full.view())))));

        // верный товар; остальные кандидаты отличаются от него одним полем
        auto stock = [](int qty) { return make_array(make_document(kvp("warehouse", "Москва-1"), kvp("qty", qty))); };
        std::vector<std::pair<std::string, bsoncxx::document::value>> candidates;
        candidates.emplace_back("всё по правилу", make_document(
            kvp("sku", "SKU-AC-034"), kvp("title", "Кабель HDMI 2 м"), kvp("category", "аксессуары"), kvp("price", 990), kvp("stock", stock(15))));
        candidates.emplace_back("категория не из списка", make_document(
            kvp("sku", "SKU-AC-034"), kvp("title", "Кабель HDMI 2 м"), kvp("category", "кабели"), kvp("price", 990), kvp("stock", stock(15))));
        candidates.emplace_back("артикул не по шаблону", make_document(
            kvp("sku", "AC-034"), kvp("title", "Кабель HDMI 2 м"), kvp("category", "аксессуары"), kvp("price", 990), kvp("stock", stock(15))));
        candidates.emplace_back("название короче трёх знаков", make_document(
            kvp("sku", "SKU-AC-034"), kvp("title", "ТВ"), kvp("category", "аксессуары"), kvp("price", 990), kvp("stock", stock(15))));
        candidates.emplace_back("на складе нет количества", make_document(
            kvp("sku", "SKU-AC-034"), kvp("title", "Кабель HDMI 2 м"), kvp("category", "аксессуары"), kvp("price", 990),
            kvp("stock", make_array(make_document(kvp("warehouse", "Москва-1"))))));
        candidates.emplace_back("количество меньше нуля", make_document(
            kvp("sku", "SKU-AC-034"), kvp("title", "Кабель HDMI 2 м"), kvp("category", "аксессуары"), kvp("price", 990), kvp("stock", stock(-2))));
        candidates.emplace_back("поле, которого нет в правиле", make_document(
            kvp("sku", "SKU-AC-034"), kvp("title", "Кабель HDMI 2 м"), kvp("category", "аксессуары"), kvp("price", 990), kvp("stock", stock(15)),
            kvp("color", "чёрный")));

        for (const auto& [label, doc] : candidates) {
            try {
                checked.insert_one(doc.view());
                std::cout << "принят:   " << label << std::endl;
            } catch (const mongocxx::operation_exception&) {
                std::cout << "отклонён: " << label << std::endl;
            }
        }
    }
}
