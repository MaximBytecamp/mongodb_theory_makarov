// Глава 3.1 · Правила на уровне базы: $jsonSchema
// Пример 3 из 7 · §3 Коллекция с правилом: validator · коллекция с правилом
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/03.cpp
//   cd primery, затем g++ -std=c++17 03.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto products = db["products"];
    auto orders = db["orders"];
    auto events = client["logs"]["events"];
    auto sandbox = client["sandbox"];
    auto box = sandbox["products"];   // песочница: здесь можно менять

    auto catalog = sandbox["catalog"];   // коллекция без правила, §1

    // Правило товара (§2 главы): обязательные поля и типы значений.
    auto schema = make_document(
        kvp("bsonType", "object"),
        kvp("required", make_array("sku", "title", "category", "price")),
        kvp("properties", make_document(
            kvp("sku", make_document(kvp("bsonType", "string"))),
            kvp("title", make_document(kvp("bsonType", "string"))),
            kvp("category", make_document(kvp("bsonType", "string"))),
            kvp("price", make_document(kvp("bsonType", "number"), kvp("minimum", 1))))));

    {
        // ── пример из главы ──────────────────────────────────────
        sandbox["checked"].drop();
        auto checked = sandbox.create_collection("checked",
            make_document(kvp("validator", make_document(kvp("$jsonSchema", schema.view())))));

        checked.insert_one(make_document(
            kvp("sku", "SKU-AC-030"),
            kvp("title", "Чехол для ноутбука 15 дюймов"),
            kvp("category", "аксессуары"),
            kvp("price", 1990)));
        std::cout << "чехол записан" << std::endl;

        try {
            checked.insert_one(make_document(
                kvp("sku", "SKU-AC-032"),
                kvp("category", "аксессуары"),
                kvp("price", -350)));
            std::cout << "товар без названия записан" << std::endl;
        } catch (const mongocxx::operation_exception& e) {
            std::cout << "товар без названия отклонён, код ошибки " << e.code().value() << std::endl;
        }

        std::cout << "документов в коллекции: " << checked.count_documents(make_document()) << std::endl;
    }
}
