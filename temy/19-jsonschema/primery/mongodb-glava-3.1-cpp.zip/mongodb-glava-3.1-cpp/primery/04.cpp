// Глава 3.1 · Правила на уровне базы: $jsonSchema
// Пример 4 из 7 · §4 Почему документ отклонён: errInfo · причины отказа из errInfo
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/04.cpp
//   cd primery, затем g++ -std=c++17 04.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto products = db["products"];
    auto orders = db["orders"];
    auto events = client["logs"]["events"];
    auto sandbox = client["sandbox"];
    auto box = sandbox["products"];   // песочница: здесь можно менять

    auto catalog = sandbox["catalog"];   // коллекция без правила, §1

    // Правило товара (§2 главы): обязательные поля и типы значений.
    auto schema = make_document(
        kvp("bsonType", "object"),
        kvp("required", make_array("sku", "title", "category", "price")),
        kvp("properties", make_document(
            kvp("sku", make_document(kvp("bsonType", "string"))),
            kvp("title", make_document(kvp("bsonType", "string"))),
            kvp("category", make_document(kvp("bsonType", "string"))),
            kvp("price", make_document(kvp("bsonType", "number"), kvp("minimum", 1))))));

    {
        // ── пример из главы ──────────────────────────────────────
        auto checked = sandbox["checked"];
        try {
            checked.insert_one(make_document(
                kvp("sku", "SKU-AC-031"),
                kvp("category", "аксессуары"),
                kvp("price", "2 490")));
        } catch (const mongocxx::operation_exception& e) {
            std::cout << "подставка отклонена, причины:" << std::endl;
            auto info = e.raw_server_error()->view()["writeErrors"][0]["errInfo"];
            for (auto&& item : info["details"]["schemaRulesNotSatisfied"].get_array().value) {
                auto rule = item.get_document().value;
                std::string name{rule["operatorName"].get_string().value};
                if (name == "required") {
                    std::cout << "  нет обязательных полей:";
                    for (auto&& field : rule["missingProperties"].get_array().value) {
                        std::cout << " " << field.get_string().value;
                    }
                    std::cout << std::endl;
                }
                if (name == "properties") {
                    for (auto&& prop : rule["propertiesNotSatisfied"].get_array().value) {
                        for (auto&& detail : prop["details"].get_array().value) {
                            std::cout << "  поле " << prop["propertyName"].get_string().value << ": "
                                      << detail["operatorName"].get_string().value << " — "
                                      << detail["reason"].get_string().value << std::endl;
                        }
                    }
                }
            }
        }
    }
}
