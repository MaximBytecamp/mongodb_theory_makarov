// Глава 3.1 · Правила на уровне базы: $jsonSchema
// Пример 6 из 7 · §6 Правило для коллекции с данными: collMod · правило для коллекции с данными
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/06.cpp
//   cd primery, затем g++ -std=c++17 06.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto products = db["products"];
    auto orders = db["orders"];
    auto events = client["logs"]["events"];
    auto sandbox = client["sandbox"];
    auto box = sandbox["products"];   // песочница: здесь можно менять

    auto catalog = sandbox["catalog"];   // коллекция без правила, §1

    // Правило товара (§2 главы): обязательные поля и типы значений.
    auto schema = make_document(
        kvp("bsonType", "object"),
        kvp("required", make_array("sku", "title", "category", "price")),
        kvp("properties", make_document(
            kvp("sku", make_document(kvp("bsonType", "string"))),
            kvp("title", make_document(kvp("bsonType", "string"))),
            kvp("category", make_document(kvp("bsonType", "string"))),
            kvp("price", make_document(kvp("bsonType", "number"), kvp("minimum", 1))))));

    {
        // ── пример из главы ──────────────────────────────────────
        box.insert_one(make_document(
            kvp("_id", "p-901"),
            kvp("sku", "SKU-AC-040"),
            kvp("title", "Сумка для ноутбука"),
            kvp("category", "аксессуары"),
            kvp("price", "1 290")));

        sandbox.run_command(make_document(
            kvp("collMod", "products"),
            kvp("validator", make_document(kvp("$jsonSchema", schema.view()))),
            kvp("validationLevel", "strict")));
        std::cout << "товаров в песочнице:     " << box.count_documents(make_document()) << std::endl;
        std::cout << "не подходят под правило: "
                  << box.count_documents(make_document(kvp("$nor", make_array(make_document(kvp("$jsonSchema", schema.view()))))))
                  << std::endl;

        try {
            box.update_one(make_document(kvp("_id", "p-901")),
                           make_document(kvp("$set", make_document(kvp("brand", "OEM")))));
            std::cout << "strict: бренд сумки записан" << std::endl;
        } catch (const mongocxx::operation_exception& e) {
            std::cout << "strict: бренд сумки не записан, код ошибки " << e.code().value() << std::endl;
        }

        sandbox.run_command(make_document(kvp("collMod", "products"), kvp("validationLevel", "moderate")));
        box.update_one(make_document(kvp("_id", "p-901")),
                       make_document(kvp("$set", make_document(kvp("brand", "OEM")))));
        std::cout << "moderate: бренд сумки записан" << std::endl;

        try {
            box.update_one(make_document(kvp("_id", "p-001")),
                           make_document(kvp("$set", make_document(kvp("price", 0)))));
            std::cout << "moderate: цена ноутбука 0 записана" << std::endl;
        } catch (const mongocxx::operation_exception& e) {
            std::cout << "moderate: цена ноутбука 0 не записана, код ошибки " << e.code().value() << std::endl;
        }
    }
}
