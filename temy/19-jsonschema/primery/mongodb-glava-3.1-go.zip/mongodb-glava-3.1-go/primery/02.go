//go:build ignore

// Глава 3.1 · Правила на уровне базы: $jsonSchema
// Пример 2 из 7 · §2 Правило $jsonSchema и проверка данных · правило как условие запроса
//
// Запуск из папки архива:
//   docker compose run --rm go primery/02.go
//   cd primery, затем go run 02.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	products := db.Collection("products")
	orders := db.Collection("orders")
	events := client.Database("logs").Collection("events")
	sandbox := client.Database("sandbox")
	box := sandbox.Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, products, orders, events, sandbox, box

	catalog := sandbox.Collection("catalog") // коллекция без правила, §1

	// Правило товара (§2 главы): обязательные поля и типы значений.
	schema := bson.D{
		{Key: "bsonType", Value: "object"},
		{Key: "required", Value: bson.A{"sku", "title", "category", "price"}},
		{Key: "properties", Value: bson.D{
			{Key: "sku", Value: bson.D{{Key: "bsonType", Value: "string"}}},
			{Key: "title", Value: bson.D{{Key: "bsonType", Value: "string"}}},
			{Key: "category", Value: bson.D{{Key: "bsonType", Value: "string"}}},
			{Key: "price", Value: bson.D{{Key: "bsonType", Value: "number"}, {Key: "minimum", Value: 1}}},
		}},
	}
	_, _ = catalog, schema

	{
		// ── пример из главы ──────────────────────────────────────
		vMagazine, _ := products.CountDocuments(ctx, bson.D{{Key: "$jsonSchema", Value: schema}})
		vKataloge, _ := catalog.CountDocuments(ctx, bson.D{{Key: "$jsonSchema", Value: schema}})
		fmt.Println("shop.products, подходят:  ", vMagazine)
		fmt.Println("sandbox.catalog, подходят:", vKataloge)

		cursor, _ := catalog.Find(ctx, bson.D{{Key: "$nor", Value: bson.A{bson.D{{Key: "$jsonSchema", Value: schema}}}}},
		    options.Find().SetProjection(bson.D{{Key: "_id", Value: 0}, {Key: "sku", Value: 1}, {Key: "title", Value: 1}, {Key: "price", Value: 1}}))
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println("не подходит:", string(out))
		}
	}
}
