//go:build ignore

// Глава 3.1 · Правила на уровне базы: $jsonSchema
// Пример 4 из 7 · §4 Почему документ отклонён: errInfo · причины отказа из errInfo
//
// Запуск из папки архива:
//   docker compose run --rm go primery/04.go
//   cd primery, затем go run 04.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────

// Часть errInfo, которую читает пример: какие правила схемы не выполнены.
type schemaRule struct {
    OperatorName           string   `bson:"operatorName"`
    MissingProperties      []string `bson:"missingProperties"`
    PropertiesNotSatisfied []struct {
        PropertyName string `bson:"propertyName"`
        Details      []struct {
            OperatorName string `bson:"operatorName"`
            Reason       string `bson:"reason"`
        } `bson:"details"`
    } `bson:"propertiesNotSatisfied"`
}
var we mongo.WriteException

func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	products := db.Collection("products")
	orders := db.Collection("orders")
	events := client.Database("logs").Collection("events")
	sandbox := client.Database("sandbox")
	box := sandbox.Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, products, orders, events, sandbox, box

	catalog := sandbox.Collection("catalog") // коллекция без правила, §1

	// Правило товара (§2 главы): обязательные поля и типы значений.
	schema := bson.D{
		{Key: "bsonType", Value: "object"},
		{Key: "required", Value: bson.A{"sku", "title", "category", "price"}},
		{Key: "properties", Value: bson.D{
			{Key: "sku", Value: bson.D{{Key: "bsonType", Value: "string"}}},
			{Key: "title", Value: bson.D{{Key: "bsonType", Value: "string"}}},
			{Key: "category", Value: bson.D{{Key: "bsonType", Value: "string"}}},
			{Key: "price", Value: bson.D{{Key: "bsonType", Value: "number"}, {Key: "minimum", Value: 1}}},
		}},
	}
	_, _ = catalog, schema

	{
		// ── пример из главы ──────────────────────────────────────
		checked := sandbox.Collection("checked")
		_, err := checked.InsertOne(ctx, bson.D{
		    {Key: "sku", Value: "SKU-AC-031"},
		    {Key: "category", Value: "аксессуары"},
		    {Key: "price", Value: "2 490"}})
		if errors.As(err, &we) {
		    var info struct {
		        Details struct {
		            Rules []schemaRule `bson:"schemaRulesNotSatisfied"`
		        } `bson:"details"`
		    }
		    bson.Unmarshal(we.WriteErrors[0].Details, &info)
		    fmt.Println("подставка отклонена, причины:")
		    for _, rule := range info.Details.Rules {
		        if rule.OperatorName == "required" {
		            fmt.Println("  нет обязательных полей:", rule.MissingProperties)
		        }
		        if rule.OperatorName == "properties" {
		            for _, prop := range rule.PropertiesNotSatisfied {
		                for _, detail := range prop.Details {
		                    fmt.Println("  поле "+prop.PropertyName+":", detail.OperatorName, "—", detail.Reason)
		                }
		            }
		        }
		    }
		}
	}
}
