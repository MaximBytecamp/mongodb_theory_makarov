//go:build ignore

// Глава 3.1 · Правила на уровне базы: $jsonSchema
// Пример 7 из 7 · §7 validationAction: предупреждение вместо отказа · предупреждение вместо отказа
//
// Запуск из папки архива:
//   docker compose run --rm go primery/07.go
//   cd primery, затем go run 07.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	products := db.Collection("products")
	orders := db.Collection("orders")
	events := client.Database("logs").Collection("events")
	sandbox := client.Database("sandbox")
	box := sandbox.Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, products, orders, events, sandbox, box

	catalog := sandbox.Collection("catalog") // коллекция без правила, §1

	// Правило товара (§2 главы): обязательные поля и типы значений.
	schema := bson.D{
		{Key: "bsonType", Value: "object"},
		{Key: "required", Value: bson.A{"sku", "title", "category", "price"}},
		{Key: "properties", Value: bson.D{
			{Key: "sku", Value: bson.D{{Key: "bsonType", Value: "string"}}},
			{Key: "title", Value: bson.D{{Key: "bsonType", Value: "string"}}},
			{Key: "category", Value: bson.D{{Key: "bsonType", Value: "string"}}},
			{Key: "price", Value: bson.D{{Key: "bsonType", Value: "number"}, {Key: "minimum", Value: 1}}},
		}},
	}
	_, _ = catalog, schema

	{
		// ── пример из главы ──────────────────────────────────────
		sandbox.RunCommand(ctx, bson.D{
		    {Key: "collMod", Value: "products"},
		    {Key: "validationAction", Value: "warn"}})

		box.InsertOne(ctx, bson.D{
		    {Key: "_id", Value: "p-902"},
		    {Key: "sku", Value: "SKU-AC-041"},
		    {Key: "title", Value: "Сумка-чехол"},
		    {Key: "category", Value: "аксессуары"},
		    {Key: "price", Value: -1}})
		fmt.Println("товар с ценой -1 записан")
		ne, _ := box.CountDocuments(ctx, bson.D{{Key: "$nor", Value: bson.A{bson.D{{Key: "$jsonSchema", Value: schema}}}}})
		fmt.Println("не подходят под правило:", ne)

		specs, _ := sandbox.ListCollectionSpecifications(ctx, bson.D{{Key: "name", Value: "products"}})
		fmt.Println("validationLevel: ", specs[0].Options.Lookup("validationLevel").StringValue())
		fmt.Println("validationAction:", specs[0].Options.Lookup("validationAction").StringValue())
	}
}
