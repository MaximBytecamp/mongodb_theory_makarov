//go:build ignore

// Глава 3.1 · Правила на уровне базы: $jsonSchema
// Пример 1 из 7 · §1 Сервер принимает любой документ · три товара без правила
//
// Запуск из папки архива:
//   docker compose run --rm go primery/01.go
//   cd primery, затем go run 01.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	products := db.Collection("products")
	orders := db.Collection("orders")
	events := client.Database("logs").Collection("events")
	sandbox := client.Database("sandbox")
	box := sandbox.Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, products, orders, events, sandbox, box

	catalog := sandbox.Collection("catalog") // коллекция без правила, §1

	// Правило товара (§2 главы): обязательные поля и типы значений.
	schema := bson.D{
		{Key: "bsonType", Value: "object"},
		{Key: "required", Value: bson.A{"sku", "title", "category", "price"}},
		{Key: "properties", Value: bson.D{
			{Key: "sku", Value: bson.D{{Key: "bsonType", Value: "string"}}},
			{Key: "title", Value: bson.D{{Key: "bsonType", Value: "string"}}},
			{Key: "category", Value: bson.D{{Key: "bsonType", Value: "string"}}},
			{Key: "price", Value: bson.D{{Key: "bsonType", Value: "number"}, {Key: "minimum", Value: 1}}},
		}},
	}
	_, _ = catalog, schema

	{
		// ── пример из главы ──────────────────────────────────────
		catalog.Drop(ctx)
		catalog.InsertOne(ctx, bson.D{
		    {Key: "sku", Value: "SKU-AC-030"},
		    {Key: "title", Value: "Чехол для ноутбука 15 дюймов"},
		    {Key: "category", Value: "аксессуары"},
		    {Key: "price", Value: 1990}})
		catalog.InsertOne(ctx, bson.D{
		    {Key: "sku", Value: "SKU-AC-031"},
		    {Key: "title", Value: "Подставка под монитор"},
		    {Key: "category", Value: "аксессуары"},
		    {Key: "price", Value: "2 490"}})
		catalog.InsertOne(ctx, bson.D{
		    {Key: "sku", Value: "SKU-AC-032"},
		    {Key: "category", Value: "аксессуары"},
		    {Key: "price", Value: -350}})

		n, _ := catalog.CountDocuments(ctx, bson.D{})
		fmt.Println("документов в коллекции:", n)

		cursor, _ := catalog.Find(ctx, bson.D{},
		    options.Find().SetProjection(bson.D{{Key: "_id", Value: 0}}))
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}
	}
}
