//go:build ignore

// Глава 3.1 · Правила на уровне базы: $jsonSchema
// Пример 6 из 7 · §6 Правило для коллекции с данными: collMod · правило для коллекции с данными
//
// Запуск из папки архива:
//   docker compose run --rm go primery/06.go
//   cd primery, затем go run 06.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────

var we mongo.WriteException

func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	products := db.Collection("products")
	orders := db.Collection("orders")
	events := client.Database("logs").Collection("events")
	sandbox := client.Database("sandbox")
	box := sandbox.Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, products, orders, events, sandbox, box

	catalog := sandbox.Collection("catalog") // коллекция без правила, §1

	// Правило товара (§2 главы): обязательные поля и типы значений.
	schema := bson.D{
		{Key: "bsonType", Value: "object"},
		{Key: "required", Value: bson.A{"sku", "title", "category", "price"}},
		{Key: "properties", Value: bson.D{
			{Key: "sku", Value: bson.D{{Key: "bsonType", Value: "string"}}},
			{Key: "title", Value: bson.D{{Key: "bsonType", Value: "string"}}},
			{Key: "category", Value: bson.D{{Key: "bsonType", Value: "string"}}},
			{Key: "price", Value: bson.D{{Key: "bsonType", Value: "number"}, {Key: "minimum", Value: 1}}},
		}},
	}
	_, _ = catalog, schema

	{
		// ── пример из главы ──────────────────────────────────────
		box.InsertOne(ctx, bson.D{
		    {Key: "_id", Value: "p-901"},
		    {Key: "sku", Value: "SKU-AC-040"},
		    {Key: "title", Value: "Сумка для ноутбука"},
		    {Key: "category", Value: "аксессуары"},
		    {Key: "price", Value: "1 290"}})

		sandbox.RunCommand(ctx, bson.D{
		    {Key: "collMod", Value: "products"},
		    {Key: "validator", Value: bson.D{{Key: "$jsonSchema", Value: schema}}},
		    {Key: "validationLevel", Value: "strict"}})
		vsego, _ := box.CountDocuments(ctx, bson.D{})
		ne, _ := box.CountDocuments(ctx, bson.D{{Key: "$nor", Value: bson.A{bson.D{{Key: "$jsonSchema", Value: schema}}}}})
		fmt.Println("товаров в песочнице:    ", vsego)
		fmt.Println("не подходят под правило:", ne)

		_, err := box.UpdateOne(ctx, bson.D{{Key: "_id", Value: "p-901"}},
		    bson.D{{Key: "$set", Value: bson.D{{Key: "brand", Value: "OEM"}}}})
		if errors.As(err, &we) {
		    fmt.Println("strict: бренд сумки не записан, код ошибки", we.WriteErrors[0].Code)
		} else {
		    fmt.Println("strict: бренд сумки записан")
		}

		sandbox.RunCommand(ctx, bson.D{
		    {Key: "collMod", Value: "products"},
		    {Key: "validationLevel", Value: "moderate"}})
		box.UpdateOne(ctx, bson.D{{Key: "_id", Value: "p-901"}},
		    bson.D{{Key: "$set", Value: bson.D{{Key: "brand", Value: "OEM"}}}})
		fmt.Println("moderate: бренд сумки записан")

		_, err = box.UpdateOne(ctx, bson.D{{Key: "_id", Value: "p-001"}},
		    bson.D{{Key: "$set", Value: bson.D{{Key: "price", Value: 0}}}})
		if errors.As(err, &we) {
		    fmt.Println("moderate: цена ноутбука 0 не записана, код ошибки", we.WriteErrors[0].Code)
		} else {
		    fmt.Println("moderate: цена ноутбука 0 записана")
		}
	}
}
