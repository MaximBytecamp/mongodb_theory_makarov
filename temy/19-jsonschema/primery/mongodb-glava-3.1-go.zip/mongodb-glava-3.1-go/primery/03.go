//go:build ignore

// Глава 3.1 · Правила на уровне базы: $jsonSchema
// Пример 3 из 7 · §3 Коллекция с правилом: validator · коллекция с правилом
//
// Запуск из папки архива:
//   docker compose run --rm go primery/03.go
//   cd primery, затем go run 03.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────

var we mongo.WriteException

func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	products := db.Collection("products")
	orders := db.Collection("orders")
	events := client.Database("logs").Collection("events")
	sandbox := client.Database("sandbox")
	box := sandbox.Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, products, orders, events, sandbox, box

	catalog := sandbox.Collection("catalog") // коллекция без правила, §1

	// Правило товара (§2 главы): обязательные поля и типы значений.
	schema := bson.D{
		{Key: "bsonType", Value: "object"},
		{Key: "required", Value: bson.A{"sku", "title", "category", "price"}},
		{Key: "properties", Value: bson.D{
			{Key: "sku", Value: bson.D{{Key: "bsonType", Value: "string"}}},
			{Key: "title", Value: bson.D{{Key: "bsonType", Value: "string"}}},
			{Key: "category", Value: bson.D{{Key: "bsonType", Value: "string"}}},
			{Key: "price", Value: bson.D{{Key: "bsonType", Value: "number"}, {Key: "minimum", Value: 1}}},
		}},
	}
	_, _ = catalog, schema

	{
		// ── пример из главы ──────────────────────────────────────
		sandbox.Collection("checked").Drop(ctx)
		sandbox.CreateCollection(ctx, "checked",
		    options.CreateCollection().SetValidator(bson.D{{Key: "$jsonSchema", Value: schema}}))
		checked := sandbox.Collection("checked")

		checked.InsertOne(ctx, bson.D{
		    {Key: "sku", Value: "SKU-AC-030"},
		    {Key: "title", Value: "Чехол для ноутбука 15 дюймов"},
		    {Key: "category", Value: "аксессуары"},
		    {Key: "price", Value: 1990}})
		fmt.Println("чехол записан")

		_, err := checked.InsertOne(ctx, bson.D{
		    {Key: "sku", Value: "SKU-AC-032"},
		    {Key: "category", Value: "аксессуары"},
		    {Key: "price", Value: -350}})
		if errors.As(err, &we) {
		    fmt.Println("товар без названия отклонён, код ошибки", we.WriteErrors[0].Code)
		} else {
		    fmt.Println("товар без названия записан")
		}

		n, _ := checked.CountDocuments(ctx, bson.D{})
		fmt.Println("документов в коллекции:", n)
	}
}
