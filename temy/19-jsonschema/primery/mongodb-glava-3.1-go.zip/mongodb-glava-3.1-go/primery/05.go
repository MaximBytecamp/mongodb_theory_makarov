//go:build ignore

// Глава 3.1 · Правила на уровне базы: $jsonSchema
// Пример 5 из 7 · §5 Ключевые слова правила · ключевые слова правила
//
// Запуск из папки архива:
//   docker compose run --rm go primery/05.go
//   cd primery, затем go run 05.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	products := db.Collection("products")
	orders := db.Collection("orders")
	events := client.Database("logs").Collection("events")
	sandbox := client.Database("sandbox")
	box := sandbox.Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, products, orders, events, sandbox, box

	catalog := sandbox.Collection("catalog") // коллекция без правила, §1

	// Правило товара (§2 главы): обязательные поля и типы значений.
	schema := bson.D{
		{Key: "bsonType", Value: "object"},
		{Key: "required", Value: bson.A{"sku", "title", "category", "price"}},
		{Key: "properties", Value: bson.D{
			{Key: "sku", Value: bson.D{{Key: "bsonType", Value: "string"}}},
			{Key: "title", Value: bson.D{{Key: "bsonType", Value: "string"}}},
			{Key: "category", Value: bson.D{{Key: "bsonType", Value: "string"}}},
			{Key: "price", Value: bson.D{{Key: "bsonType", Value: "number"}, {Key: "minimum", Value: 1}}},
		}},
	}
	_, _ = catalog, schema

	{
		// ── пример из главы ──────────────────────────────────────
		full := bson.D{
		    {Key: "bsonType", Value: "object"},
		    {Key: "required", Value: bson.A{"sku", "title", "category", "price"}},
		    {Key: "properties", Value: bson.D{
		        {Key: "sku", Value: bson.D{{Key: "bsonType", Value: "string"}, {Key: "pattern", Value: "^SKU-[A-Z]{2}-[0-9]{3}$"}}},
		        {Key: "title", Value: bson.D{{Key: "bsonType", Value: "string"}, {Key: "minLength", Value: 3}}},
		        {Key: "category", Value: bson.D{{Key: "enum", Value: bson.A{"ноутбуки", "смартфоны", "периферия", "комплектующие", "аксессуары"}}}},
		        {Key: "price", Value: bson.D{{Key: "bsonType", Value: "number"}, {Key: "minimum", Value: 1}}},
		        {Key: "stock", Value: bson.D{
		            {Key: "bsonType", Value: "array"},
		            {Key: "items", Value: bson.D{
		                {Key: "bsonType", Value: "object"},
		                {Key: "required", Value: bson.A{"warehouse", "qty"}},
		                {Key: "properties", Value: bson.D{
		                    {Key: "qty", Value: bson.D{{Key: "bsonType", Value: "number"}, {Key: "minimum", Value: 0}}},
		                }},
		            }},
		        }},
		    }},
		}

		sandbox.Collection("checked").Drop(ctx)
		sandbox.CreateCollection(ctx, "checked",
		    options.CreateCollection().SetValidator(bson.D{{Key: "$jsonSchema", Value: full}}))
		checked := sandbox.Collection("checked")

		// base — товар, который проходит правило; with возвращает его копию,
		// где одно поле заменено или добавлено
		base := func() bson.D {
		    return bson.D{
		        {Key: "sku", Value: "SKU-AC-034"},
		        {Key: "title", Value: "Кабель HDMI 2 м"},
		        {Key: "category", Value: "аксессуары"},
		        {Key: "price", Value: 990},
		        {Key: "stock", Value: bson.A{bson.D{{Key: "warehouse", Value: "Москва-1"}, {Key: "qty", Value: 15}}}}}
		}
		with := func(key string, value any) bson.D {
		    doc := base()
		    for i := range doc {
		        if doc[i].Key == key {
		            doc[i].Value = value
		            return doc
		        }
		    }
		    return append(doc, bson.E{Key: key, Value: value})
		}
		candidates := []struct {
		    label string
		    doc   bson.D
		}{
		    {"всё по правилу", base()},
		    {"категория не из списка", with("category", "кабели")},
		    {"артикул не по шаблону", with("sku", "AC-034")},
		    {"название короче трёх знаков", with("title", "ТВ")},
		    {"на складе нет количества", with("stock", bson.A{bson.D{{Key: "warehouse", Value: "Москва-1"}}})},
		    {"количество меньше нуля", with("stock", bson.A{bson.D{{Key: "warehouse", Value: "Москва-1"}, {Key: "qty", Value: -2}}})},
		    {"поле, которого нет в правиле", with("color", "чёрный")},
		}
		for _, c := range candidates {
		    if _, err := checked.InsertOne(ctx, c.doc); err != nil {
		        fmt.Println("отклонён:", c.label)
		    } else {
		        fmt.Println("принят:  ", c.label)
		    }
		}
	}
}
