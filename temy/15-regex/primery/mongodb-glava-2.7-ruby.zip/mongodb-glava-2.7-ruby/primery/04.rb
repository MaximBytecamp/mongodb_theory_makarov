# Глава 2.7 · Текстовые шаблоны: $regex и $options
# Пример 4 из 6 · §4 Символы шаблона и экранирование · точка в шаблоне
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/04.rb
#   cd primery, затем ruby 04.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
puts "шаблон .:  " + vacancies.count_documents({ "title" => { "$regex" => "." } }).to_s
puts "шаблон \\.: " + vacancies.count_documents({ "title" => { "$regex" => "\\." } }).to_s

vacancies.find({ "title" => { "$regex" => "\\." } }, projection: { "_id" => 0, "title" => 1 })
         .each { |doc| puts doc.inspect }
