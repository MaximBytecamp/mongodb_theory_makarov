# Глава 2.7 · Текстовые шаблоны: $regex и $options
# Пример 3 из 6 · §3 Регистр: $options · регистр букв
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/03.rb
#   cd primery, затем ruby 03.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
puts "junior:      " + vacancies.count_documents({ "title" => { "$regex" => "junior" } }).to_s
puts "junior, i:   " + vacancies.count_documents({ "title" => { "$regex" => "junior", "$options" => "i" } }).to_s
puts "аналитик:    " + vacancies.count_documents({ "title" => { "$regex" => "аналитик" } }).to_s
puts "аналитик, i: " + vacancies.count_documents({ "title" => { "$regex" => "аналитик", "$options" => "i" } }).to_s
