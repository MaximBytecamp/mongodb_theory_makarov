# Глава 2.7 · Текстовые шаблоны: $regex и $options
# Пример 2 из 6 · §2 Начало и конец строки · начало и конец строки
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/02.rb
#   cd primery, затем ruby 02.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
puts "вакансии: начинается с Junior:      " + vacancies.count_documents({ "title" => { "$regex" => "^Junior" } }).to_s
puts "резюме: начинается с Junior:        " + resumes.count_documents({ "position" => { "$regex" => "^Junior" } }).to_s
puts "вакансии: кончается на разработчик: " + vacancies.count_documents({ "title" => { "$regex" => "разработчик$" } }).to_s

resumes.find({ "position" => { "$regex" => "^Junior" } }, projection: { "_id" => 0, "fio" => 1, "position" => 1 })
       .each { |doc| puts doc.inspect }
