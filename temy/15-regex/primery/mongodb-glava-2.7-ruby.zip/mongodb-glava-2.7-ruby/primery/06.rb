# Глава 2.7 · Текстовые шаблоны: $regex и $options
# Пример 6 из 6 · §6 Шаблон вместе с $not и $or · шаблон с $not и $or
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/06.rb
#   cd primery, затем ruby 06.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
puts "не содержит разработчик:      " + vacancies.count_documents({ "title" => { "$not" => { "$regex" => "разработчик" } } }).to_s
puts "Junior или Frontend в начале: " + vacancies.count_documents({ "$or" => [{ "title" => { "$regex" => "^Junior" } }, { "title" => { "$regex" => "^Frontend" } }] }).to_s
