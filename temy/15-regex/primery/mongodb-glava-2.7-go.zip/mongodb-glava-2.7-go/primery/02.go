//go:build ignore

// Глава 2.7 · Текстовые шаблоны: $regex и $options
// Пример 2 из 6 · §2 Начало и конец строки · начало и конец строки
//
// Запуск из папки архива:
//   docker compose run --rm go primery/02.go
//   cd primery, затем go run 02.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("hh")
	resumes := db.Collection("resumes")
	vacancies := db.Collection("vacancies")
	companies := db.Collection("companies")
	interviews := db.Collection("interviews")
	box := client.Database("sandbox").Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, resumes, vacancies, companies, interviews, box

	{
		// ── пример из главы ──────────────────────────────────────
		vNachalo, _ := vacancies.CountDocuments(ctx, bson.D{{Key: "title", Value: bson.D{{Key: "$regex", Value: "^Junior"}}}})
		rNachalo, _ := resumes.CountDocuments(ctx, bson.D{{Key: "position", Value: bson.D{{Key: "$regex", Value: "^Junior"}}}})
		vKonec, _ := vacancies.CountDocuments(ctx, bson.D{{Key: "title", Value: bson.D{{Key: "$regex", Value: "разработчик$"}}}})

		fmt.Println("вакансии: начинается с Junior:     ", vNachalo)
		fmt.Println("резюме: начинается с Junior:       ", rNachalo)
		fmt.Println("вакансии: кончается на разработчик:", vKonec)

		cursor, _ := resumes.Find(ctx, bson.D{{Key: "position", Value: bson.D{{Key: "$regex", Value: "^Junior"}}}},
		    options.Find().SetProjection(bson.D{{Key: "_id", Value: 0}, {Key: "fio", Value: 1}, {Key: "position", Value: 1}}))
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}
	}
}
