//go:build ignore

// Глава 2.7 · Текстовые шаблоны: $regex и $options
// Пример 6 из 6 · §6 Шаблон вместе с $not и $or · шаблон с $not и $or
//
// Запуск из папки архива:
//   docker compose run --rm go primery/06.go
//   cd primery, затем go run 06.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("hh")
	resumes := db.Collection("resumes")
	vacancies := db.Collection("vacancies")
	companies := db.Collection("companies")
	interviews := db.Collection("interviews")
	box := client.Database("sandbox").Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, resumes, vacancies, companies, interviews, box

	{
		// ── пример из главы ──────────────────────────────────────
		neSoderzhit, _ := vacancies.CountDocuments(ctx, bson.D{{Key: "title", Value: bson.D{{Key: "$not", Value: bson.D{{Key: "$regex", Value: "разработчик"}}}}}})
		ili, _ := vacancies.CountDocuments(ctx, bson.D{{Key: "$or", Value: bson.A{bson.D{{Key: "title", Value: bson.D{{Key: "$regex", Value: "^Junior"}}}}, bson.D{{Key: "title", Value: bson.D{{Key: "$regex", Value: "^Frontend"}}}}}}})

		fmt.Println("не содержит разработчик:     ", neSoderzhit)
		fmt.Println("Junior или Frontend в начале:", ili)
	}
}
