// Глава 2.7 · Текстовые шаблоны: $regex и $options
// Пример 3 из 6 · §3 Регистр: $options · регистр букв
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/03.cpp
//   cd primery, затем g++ -std=c++17 03.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["hh"];
    auto resumes = db["resumes"];
    auto vacancies = db["vacancies"];
    auto companies = db["companies"];
    auto interviews = db["interviews"];
    auto box = client["sandbox"]["products"];   // песочница: здесь можно менять

    {
        // ── пример из главы ──────────────────────────────────────
        std::cout << "junior:      " << vacancies.count_documents(make_document(kvp("title", make_document(kvp("$regex", "junior"))))) << std::endl;
        std::cout << "junior, i:   " << vacancies.count_documents(make_document(kvp("title", make_document(kvp("$regex", "junior"), kvp("$options", "i"))))) << std::endl;
        std::cout << "аналитик:    " << vacancies.count_documents(make_document(kvp("title", make_document(kvp("$regex", "аналитик"))))) << std::endl;
        std::cout << "аналитик, i: " << vacancies.count_documents(make_document(kvp("title", make_document(kvp("$regex", "аналитик"), kvp("$options", "i"))))) << std::endl;
    }
}
