# Глава 2.7 · Текстовые шаблоны: $regex и $options
# Пример 4 из 6 · §4 Символы шаблона и экранирование · точка в шаблоне
#
# Запуск из папки архива:
#   docker compose run --rm python primery/04.py
#   cd primery, затем python 04.py (Windows) или python3 04.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
print("шаблон .: ", vacancies.count_documents({"title": {"$regex": "."}}))
print("шаблон \\.:", vacancies.count_documents({"title": {"$regex": "\\."}}))

for doc in vacancies.find({"title": {"$regex": "\\."}}, {"_id": 0, "title": 1}):
    print(doc)
