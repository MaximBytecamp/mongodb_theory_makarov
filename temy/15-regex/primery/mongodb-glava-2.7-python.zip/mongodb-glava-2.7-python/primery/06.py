# Глава 2.7 · Текстовые шаблоны: $regex и $options
# Пример 6 из 6 · §6 Шаблон вместе с $not и $or · шаблон с $not и $or
#
# Запуск из папки архива:
#   docker compose run --rm python primery/06.py
#   cd primery, затем python 06.py (Windows) или python3 06.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
print("не содержит разработчик:     ", vacancies.count_documents({"title": {"$not": {"$regex": "разработчик"}}}))
print("Junior или Frontend в начале:", vacancies.count_documents({"$or": [{"title": {"$regex": "^Junior"}}, {"title": {"$regex": "^Frontend"}}]}))
