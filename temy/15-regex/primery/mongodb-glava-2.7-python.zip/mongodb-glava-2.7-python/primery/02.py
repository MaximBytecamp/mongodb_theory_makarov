# Глава 2.7 · Текстовые шаблоны: $regex и $options
# Пример 2 из 6 · §2 Начало и конец строки · начало и конец строки
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
print("вакансии: начинается с Junior:     ", vacancies.count_documents({"title": {"$regex": "^Junior"}}))
print("резюме: начинается с Junior:       ", resumes.count_documents({"position": {"$regex": "^Junior"}}))
print("вакансии: кончается на разработчик:", vacancies.count_documents({"title": {"$regex": "разработчик$"}}))

for doc in resumes.find({"position": {"$regex": "^Junior"}}, {"_id": 0, "fio": 1, "position": 1}):
    print(doc)
