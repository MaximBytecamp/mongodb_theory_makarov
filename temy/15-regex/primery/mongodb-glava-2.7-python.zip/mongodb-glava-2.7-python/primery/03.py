# Глава 2.7 · Текстовые шаблоны: $regex и $options
# Пример 3 из 6 · §3 Регистр: $options · регистр букв
#
# Запуск из папки архива:
#   docker compose run --rm python primery/03.py
#   cd primery, затем python 03.py (Windows) или python3 03.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
print("junior:     ", vacancies.count_documents({"title": {"$regex": "junior"}}))
print("junior, i:  ", vacancies.count_documents({"title": {"$regex": "junior", "$options": "i"}}))
print("аналитик:   ", vacancies.count_documents({"title": {"$regex": "аналитик"}}))
print("аналитик, i:", vacancies.count_documents({"title": {"$regex": "аналитик", "$options": "i"}}))
