# Глава 2.7 · Текстовые шаблоны: $regex и $options
# Пример 5 из 6 · §5 Шаблон и поле-массив · шаблон и поле-массив
#
# Запуск из папки архива:
#   docker compose run --rm python primery/05.py
#   cd primery, затем python 05.py (Windows) или python3 05.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
for doc in resumes.find({"skills": {"$regex": "^Postgre"}}, {"_id": 0, "fio": 1, "skills": 1}):
    print(doc)
