# Глава 4.6 · $unwind: массив становится документами
# Пример 8 из 9 · §7 Документы без массива · пустые массивы у отменённых заказов
#
# Запуск из папки архива:
#   docker compose run --rm python primery/08.py
#   cd primery, затем python 08.py (Windows) или python3 08.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

from datetime import datetime


def show(docs, *fields):
    """Печатает у каждого документа поля fields в строку через « | »; вложенные — через точку."""
    count = 0
    for doc in docs:
        cells = []
        for path in fields:
            value = doc
            for key in path.split("."):
                value = value.get(key) if isinstance(value, dict) else None
            if isinstance(value, datetime):
                value = value.strftime("%Y-%m-%d %H:%M")
            if isinstance(value, bool):
                value = str(value).lower()
            cells.append("—" if value is None else str(value))
        print(" | ".join(cells))
        count += 1
    print("документов:", count)

# ── пример из главы ───────────────────────────────────────────
empty_plain = [
    {"$set": {"items": {"$cond": [{"$eq": ["$status", "отменён"]}, [], "$items"]}}},
    {"$unwind": "$items"},
    {"$count": "docs"},
]

empty_kept = [
    {"$set": {"items": {"$cond": [{"$eq": ["$status", "отменён"]}, [], "$items"]}}},
    {"$unwind": {"path": "$items", "preserveNullAndEmptyArrays": True}},
    {"$count": "docs"},
]

print("── $unwind")
for doc in orders.aggregate(empty_plain):
    print(doc)

print("── с preserveNullAndEmptyArrays")
for doc in orders.aggregate(empty_kept):
    print(doc)
