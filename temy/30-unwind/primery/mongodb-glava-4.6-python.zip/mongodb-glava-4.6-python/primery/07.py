# Глава 4.6 · $unwind: массив становится документами
# Пример 7 из 9 · §7 Документы без массива · $unwind по полю, которого нет у части заказов
#
# Запуск из папки архива:
#   docker compose run --rm python primery/07.py
#   cd primery, затем python 07.py (Windows) или python3 07.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

from datetime import datetime


def show(docs, *fields):
    """Печатает у каждого документа поля fields в строку через « | »; вложенные — через точку."""
    count = 0
    for doc in docs:
        cells = []
        for path in fields:
            value = doc
            for key in path.split("."):
                value = value.get(key) if isinstance(value, dict) else None
            if isinstance(value, datetime):
                value = value.strftime("%Y-%m-%d %H:%M")
            if isinstance(value, bool):
                value = str(value).lower()
            cells.append("—" if value is None else str(value))
        print(" | ".join(cells))
        count += 1
    print("документов:", count)

# ── пример из главы ───────────────────────────────────────────
promo_plain = [
    {"$unwind": "$promo"},
    {"$count": "orders"},
]

promo_kept = [
    {"$unwind": {"path": "$promo", "preserveNullAndEmptyArrays": True}},
    {"$count": "orders"},
]

print("── $unwind по promo")
for doc in orders.aggregate(promo_plain):
    print(doc)

print("── с preserveNullAndEmptyArrays")
for doc in orders.aggregate(promo_kept):
    print(doc)
