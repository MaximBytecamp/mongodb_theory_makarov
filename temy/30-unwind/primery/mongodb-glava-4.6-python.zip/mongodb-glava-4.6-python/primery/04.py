# Глава 4.6 · $unwind: массив становится документами
# Пример 4 из 9 · §4 Поля документа повторяются · сумма заказов до $unwind и после
#
# Запуск из папки архива:
#   docker compose run --rm python primery/04.py
#   cd primery, затем python 04.py (Windows) или python3 04.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

from datetime import datetime


def show(docs, *fields):
    """Печатает у каждого документа поля fields в строку через « | »; вложенные — через точку."""
    count = 0
    for doc in docs:
        cells = []
        for path in fields:
            value = doc
            for key in path.split("."):
                value = value.get(key) if isinstance(value, dict) else None
            if isinstance(value, datetime):
                value = value.strftime("%Y-%m-%d %H:%M")
            if isinstance(value, bool):
                value = str(value).lower()
            cells.append("—" if value is None else str(value))
        print(" | ".join(cells))
        count += 1
    print("документов:", count)

# ── пример из главы ───────────────────────────────────────────
by_orders = [
    {"$group": {"_id": None, "revenue": {"$sum": "$total"}}},
]

by_lines_total = [
    {"$unwind": "$items"},
    {"$group": {"_id": None, "revenue": {"$sum": "$total"}}},
]

by_lines = [
    {"$unwind": "$items"},
    {"$group": {
        "_id": None,
        "revenue": {"$sum": {"$multiply": ["$items.qty", "$items.price"]}},
    }},
]

print("── сумма total по заказам")
for doc in orders.aggregate(by_orders):
    print(doc)

print("── сумма total после $unwind")
for doc in orders.aggregate(by_lines_total):
    print(doc)

print("── сумма qty × price после $unwind")
for doc in orders.aggregate(by_lines):
    print(doc)
