# Глава 4.6 · $unwind: массив становится документами — примеры на C++

Архив к «Справочнику по MongoDB»: все примеры главы готовыми программами, данные баз и стенд в Docker.
Глава: https://maximbytecamp.github.io/mongodb_theory_makarov/temy/30-unwind/index.html

Язык: **C++** · драйвер mongocxx 4.5 · сервер MongoDB 7.

## Что в архиве

```text
mongodb-glava-4.6-cpp/
  README.md         эта инструкция
  primery/          примеры главы — по программе на пример
    01.cpp … 09.cpp
  compose.yaml      стенд в Docker: сервер, базы, mongo-express, C++
  docker/           образ с драйвером C++ и скрипт запуска run.sh
  stend/seed/       данные баз: 12 файлов JSON
  stend/load.ps1    загрузка данных на установленный сервер — Windows
  stend/load.sh     то же — macOS и Linux
```

## Порядок работы

1. **Базы.** Глава **только читает** данные — сбрасывать базы не нужно.
2. **Примеры — по порядку, каждый один раз.** Пример в главе рассчитан на данные, которые оставил
   предыдущий. Если запустить пример дважды или пропустить, числа разойдутся с книгой — тогда
   сбросьте базы и начните с `01.cpp`.
3. **Сверка.** Что должна напечатать каждая программа — в разделе «Примеры и выводы» ниже.
   Отличаться могут только `_id`, которые выдаёт сервер, текущие дата и время и порядок
   в списке коллекций: сервер отдаёт их имена в произвольном порядке. У документа, который
   создан обновлением с `upsert`, поля тоже могут идти в другом порядке — значения при этом те же.

Подойдёт любой из двух способов. Адрес сервера в обоих — `mongodb://localhost:27017`, код примеров
одинаковый.

| Способ | Что нужно | Когда подходит |
|---|---|---|
| **1. Docker** | Docker Desktop | Compass и сервер не установились или не подключаются; ничего, кроме Docker, ставить не нужно |
| **2. Сервер и Compass** | MongoDB Server, Compass, C++ с драйвером | сервер и Compass уже стоят и подключаются |

## Способ 1. Docker

Docker Desktop — с [docker.com](https://www.docker.com/products/docker-desktop/); на Linux — Docker Engine.
Перед командами Docker Desktop должен быть запущен. Команды одинаковые в PowerShell, cmd и терминале
macOS/Linux; выполняйте их **из папки архива** — там, где лежит `compose.yaml`.

1. Поднять сервер и загрузить базы курса:

   ```bash
   docker compose up -d
   ```

2. Запустить пример — путь к файлу пишется от папки архива:

   ```bash
   docker compose run --rm cpp primery/01.cpp
   ```

   При первом запуске Docker соберёт образ с драйвером C++ — это несколько минут: драйвер C++ собирается из исходников.
   Дальше запуск идёт за секунды.

3. Все примеры главы подряд, по порядку, одной командой:

   ```bash
   docker compose run --rm cpp primery
   ```

   Перед каждой программой печатается её имя: `── primery/01.cpp ──`.

**Смотреть данные.** Compass не нужен: в браузере откройте http://localhost:8081, логин `student`,
пароль `student` — это mongo-express, в нём видны базы, коллекции и документы. Если Compass
установлен, он подключается к этому же серверу по адресу `mongodb://localhost:27017`.

**Консоль сервера:** `docker compose exec mongo mongosh`.

**Остановить и удалить:**

```bash
docker compose stop        # остановить; данные останутся
docker compose down        # удалить контейнеры; данные останутся
docker compose down -v     # удалить всё вместе с данными
```

Архивы всех глав пользуются одним и тем же сервером и данными: после этой главы можно распаковать
архив следующей и работать там, не удаляя стенд.

## Способ 2. Установленный сервер MongoDB и Compass

Нужны MongoDB Server 7 или 8 и MongoDB Compass — установка по шагам в
[главе 1.0а](https://maximbytecamp.github.io/mongodb_theory_makarov/temy/00a-windows-10-mongodb-7/index.html).
Проверка: Compass подключается к `mongodb://localhost:27017`.

### Шаг 1. Загрузить базы курса

Windows, PowerShell, из папки архива — нужен `mongoimport` из MongoDB Command Line Database Tools:

```powershell
powershell -ExecutionPolicy Bypass -File stend\load.ps1
```

macOS и Linux (`mongoimport`: `brew tap mongodb/brew && brew install mongodb-database-tools`):

```bash
bash stend/load.sh
```

Скрипт пересоздаёт коллекции целиком, поэтому он же сбрасывает базы: повторный запуск ничего не двоит.

**Без `mongoimport` — через Compass.** Подключитесь к `mongodb://localhost:27017`, нажмите **Create database**,
затем в коллекции **Add data → Import JSON or CSV file** и выберите файл из `stend/seed`. Имя файла
подсказывает, куда класть: `shop.orders.json` — база `shop`, коллекция `orders`. Так загружаются все
12 файлов; пошагово с кадрами — [глава 1.0, §7](https://maximbytecamp.github.io/mongodb_theory_makarov/temy/00-uchebnye-bazy/index.html#s7).

После загрузки в Compass нажмите **Refresh**: в списке должны быть базы `shop`, `hh`, `logs`, `org`
и `sandbox`. В `shop.products` — 21 документ, в `shop.orders` — 120.

### Шаг 2. Драйвер C++ и запуск

Драйвер C++ на Windows и Linux собирается из исходников долго и с зависимостями, поэтому
там примеры запускаются **только в Docker** — способ 1. Если сервер MongoDB уже установлен и занимает порт
27017, остановите службу MongoDB или перед `docker compose up -d` создайте файл `.env` (см. «Частые ошибки»).

На macOS драйвер ставится из Homebrew:

```bash
brew install mongo-cxx-driver
cd primery
g++ -std=c++17 01.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
```

Остальные примеры запускаются так же: `02.cpp`, `03.cpp` и далее. Если сервер слушает другой адрес,
задайте его переменной `MONGO_URI` — программы глав 1.2–1.8 читают её при подключении.

## Примеры и выводы

| Файл | Параграф главы | Что делает |
|---|---|---|
| `01.cpp` | §1 Стадия $unwind | заказ из трёх позиций после $unwind |
| `02.cpp` | §2 Сколько документов выходит из $unwind | сколько документов до $unwind и после |
| `03.cpp` | §3 Группировка по элементам массива | позиции заказов по категориям |
| `04.cpp` | §4 Поля документа повторяются | сумма заказов до $unwind и после |
| `05.cpp` | §5 $match до $unwind и после | $match до $unwind и после |
| `06.cpp` | §6 Номер элемента: includeArrayIndex | includeArrayIndex: номер позиции |
| `07.cpp` | §7 Документы без массива | $unwind по полю, которого нет у части заказов |
| `08.cpp` | §7 Документы без массива | пустые массивы у отменённых заказов |
| `09.cpp` | §8 Самые продаваемые товары | три самых продаваемых товара |

### 01.cpp · §1 Стадия $unwind

Заказ из трёх позиций после $unwind.

```text
2026-0002 | Ноутбук ASUS VivoBook 15 | 1
2026-0002 | Веб-камера Logitech C920 | 1
2026-0002 | Наушники Sony WH-1000XM5 | 3
документов: 3
```

### 02.cpp · §2 Сколько документов выходит из $unwind

Сколько документов до $unwind и после.

```text
── заказов
{ "orders" : 120 }
── позиций после $unwind
{ "lines" : 271 }
```

### 03.cpp · §3 Группировка по элементам массива

Позиции заказов по категориям.

```text
{ "_id" : "ноутбуки", "lines" : 67, "qty" : 103, "revenue" : 8085980 }
{ "_id" : "смартфоны", "lines" : 57, "qty" : 103, "revenue" : 4487970 }
{ "_id" : "периферия", "lines" : 66, "qty" : 106, "revenue" : 1606540 }
{ "_id" : "комплектующие", "lines" : 48, "qty" : 75, "revenue" : 1067950 }
{ "_id" : "аксессуары", "lines" : 33, "qty" : 53, "revenue" : 137870 }
```

### 04.cpp · §4 Поля документа повторяются

Сумма заказов до $unwind и после.

```text
── сумма total по заказам
{ "_id" : null, "revenue" : 15386310 }
── сумма total после $unwind
{ "_id" : null, "revenue" : 41847990 }
── сумма qty × price после $unwind
{ "_id" : null, "revenue" : 15386310 }
```

### 05.cpp · §5 $match до $unwind и после

$match до $unwind и после.

```text
── $match до $unwind
{ "lines" : 154 }
── $match после $unwind
{ "lines" : 67 }
── $match до и после
{ "lines" : 67 }
```

### 06.cpp · §6 Номер элемента: includeArrayIndex

IncludeArrayIndex: номер позиции.

```text
2026-0002 | 0 | Ноутбук ASUS VivoBook 15
2026-0002 | 1 | Веб-камера Logitech C920
2026-0002 | 2 | Наушники Sony WH-1000XM5
документов: 3
```

### 07.cpp · §7 Документы без массива

$unwind по полю, которого нет у части заказов.

```text
── $unwind по promo
{ "orders" : 40 }
── с preserveNullAndEmptyArrays
{ "orders" : 120 }
```

### 08.cpp · §7 Документы без массива

Пустые массивы у отменённых заказов.

```text
── $unwind
{ "docs" : 228 }
── с preserveNullAndEmptyArrays
{ "docs" : 248 }
```

### 09.cpp · §8 Самые продаваемые товары

Три самых продаваемых товара.

```text
{ "_id" : "Смартфон Apple iPhone 15", "qty" : 20 }
{ "_id" : "Ноутбук Apple MacBook Air 13", "qty" : 19 }
{ "_id" : "SSD Samsung 980 1 ТБ", "qty" : 18 }
```

## Частые ошибки

| Что видно | Причина | Что сделать |
|---|---|---|
| `port is already allocated`, `address already in use` на `docker compose up -d` | порт 27017 занят: уже работает установленный MongoDB или стенд `mongodb-practice` | остановите тот сервер или создайте рядом с `compose.yaml` файл `.env` со строкой `MONGO_PORT=27018`: в PowerShell — `Set-Content .env "MONGO_PORT=27018"`, в bash — `echo "MONGO_PORT=27018" > .env`. Программы в Docker это не затрагивает, Compass подключайте к `localhost:27018` |
| `Cannot connect to the Docker daemon`, `error during connect` | Docker Desktop не запущен | запустите Docker Desktop и дождитесь зелёного статуса Engine running |
| `ServerSelectionTimeoutError`, `Connection refused`, `No server available` | сервер не запущен | Docker: `docker compose up -d`; способ 2 — запустите службу MongoDB |
| `Файл не найден: …` | путь написан не от папки архива или команда выполнена в другой папке | перейдите в папку, где лежит `compose.yaml`, и пишите путь `primery/01.cpp` |
| числа в выводе не совпадают с README | пример запускали дважды, пропустили или базы не сброшены | сбросьте базы и запустите примеры с первого по порядку |

В PowerShell не используйте `echo … > .env`: Windows PowerShell 5 пишет такой файл в UTF-16, и Docker
Compose его не прочитает.
