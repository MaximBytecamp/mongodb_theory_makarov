# Глава 4.6 · $unwind: массив становится документами
# Пример 9 из 9 · §8 Самые продаваемые товары · три самых продаваемых товара
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/09.rb
#   cd primery, затем ruby 09.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# Печатает у каждого документа поля fields в строку через « | »; вложенные — через точку.
def show(docs, *fields)
  count = 0
  docs.each do |doc|
    cells = fields.map do |path|
      value = path.split(".").reduce(doc) { |v, key| v.is_a?(Hash) ? v[key] : nil }
      value = value.utc.strftime("%Y-%m-%d %H:%M") if value.is_a?(Time)
      value.nil? ? "—" : value.to_s
    end
    puts cells.join(" | ")
    count += 1
  end
  puts "документов: #{count}"
end

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "status" => "доставлен" } },
  { "$unwind" => "$items" },
  { "$group" => { "_id" => "$items.title", "qty" => { "$sum" => "$items.qty" } } },
  { "$sort" => { "qty" => -1, "_id" => 1 } },
  { "$limit" => 3 },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
