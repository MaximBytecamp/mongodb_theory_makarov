# Глава 4.6 · $unwind: массив становится документами
# Пример 4 из 9 · §4 Поля документа повторяются · сумма заказов до $unwind и после
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/04.rb
#   cd primery, затем ruby 04.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# Печатает у каждого документа поля fields в строку через « | »; вложенные — через точку.
def show(docs, *fields)
  count = 0
  docs.each do |doc|
    cells = fields.map do |path|
      value = path.split(".").reduce(doc) { |v, key| v.is_a?(Hash) ? v[key] : nil }
      value = value.utc.strftime("%Y-%m-%d %H:%M") if value.is_a?(Time)
      value.nil? ? "—" : value.to_s
    end
    puts cells.join(" | ")
    count += 1
  end
  puts "документов: #{count}"
end

# ── пример из главы ───────────────────────────────────────────
by_orders = [
  { "$group" => { "_id" => nil, "revenue" => { "$sum" => "$total" } } },
]

by_lines_total = [
  { "$unwind" => "$items" },
  { "$group" => { "_id" => nil, "revenue" => { "$sum" => "$total" } } },
]

by_lines = [
  { "$unwind" => "$items" },
  { "$group" => {
    "_id" => nil,
    "revenue" => { "$sum" => { "$multiply" => ["$items.qty", "$items.price"] } },
  } },
]

puts "── сумма total по заказам"
orders.aggregate(by_orders).each { |doc| puts doc.inspect }

puts "── сумма total после $unwind"
orders.aggregate(by_lines_total).each { |doc| puts doc.inspect }

puts "── сумма qty × price после $unwind"
orders.aggregate(by_lines).each { |doc| puts doc.inspect }
