# Глава 1.4 · Чтение: find, find_one и курсор
# Пример 7 из 10 · §4 Курсор проходится один раз · Python
#
# Запуск из папки архива:
#   docker compose run --rm python primery/07.py
#   cd primery, затем python 07.py (Windows) или python3 07.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
cursor = products.find({"category": "ноутбуки"})

print("найдено:", len(list(cursor)))   # 5
for doc in cursor:                  # ни одной строки
    print(doc["title"])
