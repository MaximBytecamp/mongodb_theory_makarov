# Глава 1.4 · Чтение: find, find_one и курсор
# Пример 10 из 10 · §6 Точечная нотация: внутрь документа · вложенное поле
#
# Запуск из папки архива:
#   docker compose run --rm python primery/10.py
#   cd primery, затем python 10.py (Windows) или python3 10.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
orders = client["shop"]["orders"]

# доставка в Екатеринбург — 28 заказов
orders.count_documents({"delivery.city": "Екатеринбург"})

# оплаченные заказы
orders.count_documents({"payment.paid": True})
