# Глава 1.4 · Чтение: find, find_one и курсор
# Пример 4 из 10 · §3 find: курсор, а не список · перебор курсора
#
# Запуск из папки архива:
#   docker compose run --rm python primery/04.py
#   cd primery, затем python 04.py (Windows) или python3 04.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
cursor = products.find({"category": "смартфоны"})
print(type(cursor).__name__)

for doc in cursor:
    print(doc["_id"], doc["title"], doc["price"])
