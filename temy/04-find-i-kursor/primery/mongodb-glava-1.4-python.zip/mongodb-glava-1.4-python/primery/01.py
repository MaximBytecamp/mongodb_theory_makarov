# Глава 1.4 · Чтение: find, find_one и курсор
# Пример 1 из 10 · §1 find_one: первый подходящий · один документ
#
# Запуск из папки архива:
#   docker compose run --rm python primery/01.py
#   cd primery, затем python 01.py (Windows) или python3 01.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
products = client["shop"]["products"]

one = products.find_one({"category": "смартфоны"})
print(one["title"], one["price"])
