# Глава 1.4 · Чтение: find, find_one и курсор
# Пример 5 из 10 · §3 find: курсор, а не список · курсор → список
#
# Запуск из папки архива:
#   docker compose run --rm python primery/05.py
#   cd primery, затем python 05.py (Windows) или python3 05.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
items = list(products.find({"category": "смартфоны"}))
print(len(items))        # 4
