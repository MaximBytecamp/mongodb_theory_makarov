# Глава 1.4 · Чтение: find, find_one и курсор
# Пример 9 из 10 · §5 Порядок без сортировки не определён · явный порядок
#
# Запуск из папки архива:
#   docker compose run --rm python primery/09.py
#   cd primery, затем python 09.py (Windows) или python3 09.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
for doc in products.find({"category": "смартфоны"}).sort("price", 1):
    print(doc["price"], doc["title"])
