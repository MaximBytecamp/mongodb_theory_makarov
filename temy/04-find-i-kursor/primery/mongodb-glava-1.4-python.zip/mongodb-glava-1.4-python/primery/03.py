# Глава 1.4 · Чтение: find, find_one и курсор
# Пример 3 из 10 · §2 Фильтр — это документ · фильтр собирается по частям
#
# Запуск из папки архива:
#   docker compose run --rm python primery/03.py
#   cd primery, затем python 03.py (Windows) или python3 03.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
def search(products, category=None, brand=None):
    query = {}
    if category:
        query["category"] = category
    if brand:
        query["brand"] = brand
    return list(products.find(query))

found = search(products, category="смартфоны")
print("смартфонов:", len(found))
