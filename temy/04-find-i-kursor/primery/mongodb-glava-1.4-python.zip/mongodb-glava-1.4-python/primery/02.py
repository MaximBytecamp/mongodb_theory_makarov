# Глава 1.4 · Чтение: find, find_one и курсор
# Пример 2 из 10 · §1 find_one: первый подходящий · ничего не нашлось
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
missing = products.find_one({"category": "велосипеды"})
print(missing)          # None

# поэтому обращаться к полям можно только после проверки
if missing is not None:
    print(missing["title"])
