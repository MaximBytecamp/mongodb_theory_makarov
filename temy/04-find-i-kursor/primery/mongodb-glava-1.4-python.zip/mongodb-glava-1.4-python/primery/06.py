# Глава 1.4 · Чтение: find, find_one и курсор
# Пример 6 из 10 · §4 Курсор проходится один раз · второй проход
#
# Запуск из папки архива:
#   docker compose run --rm python primery/06.py
#   cd primery, затем python 06.py (Windows) или python3 06.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
cursor = products.find({"category": "смартфоны"})

for doc in cursor:
    print(doc["_id"])       # четыре строки

print("второй проход:", list(cursor))
