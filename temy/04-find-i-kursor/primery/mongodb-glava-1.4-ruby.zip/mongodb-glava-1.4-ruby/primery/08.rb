# Глава 1.4 · Чтение: find, find_one и курсор
# Пример 8 из 10 · §4 Курсор проходится один раз · Ruby
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/08.rb
#   cd primery, затем ruby 08.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
items = products.find({ "category" => "ноутбуки" }).to_a

puts "найдено: #{items.size}"         # 5, один запрос к серверу
items.each { |doc| puts doc["title"] }  # пять строк, без запроса
