# Глава 1.4 · Чтение: find, find_one и курсор
# Пример 2 из 10 · §1 find_one: первый подходящий · ничего не нашлось
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/02.rb
#   cd primery, затем ruby 02.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
missing = products.find({ "category" => "велосипеды" }).first
puts missing.inspect     # nil

# поэтому обращаться к полям можно только после проверки
puts missing["title"] unless missing.nil?
