# Глава 1.4 · Чтение: find, find_one и курсор
# Пример 7 из 10 · §4 Курсор проходится один раз · Ruby
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/07.rb
#   cd primery, затем ruby 07.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
# в Ruby эта ловушка не срабатывает: view перезапрашивает данные
view = products.find({ "category" => "ноутбуки" })

puts "найдено: #{view.to_a.size}"   # 5, первый запрос
view.each { |doc| puts doc["title"] }  # 5, второй запрос
