# Глава 1.4 · Чтение: find, find_one и курсор
# Пример 10 из 10 · §6 Точечная нотация: внутрь документа · вложенное поле
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/10.rb
#   cd primery, затем ruby 10.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
orders = client.use("shop").database[:orders]

# доставка в Екатеринбург — 28 заказов
orders.count_documents({ "delivery.city" => "Екатеринбург" })

# оплаченные заказы
orders.count_documents({ "payment.paid" => true })
