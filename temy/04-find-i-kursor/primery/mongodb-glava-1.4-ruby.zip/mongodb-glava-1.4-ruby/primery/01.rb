# Глава 1.4 · Чтение: find, find_one и курсор
# Пример 1 из 10 · §1 find_one: первый подходящий · один документ
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/01.rb
#   cd primery, затем ruby 01.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
products = client.use("shop").database[:products]

one = products.find({ "category" => "смартфоны" }).first
puts "#{one['title']} #{one['price']}"
