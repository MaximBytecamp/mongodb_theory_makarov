# Глава 1.4 · Чтение: find, find_one и курсор
# Пример 9 из 10 · §5 Порядок без сортировки не определён · явный порядок
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/09.rb
#   cd primery, затем ruby 09.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
products.find({ "category" => "смартфоны" })
        .sort({ "price" => 1 })
        .each { |doc| puts "#{doc['price']} #{doc['title']}" }
