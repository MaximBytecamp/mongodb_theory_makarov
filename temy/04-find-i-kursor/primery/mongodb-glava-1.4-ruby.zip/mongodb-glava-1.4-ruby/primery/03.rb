# Глава 1.4 · Чтение: find, find_one и курсор
# Пример 3 из 10 · §2 Фильтр — это документ · фильтр собирается по частям
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/03.rb
#   cd primery, затем ruby 03.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
def search(products, category: nil, brand: nil)
  query = {}
  query["category"] = category if category
  query["brand"] = brand if brand
  products.find(query).to_a
end

found = search(products, category: "смартфоны")
puts "смартфонов: #{found.size}"
