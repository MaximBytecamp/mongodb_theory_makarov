# Глава 1.4 · Чтение: find, find_one и курсор
# Пример 6 из 10 · §4 Курсор проходится один раз · второй проход
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/06.rb
#   cd primery, затем ruby 06.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
view = products.find({ "category" => "смартфоны" })

view.each { |doc| puts doc["_id"] }   # четыре строки

# запрос выполняется заново — документы те же
puts "второй проход: #{view.to_a.size} документов"
