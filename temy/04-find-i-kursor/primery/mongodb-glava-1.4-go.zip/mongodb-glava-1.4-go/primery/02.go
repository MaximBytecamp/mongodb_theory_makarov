//go:build ignore

// Глава 1.4 · Чтение: find, find_one и курсор
// Пример 2 из 10 · §1 find_one: первый подходящий · ничего не нашлось
//
// Запуск из папки архива:
//   docker compose run --rm go primery/02.go
//   cd primery, затем go run 02.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────

// Product — поля товара, которые читают примеры. Тип объявлен в главе 1.4.
type Product struct {
	ID       string `bson:"_id"`
	SKU      string `bson:"sku"`
	Title    string `bson:"title"`
	Category string `bson:"category"`
	Price    int    `bson:"price"`
}

var missing Product

func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	products := db.Collection("products")
	orders := db.Collection("orders")
	box := client.Database("sandbox").Collection("products") // песочница: здесь можно менять
	_, _, _, _ = db, products, orders, box

	{
		// ── пример из главы ──────────────────────────────────────
		err := products.FindOne(ctx,
		    bson.D{{Key: "category", Value: "велосипеды"}}).Decode(&missing)

		// «не нашлось» — это отдельная ошибка, а не пустая структура
		if errors.Is(err, mongo.ErrNoDocuments) {
		    fmt.Println("ничего не нашлось")
		}
	}
}
