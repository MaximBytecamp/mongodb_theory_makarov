# Глава 1.2 · Документ и BSON
# Пример 2 из 2 · §5 Поле _id · _id, которого не было
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
result = box.insert_one({
    "sku": "SKU-AC-022", "title": "Коврик для мыши XL", "price": 1290,
})

print("присвоенный _id:", result.inserted_id)
print("тип:", type(result.inserted_id).__name__)
print("время создания:", result.inserted_id.generation_time)
