# Глава 1.2 · Документ и BSON
# Пример 1 из 2 · §3 Типы значений · типы полей документа
#
# Запуск из папки архива:
#   docker compose run --rm python primery/01.py
#   cd primery, затем python 01.py (Windows) или python3 01.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
one = db["products"].find_one({"_id": "p-012"})

for name, value in one.items():
    print(f"{name:10} {type(value).__name__}")
