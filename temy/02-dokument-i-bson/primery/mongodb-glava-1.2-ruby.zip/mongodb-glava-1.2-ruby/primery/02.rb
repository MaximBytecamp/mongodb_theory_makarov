# Глава 1.2 · Документ и BSON
# Пример 2 из 2 · §5 Поле _id · _id, которого не было
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/02.rb
#   cd primery, затем ruby 02.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
result = box.insert_one({
  "sku" => "SKU-AC-022", "title" => "Коврик для мыши XL", "price" => 1290
})

oid = result.inserted_id
puts "присвоенный _id: #{oid}"
puts "тип: #{oid.class}"
puts "время создания: #{oid.generation_time}"
