//go:build ignore

// Глава 1.2 · Документ и BSON
// Пример 2 из 2 · §5 Поле _id · _id, которого не было
//
// Запуск из папки архива:
//   docker compose run --rm go primery/02.go
//   cd primery, затем go run 02.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	products := db.Collection("products")
	orders := db.Collection("orders")
	box := client.Database("sandbox").Collection("products") // песочница: здесь можно менять
	_, _, _, _ = db, products, orders, box

	{
		// ── пример из главы ──────────────────────────────────────
		res, err := box.InsertOne(ctx, bson.D{
		    {Key: "sku", Value: "SKU-AC-022"},
		    {Key: "title", Value: "Коврик для мыши XL"},
		    {Key: "price", Value: 1290},
		})
		if err != nil {
		    log.Fatal(err)
		}

		oid := res.InsertedID.(bson.ObjectID)
		fmt.Println("присвоенный _id:", oid.Hex())
		fmt.Printf("тип: %T\n", oid)
		fmt.Println("время создания:", oid.Timestamp().UTC())
	}
}
