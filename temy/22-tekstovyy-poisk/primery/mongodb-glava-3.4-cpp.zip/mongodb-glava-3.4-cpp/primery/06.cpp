// Глава 3.4 · Текстовый поиск: $text и $search
// Пример 6 из 6 · §6 Индекс по нескольким полям и веса · индекс по двум полям с весами
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/06.cpp
//   cd primery, затем g++ -std=c++17 06.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto products = db["products"];
    auto orders = db["orders"];
    auto events = client["logs"]["events"];
    auto sandbox = client["sandbox"];
    auto box = sandbox["products"];   // песочница: здесь можно менять

    auto showcase = sandbox["showcase"];   // копия товаров магазина: на ней строится текстовый индекс

    {
        // ── пример из главы ──────────────────────────────────────
        showcase.indexes().drop_one("title_text");
        auto weights = make_document(kvp("title", 10), kvp("category", 1));
        mongocxx::options::index poisk;
        poisk.weights(weights.view());
        poisk.default_language("russian");
        poisk.name("poisk");
        showcase.create_index(make_document(kvp("title", "text"), kvp("category", "text")), poisk);

        mongocxx::options::find by_score;
        by_score.projection(make_document(kvp("_id", 0), kvp("title", 1), kvp("score", make_document(kvp("$meta", "textScore")))));
        by_score.sort(make_document(kvp("score", make_document(kvp("$meta", "textScore"))), kvp("title", 1)));
        for (auto&& doc : showcase.find(make_document(kvp("$text", make_document(kvp("$search", "смартфоны")))), by_score)) {
            std::cout << std::fixed << std::setprecision(3) << doc["score"].get_double().value << " "
                      << doc["title"].get_string().value << std::endl;
        }

        try {
            showcase.create_index(make_document(kvp("brand", "text")));
        } catch (const mongocxx::operation_exception& e) {
            std::cout << "второй текстовый индекс не создан, код " << e.code().value() << std::endl;
        }
    }
}
