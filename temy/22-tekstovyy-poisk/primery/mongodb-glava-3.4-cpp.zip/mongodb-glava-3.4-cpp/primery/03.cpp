// Глава 3.4 · Текстовый поиск: $text и $search
// Пример 3 из 6 · §3 Несколько слов, фраза, исключение · слова, фраза, исключение
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/03.cpp
//   cd primery, затем g++ -std=c++17 03.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto products = db["products"];
    auto orders = db["orders"];
    auto events = client["logs"]["events"];
    auto sandbox = client["sandbox"];
    auto box = sandbox["products"];   // песочница: здесь можно менять

    auto showcase = sandbox["showcase"];   // копия товаров магазина: на ней строится текстовый индекс

    {
        // ── пример из главы ──────────────────────────────────────
        mongocxx::options::find by_title;
        by_title.sort(make_document(kvp("title", 1)));
        for (std::string search : {"мышь клавиатура", "\"для ноутбука\"", "ноутбук -рюкзак", "ноут", "для"}) {
            std::string found;
            for (auto&& doc : showcase.find(make_document(kvp("$text", make_document(kvp("$search", search)))), by_title)) {
                if (!found.empty()) found += ", ";
                found += std::string{doc["title"].get_string().value};
            }
            size_t letters = 0;                       // в UTF-8 буква кириллицы занимает два байта
            for (unsigned char c : search) letters += (c & 0xC0) != 0x80;
            std::cout << search << std::string(16 - std::min<size_t>(16, letters), ' ') << " → "
                      << (found.empty() ? "ничего" : found) << std::endl;
        }
    }
}
