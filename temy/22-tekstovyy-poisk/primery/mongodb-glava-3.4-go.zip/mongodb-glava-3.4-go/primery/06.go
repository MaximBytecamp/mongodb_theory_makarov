//go:build ignore

// Глава 3.4 · Текстовый поиск: $text и $search
// Пример 6 из 6 · §6 Индекс по нескольким полям и веса · индекс по двум полям с весами
//
// Запуск из папки архива:
//   docker compose run --rm go primery/06.go
//   cd primery, затем go run 06.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"
	"strings"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = strings.Join
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────

var ce mongo.CommandError

func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	products := db.Collection("products")
	orders := db.Collection("orders")
	events := client.Database("logs").Collection("events")
	sandbox := client.Database("sandbox")
	box := sandbox.Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, products, orders, events, sandbox, box

	showcase := sandbox.Collection("showcase") // копия товаров магазина: на ней строится текстовый индекс
	_ = showcase

	{
		// ── пример из главы ──────────────────────────────────────
		showcase.Indexes().DropOne(ctx, "title_text")
		showcase.Indexes().CreateOne(ctx, mongo.IndexModel{
		    Keys: bson.D{{Key: "title", Value: "text"}, {Key: "category", Value: "text"}},
		    Options: options.Index().
		        SetWeights(bson.D{{Key: "title", Value: 10}, {Key: "category", Value: 1}}).
		        SetDefaultLanguage("russian").
		        SetName("poisk")})

		cursor, _ := showcase.Find(ctx, bson.D{{Key: "$text", Value: bson.D{{Key: "$search", Value: "смартфоны"}}}},
		    options.Find().
		        SetProjection(bson.D{{Key: "_id", Value: 0}, {Key: "title", Value: 1}, {Key: "score", Value: bson.D{{Key: "$meta", Value: "textScore"}}}}).
		        SetSort(bson.D{{Key: "score", Value: bson.D{{Key: "$meta", Value: "textScore"}}}, {Key: "title", Value: 1}}))
		for cursor.Next(ctx) {
		    fmt.Printf("%.3f %s\n", cursor.Current.Lookup("score").Double(), cursor.Current.Lookup("title").StringValue())
		}

		_, err := showcase.Indexes().CreateOne(ctx, mongo.IndexModel{Keys: bson.D{{Key: "brand", Value: "text"}}})
		if errors.As(err, &ce) {
		    fmt.Println("второй текстовый индекс не создан, код", ce.Code)
		}
	}
}
