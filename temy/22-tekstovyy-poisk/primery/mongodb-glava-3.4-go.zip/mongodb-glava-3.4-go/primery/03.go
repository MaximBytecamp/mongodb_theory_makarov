//go:build ignore

// Глава 3.4 · Текстовый поиск: $text и $search
// Пример 3 из 6 · §3 Несколько слов, фраза, исключение · слова, фраза, исключение
//
// Запуск из папки архива:
//   docker compose run --rm go primery/03.go
//   cd primery, затем go run 03.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"
	"strings"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = strings.Join
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	products := db.Collection("products")
	orders := db.Collection("orders")
	events := client.Database("logs").Collection("events")
	sandbox := client.Database("sandbox")
	box := sandbox.Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, products, orders, events, sandbox, box

	showcase := sandbox.Collection("showcase") // копия товаров магазина: на ней строится текстовый индекс
	_ = showcase

	{
		// ── пример из главы ──────────────────────────────────────
		for _, search := range []string{"мышь клавиатура", "\"для ноутбука\"", "ноутбук -рюкзак", "ноут", "для"} {
		    cursor, _ := showcase.Find(ctx, bson.D{{Key: "$text", Value: bson.D{{Key: "$search", Value: search}}}},
		        options.Find().SetSort(bson.D{{Key: "title", Value: 1}}))
		    found := []string{}
		    for cursor.Next(ctx) {
		        found = append(found, cursor.Current.Lookup("title").StringValue())
		    }
		    line := strings.Join(found, ", ")
		    if line == "" {
		        line = "ничего"
		    }
		    fmt.Printf("%-16s → %s\n", search, line)
		}
	}
}
