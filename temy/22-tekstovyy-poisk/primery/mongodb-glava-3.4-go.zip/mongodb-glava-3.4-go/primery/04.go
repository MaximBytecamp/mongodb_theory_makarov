//go:build ignore

// Глава 3.4 · Текстовый поиск: $text и $search
// Пример 4 из 6 · §4 Оценка совпадения · оценка совпадения
//
// Запуск из папки архива:
//   docker compose run --rm go primery/04.go
//   cd primery, затем go run 04.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"
	"strings"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = strings.Join
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	products := db.Collection("products")
	orders := db.Collection("orders")
	events := client.Database("logs").Collection("events")
	sandbox := client.Database("sandbox")
	box := sandbox.Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, products, orders, events, sandbox, box

	showcase := sandbox.Collection("showcase") // копия товаров магазина: на ней строится текстовый индекс
	_ = showcase

	{
		// ── пример из главы ──────────────────────────────────────
		cursor, _ := showcase.Find(ctx, bson.D{{Key: "$text", Value: bson.D{{Key: "$search", Value: "apple ноутбук"}}}},
		    options.Find().
		        SetProjection(bson.D{{Key: "_id", Value: 0}, {Key: "title", Value: 1}, {Key: "score", Value: bson.D{{Key: "$meta", Value: "textScore"}}}}).
		        SetSort(bson.D{{Key: "score", Value: bson.D{{Key: "$meta", Value: "textScore"}}}, {Key: "title", Value: 1}}))
		for cursor.Next(ctx) {
		    fmt.Printf("%.3f %s\n", cursor.Current.Lookup("score").Double(), cursor.Current.Lookup("title").StringValue())
		}
	}
}
