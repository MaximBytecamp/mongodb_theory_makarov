# Глава 3.4 · Текстовый поиск: $text и $search
# Пример 6 из 6 · §6 Индекс по нескольким полям и веса · индекс по двум полям с весами
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/06.rb
#   cd primery, затем ruby 06.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
events = client.use("logs").database[:events]
sandbox = client.use("sandbox").database
box = sandbox[:products]   # песочница: здесь можно менять

showcase = sandbox[:showcase]     # копия товаров магазина: на ней строится текстовый индекс

# ── пример из главы ───────────────────────────────────────────
showcase.indexes.drop_one("title_text")
showcase.indexes.create_one({ "title" => "text", "category" => "text" },
                            weights: { "title" => 10, "category" => 1 }, default_language: "russian", name: "poisk")

showcase.find({ "$text" => { "$search" => "смартфоны" } },
              projection: { "_id" => 0, "title" => 1, "score" => { "$meta" => "textScore" } })
        .sort({ "score" => { "$meta" => "textScore" }, "title" => 1 })
        .each { |doc| puts format("%.3f", doc["score"]) + " " + doc["title"] }

begin
  showcase.indexes.create_one({ "brand" => "text" })
rescue Mongo::Error::OperationFailure => e
  puts "второй текстовый индекс не создан, код #{e.code}"
end
