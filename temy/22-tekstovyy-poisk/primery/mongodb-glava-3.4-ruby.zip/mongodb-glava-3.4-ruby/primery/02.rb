# Глава 3.4 · Текстовый поиск: $text и $search
# Пример 2 из 6 · §2 Текстовый индекс и $text · текстовый индекс и $text
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/02.rb
#   cd primery, затем ruby 02.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
events = client.use("logs").database[:events]
sandbox = client.use("sandbox").database
box = sandbox[:products]   # песочница: здесь можно менять

showcase = sandbox[:showcase]     # копия товаров магазина: на ней строится текстовый индекс

# ── пример из главы ───────────────────────────────────────────
showcase.indexes.create_one({ "title" => "text" }, default_language: "russian")
# ключ текстового индекса хранится как _fts, поэтому индекс ищется в списке по этому полю
puts "создан индекс: " + showcase.indexes.find { |ix| ix["key"].key?("_fts") }["name"]

showcase.find({ "$text" => { "$search" => "ноутбуки" } }, projection: { "_id" => 0, "title" => 1 })
        .sort({ "title" => 1 })
        .each { |doc| puts doc["title"] }
