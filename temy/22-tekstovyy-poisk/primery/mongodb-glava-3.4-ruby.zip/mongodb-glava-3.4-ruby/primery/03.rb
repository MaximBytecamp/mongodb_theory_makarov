# Глава 3.4 · Текстовый поиск: $text и $search
# Пример 3 из 6 · §3 Несколько слов, фраза, исключение · слова, фраза, исключение
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/03.rb
#   cd primery, затем ruby 03.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
events = client.use("logs").database[:events]
sandbox = client.use("sandbox").database
box = sandbox[:products]   # песочница: здесь можно менять

showcase = sandbox[:showcase]     # копия товаров магазина: на ней строится текстовый индекс

# ── пример из главы ───────────────────────────────────────────
["мышь клавиатура", '"для ноутбука"', "ноутбук -рюкзак", "ноут", "для"].each do |search|
  found = showcase.find({ "$text" => { "$search" => search } }).sort({ "title" => 1 }).map { |doc| doc["title"] }
  puts search.ljust(16) + " → " + (found.empty? ? "ничего" : found.join(", "))
end
