# Глава 3.4 · Текстовый поиск: $text и $search
# Пример 5 из 6 · §5 Язык индекса и язык запроса · язык индекса и язык запроса
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/05.rb
#   cd primery, затем ruby 05.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
events = client.use("logs").database[:events]
sandbox = client.use("sandbox").database
box = sandbox[:products]   # песочница: здесь можно менять

showcase = sandbox[:showcase]     # копия товаров магазина: на ней строится текстовый индекс

# ── пример из главы ───────────────────────────────────────────
[["ноутбуки", "russian"], ["ноутбуки", "none"], ["ноутбук", "none"], ["для", "none"]].each do |search, language|
  count = showcase.count_documents({ "$text" => { "$search" => search, "$language" => language } })
  puts "#{search} (#{language}): #{count}"
end
