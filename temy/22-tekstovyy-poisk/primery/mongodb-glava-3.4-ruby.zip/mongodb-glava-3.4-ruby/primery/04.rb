# Глава 3.4 · Текстовый поиск: $text и $search
# Пример 4 из 6 · §4 Оценка совпадения · оценка совпадения
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/04.rb
#   cd primery, затем ruby 04.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
events = client.use("logs").database[:events]
sandbox = client.use("sandbox").database
box = sandbox[:products]   # песочница: здесь можно менять

showcase = sandbox[:showcase]     # копия товаров магазина: на ней строится текстовый индекс

# ── пример из главы ───────────────────────────────────────────
showcase.find({ "$text" => { "$search" => "apple ноутбук" } },
              projection: { "_id" => 0, "title" => 1, "score" => { "$meta" => "textScore" } })
        .sort({ "score" => { "$meta" => "textScore" }, "title" => 1 })
        .each { |doc| puts format("%.3f", doc["score"]) + " " + doc["title"] }
