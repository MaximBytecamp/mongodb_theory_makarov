# Глава 3.4 · Текстовый поиск: $text и $search
# Пример 2 из 6 · §2 Текстовый индекс и $text · текстовый индекс и $text
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
events = client["logs"]["events"]
sandbox = client["sandbox"]
box = sandbox["products"]        # песочница: здесь можно менять

showcase = sandbox["showcase"]    # копия товаров магазина: на ней строится текстовый индекс

# ── пример из главы ───────────────────────────────────────────
name = showcase.create_index([("title", "text")], default_language="russian")
print("создан индекс:", name)

for doc in showcase.find({"$text": {"$search": "ноутбуки"}}, {"_id": 0, "title": 1}).sort("title", 1):
    print(doc["title"])
