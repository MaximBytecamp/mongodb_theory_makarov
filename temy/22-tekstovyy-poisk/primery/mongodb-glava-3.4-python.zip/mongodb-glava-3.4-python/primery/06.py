# Глава 3.4 · Текстовый поиск: $text и $search
# Пример 6 из 6 · §6 Индекс по нескольким полям и веса · индекс по двум полям с весами
#
# Запуск из папки архива:
#   docker compose run --rm python primery/06.py
#   cd primery, затем python 06.py (Windows) или python3 06.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
events = client["logs"]["events"]
sandbox = client["sandbox"]
box = sandbox["products"]        # песочница: здесь можно менять

showcase = sandbox["showcase"]    # копия товаров магазина: на ней строится текстовый индекс

# ── пример из главы ───────────────────────────────────────────
from pymongo.errors import OperationFailure

showcase.drop_index("title_text")
showcase.create_index([("title", "text"), ("category", "text")],
                      weights={"title": 10, "category": 1}, default_language="russian", name="poisk")

cursor = showcase.find({"$text": {"$search": "смартфоны"}},
                       {"_id": 0, "title": 1, "score": {"$meta": "textScore"}})
for doc in cursor.sort([("score", {"$meta": "textScore"}), ("title", 1)]):
    print(f"{doc['score']:.3f}", doc["title"])

try:
    showcase.create_index([("brand", "text")])
except OperationFailure as e:
    print("второй текстовый индекс не создан, код", e.code)
