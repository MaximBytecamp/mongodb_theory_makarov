# Глава 3.4 · Текстовый поиск: $text и $search
# Пример 4 из 6 · §4 Оценка совпадения · оценка совпадения
#
# Запуск из папки архива:
#   docker compose run --rm python primery/04.py
#   cd primery, затем python 04.py (Windows) или python3 04.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
events = client["logs"]["events"]
sandbox = client["sandbox"]
box = sandbox["products"]        # песочница: здесь можно менять

showcase = sandbox["showcase"]    # копия товаров магазина: на ней строится текстовый индекс

# ── пример из главы ───────────────────────────────────────────
cursor = showcase.find({"$text": {"$search": "apple ноутбук"}},
                       {"_id": 0, "title": 1, "score": {"$meta": "textScore"}})
for doc in cursor.sort([("score", {"$meta": "textScore"}), ("title", 1)]):
    print(f"{doc['score']:.3f}", doc["title"])
