# Глава 3.4 · Текстовый поиск: $text и $search
# Пример 1 из 6 · §1 Поиск слова шаблоном · поиск слова шаблоном
#
# Запуск из папки архива:
#   docker compose run --rm python primery/01.py
#   cd primery, затем python 01.py (Windows) или python3 01.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
events = client["logs"]["events"]
sandbox = client["sandbox"]
box = sandbox["products"]        # песочница: здесь можно менять

showcase = sandbox["showcase"]    # копия товаров магазина: на ней строится текстовый индекс

# ── пример из главы ───────────────────────────────────────────
showcase.drop()
showcase.insert_many(products.find())
print("товаров в копии:", showcase.count_documents({}))

print("ноутбук:         ", showcase.count_documents({"title": {"$regex": "ноутбук"}}))
print("ноутбук, без регистра:", showcase.count_documents({"title": {"$regex": "ноутбук", "$options": "i"}}))
print("ноутбуки, без регистра:", showcase.count_documents({"title": {"$regex": "ноутбуки", "$options": "i"}}))
