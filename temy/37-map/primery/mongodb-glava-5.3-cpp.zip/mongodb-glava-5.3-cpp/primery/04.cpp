// Глава 5.3 · $map: преобразование каждого элемента
// Пример 4 из 7 · §4 $max, $min и $avg над массивом · $max, $min и $avg над массивом
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/04.cpp
//   cd primery, затем g++ -std=c++17 04.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto orders = db["orders"];
    auto products = db["products"];
    auto customers = db["customers"];
    auto sandbox = client["sandbox"];

    {
        // ── пример из главы ──────────────────────────────────────
        mongocxx::pipeline pipeline;
        pipeline.match(make_document(
            kvp("_id", make_document(
                kvp("$in", make_array("o-0001", "o-0002", "o-0003", "o-0004", "o-0005"))))));
        pipeline.project(make_document(
            kvp("_id", 0),
            kvp("number", 1),
            kvp("max_line", make_document(
                kvp("$max", make_document(
                    kvp("$map", make_document(
                        kvp("input", "$items"),
                        kvp("in", make_document(kvp("$multiply", make_array("$$this.qty", "$$this.price")))))))))),
            kvp("min_line", make_document(
                kvp("$min", make_document(
                    kvp("$map", make_document(
                        kvp("input", "$items"),
                        kvp("in", make_document(kvp("$multiply", make_array("$$this.qty", "$$this.price")))))))))),
            kvp("avg_price", make_document(kvp("$avg", "$items.price")))));

        for (auto&& doc : orders.aggregate(pipeline)) {
            std::cout << bsoncxx::to_json(doc, bsoncxx::ExtendedJsonMode::k_relaxed) << std::endl;
        }
    }
}
