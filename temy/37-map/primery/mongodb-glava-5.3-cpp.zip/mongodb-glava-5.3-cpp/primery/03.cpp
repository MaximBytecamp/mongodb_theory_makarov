// Глава 5.3 · $map: преобразование каждого элемента
// Пример 3 из 7 · §3 Новый документ из элемента · $map с as: позиции из двух полей
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/03.cpp
//   cd primery, затем g++ -std=c++17 03.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto orders = db["orders"];
    auto products = db["products"];
    auto customers = db["customers"];
    auto sandbox = client["sandbox"];

    {
        // ── пример из главы ──────────────────────────────────────
        mongocxx::pipeline pipeline;
        pipeline.match(make_document(kvp("_id", "o-0002")));
        pipeline.project(make_document(
            kvp("_id", 0),
            kvp("number", 1),
            kvp("lines", make_document(
                kvp("$map", make_document(
                    kvp("input", "$items"),
                    kvp("as", "line"),
                    kvp("in", make_document(
                        kvp("title", "$$line.title"),
                        kvp("sum", make_document(kvp("$multiply", make_array("$$line.qty", "$$line.price"))))))))))));

        for (auto&& doc : orders.aggregate(pipeline)) {
            std::cout << bsoncxx::to_json(doc, bsoncxx::ExtendedJsonMode::k_relaxed) << std::endl;
        }
    }
}
