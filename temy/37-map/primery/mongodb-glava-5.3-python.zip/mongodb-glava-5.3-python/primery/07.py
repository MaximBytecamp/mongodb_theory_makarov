# Глава 5.3 · $map: преобразование каждого элемента
# Пример 7 из 7 · §7 Записи, которые сервер не принимает · записи $map, которые сервер не принимает
#
# Запуск из папки архива:
#   docker compose run --rm python primery/07.py
#   cd primery, затем python 07.py (Windows) или python3 07.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
from pymongo.errors import OperationFailure

no_in = [
    {"$match": {"_id": "o-0002"}},
    {"$project": {"x": {"$map": {"input": "$items"}}}},
]

string_input = [
    {"$match": {"_id": "o-0002"}},
    {"$project": {"x": {"$map": {"input": "$promo", "in": "$$this"}}}},
]

print("── нет in")
try:
    for doc in orders.aggregate(no_in):
        print(doc)
except OperationFailure as e:
    print("код", e.code)
    print(e.details["errmsg"])

print("── input — строка")
try:
    for doc in orders.aggregate(string_input):
        print(doc)
except OperationFailure as e:
    print("код", e.code)
    print(e.details["errmsg"])
