# Глава 5.3 · $map: преобразование каждого элемента
# Пример 2 из 7 · §2 Сходится ли total с позициями · сходится ли total с позициями
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$project": {"matches": {"$eq": [
        "$total",
        {"$sum": {"$map": {
            "input": "$items",
            "in": {"$multiply": ["$$this.qty", "$$this.price"]},
        }}},
    ]}}},
    {"$group": {"_id": "$matches", "orders": {"$sum": 1}}},
]

for doc in orders.aggregate(pipeline):
    print(doc)
