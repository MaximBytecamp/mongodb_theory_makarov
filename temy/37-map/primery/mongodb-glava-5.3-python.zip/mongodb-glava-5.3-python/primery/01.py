# Глава 5.3 · $map: преобразование каждого элемента
# Пример 1 из 7 · §1 Выражение $map · $map: сумма каждой позиции
#
# Запуск из папки архива:
#   docker compose run --rm python primery/01.py
#   cd primery, затем python 01.py (Windows) или python3 01.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": "o-0002"}},
    {"$project": {
        "_id": 0,
        "number": 1,
        "total": 1,
        "sums": {"$map": {
            "input": "$items",
            "in": {"$multiply": ["$$this.qty", "$$this.price"]},
        }},
        "sum_of": {"$sum": {"$map": {
            "input": "$items",
            "in": {"$multiply": ["$$this.qty", "$$this.price"]},
        }}},
    }},
]

for doc in orders.aggregate(pipeline):
    print(doc)
