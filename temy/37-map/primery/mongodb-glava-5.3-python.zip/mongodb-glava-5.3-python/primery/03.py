# Глава 5.3 · $map: преобразование каждого элемента
# Пример 3 из 7 · §3 Новый документ из элемента · $map с as: позиции из двух полей
#
# Запуск из папки архива:
#   docker compose run --rm python primery/03.py
#   cd primery, затем python 03.py (Windows) или python3 03.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": "o-0002"}},
    {"$project": {
        "_id": 0,
        "number": 1,
        "lines": {"$map": {
            "input": "$items",
            "as": "line",
            "in": {
                "title": "$$line.title",
                "sum": {"$multiply": ["$$line.qty", "$$line.price"]},
            },
        }},
    }},
]

for doc in orders.aggregate(pipeline):
    print(doc)
