# Глава 5.3 · $map: преобразование каждого элемента
# Пример 4 из 7 · §4 $max, $min и $avg над массивом · $max, $min и $avg над массивом
#
# Запуск из папки архива:
#   docker compose run --rm python primery/04.py
#   cd primery, затем python 04.py (Windows) или python3 04.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": {"$in": ["o-0001", "o-0002", "o-0003", "o-0004", "o-0005"]}}},
    {"$project": {
        "_id": 0,
        "number": 1,
        "max_line": {"$max": {"$map": {
            "input": "$items",
            "in": {"$multiply": ["$$this.qty", "$$this.price"]},
        }}},
        "min_line": {"$min": {"$map": {
            "input": "$items",
            "in": {"$multiply": ["$$this.qty", "$$this.price"]},
        }}},
        "avg_price": {"$avg": "$items.price"},
    }},
]

for doc in orders.aggregate(pipeline):
    print(doc)
