# Глава 5.3 · $map: преобразование каждого элемента
# Пример 5 из 7 · §5 Строки из элементов · склады строками
#
# Запуск из папки архива:
#   docker compose run --rm python primery/05.py
#   cd primery, затем python 05.py (Windows) или python3 05.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"category": "комплектующие"}},
    {"$project": {
        "_id": 0,
        "title": 1,
        "where": {"$map": {
            "input": "$stock",
            "in": {"$concat": ["$$this.warehouse", ": ", {"$toString": "$$this.qty"}]},
        }},
    }},
]

for doc in products.aggregate(pipeline):
    print(doc)
