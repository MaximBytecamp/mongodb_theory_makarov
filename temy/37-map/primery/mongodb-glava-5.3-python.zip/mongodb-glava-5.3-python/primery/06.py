# Глава 5.3 · $map: преобразование каждого элемента
# Пример 6 из 7 · §6 Сначала $filter, потом $map · $map над результатом $filter
#
# Запуск из папки архива:
#   docker compose run --rm python primery/06.py
#   cd primery, затем python 06.py (Windows) или python3 06.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": "o-0004"}},
    {"$project": {
        "_id": 0,
        "number": 1,
        "periphery": {"$map": {
            "input": {"$filter": {
                "input": "$items",
                "cond": {"$eq": ["$$this.category", "периферия"]},
            }},
            "in": {"$concat": ["$$this.title", " × ", {"$toString": "$$this.qty"}]},
        }},
    }},
]

for doc in orders.aggregate(pipeline):
    print(doc)
