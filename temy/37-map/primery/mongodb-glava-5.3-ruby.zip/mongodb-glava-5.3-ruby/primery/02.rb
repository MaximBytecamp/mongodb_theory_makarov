# Глава 5.3 · $map: преобразование каждого элемента
# Пример 2 из 7 · §2 Сходится ли total с позициями · сходится ли total с позициями
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/02.rb
#   cd primery, затем ruby 02.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$project" => { "matches" => { "$eq" => [
    "$total",
    { "$sum" => { "$map" => {
      "input" => "$items",
      "in" => { "$multiply" => ["$$this.qty", "$$this.price"] },
    } } },
  ] } } },
  { "$group" => { "_id" => "$matches", "orders" => { "$sum" => 1 } } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
