# Глава 5.3 · $map: преобразование каждого элемента
# Пример 6 из 7 · §6 Сначала $filter, потом $map · $map над результатом $filter
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/06.rb
#   cd primery, затем ruby 06.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => "o-0004" } },
  { "$project" => {
    "_id" => 0,
    "number" => 1,
    "periphery" => { "$map" => {
      "input" => { "$filter" => {
        "input" => "$items",
        "cond" => { "$eq" => ["$$this.category", "периферия"] },
      } },
      "in" => { "$concat" => ["$$this.title", " × ", { "$toString" => "$$this.qty" }] },
    } },
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
