# Глава 5.3 · $map: преобразование каждого элемента
# Пример 3 из 7 · §3 Новый документ из элемента · $map с as: позиции из двух полей
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/03.rb
#   cd primery, затем ruby 03.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => "o-0002" } },
  { "$project" => {
    "_id" => 0,
    "number" => 1,
    "lines" => { "$map" => {
      "input" => "$items",
      "as" => "line",
      "in" => {
        "title" => "$$line.title",
        "sum" => { "$multiply" => ["$$line.qty", "$$line.price"] },
      },
    } },
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
