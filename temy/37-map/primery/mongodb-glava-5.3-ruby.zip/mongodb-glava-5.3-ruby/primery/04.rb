# Глава 5.3 · $map: преобразование каждого элемента
# Пример 4 из 7 · §4 $max, $min и $avg над массивом · $max, $min и $avg над массивом
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/04.rb
#   cd primery, затем ruby 04.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => { "$in" => ["o-0001", "o-0002", "o-0003", "o-0004", "o-0005"] } } },
  { "$project" => {
    "_id" => 0,
    "number" => 1,
    "max_line" => { "$max" => { "$map" => {
      "input" => "$items",
      "in" => { "$multiply" => ["$$this.qty", "$$this.price"] },
    } } },
    "min_line" => { "$min" => { "$map" => {
      "input" => "$items",
      "in" => { "$multiply" => ["$$this.qty", "$$this.price"] },
    } } },
    "avg_price" => { "$avg" => "$items.price" },
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
