# Глава 5.3 · $map: преобразование каждого элемента
# Пример 1 из 7 · §1 Выражение $map · $map: сумма каждой позиции
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/01.rb
#   cd primery, затем ruby 01.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => "o-0002" } },
  { "$project" => {
    "_id" => 0,
    "number" => 1,
    "total" => 1,
    "sums" => { "$map" => {
      "input" => "$items",
      "in" => { "$multiply" => ["$$this.qty", "$$this.price"] },
    } },
    "sum_of" => { "$sum" => { "$map" => {
      "input" => "$items",
      "in" => { "$multiply" => ["$$this.qty", "$$this.price"] },
    } } },
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
