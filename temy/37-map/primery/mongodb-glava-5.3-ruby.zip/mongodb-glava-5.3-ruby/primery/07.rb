# Глава 5.3 · $map: преобразование каждого элемента
# Пример 7 из 7 · §7 Записи, которые сервер не принимает · записи $map, которые сервер не принимает
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/07.rb
#   cd primery, затем ruby 07.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
no_in = [
  { "$match" => { "_id" => "o-0002" } },
  { "$project" => { "x" => { "$map" => { "input" => "$items" } } } },
]

string_input = [
  { "$match" => { "_id" => "o-0002" } },
  { "$project" => { "x" => { "$map" => { "input" => "$promo", "in" => "$$this" } } } },
]

puts "── нет in"
begin
  orders.aggregate(no_in).each { |doc| puts doc.inspect }
rescue Mongo::Error::OperationFailure => e
  puts "код #{e.code}"
  puts e.document["errmsg"]
end

puts "── input — строка"
begin
  orders.aggregate(string_input).each { |doc| puts doc.inspect }
rescue Mongo::Error::OperationFailure => e
  puts "код #{e.code}"
  puts e.document["errmsg"]
end
