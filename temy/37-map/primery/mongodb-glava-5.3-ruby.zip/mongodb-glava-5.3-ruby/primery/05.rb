# Глава 5.3 · $map: преобразование каждого элемента
# Пример 5 из 7 · §5 Строки из элементов · склады строками
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/05.rb
#   cd primery, затем ruby 05.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "category" => "комплектующие" } },
  { "$project" => {
    "_id" => 0,
    "title" => 1,
    "where" => { "$map" => {
      "input" => "$stock",
      "in" => { "$concat" => ["$$this.warehouse", ": ", { "$toString" => "$$this.qty" }] },
    } },
  } },
]

products.aggregate(pipeline).each { |doc| puts doc.inspect }
