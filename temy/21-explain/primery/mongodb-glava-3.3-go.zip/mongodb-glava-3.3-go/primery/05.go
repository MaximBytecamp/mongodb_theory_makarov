//go:build ignore

// Глава 3.3 · Как читать explain: COLLSCAN против IXSCAN
// Пример 5 из 6 · §5 Сортировка в памяти · сортировка в памяти и по индексу
//
// Запуск из папки архива:
//   docker compose run --rm go primery/05.go
//   cd primery, затем go run 05.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"strings"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = fmt.Sprint
var _ = strings.Join
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────

// summary — план и счётчики explain одной строкой: стадии | вернул | ключей | документов.
func summary(coll *mongo.Collection, find bson.D) string {
	cmd := append(bson.D{{Key: "find", Value: coll.Name()}}, find...)
	var res bson.Raw
	coll.Database().RunCommand(context.Background(),
		bson.D{{Key: "explain", Value: cmd}, {Key: "verbosity", Value: "executionStats"}}).Decode(&res)
	stage := res.Lookup("queryPlanner", "winningPlan").Document()
	if inner, ok := stage.Lookup("queryPlan").DocumentOK(); ok { // MongoDB 7 кладёт план во вложенное поле
		stage = inner
	}
	steps := []string{}
	for {
		step := stage.Lookup("stage").StringValue()
		if name, ok := stage.Lookup("indexName").StringValueOK(); ok {
			step += " " + name
		}
		steps = append(steps, step)
		next, ok := stage.Lookup("inputStage").DocumentOK()
		if !ok {
			break
		}
		stage = next
	}
	stats := res.Lookup("executionStats").Document()
	return fmt.Sprintf("%s | вернул %d | ключей %d | документов %d", strings.Join(steps, " → "),
		stats.Lookup("nReturned").AsInt64(), stats.Lookup("totalKeysExamined").AsInt64(),
		stats.Lookup("totalDocsExamined").AsInt64())
}


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	products := db.Collection("products")
	orders := db.Collection("orders")
	events := client.Database("logs").Collection("events")
	sandbox := client.Database("sandbox")
	box := sandbox.Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, products, orders, events, sandbox, box

	journal := sandbox.Collection("events") // копия журнала: на ней строятся индексы главы
	_ = journal

	{
		// ── пример из главы ──────────────────────────────────────
		journal.Indexes().DropOne(ctx, "service_1")
		last := bson.D{
		    {Key: "filter", Value: bson.D{{Key: "service", Value: "payments"}}},
		    {Key: "sort", Value: bson.D{{Key: "ts", Value: -1}}},
		    {Key: "limit", Value: 10}}
		fmt.Println("до индекса по ts:   ", summary(journal, last))

		name, _ := journal.Indexes().CreateOne(ctx, mongo.IndexModel{Keys: bson.D{{Key: "service", Value: 1}, {Key: "ts", Value: -1}}})
		fmt.Println("создан индекс:", name)
		fmt.Println("после индекса по ts:", summary(journal, last))
	}
}
