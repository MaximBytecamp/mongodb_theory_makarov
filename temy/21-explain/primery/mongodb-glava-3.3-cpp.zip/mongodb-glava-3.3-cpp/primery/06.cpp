// Глава 3.3 · Как читать explain: COLLSCAN против IXSCAN
// Пример 6 из 6 · §6 Порядок полей в индексе: равенство, сортировка, диапазон · порядок полей: равенство, сортировка, диапазон
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/06.cpp
//   cd primery, затем g++ -std=c++17 06.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────

// summary — план и счётчики explain одной строкой: стадии | вернул | ключей | документов.
std::string summary(mongocxx::database& db, const std::string& coll, bsoncxx::document::view find) {
    bsoncxx::builder::basic::document cmd;
    cmd.append(kvp("find", coll));
    for (auto&& field : find) cmd.append(kvp(field.key(), field.get_value()));
    auto res = db.run_command(make_document(kvp("explain", cmd.view()), kvp("verbosity", "executionStats")));
    auto stage = res.view()["queryPlanner"]["winningPlan"].get_document().value;
    if (stage["queryPlan"]) stage = stage["queryPlan"].get_document().value;   // MongoDB 7 кладёт план во вложенное поле
    std::string steps;
    while (true) {
        steps += std::string{stage["stage"].get_string().value};
        if (stage["indexName"]) steps += " " + std::string{stage["indexName"].get_string().value};
        if (!stage["inputStage"]) break;
        steps += " → ";
        stage = stage["inputStage"].get_document().value;
    }
    auto stats = res.view()["executionStats"].get_document().value;
    auto number = [&](const char* name) {
        auto value = stats[name];
        return std::to_string(value.type() == bsoncxx::type::k_int64 ? value.get_int64().value : value.get_int32().value);
    };
    return steps + " | вернул " + number("nReturned") + " | ключей " + number("totalKeysExamined")
         + " | документов " + number("totalDocsExamined");
}


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto products = db["products"];
    auto orders = db["orders"];
    auto events = client["logs"]["events"];
    auto sandbox = client["sandbox"];
    auto box = sandbox["products"];   // песочница: здесь можно менять

    auto journal = sandbox["events"];      // копия журнала: на ней строятся индексы главы

    {
        // ── пример из главы ──────────────────────────────────────
        journal.create_index(make_document(kvp("service", 1), kvp("ts", -1), kvp("status", 1)));

        for (std::string name : {"service_1_status_1", "service_1_ts_-1", "service_1_ts_-1_status_1"}) {
            auto find = make_document(
                kvp("filter", make_document(kvp("service", "payments"), kvp("status", make_document(kvp("$gte", 500))))),
                kvp("sort", make_document(kvp("ts", -1))),
                kvp("limit", 5),
                kvp("hint", name));
            std::cout << name << std::string(25 - name.size(), ' ') << summary(sandbox, "events", find.view()) << std::endl;
        }
    }
}
