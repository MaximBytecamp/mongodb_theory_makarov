# Глава 3.3 · Как читать explain: COLLSCAN против IXSCAN
# Пример 2 из 6 · §2 queryPlanner: какой план выбран · выбранный и отклонённый планы
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
events = client["logs"]["events"]
sandbox = client["sandbox"]
box = sandbox["products"]        # песочница: здесь можно менять

journal = sandbox["events"]       # копия журнала: на ней строятся индексы главы


def summary(coll, **find):
    """План и счётчики explain одной строкой: стадии | вернул | ключей | документов."""
    info = coll.database.command("explain", {"find": coll.name, **find}, verbosity="executionStats")
    stage = info["queryPlanner"]["winningPlan"]
    stage = stage.get("queryPlan", stage)     # MongoDB 7 кладёт план во вложенное поле
    steps = []
    while stage:
        steps.append(stage["stage"] + (" " + stage["indexName"] if "indexName" in stage else ""))
        stage = stage.get("inputStage")
    stats = info["executionStats"]
    return (" → ".join(steps) + f" | вернул {stats['nReturned']}"
            + f" | ключей {stats['totalKeysExamined']} | документов {stats['totalDocsExamined']}")

# ── пример из главы ───────────────────────────────────────────
journal.create_index("service")
journal.create_index([("service", 1), ("status", 1)])

filtr = {"service": "payments", "status": {"$gte": 500}}
print("выбран:", summary(journal, filter=filtr))

info = journal.find(filtr).explain()
for rejected in info["queryPlanner"]["rejectedPlans"]:
    stage = rejected.get("queryPlan", rejected)
    while "inputStage" in stage:
        stage = stage["inputStage"]
    print("отклонён план по индексу", stage["indexName"])
