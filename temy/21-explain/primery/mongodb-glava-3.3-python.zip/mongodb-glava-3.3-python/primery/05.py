# Глава 3.3 · Как читать explain: COLLSCAN против IXSCAN
# Пример 5 из 6 · §5 Сортировка в памяти · сортировка в памяти и по индексу
#
# Запуск из папки архива:
#   docker compose run --rm python primery/05.py
#   cd primery, затем python 05.py (Windows) или python3 05.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
events = client["logs"]["events"]
sandbox = client["sandbox"]
box = sandbox["products"]        # песочница: здесь можно менять

journal = sandbox["events"]       # копия журнала: на ней строятся индексы главы


def summary(coll, **find):
    """План и счётчики explain одной строкой: стадии | вернул | ключей | документов."""
    info = coll.database.command("explain", {"find": coll.name, **find}, verbosity="executionStats")
    stage = info["queryPlanner"]["winningPlan"]
    stage = stage.get("queryPlan", stage)     # MongoDB 7 кладёт план во вложенное поле
    steps = []
    while stage:
        steps.append(stage["stage"] + (" " + stage["indexName"] if "indexName" in stage else ""))
        stage = stage.get("inputStage")
    stats = info["executionStats"]
    return (" → ".join(steps) + f" | вернул {stats['nReturned']}"
            + f" | ключей {stats['totalKeysExamined']} | документов {stats['totalDocsExamined']}")

# ── пример из главы ───────────────────────────────────────────
journal.drop_index("service_1")
last = {"filter": {"service": "payments"}, "sort": {"ts": -1}, "limit": 10}
print("до индекса по ts:   ", summary(journal, **last))

print("создан индекс:", journal.create_index([("service", 1), ("ts", -1)]))
print("после индекса по ts:", summary(journal, **last))
