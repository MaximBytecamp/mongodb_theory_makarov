# Глава 3.3 · Как читать explain: COLLSCAN против IXSCAN
# Пример 5 из 6 · §5 Сортировка в памяти · сортировка в памяти и по индексу
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/05.rb
#   cd primery, затем ruby 05.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
events = client.use("logs").database[:events]
sandbox = client.use("sandbox").database
box = sandbox[:products]   # песочница: здесь можно менять

journal = sandbox[:events]        # копия журнала: на ней строятся индексы главы

# План и счётчики explain одной строкой: стадии | вернул | ключей | документов.
def summary(coll, find)
  info = coll.database.command(explain: { find: coll.name }.merge(find), verbosity: "executionStats").first
  stage = info["queryPlanner"]["winningPlan"]
  stage = stage["queryPlan"] || stage     # MongoDB 7 кладёт план во вложенное поле
  steps = []
  while stage
    steps << stage["stage"] + (stage["indexName"] ? " " + stage["indexName"] : "")
    stage = stage["inputStage"]
  end
  stats = info["executionStats"]
  steps.join(" → ") + " | вернул #{stats["nReturned"]}" +
    " | ключей #{stats["totalKeysExamined"]} | документов #{stats["totalDocsExamined"]}"
end

# ── пример из главы ───────────────────────────────────────────
journal.indexes.drop_one("service_1")
last = { filter: { "service" => "payments" }, sort: { "ts" => -1 }, limit: 10 }
puts "до индекса по ts:    " + summary(journal, last)

journal.indexes.create_one({ "service" => 1, "ts" => -1 })
puts "создан индекс: " + journal.indexes.get({ "service" => 1, "ts" => -1 })["name"]
puts "после индекса по ts: " + summary(journal, last)
