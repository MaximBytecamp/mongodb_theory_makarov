# Глава 1.6 · Порядок и порции: sort, limit, skip — примеры на Go

Архив к «Справочнику по MongoDB»: все примеры главы готовыми программами, учебные базы и стенд в Docker.
Глава: https://maximbytecamp.github.io/mongodb_theory_makarov/temy/06-sort-limit-skip/index.html

Язык: **Go** · драйвер mongo-driver v2 · сервер MongoDB 7.

## Что в архиве

```text
mongodb-glava-1.6-go/
  README.md         эта инструкция
  primery/          примеры главы — по программе на пример
    01.go … 07.go
    go.mod, go.sum  модуль Go: версия драйвера
  compose.yaml      стенд в Docker: сервер, базы, mongo-express, Go
  docker/           образ с драйвером Go и скрипт запуска run.sh
  stend/seed/       учебные данные: 12 файлов JSON
  stend/load.ps1    загрузка данных на установленный сервер — Windows
  stend/load.sh     то же — macOS и Linux
```

## Порядок работы

1. **Базы.** Глава **только читает** данные — сбрасывать базы не нужно.
2. **Примеры — по порядку, каждый один раз.** Пример в главе рассчитан на данные, которые оставил
   предыдущий. Если запустить пример дважды или пропустить, числа разойдутся с книгой — тогда
   сбросьте базы и начните с `01.go`.
3. **Сверка.** Что должна напечатать каждая программа — в разделе «Примеры и выводы» ниже.
   Отличаться могут только `_id`, которые выдаёт сервер, текущие дата и время и порядок
   в списке коллекций: сервер отдаёт их имена в произвольном порядке. У документа, который
   создан обновлением с `upsert`, поля тоже могут идти в другом порядке — значения при этом те же.

Подойдёт любой из двух способов. Адрес сервера в обоих — `mongodb://localhost:27017`, код примеров
одинаковый.

| Способ | Что нужно | Когда подходит |
|---|---|---|
| **1. Docker** | Docker Desktop | Compass и сервер не установились или не подключаются; ничего, кроме Docker, ставить не нужно |
| **2. Сервер и Compass** | MongoDB Server, Compass, Go с драйвером | сервер и Compass уже стоят и подключаются |

## Способ 1. Docker

Docker Desktop — с [docker.com](https://www.docker.com/products/docker-desktop/); на Linux — Docker Engine.
Перед командами Docker Desktop должен быть запущен. Команды одинаковые в PowerShell, cmd и терминале
macOS/Linux; выполняйте их **из папки архива** — там, где лежит `compose.yaml`.

1. Поднять сервер и загрузить учебные базы:

   ```bash
   docker compose up -d
   ```

2. Запустить пример — путь к файлу пишется от папки архива:

   ```bash
   docker compose run --rm go primery/01.go
   ```

   При первом запуске Docker соберёт образ с драйвером Go — это пара минут.
   Дальше запуск идёт за секунды.

3. Все примеры главы подряд, по порядку, одной командой:

   ```bash
   docker compose run --rm go primery
   ```

   Перед каждой программой печатается её имя: `── primery/01.go ──`.

**Смотреть данные.** Compass не нужен: в браузере откройте http://localhost:8081, логин `student`,
пароль `student` — это mongo-express, в нём видны базы, коллекции и документы. Если Compass
установлен, он подключается к этому же серверу по адресу `mongodb://localhost:27017`.

**Консоль сервера:** `docker compose exec mongo mongosh`.

**Остановить и удалить:**

```bash
docker compose stop        # остановить; данные останутся
docker compose down        # удалить контейнеры; данные останутся
docker compose down -v     # удалить всё вместе с данными
```

Архивы всех глав пользуются одним и тем же сервером и данными: после этой главы можно распаковать
архив следующей и работать там, не удаляя стенд.

## Способ 2. Установленный сервер MongoDB и Compass

Нужны MongoDB Server 7 или 8 и MongoDB Compass — установка по шагам в
[главе 1.0а](https://maximbytecamp.github.io/mongodb_theory_makarov/temy/00a-windows-10-mongodb-7/index.html).
Проверка: Compass подключается к `mongodb://localhost:27017`.

### Шаг 1. Загрузить учебные базы

Windows, PowerShell, из папки архива — нужен `mongoimport` из MongoDB Command Line Database Tools:

```powershell
powershell -ExecutionPolicy Bypass -File stend\load.ps1
```

macOS и Linux (`mongoimport`: `brew tap mongodb/brew && brew install mongodb-database-tools`):

```bash
bash stend/load.sh
```

Скрипт пересоздаёт коллекции целиком, поэтому он же сбрасывает базы: повторный запуск ничего не двоит.

**Без `mongoimport` — через Compass.** Подключитесь к `mongodb://localhost:27017`, нажмите **Create database**,
затем в коллекции **Add data → Import JSON or CSV file** и выберите файл из `stend/seed`. Имя файла
подсказывает, куда класть: `shop.orders.json` — база `shop`, коллекция `orders`. Так загружаются все
12 файлов; пошагово с кадрами — [глава 1.0, §7](https://maximbytecamp.github.io/mongodb_theory_makarov/temy/00-uchebnye-bazy/index.html#s7).

После загрузки в Compass нажмите **Refresh**: в списке должны быть базы `shop`, `hh`, `logs`, `org`
и `sandbox`. В `shop.products` — 21 документ, в `shop.orders` — 120.

### Шаг 2. Драйвер Go и запуск

Go 1.25 или новее — с [go.dev/dl](https://go.dev/dl/). Отдельно драйвер ставить не нужно:
в папке `primery` лежит `go.mod`, и Go скачает драйвер сам при первом запуске.

Команды одинаковые во всех системах:

```bash
cd primery
go mod download
go run 01.go
```

Каждый файл — отдельная программа со своей функцией `main`, поэтому запускается по имени файла: `go run 01.go`.
Команда `go run .` здесь не подходит. Первая строка файлов `//go:build ignore` нужна, чтобы редактор
не считал все файлы одной программой, — запуску она не мешает.

Остальные примеры запускаются так же: `02.go`, `03.go` и далее. Если сервер слушает другой адрес,
задайте его переменной `MONGO_URI` — программы глав 1.2–1.8 читают её при подключении.

## Примеры и выводы

| Файл | Параграф главы | Что делает |
|---|---|---|
| `01.go` | §1 sort: порядок задаётся явно | пять самых дорогих товаров |
| `02.go` | §2 Сортировка по нескольким полям | по категории, внутри — по цене |
| `03.go` | §3 limit: сколько вернуть | три самых свежих события |
| `04.go` | §4 skip: постраничный вывод | вторая страница по пять |
| `05.go` | §6 Чем плох skip на больших данных | Go |
| `06.go` | §6 Чем плох skip на больших данных | Go |
| `07.go` | §7 count_documents: сколько всего | счёт по фильтру |

### 01.go · §1 sort: порядок задаётся явно

Пять самых дорогих товаров.

```text
  114990  Ноутбук Apple MacBook Air 13
   89990  Ноутбук Acer Nitro V15
   79990  Смартфон Apple iPhone 15
   67900  Ноутбук HP Pavilion 14
   51490  Ноутбук ASUS VivoBook 15
```

### 02.go · §2 Сортировка по нескольким полям

По категории, внутри — по цене.
Вывода нет.

### 03.go · §3 limit: сколько вернуть

Три самых свежих события.

```text
{"ts":{"$date":{"$numberLong":"1788372934000"}},"service":"search","status":{"$numberInt":"503"}}
{"ts":{"$date":{"$numberLong":"1788372802000"}},"service":"payments","status":{"$numberInt":"500"}}
{"ts":{"$date":{"$numberLong":"1788372701000"}},"service":"search","status":{"$numberInt":"503"}}
```

### 04.go · §4 skip: постраничный вывод

Вторая страница по пять.

```text
Кабель USB-C 2 м
Клавиатура Keychron K2
Монитор Dell P2422H
Мышь Logitech MX Master 3S
Наушники Sony WH-1000XM5
```

### 05.go · §6 Чем плох skip на больших данных

Go.
Вывода нет.

### 06.go · §6 Чем плох skip на больших данных

Go.
Вывода нет.

### 07.go · §7 count_documents: сколько всего

Счёт по фильтру.

```text
всего товаров: 21
ноутбуков: 5
заказов: 120
доставленных: 69
```

## Частые ошибки

| Что видно | Причина | Что сделать |
|---|---|---|
| `port is already allocated`, `address already in use` на `docker compose up -d` | порт 27017 занят: уже работает установленный MongoDB или стенд `mongodb-practice` | остановите тот сервер или создайте рядом с `compose.yaml` файл `.env` со строкой `MONGO_PORT=27018`: в PowerShell — `Set-Content .env "MONGO_PORT=27018"`, в bash — `echo "MONGO_PORT=27018" > .env`. Программы в Docker это не затрагивает, Compass подключайте к `localhost:27018` |
| `Cannot connect to the Docker daemon`, `error during connect` | Docker Desktop не запущен | запустите Docker Desktop и дождитесь зелёного статуса Engine running |
| `ServerSelectionTimeoutError`, `Connection refused`, `No server available` | сервер не запущен | Docker: `docker compose up -d`; способ 2 — запустите службу MongoDB |
| `Файл не найден: …` | путь написан не от папки архива или команда выполнена в другой папке | перейдите в папку, где лежит `compose.yaml`, и пишите путь `primery/01.go` |
| числа в выводе не совпадают с README | пример запускали дважды, пропустили или базы не сброшены | сбросьте базы и запустите примеры с первого по порядку |

В PowerShell не используйте `echo … > .env`: Windows PowerShell 5 пишет такой файл в UTF-16, и Docker
Compose его не прочитает.
