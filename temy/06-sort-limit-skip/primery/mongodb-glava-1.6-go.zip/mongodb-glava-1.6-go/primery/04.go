//go:build ignore

// Глава 1.6 · Порядок и порции: sort, limit, skip
// Пример 4 из 7 · §4 skip: постраничный вывод · вторая страница по пять
//
// Запуск из папки архива:
//   docker compose run --rm go primery/04.go
//   cd primery, затем go run 04.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────

// Product — поля товара, которые читают примеры. Тип объявлен в главе 1.4.
type Product struct {
	ID       string `bson:"_id"`
	SKU      string `bson:"sku"`
	Title    string `bson:"title"`
	Category string `bson:"category"`
	Price    int    `bson:"price"`
}

var rows []bson.M

func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	products := db.Collection("products")
	orders := db.Collection("orders")
	box := client.Database("sandbox").Collection("products") // песочница: здесь можно менять
	_, _, _, _ = db, products, orders, box

	// Коллекция на 20 000 документов для замера в §6. Создаётся один раз.
	col := client.Database("sandbox").Collection("bench")
	if n, _ := col.CountDocuments(ctx, bson.D{}); n == 0 {
		docs := make([]any, 0, 20000)
		for i := 0; i < 20000; i++ {
			docs = append(docs, bson.D{{Key: "_id", Value: i}})
		}
		col.InsertMany(ctx, docs)
	}
	lastSeenID := 19989 // последний _id предыдущей страницы
	_, _ = col, lastSeenID

	{
		// ── пример из главы ──────────────────────────────────────
		page, perPage := int64(2), int64(5)

		cursor, _ := products.Find(ctx, bson.D{},
		    options.Find().
		        SetProjection(bson.D{{Key: "_id", Value: 0}, {Key: "title", Value: 1}}).
		        SetSort(bson.D{{Key: "title", Value: 1}}).
		        SetSkip((page - 1) * perPage).
		        SetLimit(perPage))

		cursor.All(ctx, &rows)
		for _, doc := range rows {
		    fmt.Println(doc["title"])
		}
	}
}
