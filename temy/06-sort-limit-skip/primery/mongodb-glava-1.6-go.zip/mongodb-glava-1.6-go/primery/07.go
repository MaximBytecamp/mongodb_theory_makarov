//go:build ignore

// Глава 1.6 · Порядок и порции: sort, limit, skip
// Пример 7 из 7 · §7 count_documents: сколько всего · счёт по фильтру
//
// Запуск из папки архива:
//   docker compose run --rm go primery/07.go
//   cd primery, затем go run 07.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────

// Product — поля товара, которые читают примеры. Тип объявлен в главе 1.4.
type Product struct {
	ID       string `bson:"_id"`
	SKU      string `bson:"sku"`
	Title    string `bson:"title"`
	Category string `bson:"category"`
	Price    int    `bson:"price"`
}


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	products := db.Collection("products")
	orders := db.Collection("orders")
	box := client.Database("sandbox").Collection("products") // песочница: здесь можно менять
	_, _, _, _ = db, products, orders, box

	// Коллекция на 20 000 документов для замера в §6. Создаётся один раз.
	col := client.Database("sandbox").Collection("bench")
	if n, _ := col.CountDocuments(ctx, bson.D{}); n == 0 {
		docs := make([]any, 0, 20000)
		for i := 0; i < 20000; i++ {
			docs = append(docs, bson.D{{Key: "_id", Value: i}})
		}
		col.InsertMany(ctx, docs)
	}
	lastSeenID := 19989 // последний _id предыдущей страницы
	_, _ = col, lastSeenID

	{
		// ── пример из главы ──────────────────────────────────────
		n, _ := products.CountDocuments(ctx, bson.D{})
		fmt.Println("всего товаров:", n)

		n, _ = products.CountDocuments(ctx,
		    bson.D{{Key: "category", Value: "ноутбуки"}})
		fmt.Println("ноутбуков:", n)

		n, _ = orders.CountDocuments(ctx, bson.D{})
		fmt.Println("заказов:", n)

		n, _ = orders.CountDocuments(ctx,
		    bson.D{{Key: "status", Value: "доставлен"}})
		fmt.Println("доставленных:", n)
	}
}
