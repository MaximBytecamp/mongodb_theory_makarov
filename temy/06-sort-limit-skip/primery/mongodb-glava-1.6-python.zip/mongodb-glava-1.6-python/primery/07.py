# Глава 1.6 · Порядок и порции: sort, limit, skip
# Пример 7 из 7 · §7 count_documents: сколько всего · счёт по фильтру
#
# Запуск из папки архива:
#   docker compose run --rm python primery/07.py
#   cd primery, затем python 07.py (Windows) или python3 07.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# Коллекция на 20 000 документов для замера в §6. Создаётся один раз.
col = client["sandbox"]["bench"]
if col.count_documents({}) == 0:
    col.insert_many({"_id": n} for n in range(20000))
last_seen_id = 19989                        # последний _id предыдущей страницы

# ── пример из главы ───────────────────────────────────────────
print("всего товаров:", products.count_documents({}))
print("ноутбуков:", products.count_documents({"category": "ноутбуки"}))
print("заказов:", orders.count_documents({}))
print("доставленных:", orders.count_documents({"status": "доставлен"}))
