# Глава 1.6 · Порядок и порции: sort, limit, skip
# Пример 3 из 7 · §3 limit: сколько вернуть · три самых свежих события
#
# Запуск из папки архива:
#   docker compose run --rm python primery/03.py
#   cd primery, затем python 03.py (Windows) или python3 03.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# Коллекция на 20 000 документов для замера в §6. Создаётся один раз.
col = client["sandbox"]["bench"]
if col.count_documents({}) == 0:
    col.insert_many({"_id": n} for n in range(20000))
last_seen_id = 19989                        # последний _id предыдущей страницы

# ── пример из главы ───────────────────────────────────────────
events = client["logs"]["events"]

for doc in events.find({"level": "error"},
                        {"_id": 0, "ts": 1, "service": 1, "status": 1}) \
                .sort("ts", -1).limit(3):
    print(doc)
