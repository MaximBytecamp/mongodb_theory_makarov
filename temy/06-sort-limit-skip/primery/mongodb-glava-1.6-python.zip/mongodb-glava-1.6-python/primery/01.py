# Глава 1.6 · Порядок и порции: sort, limit, skip
# Пример 1 из 7 · §1 sort: порядок задаётся явно · пять самых дорогих товаров
#
# Запуск из папки архива:
#   docker compose run --rm python primery/01.py
#   cd primery, затем python 01.py (Windows) или python3 01.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# Коллекция на 20 000 документов для замера в §6. Создаётся один раз.
col = client["sandbox"]["bench"]
if col.count_documents({}) == 0:
    col.insert_many({"_id": n} for n in range(20000))
last_seen_id = 19989                        # последний _id предыдущей страницы

# ── пример из главы ───────────────────────────────────────────
for doc in products.find({}, {"_id": 0, "title": 1, "price": 1}) \
                     .sort("price", -1) \
                     .limit(5):
    print(f'{doc["price"]:>7} {doc["title"]}')
