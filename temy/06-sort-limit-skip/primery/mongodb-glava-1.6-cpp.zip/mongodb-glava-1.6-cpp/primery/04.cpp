// Глава 1.6 · Порядок и порции: sort, limit, skip
// Пример 4 из 7 · §4 skip: постраничный вывод · вторая страница по пять
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/04.cpp
//   cd primery, затем g++ -std=c++17 04.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto products = db["products"];
    auto orders = db["orders"];
    auto box = client["sandbox"]["products"];   // песочница: здесь можно менять

    // Коллекция на 20 000 документов для замера в §6. Создаётся один раз.
    auto col = client["sandbox"]["bench"];
    if (col.count_documents(make_document()) == 0) {
        std::vector<bsoncxx::document::value> docs;
        for (int n = 0; n < 20000; ++n) docs.push_back(make_document(kvp("_id", n)));
        col.insert_many(docs);
    }
    int last_seen_id = 19989;   // последний _id предыдущей страницы

    {
        // ── пример из главы ──────────────────────────────────────
        int page = 2, per_page = 5;

        mongocxx::options::find options;
        options.projection(make_document(kvp("_id", 0), kvp("title", 1)));
        options.sort(make_document(kvp("title", 1)));
        options.skip((page - 1) * per_page);
        options.limit(per_page);

        for (const auto& doc : products.find(make_document(), options))
            std::cout << doc["title"].get_string().value << std::endl;
    }
}
