# Глава 1.6 · Порядок и порции: sort, limit, skip
# Пример 1 из 7 · §1 sort: порядок задаётся явно · пять самых дорогих товаров
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/01.rb
#   cd primery, затем ruby 01.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# Коллекция на 20 000 документов для замера в §6. Создаётся один раз.
col = client.use("sandbox").database[:bench]
col.insert_many((0...20000).map { |n| { "_id" => n } }) if col.count_documents({}).zero?
last_seen_id = 19989                        # последний _id предыдущей страницы

# ── пример из главы ───────────────────────────────────────────
products.find({}, projection: { "_id" => 0, "title" => 1, "price" => 1 })
        .sort({ "price" => -1 })
        .limit(5)
        .each { |doc| puts format("%8d  %s", doc["price"], doc["title"]) }
