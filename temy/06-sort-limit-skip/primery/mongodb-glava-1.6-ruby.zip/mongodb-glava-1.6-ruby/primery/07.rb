# Глава 1.6 · Порядок и порции: sort, limit, skip
# Пример 7 из 7 · §7 count_documents: сколько всего · счёт по фильтру
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/07.rb
#   cd primery, затем ruby 07.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# Коллекция на 20 000 документов для замера в §6. Создаётся один раз.
col = client.use("sandbox").database[:bench]
col.insert_many((0...20000).map { |n| { "_id" => n } }) if col.count_documents({}).zero?
last_seen_id = 19989                        # последний _id предыдущей страницы

# ── пример из главы ───────────────────────────────────────────
puts "всего товаров: #{products.count_documents({})}"
puts "ноутбуков: #{products.count_documents({ 'category' => 'ноутбуки' })}"
puts "заказов: #{orders.count_documents({})}"
puts "доставленных: #{orders.count_documents({ 'status' => 'доставлен' })}"
