# Глава 1.6 · Порядок и порции: sort, limit, skip
# Пример 3 из 7 · §3 limit: сколько вернуть · три самых свежих события
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/03.rb
#   cd primery, затем ruby 03.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# Коллекция на 20 000 документов для замера в §6. Создаётся один раз.
col = client.use("sandbox").database[:bench]
col.insert_many((0...20000).map { |n| { "_id" => n } }) if col.count_documents({}).zero?
last_seen_id = 19989                        # последний _id предыдущей страницы

# ── пример из главы ───────────────────────────────────────────
events = client.use("logs").database[:events]

events.find({ "level" => "error" },
             projection: { "_id" => 0, "ts" => 1,
                           "service" => 1, "status" => 1 })
      .sort({ "ts" => -1 })
      .limit(3)
      .each { |doc| puts doc.inspect }
