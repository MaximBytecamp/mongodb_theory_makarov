# Глава 1.6 · Порядок и порции: sort, limit, skip
# Пример 4 из 7 · §4 skip: постраничный вывод · вторая страница по пять
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/04.rb
#   cd primery, затем ruby 04.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# Коллекция на 20 000 документов для замера в §6. Создаётся один раз.
col = client.use("sandbox").database[:bench]
col.insert_many((0...20000).map { |n| { "_id" => n } }) if col.count_documents({}).zero?
last_seen_id = 19989                        # последний _id предыдущей страницы

# ── пример из главы ───────────────────────────────────────────
page, per_page = 2, 5

products.find({}, projection: { "_id" => 0, "title" => 1 })
        .sort({ "title" => 1 })
        .skip((page - 1) * per_page)
        .limit(per_page)
        .each { |doc| puts doc["title"] }
