# Глава 4.9 · $replaceRoot, $replaceWith и $redact
# Пример 7 из 8 · §7 $redact на всей коллекции · позиции до $redact и после
#
# Запуск из папки архива:
#   docker compose run --rm python primery/07.py
#   cd primery, затем python 07.py (Windows) или python3 07.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

from datetime import datetime


def show(docs, *fields):
    """Печатает у каждого документа поля fields в строку через « | »; вложенные — через точку."""
    count = 0
    for doc in docs:
        cells = []
        for path in fields:
            value = doc
            for key in path.split("."):
                value = value.get(key) if isinstance(value, dict) else None
            if isinstance(value, datetime):
                value = value.strftime("%Y-%m-%d %H:%M")
            if isinstance(value, bool):
                value = str(value).lower()
            cells.append("—" if value is None else str(value))
        print(" | ".join(cells))
        count += 1
    print("документов:", count)

# ── пример из главы ───────────────────────────────────────────
lines_all = [
    {"$unwind": "$items"},
    {"$count": "lines"},
]

lines_redacted = [
    {"$redact": {"$cond": [{"$eq": ["$category", "аксессуары"]}, "$$PRUNE", "$$DESCEND"]}},
    {"$unwind": "$items"},
    {"$count": "lines"},
]

orders_empty = [
    {"$redact": {"$cond": [{"$eq": ["$category", "аксессуары"]}, "$$PRUNE", "$$DESCEND"]}},
    {"$match": {"items": {"$size": 0}}},
    {"$count": "orders"},
]

print("── позиций всего")
for doc in orders.aggregate(lines_all):
    print(doc)

print("── позиций без аксессуаров")
for doc in orders.aggregate(lines_redacted):
    print(doc)

print("── заказов, где не осталось позиций")
for doc in orders.aggregate(orders_empty):
    print(doc)
