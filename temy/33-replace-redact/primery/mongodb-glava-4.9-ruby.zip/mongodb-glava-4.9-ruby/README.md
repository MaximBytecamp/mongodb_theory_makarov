# Глава 4.9 · $replaceRoot, $replaceWith и $redact — примеры на Ruby

Архив к «Справочнику по MongoDB»: все примеры главы готовыми программами, данные баз и стенд в Docker.
Глава: https://maximbytecamp.github.io/mongodb_theory_makarov/temy/33-replace-redact/index.html

Язык: **Ruby** · драйвер gem mongo 2.21 · сервер MongoDB 7.

## Что в архиве

```text
mongodb-glava-4.9-ruby/
  README.md         эта инструкция
  primery/          примеры главы — по программе на пример
    01.rb … 08.rb
  compose.yaml      стенд в Docker: сервер, базы, mongo-express, Ruby
  docker/           образ с драйвером Ruby и скрипт запуска run.sh
  stend/seed/       данные баз: 12 файлов JSON
  stend/load.ps1    загрузка данных на установленный сервер — Windows
  stend/load.sh     то же — macOS и Linux
```

## Порядок работы

1. **Базы.** Глава **только читает** данные — сбрасывать базы не нужно.
2. **Примеры — по порядку, каждый один раз.** Пример в главе рассчитан на данные, которые оставил
   предыдущий. Если запустить пример дважды или пропустить, числа разойдутся с книгой — тогда
   сбросьте базы и начните с `01.rb`.
3. **Сверка.** Что должна напечатать каждая программа — в разделе «Примеры и выводы» ниже.
   Отличаться могут только `_id`, которые выдаёт сервер, текущие дата и время и порядок
   в списке коллекций: сервер отдаёт их имена в произвольном порядке. У документа, который
   создан обновлением с `upsert`, поля тоже могут идти в другом порядке — значения при этом те же.

Подойдёт любой из двух способов. Адрес сервера в обоих — `mongodb://localhost:27017`, код примеров
одинаковый.

| Способ | Что нужно | Когда подходит |
|---|---|---|
| **1. Docker** | Docker Desktop | Compass и сервер не установились или не подключаются; ничего, кроме Docker, ставить не нужно |
| **2. Сервер и Compass** | MongoDB Server, Compass, Ruby с драйвером | сервер и Compass уже стоят и подключаются |

## Способ 1. Docker

Docker Desktop — с [docker.com](https://www.docker.com/products/docker-desktop/); на Linux — Docker Engine.
Перед командами Docker Desktop должен быть запущен. Команды одинаковые в PowerShell, cmd и терминале
macOS/Linux; выполняйте их **из папки архива** — там, где лежит `compose.yaml`.

1. Поднять сервер и загрузить базы курса:

   ```bash
   docker compose up -d
   ```

2. Запустить пример — путь к файлу пишется от папки архива:

   ```bash
   docker compose run --rm ruby primery/01.rb
   ```

   При первом запуске Docker соберёт образ с драйвером Ruby — это пара минут.
   Дальше запуск идёт за секунды.

3. Все примеры главы подряд, по порядку, одной командой:

   ```bash
   docker compose run --rm ruby primery
   ```

   Перед каждой программой печатается её имя: `── primery/01.rb ──`.

**Смотреть данные.** Compass не нужен: в браузере откройте http://localhost:8081, логин `student`,
пароль `student` — это mongo-express, в нём видны базы, коллекции и документы. Если Compass
установлен, он подключается к этому же серверу по адресу `mongodb://localhost:27017`.

**Консоль сервера:** `docker compose exec mongo mongosh`.

**Остановить и удалить:**

```bash
docker compose stop        # остановить; данные останутся
docker compose down        # удалить контейнеры; данные останутся
docker compose down -v     # удалить всё вместе с данными
```

Архивы всех глав пользуются одним и тем же сервером и данными: после этой главы можно распаковать
архив следующей и работать там, не удаляя стенд.

## Способ 2. Установленный сервер MongoDB и Compass

Нужны MongoDB Server 7 или 8 и MongoDB Compass — установка по шагам в
[главе 1.0а](https://maximbytecamp.github.io/mongodb_theory_makarov/temy/00a-windows-10-mongodb-7/index.html).
Проверка: Compass подключается к `mongodb://localhost:27017`.

### Шаг 1. Загрузить базы курса

Windows, PowerShell, из папки архива — нужен `mongoimport` из MongoDB Command Line Database Tools:

```powershell
powershell -ExecutionPolicy Bypass -File stend\load.ps1
```

macOS и Linux (`mongoimport`: `brew tap mongodb/brew && brew install mongodb-database-tools`):

```bash
bash stend/load.sh
```

Скрипт пересоздаёт коллекции целиком, поэтому он же сбрасывает базы: повторный запуск ничего не двоит.

**Без `mongoimport` — через Compass.** Подключитесь к `mongodb://localhost:27017`, нажмите **Create database**,
затем в коллекции **Add data → Import JSON or CSV file** и выберите файл из `stend/seed`. Имя файла
подсказывает, куда класть: `shop.orders.json` — база `shop`, коллекция `orders`. Так загружаются все
12 файлов; пошагово с кадрами — [глава 1.0, §7](https://maximbytecamp.github.io/mongodb_theory_makarov/temy/00-uchebnye-bazy/index.html#s7).

После загрузки в Compass нажмите **Refresh**: в списке должны быть базы `shop`, `hh`, `logs`, `org`
и `sandbox`. В `shop.products` — 21 документ, в `shop.orders` — 120.

### Шаг 2. Драйвер Ruby и запуск

Ruby 3.3. На Windows — с [rubyinstaller.org](https://rubyinstaller.org/downloads/), сборка
**with Devkit**: драйверу нужен компилятор для расширения `bson`. На последнем экране установщика оставьте
галочку **Run 'ridk install'** и в окне MSYS2 выберите пункт 3.

Windows, PowerShell:

```powershell
gem install mongo -v 2.21.0
cd primery
ruby 01.rb
```

macOS и Linux (на Linux сначала `sudo apt install ruby-full build-essential`):

```bash
gem install --user-install mongo -v 2.21.0
cd primery
ruby 01.rb
```

Остальные примеры запускаются так же: `02.rb`, `03.rb` и далее. Если сервер слушает другой адрес,
задайте его переменной `MONGO_URI` — программы глав 1.2–1.8 читают её при подключении.

## Примеры и выводы

| Файл | Параграф главы | Что делает |
|---|---|---|
| `01.rb` | §1 Стадия $replaceRoot | $replaceRoot: документ доставки вместо заказа |
| `02.rb` | §2 $replaceWith и $mergeObjects | $replaceWith и $mergeObjects |
| `03.rb` | §3 Стадии после замены документа | группировка после $replaceWith |
| `04.rb` | §4 Позиции заказа как документы | $unwind и $replaceWith: позиции как документы |
| `05.rb` | §5 Новый корень — только документ | newRoot — не документ |
| `06.rb` | §6 Стадия $redact | $redact: позиции без периферии |
| `07.rb` | §7 $redact на всей коллекции | позиции до $redact и после |
| `08.rb` | §8 Условие на каждом уровне | условие на поле, которого нет во вложенных документах |

### 01.rb · §1 Стадия $replaceRoot

$replaceRoot: документ доставки вместо заказа.

```text
{"city"=>"Новосибирск", "type"=>"курьер", "days"=>4}
```

### 02.rb · §2 $replaceWith и $mergeObjects

$replaceWith и $mergeObjects.

```text
{"number"=>"2026-0002", "city"=>"Новосибирск", "type"=>"курьер", "days"=>4}
```

### 03.rb · §3 Стадии после замены документа

Группировка после $replaceWith.

```text
{"_id"=>"почта", "orders"=>5, "days"=>4.8}
{"_id"=>"пункт выдачи", "orders"=>8, "days"=>2.625}
```

### 04.rb · §4 Позиции заказа как документы

$unwind и $replaceWith: позиции как документы.

```text
{"sku"=>"SKU-NB-002", "title"=>"Ноутбук ASUS VivoBook 15", "category"=>"ноутбуки", "qty"=>1, "price"=>51490}
{"sku"=>"SKU-PR-014", "title"=>"Веб-камера Logitech C920", "category"=>"периферия", "qty"=>1, "price"=>6790}
{"sku"=>"SKU-PR-013", "title"=>"Наушники Sony WH-1000XM5", "category"=>"периферия", "qty"=>3, "price"=>34990}
```

### 05.rb · §5 Новый корень — только документ

NewRoot — не документ.

```text
код 40228
PlanExecutor error during aggregation :: caused by :: 'newRoot' expression  must evaluate to an object, but resulting value was: MISSING. Type of resulting value: 'missing'. Input document: {}
```

### 06.rb · §6 Стадия $redact

$redact: позиции без периферии.

```text
{"_id"=>"o-0002", "number"=>"2026-0002", "items"=>[{"title"=>"Ноутбук ASUS VivoBook 15"}], "delivery"=>{"city"=>"Новосибирск"}}
```

### 07.rb · §7 $redact на всей коллекции

Позиции до $redact и после.

```text
── позиций всего
{"lines"=>271}
── позиций без аксессуаров
{"lines"=>238}
── заказов, где не осталось позиций
{"orders"=>6}
```

### 08.rb · §8 Условие на каждом уровне

Условие на поле, которого нет во вложенных документах.

```text
{"_id"=>"o-0002", "number"=>"2026-0002", "customer_id"=>"c-007", "created"=>2026-04-15 17:00:00 UTC, "status"=>"собирается", "items"=>[], "total"=>163250, "promo"=>"SPRING10"}
```

## Частые ошибки

| Что видно | Причина | Что сделать |
|---|---|---|
| `port is already allocated`, `address already in use` на `docker compose up -d` | порт 27017 занят: уже работает установленный MongoDB или стенд `mongodb-practice` | остановите тот сервер или создайте рядом с `compose.yaml` файл `.env` со строкой `MONGO_PORT=27018`: в PowerShell — `Set-Content .env "MONGO_PORT=27018"`, в bash — `echo "MONGO_PORT=27018" > .env`. Программы в Docker это не затрагивает, Compass подключайте к `localhost:27018` |
| `Cannot connect to the Docker daemon`, `error during connect` | Docker Desktop не запущен | запустите Docker Desktop и дождитесь зелёного статуса Engine running |
| `ServerSelectionTimeoutError`, `Connection refused`, `No server available` | сервер не запущен | Docker: `docker compose up -d`; способ 2 — запустите службу MongoDB |
| `Файл не найден: …` | путь написан не от папки архива или команда выполнена в другой папке | перейдите в папку, где лежит `compose.yaml`, и пишите путь `primery/01.rb` |
| числа в выводе не совпадают с README | пример запускали дважды, пропустили или базы не сброшены | сбросьте базы и запустите примеры с первого по порядку |

В PowerShell не используйте `echo … > .env`: Windows PowerShell 5 пишет такой файл в UTF-16, и Docker
Compose его не прочитает.
