# Глава 4.9 · $replaceRoot, $replaceWith и $redact
# Пример 7 из 8 · §7 $redact на всей коллекции · позиции до $redact и после
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/07.rb
#   cd primery, затем ruby 07.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# Печатает у каждого документа поля fields в строку через « | »; вложенные — через точку.
def show(docs, *fields)
  count = 0
  docs.each do |doc|
    cells = fields.map do |path|
      value = path.split(".").reduce(doc) { |v, key| v.is_a?(Hash) ? v[key] : nil }
      value = value.utc.strftime("%Y-%m-%d %H:%M") if value.is_a?(Time)
      value.nil? ? "—" : value.to_s
    end
    puts cells.join(" | ")
    count += 1
  end
  puts "документов: #{count}"
end

# ── пример из главы ───────────────────────────────────────────
lines_all = [
  { "$unwind" => "$items" },
  { "$count" => "lines" },
]

lines_redacted = [
  { "$redact" => { "$cond" => [
    { "$eq" => ["$category", "аксессуары"] },
    "$$PRUNE",
    "$$DESCEND",
  ] } },
  { "$unwind" => "$items" },
  { "$count" => "lines" },
]

orders_empty = [
  { "$redact" => { "$cond" => [
    { "$eq" => ["$category", "аксессуары"] },
    "$$PRUNE",
    "$$DESCEND",
  ] } },
  { "$match" => { "items" => { "$size" => 0 } } },
  { "$count" => "orders" },
]

puts "── позиций всего"
orders.aggregate(lines_all).each { |doc| puts doc.inspect }

puts "── позиций без аксессуаров"
orders.aggregate(lines_redacted).each { |doc| puts doc.inspect }

puts "── заказов, где не осталось позиций"
orders.aggregate(orders_empty).each { |doc| puts doc.inspect }
