# Глава 6.4 · $unionWith: документы двух коллекций в одном потоке
# Пример 3 из 6 · §3 Стадии до и после $unionWith · стадия до $unionWith и после
#
# Запуск из папки архива:
#   docker compose run --rm python primery/03.py
#   cd primery, затем python 03.py (Windows) или python3 03.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
before = [
    {"$match": {"city": "Москва"}},
    {"$unionWith": "resumes"},
    {"$count": "docs"},
]

after = [
    {"$unionWith": "resumes"},
    {"$match": {"city": "Москва"}},
    {"$count": "docs"},
]

print("── $match до $unionWith")
for doc in vacancies.aggregate(before):
    print(doc)

print("── $match после $unionWith")
for doc in vacancies.aggregate(after):
    print(doc)
