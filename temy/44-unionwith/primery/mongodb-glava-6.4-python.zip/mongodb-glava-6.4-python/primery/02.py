# Глава 6.4 · $unionWith: документы двух коллекций в одном потоке
# Пример 2 из 6 · §2 Отметка источника и группировка · вакансии и резюме по городам
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$project": {"_id": 0, "city": 1, "kind": "вакансия"}},
    {"$unionWith": {
        "coll": "resumes",
        "pipeline": [{"$project": {"_id": 0, "city": 1, "kind": "резюме"}}],
    }},
    {"$group": {
        "_id": "$city",
        "vacancies": {"$sum": {"$cond": [{"$eq": ["$kind", "вакансия"]}, 1, 0]}},
        "resumes": {"$sum": {"$cond": [{"$eq": ["$kind", "резюме"]}, 1, 0]}},
    }},
    {"$sort": {"_id": 1}},
]

for doc in vacancies.aggregate(pipeline):
    print(doc)
