# Глава 6.4 · $unionWith: документы двух коллекций в одном потоке
# Пример 1 из 6 · §1 Стадия $unionWith · $unionWith: вакансии и резюме одним списком
#
# Запуск из папки архива:
#   docker compose run --rm python primery/01.py
#   cd primery, затем python 01.py (Windows) или python3 01.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"city": "Москва"}},
    {"$project": {"_id": 0, "title": 1, "city": 1}},
    {"$unionWith": {
        "coll": "resumes",
        "pipeline": [
            {"$match": {"city": "Москва"}},
            {"$project": {"_id": 0, "title": "$position", "city": 1}},
        ],
    }},
]

for doc in vacancies.aggregate(pipeline):
    print(doc)
