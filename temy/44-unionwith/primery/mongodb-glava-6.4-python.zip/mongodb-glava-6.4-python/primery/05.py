# Глава 6.4 · $unionWith: документы двух коллекций в одном потоке
# Пример 5 из 6 · §5 Города из двух коллекций магазина · города из двух коллекций магазина
#
# Запуск из папки архива:
#   docker compose run --rm python primery/05.py
#   cd primery, затем python 05.py (Windows) или python3 05.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$project": {"_id": 0, "city": 1, "from": "customers"}},
    {"$unionWith": {
        "coll": "orders",
        "pipeline": [
            {"$project": {"_id": 0, "city": "$delivery.city", "from": "orders"}},
        ],
    }},
    {"$group": {
        "_id": "$city",
        "customers": {"$sum": {"$cond": [{"$eq": ["$from", "customers"]}, 1, 0]}},
        "deliveries": {"$sum": {"$cond": [{"$eq": ["$from", "orders"]}, 1, 0]}},
    }},
    {"$sort": {"_id": 1}},
]

for doc in customers.aggregate(pipeline):
    print(doc)
