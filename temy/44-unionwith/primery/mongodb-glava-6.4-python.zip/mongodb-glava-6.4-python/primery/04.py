# Глава 6.4 · $unionWith: документы двух коллекций в одном потоке
# Пример 4 из 6 · §4 Одна коллекция дважды · два самых дорогих и два самых дешёвых заказа
#
# Запуск из папки архива:
#   docker compose run --rm python primery/04.py
#   cd primery, затем python 04.py (Windows) или python3 04.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$sort": {"total": -1, "number": 1}},
    {"$limit": 2},
    {"$project": {"_id": 0, "number": 1, "total": 1}},
    {"$unionWith": {
        "coll": "orders",
        "pipeline": [
            {"$sort": {"total": 1, "number": 1}},
            {"$limit": 2},
            {"$project": {"_id": 0, "number": 1, "total": 1}},
        ],
    }},
]

for doc in orders.aggregate(pipeline):
    print(doc)
