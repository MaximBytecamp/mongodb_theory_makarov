# Глава 6.4 · $unionWith: документы двух коллекций в одном потоке
# Пример 6 из 6 · §6 Коллекция, которой нет в базе · коллекция, которой нет в базе
#
# Запуск из папки архива:
#   docker compose run --rm python primery/06.py
#   cd primery, затем python 06.py (Windows) или python3 06.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
only_customers = [
    {"$count": "docs"},
]

with_employees = [
    {"$unionWith": "employees"},
    {"$count": "docs"},
]

print("── покупатели")
for doc in customers.aggregate(only_customers):
    print(doc)

print("── покупатели и employees")
for doc in customers.aggregate(with_employees):
    print(doc)
