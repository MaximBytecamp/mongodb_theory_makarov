# Глава 6.4 · $unionWith: документы двух коллекций в одном потоке
# Пример 5 из 6 · §5 Города из двух коллекций магазина · города из двух коллекций магазина
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/05.rb
#   cd primery, затем ruby 05.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$project" => { "_id" => 0, "city" => 1, "from" => "customers" } },
  { "$unionWith" => {
    "coll" => "orders",
    "pipeline" => [
      { "$project" => { "_id" => 0, "city" => "$delivery.city", "from" => "orders" } },
    ],
  } },
  { "$group" => {
    "_id" => "$city",
    "customers" => { "$sum" => { "$cond" => [{ "$eq" => ["$from", "customers"] }, 1, 0] } },
    "deliveries" => { "$sum" => { "$cond" => [{ "$eq" => ["$from", "orders"] }, 1, 0] } },
  } },
  { "$sort" => { "_id" => 1 } },
]

customers.aggregate(pipeline).each { |doc| puts doc.inspect }
