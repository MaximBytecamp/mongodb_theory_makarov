# Глава 6.4 · $unionWith: документы двух коллекций в одном потоке
# Пример 6 из 6 · §6 Коллекция, которой нет в базе · коллекция, которой нет в базе
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/06.rb
#   cd primery, затем ruby 06.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
only_customers = [
  { "$count" => "docs" },
]

with_employees = [
  { "$unionWith" => "employees" },
  { "$count" => "docs" },
]

puts "── покупатели"
customers.aggregate(only_customers).each { |doc| puts doc.inspect }

puts "── покупатели и employees"
customers.aggregate(with_employees).each { |doc| puts doc.inspect }
