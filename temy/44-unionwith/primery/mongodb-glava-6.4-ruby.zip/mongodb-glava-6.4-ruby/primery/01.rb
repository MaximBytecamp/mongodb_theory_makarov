# Глава 6.4 · $unionWith: документы двух коллекций в одном потоке
# Пример 1 из 6 · §1 Стадия $unionWith · $unionWith: вакансии и резюме одним списком
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/01.rb
#   cd primery, затем ruby 01.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "city" => "Москва" } },
  { "$project" => { "_id" => 0, "title" => 1, "city" => 1 } },
  { "$unionWith" => {
    "coll" => "resumes",
    "pipeline" => [
      { "$match" => { "city" => "Москва" } },
      { "$project" => { "_id" => 0, "title" => "$position", "city" => 1 } },
    ],
  } },
]

vacancies.aggregate(pipeline).each { |doc| puts doc.inspect }
