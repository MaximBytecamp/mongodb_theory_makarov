# Глава 6.4 · $unionWith: документы двух коллекций в одном потоке
# Пример 3 из 6 · §3 Стадии до и после $unionWith · стадия до $unionWith и после
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/03.rb
#   cd primery, затем ruby 03.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
before = [
  { "$match" => { "city" => "Москва" } },
  { "$unionWith" => "resumes" },
  { "$count" => "docs" },
]

after = [
  { "$unionWith" => "resumes" },
  { "$match" => { "city" => "Москва" } },
  { "$count" => "docs" },
]

puts "── $match до $unionWith"
vacancies.aggregate(before).each { |doc| puts doc.inspect }

puts "── $match после $unionWith"
vacancies.aggregate(after).each { |doc| puts doc.inspect }
