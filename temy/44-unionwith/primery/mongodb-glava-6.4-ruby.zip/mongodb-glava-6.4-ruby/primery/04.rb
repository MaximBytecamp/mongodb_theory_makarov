# Глава 6.4 · $unionWith: документы двух коллекций в одном потоке
# Пример 4 из 6 · §4 Одна коллекция дважды · два самых дорогих и два самых дешёвых заказа
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/04.rb
#   cd primery, затем ruby 04.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$sort" => { "total" => -1, "number" => 1 } },
  { "$limit" => 2 },
  { "$project" => { "_id" => 0, "number" => 1, "total" => 1 } },
  { "$unionWith" => {
    "coll" => "orders",
    "pipeline" => [
      { "$sort" => { "total" => 1, "number" => 1 } },
      { "$limit" => 2 },
      { "$project" => { "_id" => 0, "number" => 1, "total" => 1 } },
    ],
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
