# Глава 6.4 · $unionWith: документы двух коллекций в одном потоке
# Пример 2 из 6 · §2 Отметка источника и группировка · вакансии и резюме по городам
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/02.rb
#   cd primery, затем ruby 02.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$project" => { "_id" => 0, "city" => 1, "kind" => "вакансия" } },
  { "$unionWith" => {
    "coll" => "resumes",
    "pipeline" => [{ "$project" => { "_id" => 0, "city" => 1, "kind" => "резюме" } }],
  } },
  { "$group" => {
    "_id" => "$city",
    "vacancies" => { "$sum" => { "$cond" => [{ "$eq" => ["$kind", "вакансия"] }, 1, 0] } },
    "resumes" => { "$sum" => { "$cond" => [{ "$eq" => ["$kind", "резюме"] }, 1, 0] } },
  } },
  { "$sort" => { "_id" => 1 } },
]

vacancies.aggregate(pipeline).each { |doc| puts doc.inspect }
