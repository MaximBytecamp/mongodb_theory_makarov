//go:build ignore

// Глава 6.4 · $unionWith: документы двух коллекций в одном потоке
// Пример 5 из 6 · §5 Города из двух коллекций магазина · города из двух коллекций магазина
//
// Запуск из папки архива:
//   docker compose run --rm go primery/05.go
//   cd primery, затем go run 05.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	orders := db.Collection("orders")
	customers := db.Collection("customers")
	products := db.Collection("products")
	hh := client.Database("hh")
	companies := hh.Collection("companies")
	vacancies := hh.Collection("vacancies")
	resumes := hh.Collection("resumes")
	org := client.Database("org")
	employees := org.Collection("employees")
	categories := org.Collection("categories")
	sandbox := client.Database("sandbox")
	_, _, _, _, _, _, _, _, _, _, _, _ = db, orders, customers, products, hh, companies, vacancies, resumes, org, employees, categories, sandbox

	{
		// ── пример из главы ──────────────────────────────────────
		pipeline := mongo.Pipeline{
		    {{Key: "$project", Value: bson.D{
		        {Key: "_id", Value: 0},
		        {Key: "city", Value: 1},
		        {Key: "from", Value: "customers"}}}},
		    {{Key: "$unionWith", Value: bson.D{
		        {Key: "coll", Value: "orders"},
		        {Key: "pipeline", Value: bson.A{
		            bson.D{
		                {Key: "$project", Value: bson.D{
		                    {Key: "_id", Value: 0},
		                    {Key: "city", Value: "$delivery.city"},
		                    {Key: "from", Value: "orders"}}}}}}}}},
		    {{Key: "$group", Value: bson.D{
		        {Key: "_id", Value: "$city"},
		        {Key: "customers", Value: bson.D{
		            {Key: "$sum", Value: bson.D{
		                {Key: "$cond", Value: bson.A{
		                    bson.D{{Key: "$eq", Value: bson.A{"$from", "customers"}}},
		                    1,
		                    0}}}}}},
		        {Key: "deliveries", Value: bson.D{
		            {Key: "$sum", Value: bson.D{
		                {Key: "$cond", Value: bson.A{
		                    bson.D{{Key: "$eq", Value: bson.A{"$from", "orders"}}},
		                    1,
		                    0}}}}}}}}},
		    {{Key: "$sort", Value: bson.D{{Key: "_id", Value: 1}}}},
		}

		cursor, _ := customers.Aggregate(ctx, pipeline)
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}
	}
}
