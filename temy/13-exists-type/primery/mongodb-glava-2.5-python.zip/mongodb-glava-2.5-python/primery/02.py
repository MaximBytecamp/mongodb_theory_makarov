# Глава 2.5 · Есть ли поле: $exists и $type
# Пример 2 из 7 · §2 $exists вместе с отрицанием · отрицание без документов без поля
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
print("ready_to_move $ne true:    ", resumes.count_documents({"ready_to_move": {"$ne": True}}))
print("то же и поле есть:         ", resumes.count_documents({"ready_to_move": {"$ne": True, "$exists": True}}))
print("уровень не СПО и поле есть:", resumes.count_documents({"education.level": {"$nin": ["СПО"], "$exists": True}}))
