# Глава 2.5 · Есть ли поле: $exists и $type
# Пример 4 из 7 · §4 $type: тип значения · тип значения поля
#
# Запуск из папки архива:
#   docker compose run --rm python primery/04.py
#   cd primery, затем python 04.py (Windows) или python3 04.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
print("resumes: salary число:     ", resumes.count_documents({"salary": {"$type": "number"}}))
print("resumes: salary документ:  ", resumes.count_documents({"salary": {"$type": "object"}}))
print("vacancies: salary документ:", vacancies.count_documents({"salary": {"$type": "object"}}))
print("vacancies: salary число:   ", vacancies.count_documents({"salary": {"$type": "number"}}))
