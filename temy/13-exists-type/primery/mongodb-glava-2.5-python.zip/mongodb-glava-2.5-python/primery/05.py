# Глава 2.5 · Есть ли поле: $exists и $type
# Пример 5 из 7 · §5 $type и поле-массив · $type и поле-массив
#
# Запуск из папки архива:
#   docker compose run --rm python primery/05.py
#   cd primery, затем python 05.py (Windows) или python3 05.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
print("experience массив:", resumes.count_documents({"experience": {"$type": "array"}}))
print("skills массив:    ", resumes.count_documents({"skills": {"$type": "array"}}))
print("skills строка:    ", resumes.count_documents({"skills": {"$type": "string"}}))
print("skills не массив: ", resumes.count_documents({"skills": {"$not": {"$type": "array"}}}))
