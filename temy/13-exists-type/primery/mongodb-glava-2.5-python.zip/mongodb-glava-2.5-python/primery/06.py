# Глава 2.5 · Есть ли поле: $exists и $type
# Пример 6 из 7 · §6 Значение не того типа · цена, записанная строкой
#
# Запуск из папки архива:
#   docker compose run --rm python primery/06.py
#   cd primery, затем python 06.py (Windows) или python3 06.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
# товар из веб-формы: цена пришла текстом и так и записана
box.insert_one({"_id": "p-201",
                "title": "Кабель USB-C 2 м",
                "category": "аксессуары",
                "price": "790"})

print("цена строкой:   ", box.count_documents({"price": {"$type": "string"}}))
print("цена больше 500:", box.count_documents({"price": {"$gt": 500}}))

for doc in box.find({"price": {"$type": "string"}}, {"title": 1, "price": 1}):
    print(doc)
