# Глава 2.5 · Есть ли поле: $exists и $type
# Пример 1 из 7 · §1 $exists: есть ли поле · есть ли поле в документе
#
# Запуск из папки архива:
#   docker compose run --rm python primery/01.py
#   cd primery, затем python 01.py (Windows) или python3 01.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
print("есть portfolio:    ", resumes.count_documents({"portfolio": {"$exists": True}}))
print("есть courses:      ", resumes.count_documents({"courses": {"$exists": True}}))
print("есть ready_to_move:", resumes.count_documents({"ready_to_move": {"$exists": True}}))
print("нет ready_to_move: ", resumes.count_documents({"ready_to_move": {"$exists": False}}))

for doc in resumes.find({"portfolio": {"$exists": True}}, {"_id": 0, "fio": 1, "portfolio": 1}):
    print(doc)
