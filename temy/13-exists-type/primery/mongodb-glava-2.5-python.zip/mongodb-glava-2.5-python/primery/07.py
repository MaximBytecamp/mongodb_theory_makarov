# Глава 2.5 · Есть ли поле: $exists и $type
# Пример 7 из 7 · §6 Значение не того типа · цена исправлена
#
# Запуск из папки архива:
#   docker compose run --rm python primery/07.py
#   cd primery, затем python 07.py (Windows) или python3 07.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
box.update_one({"_id": "p-201"}, {"$set": {"price": 790}})

print("цена строкой:   ", box.count_documents({"price": {"$type": "string"}}))
print("цена больше 500:", box.count_documents({"price": {"$gt": 500}}))
