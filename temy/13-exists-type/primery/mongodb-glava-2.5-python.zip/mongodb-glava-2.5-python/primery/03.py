# Глава 2.5 · Есть ли поле: $exists и $type
# Пример 3 из 7 · §3 null и отсутствующее поле · null и отсутствующее поле
#
# Запуск из папки архива:
#   docker compose run --rm python primery/03.py
#   cd primery, затем python 03.py (Windows) или python3 03.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
events = client["logs"]["events"]

print("events: user_id null:             ", events.count_documents({"user_id": None}))
print("events: user_id нет:              ", events.count_documents({"user_id": {"$exists": False}}))
print("events: user_id $type null:       ", events.count_documents({"user_id": {"$type": "null"}}))
print("resumes: ready_to_move null:      ", resumes.count_documents({"ready_to_move": None}))
print("resumes: ready_to_move $type null:", resumes.count_documents({"ready_to_move": {"$type": "null"}}))
