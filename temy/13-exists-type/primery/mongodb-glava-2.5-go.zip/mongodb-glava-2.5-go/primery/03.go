//go:build ignore

// Глава 2.5 · Есть ли поле: $exists и $type
// Пример 3 из 7 · §3 null и отсутствующее поле · null и отсутствующее поле
//
// Запуск из папки архива:
//   docker compose run --rm go primery/03.go
//   cd primery, затем go run 03.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("hh")
	resumes := db.Collection("resumes")
	vacancies := db.Collection("vacancies")
	companies := db.Collection("companies")
	interviews := db.Collection("interviews")
	box := client.Database("sandbox").Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, resumes, vacancies, companies, interviews, box

	{
		// ── пример из главы ──────────────────────────────────────
		events := client.Database("logs").Collection("events")

		ravnoNull, _ := events.CountDocuments(ctx, bson.D{{Key: "user_id", Value: nil}})
		netPolya, _ := events.CountDocuments(ctx, bson.D{{Key: "user_id", Value: bson.D{{Key: "$exists", Value: false}}}})
		tipNull, _ := events.CountDocuments(ctx, bson.D{{Key: "user_id", Value: bson.D{{Key: "$type", Value: "null"}}}})
		readyNull, _ := resumes.CountDocuments(ctx, bson.D{{Key: "ready_to_move", Value: nil}})
		readyTipNull, _ := resumes.CountDocuments(ctx, bson.D{{Key: "ready_to_move", Value: bson.D{{Key: "$type", Value: "null"}}}})

		fmt.Println("events: user_id null:             ", ravnoNull)
		fmt.Println("events: user_id нет:              ", netPolya)
		fmt.Println("events: user_id $type null:       ", tipNull)
		fmt.Println("resumes: ready_to_move null:      ", readyNull)
		fmt.Println("resumes: ready_to_move $type null:", readyTipNull)
	}
}
