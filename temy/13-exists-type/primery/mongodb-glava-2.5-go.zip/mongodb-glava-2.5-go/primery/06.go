//go:build ignore

// Глава 2.5 · Есть ли поле: $exists и $type
// Пример 6 из 7 · §6 Значение не того типа · цена, записанная строкой
//
// Запуск из папки архива:
//   docker compose run --rm go primery/06.go
//   cd primery, затем go run 06.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("hh")
	resumes := db.Collection("resumes")
	vacancies := db.Collection("vacancies")
	companies := db.Collection("companies")
	interviews := db.Collection("interviews")
	box := client.Database("sandbox").Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, resumes, vacancies, companies, interviews, box

	{
		// ── пример из главы ──────────────────────────────────────
		// товар из веб-формы: цена пришла текстом и так и записана
		box.InsertOne(ctx, bson.D{
		    {Key: "_id", Value: "p-201"},
		    {Key: "title", Value: "Кабель USB-C 2 м"},
		    {Key: "category", Value: "аксессуары"},
		    {Key: "price", Value: "790"}})

		stroka, _ := box.CountDocuments(ctx, bson.D{{Key: "price", Value: bson.D{{Key: "$type", Value: "string"}}}})
		dorozhe, _ := box.CountDocuments(ctx, bson.D{{Key: "price", Value: bson.D{{Key: "$gt", Value: 500}}}})

		fmt.Println("цена строкой:   ", stroka)
		fmt.Println("цена больше 500:", dorozhe)

		cursor, _ := box.Find(ctx, bson.D{{Key: "price", Value: bson.D{{Key: "$type", Value: "string"}}}},
		    options.Find().SetProjection(bson.D{{Key: "title", Value: 1}, {Key: "price", Value: 1}}))
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}
	}
}
