// Глава 2.5 · Есть ли поле: $exists и $type
// Пример 6 из 7 · §6 Значение не того типа · цена, записанная строкой
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/06.cpp
//   cd primery, затем g++ -std=c++17 06.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["hh"];
    auto resumes = db["resumes"];
    auto vacancies = db["vacancies"];
    auto companies = db["companies"];
    auto interviews = db["interviews"];
    auto box = client["sandbox"]["products"];   // песочница: здесь можно менять

    {
        // ── пример из главы ──────────────────────────────────────
        // товар из веб-формы: цена пришла текстом и так и записана
        box.insert_one(make_document(
            kvp("_id", "p-201"),
            kvp("title", "Кабель USB-C 2 м"),
            kvp("category", "аксессуары"),
            kvp("price", "790")));

        std::cout << "цена строкой:    " << box.count_documents(make_document(kvp("price", make_document(kvp("$type", "string"))))) << std::endl;
        std::cout << "цена больше 500: " << box.count_documents(make_document(kvp("price", make_document(kvp("$gt", 500))))) << std::endl;

        mongocxx::options::find options;
        options.projection(make_document(kvp("title", 1), kvp("price", 1)));

        for (const auto& doc : box.find(make_document(kvp("price", make_document(kvp("$type", "string")))), options)) {
            std::cout << bsoncxx::to_json(doc, bsoncxx::ExtendedJsonMode::k_relaxed) << std::endl;
        }
    }
}
