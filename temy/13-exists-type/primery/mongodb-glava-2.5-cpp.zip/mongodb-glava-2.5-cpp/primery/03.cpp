// Глава 2.5 · Есть ли поле: $exists и $type
// Пример 3 из 7 · §3 null и отсутствующее поле · null и отсутствующее поле
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/03.cpp
//   cd primery, затем g++ -std=c++17 03.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["hh"];
    auto resumes = db["resumes"];
    auto vacancies = db["vacancies"];
    auto companies = db["companies"];
    auto interviews = db["interviews"];
    auto box = client["sandbox"]["products"];   // песочница: здесь можно менять

    {
        // ── пример из главы ──────────────────────────────────────
        auto events = client["logs"]["events"];

        std::cout << "events: user_id null:              " << events.count_documents(make_document(kvp("user_id", bsoncxx::types::b_null{}))) << std::endl;
        std::cout << "events: user_id нет:               " << events.count_documents(make_document(kvp("user_id", make_document(kvp("$exists", false))))) << std::endl;
        std::cout << "events: user_id $type null:        " << events.count_documents(make_document(kvp("user_id", make_document(kvp("$type", "null"))))) << std::endl;
        std::cout << "resumes: ready_to_move null:       " << resumes.count_documents(make_document(kvp("ready_to_move", bsoncxx::types::b_null{}))) << std::endl;
        std::cout << "resumes: ready_to_move $type null: " << resumes.count_documents(make_document(kvp("ready_to_move", make_document(kvp("$type", "null"))))) << std::endl;
    }
}
