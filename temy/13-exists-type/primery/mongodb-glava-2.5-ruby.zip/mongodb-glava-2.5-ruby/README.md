# Глава 2.5 · Есть ли поле: $exists и $type — примеры на Ruby

Архив к «Справочнику по MongoDB»: все примеры главы готовыми программами, учебные базы и стенд в Docker.
Глава: https://maximbytecamp.github.io/mongodb_theory_makarov/temy/13-exists-type/index.html

Язык: **Ruby** · драйвер gem mongo 2.21 · сервер MongoDB 7.

## Что в архиве

```text
mongodb-glava-2.5-ruby/
  README.md         эта инструкция
  primery/          примеры главы — по программе на пример
    01.rb … 07.rb
  compose.yaml      стенд в Docker: сервер, базы, mongo-express, Ruby
  docker/           образ с драйвером Ruby и скрипт запуска run.sh
  stend/seed/       учебные данные: 12 файлов JSON
  stend/load.ps1    загрузка данных на установленный сервер — Windows
  stend/load.sh     то же — macOS и Linux
```

## Порядок работы

1. **Базы.** Глава **меняет песочницу** — базу `sandbox`. Перед первым примером верните базы в исходное состояние, иначе числа в выводах разойдутся с книгой. Команда сброса — в описании способа, которым вы пользуетесь.
2. **Примеры — по порядку, каждый один раз.** Пример в главе рассчитан на данные, которые оставил
   предыдущий. Если запустить пример дважды или пропустить, числа разойдутся с книгой — тогда
   сбросьте базы и начните с `01.rb`.
3. **Сверка.** Что должна напечатать каждая программа — в разделе «Примеры и выводы» ниже.
   Отличаться могут только `_id`, которые выдаёт сервер, текущие дата и время и порядок
   в списке коллекций: сервер отдаёт их имена в произвольном порядке. У документа, который
   создан обновлением с `upsert`, поля тоже могут идти в другом порядке — значения при этом те же.

Подойдёт любой из двух способов. Адрес сервера в обоих — `mongodb://localhost:27017`, код примеров
одинаковый.

| Способ | Что нужно | Когда подходит |
|---|---|---|
| **1. Docker** | Docker Desktop | Compass и сервер не установились или не подключаются; ничего, кроме Docker, ставить не нужно |
| **2. Сервер и Compass** | MongoDB Server, Compass, Ruby с драйвером | сервер и Compass уже стоят и подключаются |

## Способ 1. Docker

Docker Desktop — с [docker.com](https://www.docker.com/products/docker-desktop/); на Linux — Docker Engine.
Перед командами Docker Desktop должен быть запущен. Команды одинаковые в PowerShell, cmd и терминале
macOS/Linux; выполняйте их **из папки архива** — там, где лежит `compose.yaml`.

1. Поднять сервер и загрузить учебные базы:

   ```bash
   docker compose up -d
   ```

2. Вернуть базы в исходное состояние — глава меняет песочницу:

   ```bash
   docker compose run --rm reset
   ```

3. Запустить пример — путь к файлу пишется от папки архива:

   ```bash
   docker compose run --rm ruby primery/01.rb
   ```

   При первом запуске Docker соберёт образ с драйвером Ruby — это пара минут.
   Дальше запуск идёт за секунды.

4. Все примеры главы подряд, по порядку, одной командой:

   ```bash
   docker compose run --rm ruby primery
   ```

   Перед каждой программой печатается её имя: `── primery/01.rb ──`.

**Смотреть данные.** Compass не нужен: в браузере откройте http://localhost:8081, логин `student`,
пароль `student` — это mongo-express, в нём видны базы, коллекции и документы. Если Compass
установлен, он подключается к этому же серверу по адресу `mongodb://localhost:27017`.

**Консоль сервера:** `docker compose exec mongo mongosh`.

**Остановить и удалить:**

```bash
docker compose stop        # остановить; данные останутся
docker compose down        # удалить контейнеры; данные останутся
docker compose down -v     # удалить всё вместе с данными
```

Архивы всех глав пользуются одним и тем же сервером и данными: после этой главы можно распаковать
архив следующей и работать там, не удаляя стенд.

## Способ 2. Установленный сервер MongoDB и Compass

Нужны MongoDB Server 7 или 8 и MongoDB Compass — установка по шагам в
[главе 1.0а](https://maximbytecamp.github.io/mongodb_theory_makarov/temy/00a-windows-10-mongodb-7/index.html).
Проверка: Compass подключается к `mongodb://localhost:27017`.

### Шаг 1. Загрузить учебные базы

Windows, PowerShell, из папки архива — нужен `mongoimport` из MongoDB Command Line Database Tools:

```powershell
powershell -ExecutionPolicy Bypass -File stend\load.ps1
```

macOS и Linux (`mongoimport`: `brew tap mongodb/brew && brew install mongodb-database-tools`):

```bash
bash stend/load.sh
```

Скрипт пересоздаёт коллекции целиком, поэтому он же сбрасывает базы: повторный запуск ничего не двоит.

**Без `mongoimport` — через Compass.** Подключитесь к `mongodb://localhost:27017`, нажмите **Create database**,
затем в коллекции **Add data → Import JSON or CSV file** и выберите файл из `stend/seed`. Имя файла
подсказывает, куда класть: `shop.orders.json` — база `shop`, коллекция `orders`. Так загружаются все
12 файлов; пошагово с кадрами — [глава 1.0, §7](https://maximbytecamp.github.io/mongodb_theory_makarov/temy/00-uchebnye-bazy/index.html#s7).

**Сброс в Compass.** Главы меняют только песочницу, поэтому достаточно пересоздать её: у базы `sandbox`
в левой панели нажмите **⋯ → Drop database**, затем создайте базу `sandbox` заново и импортируйте в неё
`sandbox.products.json` (коллекция `products`) и `sandbox.warehouse.json` (коллекция `warehouse`).
Импорт в непустую коллекцию документы не заменяет — поэтому сначала удаление.

После загрузки в Compass нажмите **Refresh**: в списке должны быть базы `shop`, `hh`, `logs`, `org`
и `sandbox`. В `shop.products` — 21 документ, в `shop.orders` — 120.

### Шаг 2. Драйвер Ruby и запуск

Ruby 3.3. На Windows — с [rubyinstaller.org](https://rubyinstaller.org/downloads/), сборка
**with Devkit**: драйверу нужен компилятор для расширения `bson`. На последнем экране установщика оставьте
галочку **Run 'ridk install'** и в окне MSYS2 выберите пункт 3.

Windows, PowerShell:

```powershell
gem install mongo -v 2.21.0
cd primery
ruby 01.rb
```

macOS и Linux (на Linux сначала `sudo apt install ruby-full build-essential`):

```bash
gem install --user-install mongo -v 2.21.0
cd primery
ruby 01.rb
```

Остальные примеры запускаются так же: `02.rb`, `03.rb` и далее. Если сервер слушает другой адрес,
задайте его переменной `MONGO_URI` — программы глав 1.2–1.8 читают её при подключении.

## Примеры и выводы

| Файл | Параграф главы | Что делает |
|---|---|---|
| `01.rb` | §1 $exists: есть ли поле | есть ли поле в документе |
| `02.rb` | §2 $exists вместе с отрицанием | отрицание без документов без поля |
| `03.rb` | §3 null и отсутствующее поле | null и отсутствующее поле |
| `04.rb` | §4 $type: тип значения | тип значения поля |
| `05.rb` | §5 $type и поле-массив | $type и поле-массив |
| `06.rb` | §6 Значение не того типа | цена, записанная строкой |
| `07.rb` | §6 Значение не того типа | цена исправлена |

### 01.rb · §1 $exists: есть ли поле

Есть ли поле в документе.

```text
есть portfolio:     2
есть courses:       1
есть ready_to_move: 8
нет ready_to_move:  1
{"fio"=>"Алина Дроздова", "portfolio"=>"https://github.com/example/drozdova"}
{"fio"=>"Марк Ефремов", "portfolio"=>"https://github.com/example/efremov"}
```

### 02.rb · §2 $exists вместе с отрицанием

Отрицание без документов без поля.

```text
ready_to_move $ne true:     5
то же и поле есть:          4
уровень не СПО и поле есть: 4
```

### 03.rb · §3 null и отсутствующее поле

Null и отсутствующее поле.

```text
events: user_id null:              591
events: user_id нет:               0
events: user_id $type null:        591
resumes: ready_to_move null:       1
resumes: ready_to_move $type null: 0
```

### 04.rb · §4 $type: тип значения

Тип значения поля.

```text
resumes: salary число:      9
resumes: salary документ:   0
vacancies: salary документ: 8
vacancies: salary число:    0
```

### 05.rb · §5 $type и поле-массив

$type и поле-массив.

```text
experience массив: 8
skills массив:     9
skills строка:     9
skills не массив:  0
```

### 06.rb · §6 Значение не того типа

Цена, записанная строкой.

```text
цена строкой:    1
цена больше 500: 21
{"_id"=>"p-201", "title"=>"Кабель USB-C 2 м", "price"=>"790"}
```

### 07.rb · §6 Значение не того типа

Цена исправлена.

```text
цена строкой:    0
цена больше 500: 22
```

## Частые ошибки

| Что видно | Причина | Что сделать |
|---|---|---|
| `port is already allocated`, `address already in use` на `docker compose up -d` | порт 27017 занят: уже работает установленный MongoDB или стенд `mongodb-practice` | остановите тот сервер или создайте рядом с `compose.yaml` файл `.env` со строкой `MONGO_PORT=27018`: в PowerShell — `Set-Content .env "MONGO_PORT=27018"`, в bash — `echo "MONGO_PORT=27018" > .env`. Программы в Docker это не затрагивает, Compass подключайте к `localhost:27018` |
| `Cannot connect to the Docker daemon`, `error during connect` | Docker Desktop не запущен | запустите Docker Desktop и дождитесь зелёного статуса Engine running |
| `ServerSelectionTimeoutError`, `Connection refused`, `No server available` | сервер не запущен | Docker: `docker compose up -d`; способ 2 — запустите службу MongoDB |
| `Файл не найден: …` | путь написан не от папки архива или команда выполнена в другой папке | перейдите в папку, где лежит `compose.yaml`, и пишите путь `primery/01.rb` |
| числа в выводе не совпадают с README | пример запускали дважды, пропустили или базы не сброшены | сбросьте базы и запустите примеры с первого по порядку |

В PowerShell не используйте `echo … > .env`: Windows PowerShell 5 пишет такой файл в UTF-16, и Docker
Compose его не прочитает.
