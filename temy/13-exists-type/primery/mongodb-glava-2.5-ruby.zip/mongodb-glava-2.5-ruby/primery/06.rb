# Глава 2.5 · Есть ли поле: $exists и $type
# Пример 6 из 7 · §6 Значение не того типа · цена, записанная строкой
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/06.rb
#   cd primery, затем ruby 06.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
# товар из веб-формы: цена пришла текстом и так и записана
box.insert_one({ "_id" => "p-201",
                 "title" => "Кабель USB-C 2 м",
                 "category" => "аксессуары",
                 "price" => "790" })

puts "цена строкой:    " + box.count_documents({ "price" => { "$type" => "string" } }).to_s
puts "цена больше 500: " + box.count_documents({ "price" => { "$gt" => 500 } }).to_s

box.find({ "price" => { "$type" => "string" } }, projection: { "title" => 1, "price" => 1 })
   .each { |doc| puts doc.inspect }
