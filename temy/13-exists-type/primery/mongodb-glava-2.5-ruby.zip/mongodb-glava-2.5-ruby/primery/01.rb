# Глава 2.5 · Есть ли поле: $exists и $type
# Пример 1 из 7 · §1 $exists: есть ли поле · есть ли поле в документе
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/01.rb
#   cd primery, затем ruby 01.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
puts "есть portfolio:     " + resumes.count_documents({ "portfolio" => { "$exists" => true } }).to_s
puts "есть courses:       " + resumes.count_documents({ "courses" => { "$exists" => true } }).to_s
puts "есть ready_to_move: " + resumes.count_documents({ "ready_to_move" => { "$exists" => true } }).to_s
puts "нет ready_to_move:  " + resumes.count_documents({ "ready_to_move" => { "$exists" => false } }).to_s

resumes.find({ "portfolio" => { "$exists" => true } }, projection: { "_id" => 0, "fio" => 1, "portfolio" => 1 })
       .each { |doc| puts doc.inspect }
