# Глава 2.5 · Есть ли поле: $exists и $type
# Пример 4 из 7 · §4 $type: тип значения · тип значения поля
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/04.rb
#   cd primery, затем ruby 04.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
puts "resumes: salary число:      " + resumes.count_documents({ "salary" => { "$type" => "number" } }).to_s
puts "resumes: salary документ:   " + resumes.count_documents({ "salary" => { "$type" => "object" } }).to_s
puts "vacancies: salary документ: " + vacancies.count_documents({ "salary" => { "$type" => "object" } }).to_s
puts "vacancies: salary число:    " + vacancies.count_documents({ "salary" => { "$type" => "number" } }).to_s
