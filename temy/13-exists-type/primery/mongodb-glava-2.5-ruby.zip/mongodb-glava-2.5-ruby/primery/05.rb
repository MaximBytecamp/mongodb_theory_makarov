# Глава 2.5 · Есть ли поле: $exists и $type
# Пример 5 из 7 · §5 $type и поле-массив · $type и поле-массив
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/05.rb
#   cd primery, затем ruby 05.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
puts "experience массив: " + resumes.count_documents({ "experience" => { "$type" => "array" } }).to_s
puts "skills массив:     " + resumes.count_documents({ "skills" => { "$type" => "array" } }).to_s
puts "skills строка:     " + resumes.count_documents({ "skills" => { "$type" => "string" } }).to_s
puts "skills не массив:  " + resumes.count_documents({ "skills" => { "$not" => { "$type" => "array" } } }).to_s
