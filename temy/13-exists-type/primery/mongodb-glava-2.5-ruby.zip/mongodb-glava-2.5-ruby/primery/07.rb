# Глава 2.5 · Есть ли поле: $exists и $type
# Пример 7 из 7 · §6 Значение не того типа · цена исправлена
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/07.rb
#   cd primery, затем ruby 07.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
box.update_one({ "_id" => "p-201" }, { "$set" => { "price" => 790 } })

puts "цена строкой:    " + box.count_documents({ "price" => { "$type" => "string" } }).to_s
puts "цена больше 500: " + box.count_documents({ "price" => { "$gt" => 500 } }).to_s
