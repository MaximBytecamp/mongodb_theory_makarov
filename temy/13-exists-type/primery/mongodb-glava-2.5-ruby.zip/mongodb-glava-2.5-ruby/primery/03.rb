# Глава 2.5 · Есть ли поле: $exists и $type
# Пример 3 из 7 · §3 null и отсутствующее поле · null и отсутствующее поле
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/03.rb
#   cd primery, затем ruby 03.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
events = client.use("logs").database[:events]

puts "events: user_id null:              " + events.count_documents({ "user_id" => nil }).to_s
puts "events: user_id нет:               " + events.count_documents({ "user_id" => { "$exists" => false } }).to_s
puts "events: user_id $type null:        " + events.count_documents({ "user_id" => { "$type" => "null" } }).to_s
puts "resumes: ready_to_move null:       " + resumes.count_documents({ "ready_to_move" => nil }).to_s
puts "resumes: ready_to_move $type null: " + resumes.count_documents({ "ready_to_move" => { "$type" => "null" } }).to_s
