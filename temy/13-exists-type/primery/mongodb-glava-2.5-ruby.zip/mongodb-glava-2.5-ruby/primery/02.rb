# Глава 2.5 · Есть ли поле: $exists и $type
# Пример 2 из 7 · §2 $exists вместе с отрицанием · отрицание без документов без поля
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/02.rb
#   cd primery, затем ruby 02.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
puts "ready_to_move $ne true:     " + resumes.count_documents({ "ready_to_move" => { "$ne" => true } }).to_s
puts "то же и поле есть:          " + resumes.count_documents({ "ready_to_move" => { "$ne" => true, "$exists" => true } }).to_s
puts "уровень не СПО и поле есть: " + resumes.count_documents({ "education.level" => { "$nin" => ["СПО"], "$exists" => true } }).to_s
