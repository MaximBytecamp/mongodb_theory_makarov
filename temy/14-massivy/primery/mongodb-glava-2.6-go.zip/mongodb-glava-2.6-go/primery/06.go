//go:build ignore

// Глава 2.6 · Массивы: $all, $elemMatch, $size
// Пример 6 из 6 · §6 Элемент по номеру · элемент по номеру
//
// Запуск из папки архива:
//   docker compose run --rm go primery/06.go
//   cd primery, затем go run 06.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("hh")
	resumes := db.Collection("resumes")
	vacancies := db.Collection("vacancies")
	companies := db.Collection("companies")
	interviews := db.Collection("interviews")
	box := client.Database("sandbox").Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, resumes, vacancies, companies, interviews, box

	{
		// ── пример из главы ──────────────────────────────────────
		pervyy, _ := resumes.CountDocuments(ctx, bson.D{{Key: "skills.0", Value: "Python"}})
		neMenshe4, _ := resumes.CountDocuments(ctx, bson.D{{Key: "skills.3", Value: bson.D{{Key: "$exists", Value: true}}}})
		neMenshe5, _ := resumes.CountDocuments(ctx, bson.D{{Key: "skills.4", Value: bson.D{{Key: "$exists", Value: true}}}})

		fmt.Println("первый навык Python:", pervyy)
		fmt.Println("навыков не меньше 4:", neMenshe4)
		fmt.Println("навыков не меньше 5:", neMenshe5)

		cursor, _ := resumes.Find(ctx, bson.D{{Key: "skills.0", Value: "Python"}},
		    options.Find().SetProjection(bson.D{{Key: "_id", Value: 0}, {Key: "fio", Value: 1}, {Key: "skills", Value: 1}}))
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}
	}
}
