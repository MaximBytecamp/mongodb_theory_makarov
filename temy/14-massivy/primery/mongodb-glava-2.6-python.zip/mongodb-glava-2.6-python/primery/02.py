# Глава 2.6 · Массивы: $all, $elemMatch, $size
# Пример 2 из 6 · §2 $all: все значения из списка · все навыки из списка
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
print("$all [Python, SQL]:", resumes.count_documents({"skills": {"$all": ["Python", "SQL"]}}))
print("$in [Python, SQL]: ", resumes.count_documents({"skills": {"$in": ["Python", "SQL"]}}))

for doc in resumes.find({"skills": {"$all": ["Python", "SQL"]}}, {"_id": 0, "fio": 1, "skills": 1}):
    print(doc)
