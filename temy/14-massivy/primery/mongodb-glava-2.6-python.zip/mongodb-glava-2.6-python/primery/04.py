# Глава 2.6 · Массивы: $all, $elemMatch, $size
# Пример 4 из 6 · §4 $elemMatch: один элемент — все условия · $elemMatch: оба условия в одном элементе
#
# Запуск из папки архива:
#   docker compose run --rm python primery/04.py
#   cd primery, затем python 04.py (Windows) или python3 04.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
filtr = {"experience": {"$elemMatch": {"role": "стажёр", "months": {"$gte": 6}}}}

for doc in resumes.find(filtr, {"_id": 0, "fio": 1, "experience": 1}):
    print(doc)
