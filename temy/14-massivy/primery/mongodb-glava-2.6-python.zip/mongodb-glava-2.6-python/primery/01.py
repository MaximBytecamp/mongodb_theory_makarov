# Глава 2.6 · Массивы: $all, $elemMatch, $size
# Пример 1 из 6 · §1 Что уже известно о массивах · элемент массива и массив целиком
#
# Запуск из папки архива:
#   docker compose run --rm python primery/01.py
#   cd primery, затем python 01.py (Windows) или python3 01.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
print("среди навыков Python:      ", resumes.count_documents({"skills": "Python"}))
print("навыки ровно [Python, Git]:", resumes.count_documents({"skills": ["Python", "Git"]}))
print("навыки ровно [Git, Python]:", resumes.count_documents({"skills": ["Git", "Python"]}))
