# Глава 2.6 · Массивы: $all, $elemMatch, $size
# Пример 5 из 6 · §5 $size: длина массива · длина массива
#
# Запуск из папки архива:
#   docker compose run --rm python primery/05.py
#   cd primery, затем python 05.py (Windows) или python3 05.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
print("навыков ровно 4:", resumes.count_documents({"skills": {"$size": 4}}))
print("навыков ровно 5:", resumes.count_documents({"skills": {"$size": 5}}))
print("мест работы 0:  ", resumes.count_documents({"experience": {"$size": 0}}))
print("мест работы 2:  ", resumes.count_documents({"experience": {"$size": 2}}))
