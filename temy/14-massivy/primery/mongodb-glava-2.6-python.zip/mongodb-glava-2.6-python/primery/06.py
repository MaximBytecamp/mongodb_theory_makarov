# Глава 2.6 · Массивы: $all, $elemMatch, $size
# Пример 6 из 6 · §6 Элемент по номеру · элемент по номеру
#
# Запуск из папки архива:
#   docker compose run --rm python primery/06.py
#   cd primery, затем python 06.py (Windows) или python3 06.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
print("первый навык Python:", resumes.count_documents({"skills.0": "Python"}))
print("навыков не меньше 4:", resumes.count_documents({"skills.3": {"$exists": True}}))
print("навыков не меньше 5:", resumes.count_documents({"skills.4": {"$exists": True}}))

for doc in resumes.find({"skills.0": "Python"}, {"_id": 0, "fio": 1, "skills": 1}):
    print(doc)
