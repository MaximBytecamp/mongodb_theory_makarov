// Глава 2.6 · Массивы: $all, $elemMatch, $size
// Пример 5 из 6 · §5 $size: длина массива · длина массива
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/05.cpp
//   cd primery, затем g++ -std=c++17 05.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["hh"];
    auto resumes = db["resumes"];
    auto vacancies = db["vacancies"];
    auto companies = db["companies"];
    auto interviews = db["interviews"];
    auto box = client["sandbox"]["products"];   // песочница: здесь можно менять

    {
        // ── пример из главы ──────────────────────────────────────
        std::cout << "навыков ровно 4: " << resumes.count_documents(make_document(kvp("skills", make_document(kvp("$size", 4))))) << std::endl;
        std::cout << "навыков ровно 5: " << resumes.count_documents(make_document(kvp("skills", make_document(kvp("$size", 5))))) << std::endl;
        std::cout << "мест работы 0:   " << resumes.count_documents(make_document(kvp("experience", make_document(kvp("$size", 0))))) << std::endl;
        std::cout << "мест работы 2:   " << resumes.count_documents(make_document(kvp("experience", make_document(kvp("$size", 2))))) << std::endl;
    }
}
