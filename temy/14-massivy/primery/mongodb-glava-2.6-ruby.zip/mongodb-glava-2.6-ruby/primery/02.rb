# Глава 2.6 · Массивы: $all, $elemMatch, $size
# Пример 2 из 6 · §2 $all: все значения из списка · все навыки из списка
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/02.rb
#   cd primery, затем ruby 02.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
puts "$all [Python, SQL]: " + resumes.count_documents({ "skills" => { "$all" => ["Python", "SQL"] } }).to_s
puts "$in [Python, SQL]:  " + resumes.count_documents({ "skills" => { "$in" => ["Python", "SQL"] } }).to_s

resumes.find({ "skills" => { "$all" => ["Python", "SQL"] } }, projection: { "_id" => 0, "fio" => 1, "skills" => 1 })
       .each { |doc| puts doc.inspect }
