# Глава 2.6 · Массивы: $all, $elemMatch, $size
# Пример 1 из 6 · §1 Что уже известно о массивах · элемент массива и массив целиком
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/01.rb
#   cd primery, затем ruby 01.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
puts "среди навыков Python:       " + resumes.count_documents({ "skills" => "Python" }).to_s
puts "навыки ровно [Python, Git]: " + resumes.count_documents({ "skills" => ["Python", "Git"] }).to_s
puts "навыки ровно [Git, Python]: " + resumes.count_documents({ "skills" => ["Git", "Python"] }).to_s
