# Глава 2.6 · Массивы: $all, $elemMatch, $size
# Пример 6 из 6 · §6 Элемент по номеру · элемент по номеру
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/06.rb
#   cd primery, затем ruby 06.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
puts "первый навык Python: " + resumes.count_documents({ "skills.0" => "Python" }).to_s
puts "навыков не меньше 4: " + resumes.count_documents({ "skills.3" => { "$exists" => true } }).to_s
puts "навыков не меньше 5: " + resumes.count_documents({ "skills.4" => { "$exists" => true } }).to_s

resumes.find({ "skills.0" => "Python" }, projection: { "_id" => 0, "fio" => 1, "skills" => 1 })
       .each { |doc| puts doc.inspect }
