# Глава 2.6 · Массивы: $all, $elemMatch, $size
# Пример 5 из 6 · §5 $size: длина массива · длина массива
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/05.rb
#   cd primery, затем ruby 05.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
puts "навыков ровно 4: " + resumes.count_documents({ "skills" => { "$size" => 4 } }).to_s
puts "навыков ровно 5: " + resumes.count_documents({ "skills" => { "$size" => 5 } }).to_s
puts "мест работы 0:   " + resumes.count_documents({ "experience" => { "$size" => 0 } }).to_s
puts "мест работы 2:   " + resumes.count_documents({ "experience" => { "$size" => 2 } }).to_s
