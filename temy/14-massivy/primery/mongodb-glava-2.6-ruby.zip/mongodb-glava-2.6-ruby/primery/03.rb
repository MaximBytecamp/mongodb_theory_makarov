# Глава 2.6 · Массивы: $all, $elemMatch, $size
# Пример 3 из 6 · §3 Два условия на массив документов · два условия на массив документов
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/03.rb
#   cd primery, затем ruby 03.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
filtr = { "experience.role" => "стажёр",
          "experience.months" => { "$gte" => 6 } }

resumes.find(filtr, projection: { "_id" => 0, "fio" => 1, "experience" => 1 })
       .each { |doc| puts doc.inspect }
