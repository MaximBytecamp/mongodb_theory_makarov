# Глава 2.6 · Массивы: $all, $elemMatch, $size — примеры на Ruby

Архив к «Справочнику по MongoDB»: все примеры главы готовыми программами, учебные базы и стенд в Docker.
Глава: https://maximbytecamp.github.io/mongodb_theory_makarov/temy/14-massivy/index.html

Язык: **Ruby** · драйвер gem mongo 2.21 · сервер MongoDB 7.

## Что в архиве

```text
mongodb-glava-2.6-ruby/
  README.md         эта инструкция
  primery/          примеры главы — по программе на пример
    01.rb … 06.rb
  compose.yaml      стенд в Docker: сервер, базы, mongo-express, Ruby
  docker/           образ с драйвером Ruby и скрипт запуска run.sh
  stend/seed/       учебные данные: 12 файлов JSON
  stend/load.ps1    загрузка данных на установленный сервер — Windows
  stend/load.sh     то же — macOS и Linux
```

## Порядок работы

1. **Базы.** Глава **только читает** данные — сбрасывать базы не нужно.
2. **Примеры — по порядку, каждый один раз.** Пример в главе рассчитан на данные, которые оставил
   предыдущий. Если запустить пример дважды или пропустить, числа разойдутся с книгой — тогда
   сбросьте базы и начните с `01.rb`.
3. **Сверка.** Что должна напечатать каждая программа — в разделе «Примеры и выводы» ниже.
   Отличаться могут только `_id`, которые выдаёт сервер, текущие дата и время и порядок
   в списке коллекций: сервер отдаёт их имена в произвольном порядке. У документа, который
   создан обновлением с `upsert`, поля тоже могут идти в другом порядке — значения при этом те же.

Подойдёт любой из двух способов. Адрес сервера в обоих — `mongodb://localhost:27017`, код примеров
одинаковый.

| Способ | Что нужно | Когда подходит |
|---|---|---|
| **1. Docker** | Docker Desktop | Compass и сервер не установились или не подключаются; ничего, кроме Docker, ставить не нужно |
| **2. Сервер и Compass** | MongoDB Server, Compass, Ruby с драйвером | сервер и Compass уже стоят и подключаются |

## Способ 1. Docker

Docker Desktop — с [docker.com](https://www.docker.com/products/docker-desktop/); на Linux — Docker Engine.
Перед командами Docker Desktop должен быть запущен. Команды одинаковые в PowerShell, cmd и терминале
macOS/Linux; выполняйте их **из папки архива** — там, где лежит `compose.yaml`.

1. Поднять сервер и загрузить учебные базы:

   ```bash
   docker compose up -d
   ```

2. Запустить пример — путь к файлу пишется от папки архива:

   ```bash
   docker compose run --rm ruby primery/01.rb
   ```

   При первом запуске Docker соберёт образ с драйвером Ruby — это пара минут.
   Дальше запуск идёт за секунды.

3. Все примеры главы подряд, по порядку, одной командой:

   ```bash
   docker compose run --rm ruby primery
   ```

   Перед каждой программой печатается её имя: `── primery/01.rb ──`.

**Смотреть данные.** Compass не нужен: в браузере откройте http://localhost:8081, логин `student`,
пароль `student` — это mongo-express, в нём видны базы, коллекции и документы. Если Compass
установлен, он подключается к этому же серверу по адресу `mongodb://localhost:27017`.

**Консоль сервера:** `docker compose exec mongo mongosh`.

**Остановить и удалить:**

```bash
docker compose stop        # остановить; данные останутся
docker compose down        # удалить контейнеры; данные останутся
docker compose down -v     # удалить всё вместе с данными
```

Архивы всех глав пользуются одним и тем же сервером и данными: после этой главы можно распаковать
архив следующей и работать там, не удаляя стенд.

## Способ 2. Установленный сервер MongoDB и Compass

Нужны MongoDB Server 7 или 8 и MongoDB Compass — установка по шагам в
[главе 1.0а](https://maximbytecamp.github.io/mongodb_theory_makarov/temy/00a-windows-10-mongodb-7/index.html).
Проверка: Compass подключается к `mongodb://localhost:27017`.

### Шаг 1. Загрузить учебные базы

Windows, PowerShell, из папки архива — нужен `mongoimport` из MongoDB Command Line Database Tools:

```powershell
powershell -ExecutionPolicy Bypass -File stend\load.ps1
```

macOS и Linux (`mongoimport`: `brew tap mongodb/brew && brew install mongodb-database-tools`):

```bash
bash stend/load.sh
```

Скрипт пересоздаёт коллекции целиком, поэтому он же сбрасывает базы: повторный запуск ничего не двоит.

**Без `mongoimport` — через Compass.** Подключитесь к `mongodb://localhost:27017`, нажмите **Create database**,
затем в коллекции **Add data → Import JSON or CSV file** и выберите файл из `stend/seed`. Имя файла
подсказывает, куда класть: `shop.orders.json` — база `shop`, коллекция `orders`. Так загружаются все
12 файлов; пошагово с кадрами — [глава 1.0, §7](https://maximbytecamp.github.io/mongodb_theory_makarov/temy/00-uchebnye-bazy/index.html#s7).

После загрузки в Compass нажмите **Refresh**: в списке должны быть базы `shop`, `hh`, `logs`, `org`
и `sandbox`. В `shop.products` — 21 документ, в `shop.orders` — 120.

### Шаг 2. Драйвер Ruby и запуск

Ruby 3.3. На Windows — с [rubyinstaller.org](https://rubyinstaller.org/downloads/), сборка
**with Devkit**: драйверу нужен компилятор для расширения `bson`. На последнем экране установщика оставьте
галочку **Run 'ridk install'** и в окне MSYS2 выберите пункт 3.

Windows, PowerShell:

```powershell
gem install mongo -v 2.21.0
cd primery
ruby 01.rb
```

macOS и Linux (на Linux сначала `sudo apt install ruby-full build-essential`):

```bash
gem install --user-install mongo -v 2.21.0
cd primery
ruby 01.rb
```

Остальные примеры запускаются так же: `02.rb`, `03.rb` и далее. Если сервер слушает другой адрес,
задайте его переменной `MONGO_URI` — программы глав 1.2–1.8 читают её при подключении.

## Примеры и выводы

| Файл | Параграф главы | Что делает |
|---|---|---|
| `01.rb` | §1 Что уже известно о массивах | элемент массива и массив целиком |
| `02.rb` | §2 $all: все значения из списка | все навыки из списка |
| `03.rb` | §3 Два условия на массив документов | два условия на массив документов |
| `04.rb` | §4 $elemMatch: один элемент — все условия | $elemMatch: оба условия в одном элементе |
| `05.rb` | §5 $size: длина массива | длина массива |
| `06.rb` | §6 Элемент по номеру | элемент по номеру |

### 01.rb · §1 Что уже известно о массивах

Элемент массива и массив целиком.

```text
среди навыков Python:       6
навыки ровно [Python, Git]: 1
навыки ровно [Git, Python]: 0
```

### 02.rb · §2 $all: все значения из списка

Все навыки из списка.

```text
$all [Python, SQL]: 4
$in [Python, SQL]:  6
{"fio"=>"Пётр Ковалёв", "skills"=>["Python", "SQL", "Git", "Docker"]}
{"fio"=>"Алина Дроздова", "skills"=>["SQL", "Python", "ClickHouse", "Power BI", "Excel"]}
{"fio"=>"Ксения Лапина", "skills"=>["Postman", "SQL", "Selenium", "Python"]}
{"fio"=>"Ольга Пирогова", "skills"=>["SQL", "Excel", "Python", "ClickHouse"]}
```

### 03.rb · §3 Два условия на массив документов

Два условия на массив документов.

```text
{"fio"=>"Пётр Ковалёв", "experience"=>[{"company"=>"ИП Сорокин", "role"=>"стажёр", "months"=>6, "stack"=>["Python", "PostgreSQL"]}]}
{"fio"=>"Алина Дроздова", "experience"=>[{"company"=>"Ozon", "role"=>"младший аналитик", "months"=>14, "stack"=>["ClickHouse", "Python"]}, {"company"=>"Retail Lab", "role"=>"стажёр", "months"=>5, "stack"=>["SQL"]}]}
```

### 04.rb · §4 $elemMatch: один элемент — все условия

$elemMatch: оба условия в одном элементе.

```text
{"fio"=>"Пётр Ковалёв", "experience"=>[{"company"=>"ИП Сорокин", "role"=>"стажёр", "months"=>6, "stack"=>["Python", "PostgreSQL"]}]}
```

### 05.rb · §5 $size: длина массива

Длина массива.

```text
навыков ровно 4: 6
навыков ровно 5: 2
мест работы 0:   1
мест работы 2:   2
```

### 06.rb · §6 Элемент по номеру

Элемент по номеру.

```text
первый навык Python: 3
навыков не меньше 4: 8
навыков не меньше 5: 2
{"fio"=>"Анна Белова", "skills"=>["Python", "Git"]}
{"fio"=>"Пётр Ковалёв", "skills"=>["Python", "SQL", "Git", "Docker"]}
{"fio"=>"Марк Ефремов", "skills"=>["Python", "FastAPI", "MongoDB", "Git"]}
```

## Частые ошибки

| Что видно | Причина | Что сделать |
|---|---|---|
| `port is already allocated`, `address already in use` на `docker compose up -d` | порт 27017 занят: уже работает установленный MongoDB или стенд `mongodb-practice` | остановите тот сервер или создайте рядом с `compose.yaml` файл `.env` со строкой `MONGO_PORT=27018`: в PowerShell — `Set-Content .env "MONGO_PORT=27018"`, в bash — `echo "MONGO_PORT=27018" > .env`. Программы в Docker это не затрагивает, Compass подключайте к `localhost:27018` |
| `Cannot connect to the Docker daemon`, `error during connect` | Docker Desktop не запущен | запустите Docker Desktop и дождитесь зелёного статуса Engine running |
| `ServerSelectionTimeoutError`, `Connection refused`, `No server available` | сервер не запущен | Docker: `docker compose up -d`; способ 2 — запустите службу MongoDB |
| `Файл не найден: …` | путь написан не от папки архива или команда выполнена в другой папке | перейдите в папку, где лежит `compose.yaml`, и пишите путь `primery/01.rb` |
| числа в выводе не совпадают с README | пример запускали дважды, пропустили или базы не сброшены | сбросьте базы и запустите примеры с первого по порядку |

В PowerShell не используйте `echo … > .env`: Windows PowerShell 5 пишет такой файл в UTF-16, и Docker
Compose его не прочитает.
