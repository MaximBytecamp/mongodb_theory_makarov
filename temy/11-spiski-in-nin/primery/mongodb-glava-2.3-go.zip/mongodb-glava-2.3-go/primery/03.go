//go:build ignore

// Глава 2.3 · Списки значений: $in и $nin
// Пример 3 из 7 · §3 $in и поле-массив · хотя бы один навык из списка
//
// Запуск из папки архива:
//   docker compose run --rm go primery/03.go
//   cd primery, затем go run 03.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("hh")
	resumes := db.Collection("resumes")
	vacancies := db.Collection("vacancies")
	companies := db.Collection("companies")
	interviews := db.Collection("interviews")
	box := client.Database("sandbox").Collection("products") // песочница: здесь можно менять
	_, _, _, _, _, _ = db, resumes, vacancies, companies, interviews, box

	{
		// ── пример из главы ──────────────────────────────────────
		cursor, _ := resumes.Find(ctx, bson.D{{Key: "skills", Value: bson.D{{Key: "$in", Value: bson.A{"MongoDB", "ClickHouse"}}}}},
		    options.Find().SetProjection(bson.D{{Key: "_id", Value: 0}, {Key: "fio", Value: 1}, {Key: "skills", Value: 1}}))
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}
	}
}
