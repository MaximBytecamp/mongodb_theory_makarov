# Глава 2.3 · Списки значений: $in и $nin
# Пример 2 из 7 · §2 Порядок результата · вакансии по списку ключей
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/02.rb
#   cd primery, затем ruby 02.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
vacancies.find({ "_id" => { "$in" => ["v-008", "v-001"] } }, projection: { "title" => 1 })
         .each { |doc| puts doc.inspect }
