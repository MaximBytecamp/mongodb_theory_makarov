# Глава 2.3 · Списки значений: $in и $nin
# Пример 6 из 7 · §6 null в списке · null в списке значений
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/06.rb
#   cd primery, затем ruby 06.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
puts "ready_to_move null:              " + resumes.count_documents({ "ready_to_move" => nil }).to_s
puts "ready_to_move $in [false, null]: " + resumes.count_documents({ "ready_to_move" => { "$in" => [false, nil] } }).to_s
