# Глава 2.3 · Списки значений: $in и $nin
# Пример 4 из 7 · §4 $nin: ни одного из значений · ни одного значения из списка
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/04.rb
#   cd primery, затем ruby 04.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
puts "вакансии не в Москве и не в Ярославле: " + vacancies.count_documents({ "city" => { "$nin" => ["Москва", "Ярославль"] } }).to_s

resumes.find({ "skills" => { "$nin" => ["Python", "SQL"] } }, projection: { "_id" => 0, "fio" => 1, "skills" => 1 })
       .each { |doc| puts doc.inspect }
