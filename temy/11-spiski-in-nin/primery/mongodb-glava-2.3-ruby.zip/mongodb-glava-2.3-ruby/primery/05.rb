# Глава 2.3 · Списки значений: $in и $nin
# Пример 5 из 7 · §5 $nin и отсутствующее поле · $nin и отсутствующее поле
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/05.rb
#   cd primery, затем ruby 05.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
puts "education.level $nin [СПО]: " + resumes.count_documents({ "education.level" => { "$nin" => ["СПО"] } }).to_s
puts "education.level Высшее:     " + resumes.count_documents({ "education.level" => "Высшее" }).to_s

resumes.find({ "education.level" => { "$nin" => ["СПО"] } }, projection: { "_id" => 0, "fio" => 1, "education.level" => 1 })
       .each { |doc| puts doc.inspect }
