# Глава 2.3 · Списки значений: $in и $nin
# Пример 1 из 7 · §1 $in: одно из значений · вакансии в Москве или Казани
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/01.rb
#   cd primery, затем ruby 01.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
vacancies.find({ "city" => { "$in" => ["Москва", "Казань"] } }, projection: { "_id" => 0, "title" => 1, "city" => 1 })
         .each { |doc| puts doc.inspect }
