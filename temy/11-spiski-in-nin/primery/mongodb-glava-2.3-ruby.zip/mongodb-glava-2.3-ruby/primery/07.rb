# Глава 2.3 · Списки значений: $in и $nin
# Пример 7 из 7 · §7 Пустой список · пустой список
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/07.rb
#   cd primery, затем ruby 07.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
puts "$in []:  " + vacancies.count_documents({ "city" => { "$in" => [] } }).to_s
puts "$nin []: " + vacancies.count_documents({ "city" => { "$nin" => [] } }).to_s
