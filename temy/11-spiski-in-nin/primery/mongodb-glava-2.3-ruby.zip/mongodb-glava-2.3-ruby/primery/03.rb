# Глава 2.3 · Списки значений: $in и $nin
# Пример 3 из 7 · §3 $in и поле-массив · хотя бы один навык из списка
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/03.rb
#   cd primery, затем ruby 03.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("hh").database
resumes = db[:resumes]
vacancies = db[:vacancies]
companies = db[:companies]
interviews = db[:interviews]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
resumes.find({ "skills" => { "$in" => ["MongoDB", "ClickHouse"] } }, projection: { "_id" => 0, "fio" => 1, "skills" => 1 })
       .each { |doc| puts doc.inspect }
