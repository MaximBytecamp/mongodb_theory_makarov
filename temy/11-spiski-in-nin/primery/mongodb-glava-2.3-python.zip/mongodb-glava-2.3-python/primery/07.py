# Глава 2.3 · Списки значений: $in и $nin
# Пример 7 из 7 · §7 Пустой список · пустой список
#
# Запуск из папки архива:
#   docker compose run --rm python primery/07.py
#   cd primery, затем python 07.py (Windows) или python3 07.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
print("$in []: ", vacancies.count_documents({"city": {"$in": []}}))
print("$nin []:", vacancies.count_documents({"city": {"$nin": []}}))
