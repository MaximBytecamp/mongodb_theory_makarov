# Глава 2.3 · Списки значений: $in и $nin
# Пример 2 из 7 · §2 Порядок результата · вакансии по списку ключей
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
for doc in vacancies.find({"_id": {"$in": ["v-008", "v-001"]}}, {"title": 1}):
    print(doc)
