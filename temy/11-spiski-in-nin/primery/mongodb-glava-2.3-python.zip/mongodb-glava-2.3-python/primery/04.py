# Глава 2.3 · Списки значений: $in и $nin
# Пример 4 из 7 · §4 $nin: ни одного из значений · ни одного значения из списка
#
# Запуск из папки архива:
#   docker compose run --rm python primery/04.py
#   cd primery, затем python 04.py (Windows) или python3 04.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
print("вакансии не в Москве и не в Ярославле:", vacancies.count_documents({"city": {"$nin": ["Москва", "Ярославль"]}}))

for doc in resumes.find({"skills": {"$nin": ["Python", "SQL"]}}, {"_id": 0, "fio": 1, "skills": 1}):
    print(doc)
