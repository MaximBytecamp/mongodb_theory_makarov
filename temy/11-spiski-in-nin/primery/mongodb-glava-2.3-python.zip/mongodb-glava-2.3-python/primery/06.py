# Глава 2.3 · Списки значений: $in и $nin
# Пример 6 из 7 · §6 null в списке · null в списке значений
#
# Запуск из папки архива:
#   docker compose run --rm python primery/06.py
#   cd primery, затем python 06.py (Windows) или python3 06.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
print("ready_to_move null:             ", resumes.count_documents({"ready_to_move": None}))
print("ready_to_move $in [false, null]:", resumes.count_documents({"ready_to_move": {"$in": [False, None]}}))
