# Глава 2.3 · Списки значений: $in и $nin
# Пример 1 из 7 · §1 $in: одно из значений · вакансии в Москве или Казани
#
# Запуск из папки архива:
#   docker compose run --rm python primery/01.py
#   cd primery, затем python 01.py (Windows) или python3 01.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
for doc in vacancies.find({"city": {"$in": ["Москва", "Казань"]}}, {"_id": 0, "title": 1, "city": 1}):
    print(doc)
