# Глава 2.3 · Списки значений: $in и $nin
# Пример 5 из 7 · §5 $nin и отсутствующее поле · $nin и отсутствующее поле
#
# Запуск из папки архива:
#   docker compose run --rm python primery/05.py
#   cd primery, затем python 05.py (Windows) или python3 05.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
print("education.level $nin [СПО]:", resumes.count_documents({"education.level": {"$nin": ["СПО"]}}))
print("education.level Высшее:    ", resumes.count_documents({"education.level": "Высшее"}))

for doc in resumes.find({"education.level": {"$nin": ["СПО"]}}, {"_id": 0, "fio": 1, "education.level": 1}):
    print(doc)
