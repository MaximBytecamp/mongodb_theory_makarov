# Глава 2.3 · Списки значений: $in и $nin
# Пример 3 из 7 · §3 $in и поле-массив · хотя бы один навык из списка
#
# Запуск из папки архива:
#   docker compose run --rm python primery/03.py
#   cd primery, затем python 03.py (Windows) или python3 03.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["hh"]
resumes = db["resumes"]
vacancies = db["vacancies"]
companies = db["companies"]
interviews = db["interviews"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
for doc in resumes.find({"skills": {"$in": ["MongoDB", "ClickHouse"]}}, {"_id": 0, "fio": 1, "skills": 1}):
    print(doc)
