//go:build ignore

// Глава 4.4 · $group и аккумуляторы
// Пример 8 из 8 · §8 Ошибки записи $group · поле без аккумулятора и группа без _id
//
// Запуск из папки архива:
//   docker compose run --rm go primery/08.go
//   cd primery, затем go run 08.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"
	"strings"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = strings.Join
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────

// show — у каждого документа поля fields в строку через « | »; вложенные — через точку.
func show(cursor *mongo.Cursor, fields ...string) {
	ctx := context.Background()
	count := 0
	for cursor.Next(ctx) {
		cells := make([]string, len(fields))
		for i, path := range fields {
			value, err := cursor.Current.LookupErr(strings.Split(path, ".")...)
			switch {
			case err != nil || value.Type == bson.TypeNull:
				cells[i] = "—"
			case value.Type == bson.TypeString:
				cells[i] = value.StringValue()
			case value.Type == bson.TypeInt32:
				cells[i] = fmt.Sprint(value.Int32())
			case value.Type == bson.TypeInt64:
				cells[i] = fmt.Sprint(value.Int64())
			case value.Type == bson.TypeDouble:
				cells[i] = fmt.Sprint(value.Double())
			case value.Type == bson.TypeBoolean:
				cells[i] = fmt.Sprint(value.Boolean())
			case value.Type == bson.TypeDateTime:
				cells[i] = value.Time().UTC().Format("2006-01-02 15:04")
			default:
				cells[i] = value.String()
			}
		}
		fmt.Println(strings.Join(cells, " | "))
		count++
	}
	fmt.Println("документов:", count)
}

var ce mongo.CommandError

func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	orders := db.Collection("orders")
	products := db.Collection("products")
	customers := db.Collection("customers")
	sandbox := client.Database("sandbox")
	_, _, _, _, _ = db, orders, products, customers, sandbox

	{
		// ── пример из главы ──────────────────────────────────────
		noAccumulator := mongo.Pipeline{
		    {{Key: "$group", Value: bson.D{
		        {Key: "_id", Value: "$delivery.city"},
		        {Key: "city", Value: "$delivery.city"}}}},
		}

		noId := mongo.Pipeline{
		    {{Key: "$group", Value: bson.D{{Key: "orders", Value: bson.D{{Key: "$sum", Value: 1}}}}}},
		}

		fmt.Println("── поле без аккумулятора")
		_, err := orders.Aggregate(ctx, noAccumulator)
		if errors.As(err, &ce) {
		    fmt.Println("код", ce.Code)
		    fmt.Println(ce.Message)
		}

		fmt.Println("── группа без _id")
		_, err = orders.Aggregate(ctx, noId)
		if errors.As(err, &ce) {
		    fmt.Println("код", ce.Code)
		    fmt.Println(ce.Message)
		}
	}
}
