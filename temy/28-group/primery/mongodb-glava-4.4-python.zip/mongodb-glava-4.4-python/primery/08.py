# Глава 4.4 · $group и аккумуляторы
# Пример 8 из 8 · §8 Ошибки записи $group · поле без аккумулятора и группа без _id
#
# Запуск из папки архива:
#   docker compose run --rm python primery/08.py
#   cd primery, затем python 08.py (Windows) или python3 08.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

from datetime import datetime


def show(docs, *fields):
    """Печатает у каждого документа поля fields в строку через « | »; вложенные — через точку."""
    count = 0
    for doc in docs:
        cells = []
        for path in fields:
            value = doc
            for key in path.split("."):
                value = value.get(key) if isinstance(value, dict) else None
            if isinstance(value, datetime):
                value = value.strftime("%Y-%m-%d %H:%M")
            if isinstance(value, bool):
                value = str(value).lower()
            cells.append("—" if value is None else str(value))
        print(" | ".join(cells))
        count += 1
    print("документов:", count)

# ── пример из главы ───────────────────────────────────────────
from pymongo.errors import OperationFailure

no_accumulator = [
    {"$group": {"_id": "$delivery.city", "city": "$delivery.city"}},
]

no_id = [
    {"$group": {"orders": {"$sum": 1}}},
]

print("── поле без аккумулятора")
try:
    for doc in orders.aggregate(no_accumulator):
        print(doc)
except OperationFailure as e:
    print("код", e.code)
    print(e.details["errmsg"])

print("── группа без _id")
try:
    for doc in orders.aggregate(no_id):
        print(doc)
except OperationFailure as e:
    print("код", e.code)
    print(e.details["errmsg"])
