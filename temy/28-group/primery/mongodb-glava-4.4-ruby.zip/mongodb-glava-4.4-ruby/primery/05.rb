# Глава 4.4 · $group и аккумуляторы
# Пример 5 из 8 · §5 $match до $group · $match до $group
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/05.rb
#   cd primery, затем ruby 05.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# Печатает у каждого документа поля fields в строку через « | »; вложенные — через точку.
def show(docs, *fields)
  count = 0
  docs.each do |doc|
    cells = fields.map do |path|
      value = path.split(".").reduce(doc) { |v, key| v.is_a?(Hash) ? v[key] : nil }
      value = value.utc.strftime("%Y-%m-%d %H:%M") if value.is_a?(Time)
      value.nil? ? "—" : value.to_s
    end
    puts cells.join(" | ")
    count += 1
  end
  puts "документов: #{count}"
end

# ── пример из главы ───────────────────────────────────────────
all_orders = [
  { "$group" => { "_id" => "$delivery.city", "revenue" => { "$sum" => "$total" } } },
  { "$sort" => { "_id" => 1 } },
]

only_delivered = [
  { "$match" => { "status" => "доставлен" } },
  { "$group" => { "_id" => "$delivery.city", "revenue" => { "$sum" => "$total" } } },
  { "$sort" => { "_id" => 1 } },
]

puts "── все заказы"
orders.aggregate(all_orders).each { |doc| puts doc.inspect }

puts "── только доставленные"
orders.aggregate(only_delivered).each { |doc| puts doc.inspect }
