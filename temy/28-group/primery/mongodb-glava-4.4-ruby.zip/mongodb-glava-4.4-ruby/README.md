# Глава 4.4 · $group и аккумуляторы — примеры на Ruby

Архив к «Справочнику по MongoDB»: все примеры главы готовыми программами, данные баз и стенд в Docker.
Глава: https://maximbytecamp.github.io/mongodb_theory_makarov/temy/28-group/index.html

Язык: **Ruby** · драйвер gem mongo 2.21 · сервер MongoDB 7.

## Что в архиве

```text
mongodb-glava-4.4-ruby/
  README.md         эта инструкция
  primery/          примеры главы — по программе на пример
    01.rb … 08.rb
  compose.yaml      стенд в Docker: сервер, базы, mongo-express, Ruby
  docker/           образ с драйвером Ruby и скрипт запуска run.sh
  stend/seed/       данные баз: 12 файлов JSON
  stend/load.ps1    загрузка данных на установленный сервер — Windows
  stend/load.sh     то же — macOS и Linux
```

## Порядок работы

1. **Базы.** Глава **только читает** данные — сбрасывать базы не нужно.
2. **Примеры — по порядку, каждый один раз.** Пример в главе рассчитан на данные, которые оставил
   предыдущий. Если запустить пример дважды или пропустить, числа разойдутся с книгой — тогда
   сбросьте базы и начните с `01.rb`.
3. **Сверка.** Что должна напечатать каждая программа — в разделе «Примеры и выводы» ниже.
   Отличаться могут только `_id`, которые выдаёт сервер, текущие дата и время и порядок
   в списке коллекций: сервер отдаёт их имена в произвольном порядке. У документа, который
   создан обновлением с `upsert`, поля тоже могут идти в другом порядке — значения при этом те же.

Подойдёт любой из двух способов. Адрес сервера в обоих — `mongodb://localhost:27017`, код примеров
одинаковый.

| Способ | Что нужно | Когда подходит |
|---|---|---|
| **1. Docker** | Docker Desktop | Compass и сервер не установились или не подключаются; ничего, кроме Docker, ставить не нужно |
| **2. Сервер и Compass** | MongoDB Server, Compass, Ruby с драйвером | сервер и Compass уже стоят и подключаются |

## Способ 1. Docker

Docker Desktop — с [docker.com](https://www.docker.com/products/docker-desktop/); на Linux — Docker Engine.
Перед командами Docker Desktop должен быть запущен. Команды одинаковые в PowerShell, cmd и терминале
macOS/Linux; выполняйте их **из папки архива** — там, где лежит `compose.yaml`.

1. Поднять сервер и загрузить базы курса:

   ```bash
   docker compose up -d
   ```

2. Запустить пример — путь к файлу пишется от папки архива:

   ```bash
   docker compose run --rm ruby primery/01.rb
   ```

   При первом запуске Docker соберёт образ с драйвером Ruby — это пара минут.
   Дальше запуск идёт за секунды.

3. Все примеры главы подряд, по порядку, одной командой:

   ```bash
   docker compose run --rm ruby primery
   ```

   Перед каждой программой печатается её имя: `── primery/01.rb ──`.

**Смотреть данные.** Compass не нужен: в браузере откройте http://localhost:8081, логин `student`,
пароль `student` — это mongo-express, в нём видны базы, коллекции и документы. Если Compass
установлен, он подключается к этому же серверу по адресу `mongodb://localhost:27017`.

**Консоль сервера:** `docker compose exec mongo mongosh`.

**Остановить и удалить:**

```bash
docker compose stop        # остановить; данные останутся
docker compose down        # удалить контейнеры; данные останутся
docker compose down -v     # удалить всё вместе с данными
```

Архивы всех глав пользуются одним и тем же сервером и данными: после этой главы можно распаковать
архив следующей и работать там, не удаляя стенд.

## Способ 2. Установленный сервер MongoDB и Compass

Нужны MongoDB Server 7 или 8 и MongoDB Compass — установка по шагам в
[главе 1.0а](https://maximbytecamp.github.io/mongodb_theory_makarov/temy/00a-windows-10-mongodb-7/index.html).
Проверка: Compass подключается к `mongodb://localhost:27017`.

### Шаг 1. Загрузить базы курса

Windows, PowerShell, из папки архива — нужен `mongoimport` из MongoDB Command Line Database Tools:

```powershell
powershell -ExecutionPolicy Bypass -File stend\load.ps1
```

macOS и Linux (`mongoimport`: `brew tap mongodb/brew && brew install mongodb-database-tools`):

```bash
bash stend/load.sh
```

Скрипт пересоздаёт коллекции целиком, поэтому он же сбрасывает базы: повторный запуск ничего не двоит.

**Без `mongoimport` — через Compass.** Подключитесь к `mongodb://localhost:27017`, нажмите **Create database**,
затем в коллекции **Add data → Import JSON or CSV file** и выберите файл из `stend/seed`. Имя файла
подсказывает, куда класть: `shop.orders.json` — база `shop`, коллекция `orders`. Так загружаются все
12 файлов; пошагово с кадрами — [глава 1.0, §7](https://maximbytecamp.github.io/mongodb_theory_makarov/temy/00-uchebnye-bazy/index.html#s7).

После загрузки в Compass нажмите **Refresh**: в списке должны быть базы `shop`, `hh`, `logs`, `org`
и `sandbox`. В `shop.products` — 21 документ, в `shop.orders` — 120.

### Шаг 2. Драйвер Ruby и запуск

Ruby 3.3. На Windows — с [rubyinstaller.org](https://rubyinstaller.org/downloads/), сборка
**with Devkit**: драйверу нужен компилятор для расширения `bson`. На последнем экране установщика оставьте
галочку **Run 'ridk install'** и в окне MSYS2 выберите пункт 3.

Windows, PowerShell:

```powershell
gem install mongo -v 2.21.0
cd primery
ruby 01.rb
```

macOS и Linux (на Linux сначала `sudo apt install ruby-full build-essential`):

```bash
gem install --user-install mongo -v 2.21.0
cd primery
ruby 01.rb
```

Остальные примеры запускаются так же: `02.rb`, `03.rb` и далее. Если сервер слушает другой адрес,
задайте его переменной `MONGO_URI` — программы глав 1.2–1.8 читают её при подключении.

## Примеры и выводы

| Файл | Параграф главы | Что делает |
|---|---|---|
| `01.rb` | §1 Стадия $group | доставленные заказы по городам |
| `02.rb` | §2 Одна группа на все документы | одна группа: _id null |
| `03.rb` | §3 $avg, $min и $max | $avg, $min и $max |
| `04.rb` | §4 Ключ из двух полей | ключ из двух полей |
| `05.rb` | §5 $match до $group | $match до $group |
| `06.rb` | §6 $match после $group | $match после $group |
| `07.rb` | §7 Аккумулятор по строковому полю | $sum и $avg по строкам |
| `08.rb` | §8 Ошибки записи $group | поле без аккумулятора и группа без _id |

### 01.rb · §1 Стадия $group

Доставленные заказы по городам.

```text
{"_id"=>"Екатеринбург", "orders"=>16, "revenue"=>1390470}
{"_id"=>"Москва", "orders"=>12, "revenue"=>1387760}
{"_id"=>"Новосибирск", "orders"=>17, "revenue"=>2536840}
{"_id"=>"Санкт-Петербург", "orders"=>10, "revenue"=>1169540}
{"_id"=>"Ярославль", "orders"=>14, "revenue"=>2048020}
```

### 02.rb · §2 Одна группа на все документы

Одна группа: _id null.

```text
{"_id"=>nil, "orders"=>69, "revenue"=>8532630}
```

### 03.rb · §3 $avg, $min и $max

$avg, $min и $max.

```text
{"_id"=>"Екатеринбург", "min"=>2370, "max"=>295960, "avg"=>86904.0}
{"_id"=>"Москва", "min"=>13560, "max"=>289360, "avg"=>115647.0}
{"_id"=>"Новосибирск", "min"=>2370, "max"=>354960, "avg"=>149226.0}
{"_id"=>"Санкт-Петербург", "min"=>16980, "max"=>320740, "avg"=>116954.0}
{"_id"=>"Ярославль", "min"=>5980, "max"=>392660, "avg"=>146287.0}
```

### 04.rb · §4 Ключ из двух полей

Ключ из двух полей.

```text
{"_id"=>{"city"=>"Москва", "type"=>"курьер"}, "orders"=>4, "revenue"=>713970}
{"_id"=>{"city"=>"Москва", "type"=>"почта"}, "orders"=>1, "revenue"=>13560}
{"_id"=>{"city"=>"Москва", "type"=>"пункт выдачи"}, "orders"=>7, "revenue"=>660230}
{"_id"=>{"city"=>"Ярославль", "type"=>"курьер"}, "orders"=>2, "revenue"=>212340}
{"_id"=>{"city"=>"Ярославль", "type"=>"почта"}, "orders"=>3, "revenue"=>316870}
{"_id"=>{"city"=>"Ярославль", "type"=>"пункт выдачи"}, "orders"=>9, "revenue"=>1518810}
```

### 05.rb · §5 $match до $group

$match до $group.

```text
── все заказы
{"_id"=>"Екатеринбург", "revenue"=>3618120}
{"_id"=>"Москва", "revenue"=>2447770}
{"_id"=>"Новосибирск", "revenue"=>4371990}
{"_id"=>"Санкт-Петербург", "revenue"=>1975570}
{"_id"=>"Ярославль", "revenue"=>2972860}
── только доставленные
{"_id"=>"Екатеринбург", "revenue"=>1390470}
{"_id"=>"Москва", "revenue"=>1387760}
{"_id"=>"Новосибирск", "revenue"=>2536840}
{"_id"=>"Санкт-Петербург", "revenue"=>1169540}
{"_id"=>"Ярославль", "revenue"=>2048020}
```

### 06.rb · §6 $match после $group

$match после $group.

```text
{"_id"=>"Новосибирск", "revenue"=>2536840}
{"_id"=>"Ярославль", "revenue"=>2048020}
```

### 07.rb · §7 Аккумулятор по строковому полю

$sum и $avg по строкам.

```text
{"_id"=>nil, "sum"=>0, "avg"=>nil}
```

### 08.rb · §8 Ошибки записи $group

Поле без аккумулятора и группа без _id.

```text
── поле без аккумулятора
код 40234
The field 'city' must be an accumulator object
── группа без _id
код 15955
a group specification must include an _id
```

## Частые ошибки

| Что видно | Причина | Что сделать |
|---|---|---|
| `port is already allocated`, `address already in use` на `docker compose up -d` | порт 27017 занят: уже работает установленный MongoDB или стенд `mongodb-practice` | остановите тот сервер или создайте рядом с `compose.yaml` файл `.env` со строкой `MONGO_PORT=27018`: в PowerShell — `Set-Content .env "MONGO_PORT=27018"`, в bash — `echo "MONGO_PORT=27018" > .env`. Программы в Docker это не затрагивает, Compass подключайте к `localhost:27018` |
| `Cannot connect to the Docker daemon`, `error during connect` | Docker Desktop не запущен | запустите Docker Desktop и дождитесь зелёного статуса Engine running |
| `ServerSelectionTimeoutError`, `Connection refused`, `No server available` | сервер не запущен | Docker: `docker compose up -d`; способ 2 — запустите службу MongoDB |
| `Файл не найден: …` | путь написан не от папки архива или команда выполнена в другой папке | перейдите в папку, где лежит `compose.yaml`, и пишите путь `primery/01.rb` |
| числа в выводе не совпадают с README | пример запускали дважды, пропустили или базы не сброшены | сбросьте базы и запустите примеры с первого по порядку |

В PowerShell не используйте `echo … > .env`: Windows PowerShell 5 пишет такой файл в UTF-16, и Docker
Compose его не прочитает.
