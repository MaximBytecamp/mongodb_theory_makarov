# Глава 6.2 · $lookup с конвейером
# Пример 4 из 7 · §4 Итоги внутри $lookup · три покупателя с наибольшей суммой покупок
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/04.rb
#   cd primery, затем ruby 04.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$lookup" => {
    "from" => "orders",
    "localField" => "_id",
    "foreignField" => "customer_id",
    "pipeline" => [
      { "$match" => { "status" => "доставлен" } },
      { "$group" => {
        "_id" => nil,
        "orders" => { "$sum" => 1 },
        "spent" => { "$sum" => "$total" },
      } },
    ],
    "as" => "stats",
  } },
  { "$unwind" => "$stats" },
  { "$project" => {
    "_id" => 0,
    "name" => 1,
    "orders" => "$stats.orders",
    "spent" => "$stats.spent",
  } },
  { "$sort" => { "spent" => -1 } },
  { "$limit" => 3 },
]

customers.aggregate(pipeline).each { |doc| puts doc.inspect }
