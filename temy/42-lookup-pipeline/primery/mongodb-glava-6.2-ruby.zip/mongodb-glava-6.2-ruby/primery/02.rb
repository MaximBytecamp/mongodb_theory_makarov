# Глава 6.2 · $lookup с конвейером
# Пример 2 из 7 · §2 Поля связи и pipeline вместе · localField, foreignField и pipeline вместе
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/02.rb
#   cd primery, затем ruby 02.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => { "$in" => ["c-001", "c-007", "c-020"] } } },
  { "$lookup" => {
    "from" => "orders",
    "localField" => "_id",
    "foreignField" => "customer_id",
    "pipeline" => [{ "$match" => { "status" => "доставлен" } }],
    "as" => "delivered",
  } },
  { "$project" => { "name" => 1, "count" => { "$size" => "$delivered" } } },
]

customers.aggregate(pipeline).each { |doc| puts doc.inspect }
