# Глава 6.2 · $lookup с конвейером
# Пример 6 из 7 · §6 Связь по двум полям · резюме и вакансии с той же должностью в том же городе
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/06.rb
#   cd primery, затем ruby 06.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$lookup" => {
    "from" => "vacancies",
    "let" => { "pos" => "$position", "city" => "$city" },
    "pipeline" => [
      { "$match" => { "$expr" => { "$and" => [
        { "$eq" => ["$title", "$$pos"] },
        { "$eq" => ["$city", "$$city"] },
      ] } } },
      { "$project" => { "_id" => 0, "company" => 1 } },
    ],
    "as" => "offers",
  } },
  { "$project" => {
    "_id" => 0,
    "fio" => 1,
    "position" => 1,
    "city" => 1,
    "offers" => "$offers.company",
  } },
]

resumes.aggregate(pipeline).each { |doc| puts doc.inspect }
