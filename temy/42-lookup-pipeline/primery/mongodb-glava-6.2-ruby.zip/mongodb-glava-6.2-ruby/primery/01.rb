# Глава 6.2 · $lookup с конвейером
# Пример 1 из 7 · §1 let и pipeline · let и pipeline: доставленные заказы покупателя
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/01.rb
#   cd primery, затем ruby 01.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => { "$in" => ["c-001", "c-007", "c-020"] } } },
  { "$lookup" => {
    "from" => "orders",
    "let" => { "cid" => "$_id" },
    "pipeline" => [
      { "$match" => {
        "$expr" => { "$eq" => ["$customer_id", "$$cid"] },
        "status" => "доставлен",
      } },
      { "$project" => { "_id" => 0, "number" => 1, "total" => 1 } },
    ],
    "as" => "delivered",
  } },
  { "$project" => { "name" => 1, "delivered" => 1 } },
]

customers.aggregate(pipeline).each { |doc| puts doc.inspect }
