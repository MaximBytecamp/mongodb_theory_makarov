# Глава 6.2 · $lookup с конвейером
# Пример 5 из 7 · §5 Конвейер без связи с документом · конвейер без связи: средний чек магазина рядом с покупателем
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/05.rb
#   cd primery, затем ruby 05.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => { "$in" => ["c-001", "c-007", "c-020"] } } },
  { "$lookup" => {
    "from" => "orders",
    "pipeline" => [
      { "$match" => { "status" => "доставлен" } },
      { "$group" => { "_id" => nil, "avg" => { "$avg" => "$total" } } },
      { "$project" => { "_id" => 0, "avg" => { "$round" => ["$avg", 0] } } },
    ],
    "as" => "shop",
  } },
  { "$project" => { "name" => 1, "shop" => 1 } },
]

customers.aggregate(pipeline).each { |doc| puts doc.inspect }
