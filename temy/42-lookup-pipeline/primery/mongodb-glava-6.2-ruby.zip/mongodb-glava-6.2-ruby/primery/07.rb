# Глава 6.2 · $lookup с конвейером
# Пример 7 из 7 · §7 Переменная без $expr · переменная в $match без $expr
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/07.rb
#   cd primery, затем ruby 07.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => "c-001" } },
  { "$lookup" => {
    "from" => "orders",
    "let" => { "cid" => "$_id" },
    "pipeline" => [{ "$match" => { "customer_id" => "$$cid" } }],
    "as" => "wrong",
  } },
  { "$lookup" => {
    "from" => "orders",
    "let" => { "cid" => "$_id" },
    "pipeline" => [
      { "$match" => { "$expr" => { "$eq" => ["$customer_id", "$$cid"] } } },
    ],
    "as" => "right",
  } },
  { "$project" => {
    "_id" => 0,
    "name" => 1,
    "wrong" => { "$size" => "$wrong" },
    "right" => { "$size" => "$right" },
  } },
]

customers.aggregate(pipeline).each { |doc| puts doc.inspect }
