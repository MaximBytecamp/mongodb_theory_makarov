//go:build ignore

// Глава 6.2 · $lookup с конвейером
// Пример 4 из 7 · §4 Итоги внутри $lookup · три покупателя с наибольшей суммой покупок
//
// Запуск из папки архива:
//   docker compose run --rm go primery/04.go
//   cd primery, затем go run 04.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	orders := db.Collection("orders")
	customers := db.Collection("customers")
	products := db.Collection("products")
	hh := client.Database("hh")
	companies := hh.Collection("companies")
	vacancies := hh.Collection("vacancies")
	resumes := hh.Collection("resumes")
	org := client.Database("org")
	employees := org.Collection("employees")
	categories := org.Collection("categories")
	sandbox := client.Database("sandbox")
	_, _, _, _, _, _, _, _, _, _, _, _ = db, orders, customers, products, hh, companies, vacancies, resumes, org, employees, categories, sandbox

	{
		// ── пример из главы ──────────────────────────────────────
		pipeline := mongo.Pipeline{
		    {{Key: "$lookup", Value: bson.D{
		        {Key: "from", Value: "orders"},
		        {Key: "localField", Value: "_id"},
		        {Key: "foreignField", Value: "customer_id"},
		        {Key: "pipeline", Value: bson.A{
		            bson.D{{Key: "$match", Value: bson.D{{Key: "status", Value: "доставлен"}}}},
		            bson.D{
		                {Key: "$group", Value: bson.D{
		                    {Key: "_id", Value: nil},
		                    {Key: "orders", Value: bson.D{{Key: "$sum", Value: 1}}},
		                    {Key: "spent", Value: bson.D{{Key: "$sum", Value: "$total"}}}}}}}},
		        {Key: "as", Value: "stats"}}}},
		    {{Key: "$unwind", Value: "$stats"}},
		    {{Key: "$project", Value: bson.D{
		        {Key: "_id", Value: 0},
		        {Key: "name", Value: 1},
		        {Key: "orders", Value: "$stats.orders"},
		        {Key: "spent", Value: "$stats.spent"}}}},
		    {{Key: "$sort", Value: bson.D{{Key: "spent", Value: -1}}}},
		    {{Key: "$limit", Value: 3}},
		}

		cursor, _ := customers.Aggregate(ctx, pipeline)
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}
	}
}
