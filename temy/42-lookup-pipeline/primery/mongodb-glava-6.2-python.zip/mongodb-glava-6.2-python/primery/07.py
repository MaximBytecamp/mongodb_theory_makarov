# Глава 6.2 · $lookup с конвейером
# Пример 7 из 7 · §7 Переменная без $expr · переменная в $match без $expr
#
# Запуск из папки архива:
#   docker compose run --rm python primery/07.py
#   cd primery, затем python 07.py (Windows) или python3 07.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": "c-001"}},
    {"$lookup": {
        "from": "orders",
        "let": {"cid": "$_id"},
        "pipeline": [{"$match": {"customer_id": "$$cid"}}],
        "as": "wrong",
    }},
    {"$lookup": {
        "from": "orders",
        "let": {"cid": "$_id"},
        "pipeline": [{"$match": {"$expr": {"$eq": ["$customer_id", "$$cid"]}}}],
        "as": "right",
    }},
    {"$project": {
        "_id": 0,
        "name": 1,
        "wrong": {"$size": "$wrong"},
        "right": {"$size": "$right"},
    }},
]

for doc in customers.aggregate(pipeline):
    print(doc)
