# Глава 6.2 · $lookup с конвейером
# Пример 6 из 7 · §6 Связь по двум полям · резюме и вакансии с той же должностью в том же городе
#
# Запуск из папки архива:
#   docker compose run --rm python primery/06.py
#   cd primery, затем python 06.py (Windows) или python3 06.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$lookup": {
        "from": "vacancies",
        "let": {"pos": "$position", "city": "$city"},
        "pipeline": [
            {"$match": {"$expr": {"$and": [
                {"$eq": ["$title", "$$pos"]},
                {"$eq": ["$city", "$$city"]},
            ]}}},
            {"$project": {"_id": 0, "company": 1}},
        ],
        "as": "offers",
    }},
    {"$project": {
        "_id": 0,
        "fio": 1,
        "position": 1,
        "city": 1,
        "offers": "$offers.company",
    }},
]

for doc in resumes.aggregate(pipeline):
    print(doc)
