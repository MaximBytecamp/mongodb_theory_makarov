# Глава 6.2 · $lookup с конвейером
# Пример 4 из 7 · §4 Итоги внутри $lookup · три покупателя с наибольшей суммой покупок
#
# Запуск из папки архива:
#   docker compose run --rm python primery/04.py
#   cd primery, затем python 04.py (Windows) или python3 04.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$lookup": {
        "from": "orders",
        "localField": "_id",
        "foreignField": "customer_id",
        "pipeline": [
            {"$match": {"status": "доставлен"}},
            {"$group": {"_id": None, "orders": {"$sum": 1}, "spent": {"$sum": "$total"}}},
        ],
        "as": "stats",
    }},
    {"$unwind": "$stats"},
    {"$project": {
        "_id": 0,
        "name": 1,
        "orders": "$stats.orders",
        "spent": "$stats.spent",
    }},
    {"$sort": {"spent": -1}},
    {"$limit": 3},
]

for doc in customers.aggregate(pipeline):
    print(doc)
