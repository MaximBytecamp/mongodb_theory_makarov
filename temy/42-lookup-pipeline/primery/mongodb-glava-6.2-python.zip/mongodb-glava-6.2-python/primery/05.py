# Глава 6.2 · $lookup с конвейером
# Пример 5 из 7 · §5 Конвейер без связи с документом · конвейер без связи: средний чек магазина рядом с покупателем
#
# Запуск из папки архива:
#   docker compose run --rm python primery/05.py
#   cd primery, затем python 05.py (Windows) или python3 05.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": {"$in": ["c-001", "c-007", "c-020"]}}},
    {"$lookup": {
        "from": "orders",
        "pipeline": [
            {"$match": {"status": "доставлен"}},
            {"$group": {"_id": None, "avg": {"$avg": "$total"}}},
            {"$project": {"_id": 0, "avg": {"$round": ["$avg", 0]}}},
        ],
        "as": "shop",
    }},
    {"$project": {"name": 1, "shop": 1}},
]

for doc in customers.aggregate(pipeline):
    print(doc)
