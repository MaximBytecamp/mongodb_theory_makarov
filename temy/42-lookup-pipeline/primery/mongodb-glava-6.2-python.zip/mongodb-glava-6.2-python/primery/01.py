# Глава 6.2 · $lookup с конвейером
# Пример 1 из 7 · §1 let и pipeline · let и pipeline: доставленные заказы покупателя
#
# Запуск из папки архива:
#   docker compose run --rm python primery/01.py
#   cd primery, затем python 01.py (Windows) или python3 01.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": {"$in": ["c-001", "c-007", "c-020"]}}},
    {"$lookup": {
        "from": "orders",
        "let": {"cid": "$_id"},
        "pipeline": [
            {"$match": {
                "$expr": {"$eq": ["$customer_id", "$$cid"]},
                "status": "доставлен",
            }},
            {"$project": {"_id": 0, "number": 1, "total": 1}},
        ],
        "as": "delivered",
    }},
    {"$project": {"name": 1, "delivered": 1}},
]

for doc in customers.aggregate(pipeline):
    print(doc)
