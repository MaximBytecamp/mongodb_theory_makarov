# Глава 6.2 · $lookup с конвейером
# Пример 2 из 7 · §2 Поля связи и pipeline вместе · localField, foreignField и pipeline вместе
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": {"$in": ["c-001", "c-007", "c-020"]}}},
    {"$lookup": {
        "from": "orders",
        "localField": "_id",
        "foreignField": "customer_id",
        "pipeline": [{"$match": {"status": "доставлен"}}],
        "as": "delivered",
    }},
    {"$project": {"name": 1, "count": {"$size": "$delivered"}}},
]

for doc in customers.aggregate(pipeline):
    print(doc)
