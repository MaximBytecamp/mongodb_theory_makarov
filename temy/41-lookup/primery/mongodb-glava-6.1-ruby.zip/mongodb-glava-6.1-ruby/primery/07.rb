# Глава 6.1 · $lookup: соединение коллекций
# Пример 7 из 9 · §7 Опечатка в from · в from — коллекция, которой нет
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/07.rb
#   cd primery, затем ruby 07.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => "o-0002" } },
  { "$lookup" => {
    "from" => "customer",
    "localField" => "customer_id",
    "foreignField" => "_id",
    "as" => "customer",
  } },
  { "$project" => { "_id" => 0, "number" => 1, "customer" => 1 } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
