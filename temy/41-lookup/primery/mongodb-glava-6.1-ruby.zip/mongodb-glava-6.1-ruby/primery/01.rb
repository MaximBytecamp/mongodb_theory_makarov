# Глава 6.1 · $lookup: соединение коллекций
# Пример 1 из 9 · §1 Стадия $lookup · $lookup: покупатель заказа
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/01.rb
#   cd primery, затем ruby 01.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => "o-0002" } },
  { "$lookup" => {
    "from" => "customers",
    "localField" => "customer_id",
    "foreignField" => "_id",
    "as" => "customer",
  } },
  { "$project" => {
    "_id" => 0,
    "number" => 1,
    "customer_id" => 1,
    "customer.name" => 1,
    "customer.city" => 1,
    "customer.segment" => 1,
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
