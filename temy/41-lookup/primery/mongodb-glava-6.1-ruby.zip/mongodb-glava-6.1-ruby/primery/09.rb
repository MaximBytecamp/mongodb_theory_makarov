# Глава 6.1 · $lookup: соединение коллекций
# Пример 9 из 9 · §9 Записи, которые сервер не принимает · записи $lookup, которые сервер не принимает
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/09.rb
#   cd primery, затем ruby 09.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
no_as = [
  { "$lookup" => {
    "from" => "customers",
    "localField" => "customer_id",
    "foreignField" => "_id",
  } },
]

other_db = [
  { "$lookup" => {
    "from" => { "db" => "org", "coll" => "employees" },
    "localField" => "customer_id",
    "foreignField" => "_id",
    "as" => "x",
  } },
]

puts "── нет as"
begin
  orders.aggregate(no_as).each { |doc| puts doc.inspect }
rescue Mongo::Error::OperationFailure => e
  puts "код #{e.code}"
  puts e.document["errmsg"]
end

puts "── коллекция другой базы"
begin
  orders.aggregate(other_db).each { |doc| puts doc.inspect }
rescue Mongo::Error::OperationFailure => e
  puts "код #{e.code}"
  puts e.document["errmsg"]
end
