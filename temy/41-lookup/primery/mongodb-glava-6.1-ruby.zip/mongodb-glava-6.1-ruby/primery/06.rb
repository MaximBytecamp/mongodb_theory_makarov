# Глава 6.1 · $lookup: соединение коллекций
# Пример 6 из 9 · §6 Массив в localField · localField — массив: товары позиций заказа
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/06.rb
#   cd primery, затем ruby 06.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => "o-0002" } },
  { "$lookup" => {
    "from" => "products",
    "localField" => "items.sku",
    "foreignField" => "sku",
    "as" => "goods",
  } },
  { "$project" => {
    "_id" => 0,
    "skus" => "$items.sku",
    "goods" => { "$map" => {
      "input" => "$goods",
      "in" => { "sku" => "$$this.sku", "rating" => "$$this.rating" },
    } },
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
