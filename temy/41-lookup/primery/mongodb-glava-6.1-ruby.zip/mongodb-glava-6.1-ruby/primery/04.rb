# Глава 6.1 · $lookup: соединение коллекций
# Пример 4 из 9 · §4 Документы без пары · компании и их вакансии
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/04.rb
#   cd primery, затем ruby 04.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$lookup" => {
    "from" => "vacancies",
    "localField" => "name",
    "foreignField" => "company",
    "as" => "vacancies",
  } },
  { "$project" => {
    "_id" => 0,
    "name" => 1,
    "count" => { "$size" => "$vacancies" },
    "titles" => "$vacancies.title",
  } },
]

companies.aggregate(pipeline).each { |doc| puts doc.inspect }
