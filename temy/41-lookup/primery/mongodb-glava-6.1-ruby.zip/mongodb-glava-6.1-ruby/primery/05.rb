# Глава 6.1 · $lookup: соединение коллекций
# Пример 5 из 9 · §5 $unwind и документы без пары · $unwind после $lookup: куда деваются компании без вакансий
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/05.rb
#   cd primery, затем ruby 05.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
plain = [
  { "$lookup" => {
    "from" => "vacancies",
    "localField" => "name",
    "foreignField" => "company",
    "as" => "vacancies",
  } },
  { "$unwind" => "$vacancies" },
  { "$count" => "docs" },
]

kept = [
  { "$lookup" => {
    "from" => "vacancies",
    "localField" => "name",
    "foreignField" => "company",
    "as" => "vacancies",
  } },
  { "$unwind" => { "path" => "$vacancies", "preserveNullAndEmptyArrays" => true } },
  { "$count" => "docs" },
]

puts "── $lookup и $unwind"
companies.aggregate(plain).each { |doc| puts doc.inspect }

puts "── с preserveNullAndEmptyArrays"
companies.aggregate(kept).each { |doc| puts doc.inspect }
