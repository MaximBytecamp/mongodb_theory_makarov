# Глава 6.1 · $lookup: соединение коллекций
# Пример 8 из 9 · §8 Поле связи отсутствует · поля из localField нет у документа
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/08.rb
#   cd primery, затем ruby 08.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => "c-001" } },
  { "$lookup" => {
    "from" => "orders",
    "localField" => "referrer",
    "foreignField" => "promo",
    "as" => "found",
  } },
  { "$project" => { "_id" => 0, "name" => 1, "found" => { "$size" => "$found" } } },
]

customers.aggregate(pipeline).each { |doc| puts doc.inspect }
