# Глава 6.1 · $lookup: соединение коллекций
# Пример 2 из 9 · §2 Документ вместо массива: $unwind · выручка по сегментам покупателей
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/02.rb
#   cd primery, затем ruby 02.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "status" => "доставлен" } },
  { "$lookup" => {
    "from" => "customers",
    "localField" => "customer_id",
    "foreignField" => "_id",
    "as" => "customer",
  } },
  { "$unwind" => "$customer" },
  { "$group" => {
    "_id" => "$customer.segment",
    "orders" => { "$sum" => 1 },
    "revenue" => { "$sum" => "$total" },
  } },
  { "$sort" => { "revenue" => -1 } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
