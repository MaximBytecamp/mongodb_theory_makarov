# Глава 6.1 · $lookup: соединение коллекций
# Пример 7 из 9 · §7 Опечатка в from · в from — коллекция, которой нет
#
# Запуск из папки архива:
#   docker compose run --rm python primery/07.py
#   cd primery, затем python 07.py (Windows) или python3 07.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": "o-0002"}},
    {"$lookup": {
        "from": "customer",
        "localField": "customer_id",
        "foreignField": "_id",
        "as": "customer",
    }},
    {"$project": {"_id": 0, "number": 1, "customer": 1}},
]

for doc in orders.aggregate(pipeline):
    print(doc)
