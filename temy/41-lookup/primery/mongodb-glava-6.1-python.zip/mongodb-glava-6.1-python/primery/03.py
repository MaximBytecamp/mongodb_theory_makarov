# Глава 6.1 · $lookup: соединение коллекций
# Пример 3 из 9 · §3 Один ко многим · покупатель и все его заказы
#
# Запуск из папки архива:
#   docker compose run --rm python primery/03.py
#   cd primery, затем python 03.py (Windows) или python3 03.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": {"$in": ["c-001", "c-007", "c-020"]}}},
    {"$lookup": {
        "from": "orders",
        "localField": "_id",
        "foreignField": "customer_id",
        "as": "orders",
    }},
    {"$project": {"name": 1, "count": {"$size": "$orders"}, "numbers": "$orders.number"}},
]

for doc in customers.aggregate(pipeline):
    print(doc)
