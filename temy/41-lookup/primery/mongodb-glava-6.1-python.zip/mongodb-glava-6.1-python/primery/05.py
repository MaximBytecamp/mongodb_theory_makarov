# Глава 6.1 · $lookup: соединение коллекций
# Пример 5 из 9 · §5 $unwind и документы без пары · $unwind после $lookup: куда деваются компании без вакансий
#
# Запуск из папки архива:
#   docker compose run --rm python primery/05.py
#   cd primery, затем python 05.py (Windows) или python3 05.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
plain = [
    {"$lookup": {
        "from": "vacancies",
        "localField": "name",
        "foreignField": "company",
        "as": "vacancies",
    }},
    {"$unwind": "$vacancies"},
    {"$count": "docs"},
]

kept = [
    {"$lookup": {
        "from": "vacancies",
        "localField": "name",
        "foreignField": "company",
        "as": "vacancies",
    }},
    {"$unwind": {"path": "$vacancies", "preserveNullAndEmptyArrays": True}},
    {"$count": "docs"},
]

print("── $lookup и $unwind")
for doc in companies.aggregate(plain):
    print(doc)

print("── с preserveNullAndEmptyArrays")
for doc in companies.aggregate(kept):
    print(doc)
