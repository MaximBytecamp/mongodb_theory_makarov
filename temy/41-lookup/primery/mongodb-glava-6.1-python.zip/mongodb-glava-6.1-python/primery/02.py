# Глава 6.1 · $lookup: соединение коллекций
# Пример 2 из 9 · §2 Документ вместо массива: $unwind · выручка по сегментам покупателей
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"status": "доставлен"}},
    {"$lookup": {
        "from": "customers",
        "localField": "customer_id",
        "foreignField": "_id",
        "as": "customer",
    }},
    {"$unwind": "$customer"},
    {"$group": {
        "_id": "$customer.segment",
        "orders": {"$sum": 1},
        "revenue": {"$sum": "$total"},
    }},
    {"$sort": {"revenue": -1}},
]

for doc in orders.aggregate(pipeline):
    print(doc)
