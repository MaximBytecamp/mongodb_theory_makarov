# Глава 6.1 · $lookup: соединение коллекций
# Пример 4 из 9 · §4 Документы без пары · компании и их вакансии
#
# Запуск из папки архива:
#   docker compose run --rm python primery/04.py
#   cd primery, затем python 04.py (Windows) или python3 04.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$lookup": {
        "from": "vacancies",
        "localField": "name",
        "foreignField": "company",
        "as": "vacancies",
    }},
    {"$project": {
        "_id": 0,
        "name": 1,
        "count": {"$size": "$vacancies"},
        "titles": "$vacancies.title",
    }},
]

for doc in companies.aggregate(pipeline):
    print(doc)
