# Глава 6.1 · $lookup: соединение коллекций
# Пример 8 из 9 · §8 Поле связи отсутствует · поля из localField нет у документа
#
# Запуск из папки архива:
#   docker compose run --rm python primery/08.py
#   cd primery, затем python 08.py (Windows) или python3 08.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": "c-001"}},
    {"$lookup": {
        "from": "orders",
        "localField": "referrer",
        "foreignField": "promo",
        "as": "found",
    }},
    {"$project": {"_id": 0, "name": 1, "found": {"$size": "$found"}}},
]

for doc in customers.aggregate(pipeline):
    print(doc)
