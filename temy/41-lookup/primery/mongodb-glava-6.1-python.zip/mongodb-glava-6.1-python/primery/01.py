# Глава 6.1 · $lookup: соединение коллекций
# Пример 1 из 9 · §1 Стадия $lookup · $lookup: покупатель заказа
#
# Запуск из папки архива:
#   docker compose run --rm python primery/01.py
#   cd primery, затем python 01.py (Windows) или python3 01.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": "o-0002"}},
    {"$lookup": {
        "from": "customers",
        "localField": "customer_id",
        "foreignField": "_id",
        "as": "customer",
    }},
    {"$project": {
        "_id": 0,
        "number": 1,
        "customer_id": 1,
        "customer.name": 1,
        "customer.city": 1,
        "customer.segment": 1,
    }},
]

for doc in orders.aggregate(pipeline):
    print(doc)
