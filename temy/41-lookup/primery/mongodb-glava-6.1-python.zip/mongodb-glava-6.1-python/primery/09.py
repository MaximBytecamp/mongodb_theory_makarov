# Глава 6.1 · $lookup: соединение коллекций
# Пример 9 из 9 · §9 Записи, которые сервер не принимает · записи $lookup, которые сервер не принимает
#
# Запуск из папки архива:
#   docker compose run --rm python primery/09.py
#   cd primery, затем python 09.py (Windows) или python3 09.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
from pymongo.errors import OperationFailure

no_as = [
    {"$lookup": {
        "from": "customers",
        "localField": "customer_id",
        "foreignField": "_id",
    }},
]

other_db = [
    {"$lookup": {
        "from": {"db": "org", "coll": "employees"},
        "localField": "customer_id",
        "foreignField": "_id",
        "as": "x",
    }},
]

print("── нет as")
try:
    for doc in orders.aggregate(no_as):
        print(doc)
except OperationFailure as e:
    print("код", e.code)
    print(e.details["errmsg"])

print("── коллекция другой базы")
try:
    for doc in orders.aggregate(other_db):
        print(doc)
except OperationFailure as e:
    print("код", e.code)
    print(e.details["errmsg"])
