//go:build ignore

// Глава 6.1 · $lookup: соединение коллекций
// Пример 5 из 9 · §5 $unwind и документы без пары · $unwind после $lookup: куда деваются компании без вакансий
//
// Запуск из папки архива:
//   docker compose run --rm go primery/05.go
//   cd primery, затем go run 05.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	orders := db.Collection("orders")
	customers := db.Collection("customers")
	products := db.Collection("products")
	hh := client.Database("hh")
	companies := hh.Collection("companies")
	vacancies := hh.Collection("vacancies")
	resumes := hh.Collection("resumes")
	org := client.Database("org")
	employees := org.Collection("employees")
	categories := org.Collection("categories")
	sandbox := client.Database("sandbox")
	_, _, _, _, _, _, _, _, _, _, _, _ = db, orders, customers, products, hh, companies, vacancies, resumes, org, employees, categories, sandbox

	{
		// ── пример из главы ──────────────────────────────────────
		plain := mongo.Pipeline{
		    {{Key: "$lookup", Value: bson.D{
		        {Key: "from", Value: "vacancies"},
		        {Key: "localField", Value: "name"},
		        {Key: "foreignField", Value: "company"},
		        {Key: "as", Value: "vacancies"}}}},
		    {{Key: "$unwind", Value: "$vacancies"}},
		    {{Key: "$count", Value: "docs"}},
		}

		kept := mongo.Pipeline{
		    {{Key: "$lookup", Value: bson.D{
		        {Key: "from", Value: "vacancies"},
		        {Key: "localField", Value: "name"},
		        {Key: "foreignField", Value: "company"},
		        {Key: "as", Value: "vacancies"}}}},
		    {{Key: "$unwind", Value: bson.D{
		        {Key: "path", Value: "$vacancies"},
		        {Key: "preserveNullAndEmptyArrays", Value: true}}}},
		    {{Key: "$count", Value: "docs"}},
		}

		fmt.Println("── $lookup и $unwind")
		cursor, _ := companies.Aggregate(ctx, plain)
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}

		fmt.Println("── с preserveNullAndEmptyArrays")
		cursor, _ = companies.Aggregate(ctx, kept)
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}
	}
}
