//go:build ignore

// Глава 6.1 · $lookup: соединение коллекций
// Пример 9 из 9 · §9 Записи, которые сервер не принимает · записи $lookup, которые сервер не принимает
//
// Запуск из папки архива:
//   docker compose run --rm go primery/09.go
//   cd primery, затем go run 09.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────

var ce mongo.CommandError

func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	orders := db.Collection("orders")
	customers := db.Collection("customers")
	products := db.Collection("products")
	hh := client.Database("hh")
	companies := hh.Collection("companies")
	vacancies := hh.Collection("vacancies")
	resumes := hh.Collection("resumes")
	org := client.Database("org")
	employees := org.Collection("employees")
	categories := org.Collection("categories")
	sandbox := client.Database("sandbox")
	_, _, _, _, _, _, _, _, _, _, _, _ = db, orders, customers, products, hh, companies, vacancies, resumes, org, employees, categories, sandbox

	{
		// ── пример из главы ──────────────────────────────────────
		noAs := mongo.Pipeline{
		    {{Key: "$lookup", Value: bson.D{
		        {Key: "from", Value: "customers"},
		        {Key: "localField", Value: "customer_id"},
		        {Key: "foreignField", Value: "_id"}}}},
		}

		otherDb := mongo.Pipeline{
		    {{Key: "$lookup", Value: bson.D{
		        {Key: "from", Value: bson.D{{Key: "db", Value: "org"}, {Key: "coll", Value: "employees"}}},
		        {Key: "localField", Value: "customer_id"},
		        {Key: "foreignField", Value: "_id"},
		        {Key: "as", Value: "x"}}}},
		}

		fmt.Println("── нет as")
		_, err := orders.Aggregate(ctx, noAs)
		if errors.As(err, &ce) {
		    fmt.Println("код", ce.Code)
		    fmt.Println(ce.Message)
		}

		fmt.Println("── коллекция другой базы")
		_, err = orders.Aggregate(ctx, otherDb)
		if errors.As(err, &ce) {
		    fmt.Println("код", ce.Code)
		    fmt.Println(ce.Message)
		}
	}
}
