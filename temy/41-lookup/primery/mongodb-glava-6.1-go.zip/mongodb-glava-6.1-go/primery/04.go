//go:build ignore

// Глава 6.1 · $lookup: соединение коллекций
// Пример 4 из 9 · §4 Документы без пары · компании и их вакансии
//
// Запуск из папки архива:
//   docker compose run --rm go primery/04.go
//   cd primery, затем go run 04.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = errors.New
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	orders := db.Collection("orders")
	customers := db.Collection("customers")
	products := db.Collection("products")
	hh := client.Database("hh")
	companies := hh.Collection("companies")
	vacancies := hh.Collection("vacancies")
	resumes := hh.Collection("resumes")
	org := client.Database("org")
	employees := org.Collection("employees")
	categories := org.Collection("categories")
	sandbox := client.Database("sandbox")
	_, _, _, _, _, _, _, _, _, _, _, _ = db, orders, customers, products, hh, companies, vacancies, resumes, org, employees, categories, sandbox

	{
		// ── пример из главы ──────────────────────────────────────
		pipeline := mongo.Pipeline{
		    {{Key: "$lookup", Value: bson.D{
		        {Key: "from", Value: "vacancies"},
		        {Key: "localField", Value: "name"},
		        {Key: "foreignField", Value: "company"},
		        {Key: "as", Value: "vacancies"}}}},
		    {{Key: "$project", Value: bson.D{
		        {Key: "_id", Value: 0},
		        {Key: "name", Value: 1},
		        {Key: "count", Value: bson.D{{Key: "$size", Value: "$vacancies"}}},
		        {Key: "titles", Value: "$vacancies.title"}}}},
		}

		cursor, _ := companies.Aggregate(ctx, pipeline)
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}
	}
}
