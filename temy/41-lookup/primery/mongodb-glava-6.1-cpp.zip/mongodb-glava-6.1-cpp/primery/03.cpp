// Глава 6.1 · $lookup: соединение коллекций
// Пример 3 из 9 · §3 Один ко многим · покупатель и все его заказы
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/03.cpp
//   cd primery, затем g++ -std=c++17 03.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto orders = db["orders"];
    auto customers = db["customers"];
    auto products = db["products"];
    auto hh = client["hh"];
    auto companies = hh["companies"];
    auto vacancies = hh["vacancies"];
    auto resumes = hh["resumes"];
    auto org = client["org"];
    auto employees = org["employees"];
    auto categories = org["categories"];
    auto sandbox = client["sandbox"];

    {
        // ── пример из главы ──────────────────────────────────────
        mongocxx::pipeline pipeline;
        pipeline.match(make_document(
            kvp("_id", make_document(kvp("$in", make_array("c-001", "c-007", "c-020"))))));
        pipeline.lookup(make_document(
            kvp("from", "orders"),
            kvp("localField", "_id"),
            kvp("foreignField", "customer_id"),
            kvp("as", "orders")));
        pipeline.project(make_document(
            kvp("name", 1),
            kvp("count", make_document(kvp("$size", "$orders"))),
            kvp("numbers", "$orders.number")));

        for (auto&& doc : customers.aggregate(pipeline)) {
            std::cout << bsoncxx::to_json(doc, bsoncxx::ExtendedJsonMode::k_relaxed) << std::endl;
        }
    }
}
