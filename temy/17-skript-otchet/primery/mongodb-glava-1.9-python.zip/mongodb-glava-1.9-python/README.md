# Глава 1.9 · Скрипт целиком: отчёт по магазину — примеры на Python

Архив к «Справочнику по MongoDB»: все примеры главы готовыми программами, учебные базы и стенд в Docker.
Глава: https://maximbytecamp.github.io/mongodb_theory_makarov/temy/17-skript-otchet/index.html

Язык: **Python** · драйвер PyMongo · сервер MongoDB 7.

## Что в архиве

```text
mongodb-glava-1.9-python/
  README.md         эта инструкция
  primery/          примеры главы — по программе на пример
    01.py … 01.py
  compose.yaml      стенд в Docker: сервер, базы, mongo-express, Python
  docker/           образ с драйвером Python и скрипт запуска run.sh
  stend/seed/       учебные данные: 12 файлов JSON
  stend/load.ps1    загрузка данных на установленный сервер — Windows
  stend/load.sh     то же — macOS и Linux
requirements.txt  драйвер PyMongo для pip и для образа Docker
```

## Порядок работы

1. **Базы.** Глава **меняет песочницу** — базу `sandbox`. Перед первым примером верните базы в исходное состояние, иначе числа в выводах разойдутся с книгой. Команда сброса — в описании способа, которым вы пользуетесь.
2. **Примеры — по порядку, каждый один раз.** Пример в главе рассчитан на данные, которые оставил
   предыдущий. Если запустить пример дважды или пропустить, числа разойдутся с книгой — тогда
   сбросьте базы и начните с `01.py`.
3. **Сверка.** Что должна напечатать каждая программа — в разделе «Примеры и выводы» ниже.
   Отличаться могут только `_id`, которые выдаёт сервер, текущие дата и время и порядок
   в списке коллекций: сервер отдаёт их имена в произвольном порядке. У документа, который
   создан обновлением с `upsert`, поля тоже могут идти в другом порядке — значения при этом те же.

Подойдёт любой из двух способов. Адрес сервера в обоих — `mongodb://localhost:27017`, код примеров
одинаковый.

| Способ | Что нужно | Когда подходит |
|---|---|---|
| **1. Docker** | Docker Desktop | Compass и сервер не установились или не подключаются; ничего, кроме Docker, ставить не нужно |
| **2. Сервер и Compass** | MongoDB Server, Compass, Python с драйвером | сервер и Compass уже стоят и подключаются |

## Способ 1. Docker

Docker Desktop — с [docker.com](https://www.docker.com/products/docker-desktop/); на Linux — Docker Engine.
Перед командами Docker Desktop должен быть запущен. Команды одинаковые в PowerShell, cmd и терминале
macOS/Linux; выполняйте их **из папки архива** — там, где лежит `compose.yaml`.

1. Поднять сервер и загрузить учебные базы:

   ```bash
   docker compose up -d
   ```

2. Вернуть базы в исходное состояние — глава меняет песочницу:

   ```bash
   docker compose run --rm reset
   ```

3. Запустить пример — путь к файлу пишется от папки архива:

   ```bash
   docker compose run --rm python primery/01.py
   ```

   При первом запуске Docker соберёт образ с драйвером Python — это пара минут.
   Дальше запуск идёт за секунды.

4. Все примеры главы подряд, по порядку, одной командой:

   ```bash
   docker compose run --rm python primery
   ```

   Перед каждой программой печатается её имя: `── primery/01.py ──`.

**Смотреть данные.** Compass не нужен: в браузере откройте http://localhost:8081, логин `student`,
пароль `student` — это mongo-express, в нём видны базы, коллекции и документы. Если Compass
установлен, он подключается к этому же серверу по адресу `mongodb://localhost:27017`.

**Консоль сервера:** `docker compose exec mongo mongosh`.

**Остановить и удалить:**

```bash
docker compose stop        # остановить; данные останутся
docker compose down        # удалить контейнеры; данные останутся
docker compose down -v     # удалить всё вместе с данными
```

Архивы всех глав пользуются одним и тем же сервером и данными: после этой главы можно распаковать
архив следующей и работать там, не удаляя стенд.

## Способ 2. Установленный сервер MongoDB и Compass

Нужны MongoDB Server 7 или 8 и MongoDB Compass — установка по шагам в
[главе 1.0а](https://maximbytecamp.github.io/mongodb_theory_makarov/temy/00a-windows-10-mongodb-7/index.html).
Проверка: Compass подключается к `mongodb://localhost:27017`.

### Шаг 1. Загрузить учебные базы

Windows, PowerShell, из папки архива — нужен `mongoimport` из MongoDB Command Line Database Tools:

```powershell
powershell -ExecutionPolicy Bypass -File stend\load.ps1
```

macOS и Linux (`mongoimport`: `brew tap mongodb/brew && brew install mongodb-database-tools`):

```bash
bash stend/load.sh
```

Скрипт пересоздаёт коллекции целиком, поэтому он же сбрасывает базы: повторный запуск ничего не двоит.

**Без `mongoimport` — через Compass.** Подключитесь к `mongodb://localhost:27017`, нажмите **Create database**,
затем в коллекции **Add data → Import JSON or CSV file** и выберите файл из `stend/seed`. Имя файла
подсказывает, куда класть: `shop.orders.json` — база `shop`, коллекция `orders`. Так загружаются все
12 файлов; пошагово с кадрами — [глава 1.0, §7](https://maximbytecamp.github.io/mongodb_theory_makarov/temy/00-uchebnye-bazy/index.html#s7).

**Сброс в Compass.** Главы меняют только песочницу, поэтому достаточно пересоздать её: у базы `sandbox`
в левой панели нажмите **⋯ → Drop database**, затем создайте базу `sandbox` заново и импортируйте в неё
`sandbox.products.json` (коллекция `products`) и `sandbox.warehouse.json` (коллекция `warehouse`).
Импорт в непустую коллекцию документы не заменяет — поэтому сначала удаление.

После загрузки в Compass нажмите **Refresh**: в списке должны быть базы `shop`, `hh`, `logs`, `org`
и `sandbox`. В `shop.products` — 21 документ, в `shop.orders` — 120.

### Шаг 2. Драйвер Python и запуск

Python 3.10 или новее — с [python.org](https://www.python.org/downloads/). На Windows в установщике
отметьте **Add python.exe to PATH**.

Windows, PowerShell, из папки архива:

```powershell
python -m pip install -r requirements.txt
cd primery
python 01.py
```

macOS и Linux — драйвер ставится в виртуальное окружение: системный Python не даёт ставить пакеты напрямую.

```bash
python3 -m venv .venv
source .venv/bin/activate          # в каждом новом терминале снова
pip install -r requirements.txt
cd primery
python3 01.py
```

Если `venv` не найден на Linux: `sudo apt install python3-venv`.

Остальные примеры запускаются так же: `02.py`, `03.py` и далее. Если сервер слушает другой адрес,
задайте его переменной `MONGO_URI` — программы глав 1.2–1.8 читают её при подключении.

## Примеры и выводы

| Файл | Параграф главы | Что делает |
|---|---|---|
| `01.py` | §6 Скрипт целиком | scripts/shop_report |

### 01.py · §6 Скрипт целиком

Scripts/shop_report.

```text
1. Связь и база shop
────────────────────
базы на сервере: admin, config, hh, local, logs, org, sandbox, shop
коллекции shop: customers, orders, products
товаров 21, заказов 120, покупателей 20

2. Один товар целиком
─────────────────────
  _id        p-001
  sku        SKU-NB-001
  title      Ноутбук Lenovo IdeaPad 3
  brand      Lenovo
  category   ноутбуки
  price      42990
  specs      ['15.6"', '8 ГБ', 'SSD 512 ГБ']
  stock      [{'warehouse': 'Санкт-Петербург', 'qty': 5}]
  rating     4.2
  reviews    57
  added      2026-02-05 00:00:00

3. Пять самых дорогих товаров
─────────────────────────────
  название                         категория          цена
  Ноутбук Apple MacBook Air 13     ноутбуки         114990
  Ноутбук Acer Nitro V15           ноутбуки          89990
  Смартфон Apple iPhone 15         смартфоны         79990
  Ноутбук HP Pavilion 14           ноутбуки          67900
  Ноутбук ASUS VivoBook 15         ноутбуки          51490

4. Каталог: категории по алфавиту, внутри — от дорогих к дешёвым
────────────────────────────────────────────────────────────────
  аксессуары     Powerbank Anker 20000 мА·ч           4290
  аксессуары     Рюкзак для ноутбука Xiaomi           2990
  аксессуары     Кабель USB-C 2 м                      790
  комплектующие  Видеокарта NVIDIA RTX 4060          38990
  комплектующие  Блок питания be quiet! 650 Вт        8490
  комплектующие  SSD Samsung 980 1 ТБ                 7890
  комплектующие  Оперативная память Kingston 16 ГБ     4590
  ноутбуки       Ноутбук Apple MacBook Air 13       114990

5. Товары по категориям
───────────────────────
  аксессуары      3 шт
  комплектующие   4 шт
  ноутбуки        5 шт
  периферия       5 шт
  смартфоны       4 шт

6. Заказы страницами по 5
─────────────────────────
  страница 1
    2026-0001     5980
    2026-0003    86880
    2026-0004   106210
    2026-0006     2370
    2026-0007    75790
  страница 2
    2026-0008   285750
    2026-0009   320740
    2026-0010   120340
    2026-0011    85980
    2026-0012   222740

7. Заказ с доставкой и позициями
────────────────────────────────
  номер 2026-0001, статус доставлен, сумма 5980
  доставка: Ярославль, пункт выдачи, 1 дн.
  оплата: карта, проведена: True
    2 × Рюкзак для ноутбука Xiaomi            2990

8. Песочница: вставка, обновление, удаление
───────────────────────────────────────────
  вставлено: 2 ключи: p-301, p-302
  обновление одного: найдено 1, изменено 1
  пометка распродажи: найдено 5, изменено 5
  что стало: {'title': 'Док-станция USB-C', 'price': 5990, 'reviews': 1, 'sale': True}
  удалено: 1 · товаров в песочнице: 22

9. Итог
───────
  прочитано из shop: 21 товаров и 120 заказов
  изменено в песочнице: 1 вставка пачкой, 2 обновления, 1 удаление
```

## Частые ошибки

| Что видно | Причина | Что сделать |
|---|---|---|
| `port is already allocated`, `address already in use` на `docker compose up -d` | порт 27017 занят: уже работает установленный MongoDB или стенд `mongodb-practice` | остановите тот сервер или создайте рядом с `compose.yaml` файл `.env` со строкой `MONGO_PORT=27018`: в PowerShell — `Set-Content .env "MONGO_PORT=27018"`, в bash — `echo "MONGO_PORT=27018" > .env`. Программы в Docker это не затрагивает, Compass подключайте к `localhost:27018` |
| `Cannot connect to the Docker daemon`, `error during connect` | Docker Desktop не запущен | запустите Docker Desktop и дождитесь зелёного статуса Engine running |
| `ServerSelectionTimeoutError`, `Connection refused`, `No server available` | сервер не запущен | Docker: `docker compose up -d`; способ 2 — запустите службу MongoDB |
| `Файл не найден: …` | путь написан не от папки архива или команда выполнена в другой папке | перейдите в папку, где лежит `compose.yaml`, и пишите путь `primery/01.py` |
| числа в выводе не совпадают с README | пример запускали дважды, пропустили или базы не сброшены | сбросьте базы и запустите примеры с первого по порядку |

В PowerShell не используйте `echo … > .env`: Windows PowerShell 5 пишет такой файл в UTF-16, и Docker
Compose его не прочитает.
