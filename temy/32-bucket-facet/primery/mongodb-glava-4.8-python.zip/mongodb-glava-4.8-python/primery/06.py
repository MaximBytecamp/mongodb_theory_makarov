# Глава 4.8 · $bucket, $bucketAuto и $facet
# Пример 6 из 8 · §6 Стадия $facet · $facet: три отчёта по заказам
#
# Запуск из папки архива:
#   docker compose run --rm python primery/06.py
#   cd primery, затем python 06.py (Windows) или python3 06.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

from datetime import datetime


def show(docs, *fields):
    """Печатает у каждого документа поля fields в строку через « | »; вложенные — через точку."""
    count = 0
    for doc in docs:
        cells = []
        for path in fields:
            value = doc
            for key in path.split("."):
                value = value.get(key) if isinstance(value, dict) else None
            if isinstance(value, datetime):
                value = value.strftime("%Y-%m-%d %H:%M")
            if isinstance(value, bool):
                value = str(value).lower()
            cells.append("—" if value is None else str(value))
        print(" | ".join(cells))
        count += 1
    print("документов:", count)

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$facet": {
        "by_status": [{"$sortByCount": "$status"}],
        "by_city": [
            {"$group": {"_id": "$delivery.city", "orders": {"$sum": 1}}},
            {"$sort": {"_id": 1}},
        ],
        "top": [
            {"$sort": {"total": -1}},
            {"$limit": 3},
            {"$project": {"_id": 0, "number": 1, "total": 1}},
        ],
    }},
]

for doc in orders.aggregate(pipeline):
    print(doc)
