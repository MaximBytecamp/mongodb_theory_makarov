# Глава 4.8 · $bucket, $bucketAuto и $facet
# Пример 3 из 8 · §3 Значения вне границ: default · документы вне границ и default
#
# Запуск из папки архива:
#   docker compose run --rm python primery/03.py
#   cd primery, затем python 03.py (Windows) или python3 03.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

from datetime import datetime


def show(docs, *fields):
    """Печатает у каждого документа поля fields в строку через « | »; вложенные — через точку."""
    count = 0
    for doc in docs:
        cells = []
        for path in fields:
            value = doc
            for key in path.split("."):
                value = value.get(key) if isinstance(value, dict) else None
            if isinstance(value, datetime):
                value = value.strftime("%Y-%m-%d %H:%M")
            if isinstance(value, bool):
                value = str(value).lower()
            cells.append("—" if value is None else str(value))
        print(" | ".join(cells))
        count += 1
    print("документов:", count)

# ── пример из главы ───────────────────────────────────────────
from pymongo.errors import OperationFailure

no_default = [
    {"$bucket": {"groupBy": "$total", "boundaries": [0, 10000, 50000, 100000, 200000]}},
]

with_default = [
    {"$bucket": {
        "groupBy": "$total",
        "boundaries": [0, 10000, 50000, 100000, 200000],
        "default": "200000 и больше",
    }},
]

print("── без default")
try:
    for doc in orders.aggregate(no_default):
        print(doc)
except OperationFailure as e:
    print("код", e.code)
    print(e.details["errmsg"])

print("── с default")
for doc in orders.aggregate(with_default):
    print(doc)
