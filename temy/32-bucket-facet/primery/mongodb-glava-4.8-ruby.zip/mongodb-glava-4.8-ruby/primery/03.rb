# Глава 4.8 · $bucket, $bucketAuto и $facet
# Пример 3 из 8 · §3 Значения вне границ: default · документы вне границ и default
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/03.rb
#   cd primery, затем ruby 03.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# Печатает у каждого документа поля fields в строку через « | »; вложенные — через точку.
def show(docs, *fields)
  count = 0
  docs.each do |doc|
    cells = fields.map do |path|
      value = path.split(".").reduce(doc) { |v, key| v.is_a?(Hash) ? v[key] : nil }
      value = value.utc.strftime("%Y-%m-%d %H:%M") if value.is_a?(Time)
      value.nil? ? "—" : value.to_s
    end
    puts cells.join(" | ")
    count += 1
  end
  puts "документов: #{count}"
end

# ── пример из главы ───────────────────────────────────────────
no_default = [
  { "$bucket" => {
    "groupBy" => "$total",
    "boundaries" => [0, 10000, 50000, 100000, 200000],
  } },
]

with_default = [
  { "$bucket" => {
    "groupBy" => "$total",
    "boundaries" => [0, 10000, 50000, 100000, 200000],
    "default" => "200000 и больше",
  } },
]

puts "── без default"
begin
  orders.aggregate(no_default).each { |doc| puts doc.inspect }
rescue Mongo::Error::OperationFailure => e
  puts "код #{e.code}"
  puts e.document["errmsg"]
end

puts "── с default"
orders.aggregate(with_default).each { |doc| puts doc.inspect }
