//go:build ignore

// Глава 1.8 · Удаление
// Пример 2 из 9 · §1 delete_one: один документ · честный ответ вызывающему
//
// Запуск из папки архива:
//   docker compose run --rm go primery/02.go
//   cd primery, затем go run 02.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"time"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = fmt.Sprint
var _ = time.Now
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────

// Product — поля товара, которые читают примеры. Тип объявлен в главе 1.4.
type Product struct {
	ID       string `bson:"_id"`
	SKU      string `bson:"sku"`
	Title    string `bson:"title"`
	Category string `bson:"category"`
	Price    int    `bson:"price"`
}

func deleteProduct(ctx context.Context, box *mongo.Collection, productID string) error {
    res, err := box.DeleteOne(ctx, bson.D{{Key: "_id", Value: productID}})
    if err != nil {
        return err
    }
    if res.DeletedCount == 0 {
        return fmt.Errorf("товар %s не найден", productID)
    }
    return nil
}

func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	products := db.Collection("products")
	orders := db.Collection("orders")
	box := client.Database("sandbox").Collection("products") // песочница: здесь можно менять
	_, _, _, _ = db, products, orders, box

	{
		// ── пример из главы ──────────────────────────────────────
		// в main: p-020 уже удалён предыдущим примером
		if err := deleteProduct(ctx, box, "p-020"); err != nil {
		    fmt.Println("ошибка:", err)
		}
	}
}
