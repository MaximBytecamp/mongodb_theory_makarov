//go:build ignore

// Глава 1.8 · Удаление
// Пример 4 из 9 · §3 Порядок «посчитать → посмотреть → удалить» · три шага вместо одного
//
// Запуск из папки архива:
//   docker compose run --rm go primery/04.go
//   cd primery, затем go run 04.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"time"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = fmt.Sprint
var _ = time.Now
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────

// Product — поля товара, которые читают примеры. Тип объявлен в главе 1.4.
type Product struct {
	ID       string `bson:"_id"`
	SKU      string `bson:"sku"`
	Title    string `bson:"title"`
	Category string `bson:"category"`
	Price    int    `bson:"price"`
}

var rows []bson.M

func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	products := db.Collection("products")
	orders := db.Collection("orders")
	box := client.Database("sandbox").Collection("products") // песочница: здесь можно менять
	_, _, _, _ = db, products, orders, box

	{
		// ── пример из главы ──────────────────────────────────────
		query := bson.D{
		    {Key: "category", Value: "аксессуары"},
		    {Key: "price", Value: bson.D{{Key: "$lt", Value: 2000}}},
		}

		// 1. Сколько документов попадёт под удаление
		count, _ := box.CountDocuments(ctx, query)
		fmt.Println("под фильтр попало:", count)

		// 2. Какие именно — глазами, не наугад
		cursor, _ := box.Find(ctx, query, options.Find().SetLimit(10))
		cursor.All(ctx, &rows)

		// 3. И только теперь — удаление тем же фильтром
		res, _ := box.DeleteMany(ctx, query)
		fmt.Println("удалено:", res.DeletedCount)
	}
}
