# Глава 1.8 · Удаление
# Пример 1 из 9 · §1 delete_one: один документ · удалить по ключу
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/01.rb
#   cd primery, затем ruby 01.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
box = client.use("sandbox").database[:products]

res = box.delete_one({ "_id" => "p-020" })
puts "удалено: #{res.deleted_count}"
