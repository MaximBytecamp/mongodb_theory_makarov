# Глава 1.8 · Удаление
# Пример 4 из 9 · §3 Порядок «посчитать → посмотреть → удалить» · три шага вместо одного
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/04.rb
#   cd primery, затем ruby 04.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
query = { "category" => "аксессуары", "price" => { "$lt" => 2000 } }

# 1. Сколько документов попадёт под удаление
puts "под фильтр попало: #{box.count_documents(query)}"

# 2. Какие именно — глазами, не наугад
box.find(query, projection: { "_id" => 1, "title" => 1, "price" => 1 })
   .first(10).each { |doc| puts "  #{doc.inspect}" }

# 3. И только теперь — удаление тем же фильтром
puts "удалено: #{box.delete_many(query).deleted_count}"
