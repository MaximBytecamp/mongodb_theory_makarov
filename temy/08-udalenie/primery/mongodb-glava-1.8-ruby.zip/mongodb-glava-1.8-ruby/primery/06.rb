# Глава 1.8 · Удаление
# Пример 6 из 9 · §5 Очистить или удалить: delete_many({}) и drop() · Ruby
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/06.rb
#   cd primery, затем ruby 06.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
res = box.delete_many({})
puts "удалено: #{res.deleted_count}"            # 17
puts "коллекция есть: #{db.collection_names.include?('products')}"
