# Глава 1.8 · Удаление
# Пример 7 из 9 · §5 Очистить или удалить: delete_many({}) и drop() · Ruby
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/07.rb
#   cd primery, затем ruby 07.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
box.drop

puts "коллекция есть: #{db.collection_names.include?('products')}"  # false
