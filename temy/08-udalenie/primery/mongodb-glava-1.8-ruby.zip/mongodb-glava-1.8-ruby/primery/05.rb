# Глава 1.8 · Удаление
# Пример 5 из 9 · §4 find_one_and_delete · удалить и забрать
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/05.rb
#   cd primery, затем ruby 05.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
doc = box.find_one_and_delete({ "category" => "смартфоны" })
puts "#{doc['_id']} #{doc['title']}"
