# Глава 1.8 · Удаление
# Пример 3 из 9 · §2 delete_many: все подходящие · удалить категорию целиком
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/03.rb
#   cd primery, затем ruby 03.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
res = box.delete_many({ "category" => "аксессуары" })
puts "удалено: #{res.deleted_count}"
puts "осталось: #{box.count_documents({})}"
