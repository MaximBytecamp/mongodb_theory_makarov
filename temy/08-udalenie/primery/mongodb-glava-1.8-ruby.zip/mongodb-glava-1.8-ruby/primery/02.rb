# Глава 1.8 · Удаление
# Пример 2 из 9 · §1 delete_one: один документ · честный ответ вызывающему
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/02.rb
#   cd primery, затем ruby 02.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
def delete_product(box, product_id)
  res = box.delete_one({ "_id" => product_id })
  raise KeyError, "товар #{product_id} не найден" if res.deleted_count.zero?
end

delete_product(box, "p-020")   # p-020 уже удалён предыдущим примером
