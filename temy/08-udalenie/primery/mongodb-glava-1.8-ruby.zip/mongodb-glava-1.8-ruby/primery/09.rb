# Глава 1.8 · Удаление
# Пример 9 из 9 · §6 Мягкое удаление · витрина показывает живые
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/09.rb
#   cd primery, затем ruby 09.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
visible = { "deleted_at" => { "$exists" => false } }

box.find(visible).each do |doc|
  # ...
end
