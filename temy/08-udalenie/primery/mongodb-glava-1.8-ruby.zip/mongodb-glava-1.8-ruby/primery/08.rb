# Глава 1.8 · Удаление
# Пример 8 из 9 · §6 Мягкое удаление · пометить, а не удалить
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/08.rb
#   cd primery, затем ruby 08.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
products = db[:products]
orders = db[:orders]
box = client.use("sandbox").database[:products]   # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
box.update_one(
  { "_id" => "p-003" },
  { "$set" => { "deleted_at" => Time.now.utc } }
)
