# Глава 1.8 · Удаление
# Пример 4 из 9 · §3 Порядок «посчитать → посмотреть → удалить» · три шага вместо одного
#
# Запуск из папки архива:
#   docker compose run --rm python primery/04.py
#   cd primery, затем python 04.py (Windows) или python3 04.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
query = {"category": "аксессуары", "price": {"$lt": 2000}}

# 1. Сколько документов попадёт под удаление
print("под фильтр попало:", box.count_documents(query))

# 2. Какие именно — глазами, не наугад
for doc in box.find(query, {"_id": 1, "title": 1, "price": 1}).limit(10):
    print("  ", doc)

# 3. И только теперь — удаление тем же фильтром
res = box.delete_many(query)
print("удалено:", res.deleted_count)
