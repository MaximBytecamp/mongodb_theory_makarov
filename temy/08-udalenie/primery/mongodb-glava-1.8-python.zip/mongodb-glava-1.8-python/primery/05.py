# Глава 1.8 · Удаление
# Пример 5 из 9 · §4 find_one_and_delete · удалить и забрать
#
# Запуск из папки архива:
#   docker compose run --rm python primery/05.py
#   cd primery, затем python 05.py (Windows) или python3 05.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
doc = box.find_one_and_delete({"category": "смартфоны"})
print(doc["_id"], doc["title"], doc["price"])
