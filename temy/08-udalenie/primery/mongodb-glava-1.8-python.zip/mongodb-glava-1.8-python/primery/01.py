# Глава 1.8 · Удаление
# Пример 1 из 9 · §1 delete_one: один документ · удалить по ключу
#
# Запуск из папки архива:
#   docker compose run --rm python primery/01.py
#   cd primery, затем python 01.py (Windows) или python3 01.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
box = client["sandbox"]["products"]

res = box.delete_one({"_id": "p-020"})
print("удалено:", res.deleted_count)
