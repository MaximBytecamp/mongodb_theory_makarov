# Глава 1.8 · Удаление
# Пример 8 из 9 · §6 Мягкое удаление · пометить, а не удалить
#
# Запуск из папки архива:
#   docker compose run --rm python primery/08.py
#   cd primery, затем python 08.py (Windows) или python3 08.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
from datetime import datetime, timezone

box.update_one(
    {"_id": "p-003"},
    {"$set": {"deleted_at": datetime.now(timezone.utc)}})
