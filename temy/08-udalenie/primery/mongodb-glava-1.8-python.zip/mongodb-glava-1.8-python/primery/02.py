# Глава 1.8 · Удаление
# Пример 2 из 9 · §1 delete_one: один документ · честный ответ вызывающему
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
def delete_product(product_id):
    res = box.delete_one({"_id": product_id})
    if res.deleted_count == 0:
        raise LookupError(f"товар {product_id} не найден")

delete_product("p-020")        # p-020 уже удалён предыдущим примером
