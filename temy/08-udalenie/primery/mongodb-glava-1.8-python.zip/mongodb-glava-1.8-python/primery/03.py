# Глава 1.8 · Удаление
# Пример 3 из 9 · §2 delete_many: все подходящие · удалить категорию целиком
#
# Запуск из папки архива:
#   docker compose run --rm python primery/03.py
#   cd primery, затем python 03.py (Windows) или python3 03.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
res = box.delete_many({"category": "аксессуары"})
print("удалено:", res.deleted_count)
print("осталось:", box.count_documents({}))
