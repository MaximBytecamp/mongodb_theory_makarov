# Глава 1.8 · Удаление
# Пример 9 из 9 · §6 Мягкое удаление · витрина показывает живые
#
# Запуск из папки архива:
#   docker compose run --rm python primery/09.py
#   cd primery, затем python 09.py (Windows) или python3 09.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
visible = {"deleted_at": {"$exists": False}}

for doc in box.find(visible):
    ...
