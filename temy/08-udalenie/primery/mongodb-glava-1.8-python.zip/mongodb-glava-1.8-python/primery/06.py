# Глава 1.8 · Удаление
# Пример 6 из 9 · §5 Очистить или удалить: delete_many({}) и drop() · Python
#
# Запуск из папки архива:
#   docker compose run --rm python primery/06.py
#   cd primery, затем python 06.py (Windows) или python3 06.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
products = db["products"]
orders = db["orders"]
box = client["sandbox"]["products"]        # песочница: здесь можно менять

# ── пример из главы ───────────────────────────────────────────
res = box.delete_many({})
print("удалено:", res.deleted_count)          # 17
print("коллекция есть:",
      "products" in db.list_collection_names())   # True
