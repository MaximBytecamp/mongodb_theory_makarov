// Глава 6.3 · $graphLookup: иерархии
// Пример 7 из 8 · §8 Дерево категорий · дерево категорий: путь к корню и ветка
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/07.cpp
//   cd primery, затем g++ -std=c++17 07.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto orders = db["orders"];
    auto customers = db["customers"];
    auto products = db["products"];
    auto hh = client["hh"];
    auto companies = hh["companies"];
    auto vacancies = hh["vacancies"];
    auto resumes = hh["resumes"];
    auto org = client["org"];
    auto employees = org["employees"];
    auto categories = org["categories"];
    auto sandbox = client["sandbox"];

    {
        // ── пример из главы ──────────────────────────────────────
        mongocxx::pipeline path;
        path.match(make_document(kvp("_id", "cat-audio")));
        path.append_stage(make_document(kvp("$graphLookup", make_document(
            kvp("from", "categories"),
            kvp("startWith", "$parent_id"),
            kvp("connectFromField", "parent_id"),
            kvp("connectToField", "_id"),
            kvp("as", "path"),
            kvp("depthField", "step")))));
        path.project(make_document(
            kvp("_id", 0),
            kvp("title", 1),
            kvp("path", make_document(
                kvp("$sortArray", make_document(
                    kvp("input", make_document(
                        kvp("$map", make_document(
                            kvp("input", "$path"),
                            kvp("in", make_document(
                                kvp("step", "$$this.step"),
                                kvp("title", "$$this.title"))))))),
                    kvp("sortBy", make_document(kvp("step", 1)))))))));

        mongocxx::pipeline branch;
        branch.match(make_document(kvp("_id", "cat-comp")));
        branch.append_stage(make_document(kvp("$graphLookup", make_document(
            kvp("from", "categories"),
            kvp("startWith", "$_id"),
            kvp("connectFromField", "_id"),
            kvp("connectToField", "parent_id"),
            kvp("as", "branch")))));
        branch.project(make_document(
            kvp("_id", 0),
            kvp("title", 1),
            kvp("branch", make_document(
                kvp("$sortArray", make_document(kvp("input", "$branch.title"), kvp("sortBy", 1)))))));

        std::cout << "── путь от «Аудио» к корню" << std::endl;
        for (auto&& doc : categories.aggregate(path)) {
            std::cout << bsoncxx::to_json(doc, bsoncxx::ExtendedJsonMode::k_relaxed) << std::endl;
        }

        std::cout << "── все категории внутри «Компьютеров»" << std::endl;
        for (auto&& doc : categories.aggregate(branch)) {
            std::cout << bsoncxx::to_json(doc, bsoncxx::ExtendedJsonMode::k_relaxed) << std::endl;
        }
    }
}
