# Глава 6.3 · $graphLookup: иерархии
# Пример 6 из 8 · §7 Команды всех руководителей · размер команды и фонд оплаты каждого руководителя
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/06.rb
#   cd primery, затем ruby 06.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$graphLookup" => {
    "from" => "employees",
    "startWith" => "$_id",
    "connectFromField" => "_id",
    "connectToField" => "manager_id",
    "as" => "team",
  } },
  { "$project" => {
    "_id" => 0,
    "name" => 1,
    "people" => { "$size" => "$team" },
    "payroll" => { "$sum" => "$team.salary" },
  } },
  { "$match" => { "people" => { "$gt" => 0 } } },
  { "$sort" => { "people" => -1, "name" => 1 } },
]

employees.aggregate(pipeline).each { |doc| puts doc.inspect }
