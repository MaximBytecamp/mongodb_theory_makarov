# Глава 6.3 · $graphLookup: иерархии
# Пример 5 из 8 · §6 Обход по условию · restrictSearchWithMatch: обход только по отделу разработки
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/05.rb
#   cd primery, затем ruby 05.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
all_depts = [
  { "$match" => { "_id" => "s-001" } },
  { "$graphLookup" => {
    "from" => "employees",
    "startWith" => "$_id",
    "connectFromField" => "_id",
    "connectToField" => "manager_id",
    "as" => "team",
  } },
  { "$project" => { "_id" => 0, "name" => 1, "count" => { "$size" => "$team" } } },
]

dev_only = [
  { "$match" => { "_id" => "s-001" } },
  { "$graphLookup" => {
    "from" => "employees",
    "startWith" => "$_id",
    "connectFromField" => "_id",
    "connectToField" => "manager_id",
    "as" => "team",
    "restrictSearchWithMatch" => { "department" => "разработка" },
  } },
  { "$project" => { "_id" => 0, "name" => 1, "count" => { "$size" => "$team" } } },
]

puts "── без ограничения"
employees.aggregate(all_depts).each { |doc| puts doc.inspect }

puts "── только разработка"
employees.aggregate(dev_only).each { |doc| puts doc.inspect }
