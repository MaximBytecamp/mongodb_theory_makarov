# Глава 6.3 · $graphLookup: иерархии
# Пример 3 из 8 · §4 Сколько уровней: maxDepth · maxDepth: сколько уровней обходить
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/03.rb
#   cd primery, затем ruby 03.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
direct = [
  { "$match" => { "_id" => "s-002" } },
  { "$graphLookup" => {
    "from" => "employees",
    "startWith" => "$_id",
    "connectFromField" => "_id",
    "connectToField" => "manager_id",
    "as" => "team",
    "maxDepth" => 0,
  } },
  { "$project" => {
    "_id" => 0,
    "team" => { "$sortArray" => { "input" => "$team.name", "sortBy" => 1 } },
  } },
]

two_levels = [
  { "$match" => { "_id" => "s-002" } },
  { "$graphLookup" => {
    "from" => "employees",
    "startWith" => "$_id",
    "connectFromField" => "_id",
    "connectToField" => "manager_id",
    "as" => "team",
    "maxDepth" => 1,
  } },
  { "$project" => { "_id" => 0, "count" => { "$size" => "$team" } } },
]

puts "── maxDepth 0"
employees.aggregate(direct).each { |doc| puts doc.inspect }

puts "── maxDepth 1"
employees.aggregate(two_levels).each { |doc| puts doc.inspect }
