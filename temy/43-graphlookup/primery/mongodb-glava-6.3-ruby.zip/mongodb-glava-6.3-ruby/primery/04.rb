# Глава 6.3 · $graphLookup: иерархии
# Пример 4 из 8 · §5 Вверх по дереву · цепочка руководителей до директора
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/04.rb
#   cd primery, затем ruby 04.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "_id" => "s-013" } },
  { "$graphLookup" => {
    "from" => "employees",
    "startWith" => "$manager_id",
    "connectFromField" => "manager_id",
    "connectToField" => "_id",
    "as" => "chain",
    "depthField" => "step",
  } },
  { "$project" => {
    "_id" => 0,
    "name" => 1,
    "chain" => { "$sortArray" => {
      "input" => { "$map" => {
        "input" => "$chain",
        "in" => { "step" => "$$this.step", "name" => "$$this.name" },
      } },
      "sortBy" => { "step" => 1 },
    } },
  } },
]

employees.aggregate(pipeline).each { |doc| puts doc.inspect }
