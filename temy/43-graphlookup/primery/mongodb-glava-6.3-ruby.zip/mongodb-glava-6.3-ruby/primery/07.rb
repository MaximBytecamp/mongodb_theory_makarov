# Глава 6.3 · $graphLookup: иерархии
# Пример 7 из 8 · §8 Дерево категорий · дерево категорий: путь к корню и ветка
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/07.rb
#   cd primery, затем ruby 07.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
customers = db[:customers]
products = db[:products]
hh = client.use("hh").database
companies = hh[:companies]
vacancies = hh[:vacancies]
resumes = hh[:resumes]
org = client.use("org").database
employees = org[:employees]
categories = org[:categories]
sandbox = client.use("sandbox").database

# ── пример из главы ───────────────────────────────────────────
path = [
  { "$match" => { "_id" => "cat-audio" } },
  { "$graphLookup" => {
    "from" => "categories",
    "startWith" => "$parent_id",
    "connectFromField" => "parent_id",
    "connectToField" => "_id",
    "as" => "path",
    "depthField" => "step",
  } },
  { "$project" => {
    "_id" => 0,
    "title" => 1,
    "path" => { "$sortArray" => {
      "input" => { "$map" => {
        "input" => "$path",
        "in" => { "step" => "$$this.step", "title" => "$$this.title" },
      } },
      "sortBy" => { "step" => 1 },
    } },
  } },
]

branch = [
  { "$match" => { "_id" => "cat-comp" } },
  { "$graphLookup" => {
    "from" => "categories",
    "startWith" => "$_id",
    "connectFromField" => "_id",
    "connectToField" => "parent_id",
    "as" => "branch",
  } },
  { "$project" => {
    "_id" => 0,
    "title" => 1,
    "branch" => { "$sortArray" => { "input" => "$branch.title", "sortBy" => 1 } },
  } },
]

puts "── путь от «Аудио» к корню"
categories.aggregate(path).each { |doc| puts doc.inspect }

puts "── все категории внутри «Компьютеров»"
categories.aggregate(branch).each { |doc| puts doc.inspect }
