# Глава 6.3 · $graphLookup: иерархии
# Пример 7 из 8 · §8 Дерево категорий · дерево категорий: путь к корню и ветка
#
# Запуск из папки архива:
#   docker compose run --rm python primery/07.py
#   cd primery, затем python 07.py (Windows) или python3 07.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
path = [
    {"$match": {"_id": "cat-audio"}},
    {"$graphLookup": {
        "from": "categories",
        "startWith": "$parent_id",
        "connectFromField": "parent_id",
        "connectToField": "_id",
        "as": "path",
        "depthField": "step",
    }},
    {"$project": {
        "_id": 0,
        "title": 1,
        "path": {"$sortArray": {
            "input": {"$map": {
                "input": "$path",
                "in": {"step": "$$this.step", "title": "$$this.title"},
            }},
            "sortBy": {"step": 1},
        }},
    }},
]

branch = [
    {"$match": {"_id": "cat-comp"}},
    {"$graphLookup": {
        "from": "categories",
        "startWith": "$_id",
        "connectFromField": "_id",
        "connectToField": "parent_id",
        "as": "branch",
    }},
    {"$project": {
        "_id": 0,
        "title": 1,
        "branch": {"$sortArray": {"input": "$branch.title", "sortBy": 1}},
    }},
]

print("── путь от «Аудио» к корню")
for doc in categories.aggregate(path):
    print(doc)

print("── все категории внутри «Компьютеров»")
for doc in categories.aggregate(branch):
    print(doc)
