# Глава 6.3 · $graphLookup: иерархии
# Пример 4 из 8 · §5 Вверх по дереву · цепочка руководителей до директора
#
# Запуск из папки архива:
#   docker compose run --rm python primery/04.py
#   cd primery, затем python 04.py (Windows) или python3 04.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": "s-013"}},
    {"$graphLookup": {
        "from": "employees",
        "startWith": "$manager_id",
        "connectFromField": "manager_id",
        "connectToField": "_id",
        "as": "chain",
        "depthField": "step",
    }},
    {"$project": {
        "_id": 0,
        "name": 1,
        "chain": {"$sortArray": {
            "input": {"$map": {
                "input": "$chain",
                "in": {"step": "$$this.step", "name": "$$this.name"},
            }},
            "sortBy": {"step": 1},
        }},
    }},
]

for doc in employees.aggregate(pipeline):
    print(doc)
