# Глава 6.3 · $graphLookup: иерархии
# Пример 6 из 8 · §7 Команды всех руководителей · размер команды и фонд оплаты каждого руководителя
#
# Запуск из папки архива:
#   docker compose run --rm python primery/06.py
#   cd primery, затем python 06.py (Windows) или python3 06.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$graphLookup": {
        "from": "employees",
        "startWith": "$_id",
        "connectFromField": "_id",
        "connectToField": "manager_id",
        "as": "team",
    }},
    {"$project": {
        "_id": 0,
        "name": 1,
        "people": {"$size": "$team"},
        "payroll": {"$sum": "$team.salary"},
    }},
    {"$match": {"people": {"$gt": 0}}},
    {"$sort": {"people": -1, "name": 1}},
]

for doc in employees.aggregate(pipeline):
    print(doc)
