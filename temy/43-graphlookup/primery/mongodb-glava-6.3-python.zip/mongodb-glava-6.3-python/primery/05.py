# Глава 6.3 · $graphLookup: иерархии
# Пример 5 из 8 · §6 Обход по условию · restrictSearchWithMatch: обход только по отделу разработки
#
# Запуск из папки архива:
#   docker compose run --rm python primery/05.py
#   cd primery, затем python 05.py (Windows) или python3 05.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
all_depts = [
    {"$match": {"_id": "s-001"}},
    {"$graphLookup": {
        "from": "employees",
        "startWith": "$_id",
        "connectFromField": "_id",
        "connectToField": "manager_id",
        "as": "team",
    }},
    {"$project": {"_id": 0, "name": 1, "count": {"$size": "$team"}}},
]

dev_only = [
    {"$match": {"_id": "s-001"}},
    {"$graphLookup": {
        "from": "employees",
        "startWith": "$_id",
        "connectFromField": "_id",
        "connectToField": "manager_id",
        "as": "team",
        "restrictSearchWithMatch": {"department": "разработка"},
    }},
    {"$project": {"_id": 0, "name": 1, "count": {"$size": "$team"}}},
]

print("── без ограничения")
for doc in employees.aggregate(all_depts):
    print(doc)

print("── только разработка")
for doc in employees.aggregate(dev_only):
    print(doc)
