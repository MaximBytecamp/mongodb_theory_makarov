# Глава 6.3 · $graphLookup: иерархии
# Пример 3 из 8 · §4 Сколько уровней: maxDepth · maxDepth: сколько уровней обходить
#
# Запуск из папки архива:
#   docker compose run --rm python primery/03.py
#   cd primery, затем python 03.py (Windows) или python3 03.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
direct = [
    {"$match": {"_id": "s-002"}},
    {"$graphLookup": {
        "from": "employees",
        "startWith": "$_id",
        "connectFromField": "_id",
        "connectToField": "manager_id",
        "as": "team",
        "maxDepth": 0,
    }},
    {"$project": {
        "_id": 0,
        "team": {"$sortArray": {"input": "$team.name", "sortBy": 1}},
    }},
]

two_levels = [
    {"$match": {"_id": "s-002"}},
    {"$graphLookup": {
        "from": "employees",
        "startWith": "$_id",
        "connectFromField": "_id",
        "connectToField": "manager_id",
        "as": "team",
        "maxDepth": 1,
    }},
    {"$project": {"_id": 0, "count": {"$size": "$team"}}},
]

print("── maxDepth 0")
for doc in employees.aggregate(direct):
    print(doc)

print("── maxDepth 1")
for doc in employees.aggregate(two_levels):
    print(doc)
