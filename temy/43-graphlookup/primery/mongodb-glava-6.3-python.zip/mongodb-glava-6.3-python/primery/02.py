# Глава 6.3 · $graphLookup: иерархии
# Пример 2 из 8 · §3 Уровень: depthField · depthField: на каком уровне подчинённый
#
# Запуск из папки архива:
#   docker compose run --rm python primery/02.py
#   cd primery, затем python 02.py (Windows) или python3 02.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": "s-002"}},
    {"$graphLookup": {
        "from": "employees",
        "startWith": "$_id",
        "connectFromField": "_id",
        "connectToField": "manager_id",
        "as": "team",
        "depthField": "level",
    }},
    {"$project": {
        "_id": 0,
        "name": 1,
        "team": {"$sortArray": {
            "input": {"$map": {
                "input": "$team",
                "in": {"level": "$$this.level", "name": "$$this.name"},
            }},
            "sortBy": {"level": 1, "name": 1},
        }},
    }},
]

for doc in employees.aggregate(pipeline):
    print(doc)
