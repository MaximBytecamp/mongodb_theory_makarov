# Глава 6.3 · $graphLookup: иерархии
# Пример 8 из 8 · §9 Перепутанное направление · connectFromField и connectToField перепутаны
#
# Запуск из папки архива:
#   docker compose run --rm python primery/08.py
#   cd primery, затем python 08.py (Windows) или python3 08.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": "s-002"}},
    {"$graphLookup": {
        "from": "employees",
        "startWith": "$_id",
        "connectFromField": "manager_id",
        "connectToField": "_id",
        "as": "team",
    }},
    {"$project": {
        "_id": 0,
        "name": 1,
        "team": {"$sortArray": {"input": "$team.name", "sortBy": 1}},
    }},
]

for doc in employees.aggregate(pipeline):
    print(doc)
