# Глава 6.3 · $graphLookup: иерархии
# Пример 1 из 8 · §2 Стадия $graphLookup · $graphLookup: все подчинённые руководителя
#
# Запуск из папки архива:
#   docker compose run --rm python primery/01.py
#   cd primery, затем python 01.py (Windows) или python3 01.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
customers = db["customers"]
products = db["products"]
hh = client["hh"]
companies = hh["companies"]
vacancies = hh["vacancies"]
resumes = hh["resumes"]
org = client["org"]
employees = org["employees"]
categories = org["categories"]
sandbox = client["sandbox"]

# ── пример из главы ───────────────────────────────────────────
pipeline = [
    {"$match": {"_id": "s-002"}},
    {"$graphLookup": {
        "from": "employees",
        "startWith": "$_id",
        "connectFromField": "_id",
        "connectToField": "manager_id",
        "as": "team",
    }},
    {"$project": {
        "_id": 0,
        "name": 1,
        "count": {"$size": "$team"},
        "team": {"$sortArray": {"input": "$team.name", "sortBy": 1}},
    }},
]

for doc in employees.aggregate(pipeline):
    print(doc)
