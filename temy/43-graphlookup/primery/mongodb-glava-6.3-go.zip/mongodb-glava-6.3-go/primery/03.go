//go:build ignore

// Глава 6.3 · $graphLookup: иерархии
// Пример 3 из 8 · §4 Сколько уровней: maxDepth · maxDepth: сколько уровней обходить
//
// Запуск из папки архива:
//   docker compose run --rm go primery/03.go
//   cd primery, затем go run 03.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	orders := db.Collection("orders")
	customers := db.Collection("customers")
	products := db.Collection("products")
	hh := client.Database("hh")
	companies := hh.Collection("companies")
	vacancies := hh.Collection("vacancies")
	resumes := hh.Collection("resumes")
	org := client.Database("org")
	employees := org.Collection("employees")
	categories := org.Collection("categories")
	sandbox := client.Database("sandbox")
	_, _, _, _, _, _, _, _, _, _, _, _ = db, orders, customers, products, hh, companies, vacancies, resumes, org, employees, categories, sandbox

	{
		// ── пример из главы ──────────────────────────────────────
		direct := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{{Key: "_id", Value: "s-002"}}}},
		    {{Key: "$graphLookup", Value: bson.D{
		        {Key: "from", Value: "employees"},
		        {Key: "startWith", Value: "$_id"},
		        {Key: "connectFromField", Value: "_id"},
		        {Key: "connectToField", Value: "manager_id"},
		        {Key: "as", Value: "team"},
		        {Key: "maxDepth", Value: 0}}}},
		    {{Key: "$project", Value: bson.D{
		        {Key: "_id", Value: 0},
		        {Key: "team", Value: bson.D{
		            {Key: "$sortArray", Value: bson.D{
		                {Key: "input", Value: "$team.name"},
		                {Key: "sortBy", Value: 1}}}}}}}},
		}

		twoLevels := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{{Key: "_id", Value: "s-002"}}}},
		    {{Key: "$graphLookup", Value: bson.D{
		        {Key: "from", Value: "employees"},
		        {Key: "startWith", Value: "$_id"},
		        {Key: "connectFromField", Value: "_id"},
		        {Key: "connectToField", Value: "manager_id"},
		        {Key: "as", Value: "team"},
		        {Key: "maxDepth", Value: 1}}}},
		    {{Key: "$project", Value: bson.D{
		        {Key: "_id", Value: 0},
		        {Key: "count", Value: bson.D{{Key: "$size", Value: "$team"}}}}}},
		}

		fmt.Println("── maxDepth 0")
		cursor, _ := employees.Aggregate(ctx, direct)
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}

		fmt.Println("── maxDepth 1")
		cursor, _ = employees.Aggregate(ctx, twoLevels)
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}
	}
}
