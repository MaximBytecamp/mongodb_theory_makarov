//go:build ignore

// Глава 6.3 · $graphLookup: иерархии
// Пример 4 из 8 · §5 Вверх по дереву · цепочка руководителей до директора
//
// Запуск из папки архива:
//   docker compose run --rm go primery/04.go
//   cd primery, затем go run 04.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	orders := db.Collection("orders")
	customers := db.Collection("customers")
	products := db.Collection("products")
	hh := client.Database("hh")
	companies := hh.Collection("companies")
	vacancies := hh.Collection("vacancies")
	resumes := hh.Collection("resumes")
	org := client.Database("org")
	employees := org.Collection("employees")
	categories := org.Collection("categories")
	sandbox := client.Database("sandbox")
	_, _, _, _, _, _, _, _, _, _, _, _ = db, orders, customers, products, hh, companies, vacancies, resumes, org, employees, categories, sandbox

	{
		// ── пример из главы ──────────────────────────────────────
		pipeline := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{{Key: "_id", Value: "s-013"}}}},
		    {{Key: "$graphLookup", Value: bson.D{
		        {Key: "from", Value: "employees"},
		        {Key: "startWith", Value: "$manager_id"},
		        {Key: "connectFromField", Value: "manager_id"},
		        {Key: "connectToField", Value: "_id"},
		        {Key: "as", Value: "chain"},
		        {Key: "depthField", Value: "step"}}}},
		    {{Key: "$project", Value: bson.D{
		        {Key: "_id", Value: 0},
		        {Key: "name", Value: 1},
		        {Key: "chain", Value: bson.D{
		            {Key: "$sortArray", Value: bson.D{
		                {Key: "input", Value: bson.D{
		                    {Key: "$map", Value: bson.D{
		                        {Key: "input", Value: "$chain"},
		                        {Key: "in", Value: bson.D{
		                            {Key: "step", Value: "$$this.step"},
		                            {Key: "name", Value: "$$this.name"}}}}}}},
		                {Key: "sortBy", Value: bson.D{{Key: "step", Value: 1}}}}}}}}}},
		}

		cursor, _ := employees.Aggregate(ctx, pipeline)
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}
	}
}
