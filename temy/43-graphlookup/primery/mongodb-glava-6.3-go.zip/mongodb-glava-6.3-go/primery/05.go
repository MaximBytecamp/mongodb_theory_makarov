//go:build ignore

// Глава 6.3 · $graphLookup: иерархии
// Пример 5 из 8 · §6 Обход по условию · restrictSearchWithMatch: обход только по отделу разработки
//
// Запуск из папки архива:
//   docker compose run --rm go primery/05.go
//   cd primery, затем go run 05.go
// Что должно получиться — в README.md, раздел «Примеры и выводы».

package main

import (
	"context"
	"fmt"
	"log"
	"os"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

// Импорты нужны разным примерам главы. Строки ниже не дают Go ругаться
// на те, которыми текущий пример не пользуется.
var _ = fmt.Sprint
var _ = bson.D{}
var _ = mongo.ErrNoDocuments

// ── функции и типы из примеров главы ─────────────────────────────


func main() {
	uri := os.Getenv("MONGO_URI")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, err := mongo.Connect(options.Client().ApplyURI(uri))
	if err != nil {
		log.Fatal(err)
	}
	ctx := context.Background()
	defer client.Disconnect(ctx)

	db := client.Database("shop")
	orders := db.Collection("orders")
	customers := db.Collection("customers")
	products := db.Collection("products")
	hh := client.Database("hh")
	companies := hh.Collection("companies")
	vacancies := hh.Collection("vacancies")
	resumes := hh.Collection("resumes")
	org := client.Database("org")
	employees := org.Collection("employees")
	categories := org.Collection("categories")
	sandbox := client.Database("sandbox")
	_, _, _, _, _, _, _, _, _, _, _, _ = db, orders, customers, products, hh, companies, vacancies, resumes, org, employees, categories, sandbox

	{
		// ── пример из главы ──────────────────────────────────────
		allDepts := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{{Key: "_id", Value: "s-001"}}}},
		    {{Key: "$graphLookup", Value: bson.D{
		        {Key: "from", Value: "employees"},
		        {Key: "startWith", Value: "$_id"},
		        {Key: "connectFromField", Value: "_id"},
		        {Key: "connectToField", Value: "manager_id"},
		        {Key: "as", Value: "team"}}}},
		    {{Key: "$project", Value: bson.D{
		        {Key: "_id", Value: 0},
		        {Key: "name", Value: 1},
		        {Key: "count", Value: bson.D{{Key: "$size", Value: "$team"}}}}}},
		}

		devOnly := mongo.Pipeline{
		    {{Key: "$match", Value: bson.D{{Key: "_id", Value: "s-001"}}}},
		    {{Key: "$graphLookup", Value: bson.D{
		        {Key: "from", Value: "employees"},
		        {Key: "startWith", Value: "$_id"},
		        {Key: "connectFromField", Value: "_id"},
		        {Key: "connectToField", Value: "manager_id"},
		        {Key: "as", Value: "team"},
		        {Key: "restrictSearchWithMatch", Value: bson.D{{Key: "department", Value: "разработка"}}}}}},
		    {{Key: "$project", Value: bson.D{
		        {Key: "_id", Value: 0},
		        {Key: "name", Value: 1},
		        {Key: "count", Value: bson.D{{Key: "$size", Value: "$team"}}}}}},
		}

		fmt.Println("── без ограничения")
		cursor, _ := employees.Aggregate(ctx, allDepts)
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}

		fmt.Println("── только разработка")
		cursor, _ = employees.Aggregate(ctx, devOnly)
		for cursor.Next(ctx) {
		    var doc bson.D
		    cursor.Decode(&doc)
		    out, _ := bson.MarshalExtJSON(doc, false, false)
		    fmt.Println(string(out))
		}
	}
}
