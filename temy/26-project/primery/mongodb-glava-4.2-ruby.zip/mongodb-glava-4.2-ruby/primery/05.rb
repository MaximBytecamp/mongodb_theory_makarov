# Глава 4.2 · $project: форма ответа
# Пример 5 из 8 · §5 Склейка строк: $concat и $toString · склейка строк
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/05.rb
#   cd primery, затем ruby 05.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# Печатает у каждого документа поля fields в строку через « | »; вложенные — через точку.
def show(docs, *fields)
  count = 0
  docs.each do |doc|
    cells = fields.map do |path|
      value = path.split(".").reduce(doc) { |v, key| v.is_a?(Hash) ? v[key] : nil }
      value = value.utc.strftime("%Y-%m-%d %H:%M") if value.is_a?(Time)
      value.nil? ? "—" : value.to_s
    end
    puts cells.join(" | ")
    count += 1
  end
  puts "документов: #{count}"
end

# ── пример из главы ───────────────────────────────────────────
with_number = [
  { "$match" => { "status" => "в пути" } },
  { "$sort" => { "total" => -1 } },
  { "$limit" => 3 },
  { "$project" => {
    "_id" => 0,
    "line" => { "$concat" => ["$number", " — ", "$total"] },
  } },
]

with_string = [
  { "$match" => { "status" => "в пути" } },
  { "$sort" => { "total" => -1 } },
  { "$limit" => 3 },
  { "$project" => {
    "_id" => 0,
    "line" => { "$concat" => ["$number", " — ", { "$toString" => "$total" }, " ₽"] },
  } },
]

puts "── $concat с числом"
begin
  orders.aggregate(with_number).each { |doc| puts doc.inspect }
rescue Mongo::Error::OperationFailure => e
  puts "код #{e.code}"
  puts e.document["errmsg"]
end

puts "── $concat с $toString"
orders.aggregate(with_string).each { |doc| puts doc.inspect }
