# Глава 4.2 · $project: форма ответа
# Пример 8 из 8 · §8 Место $project в конвейере · $project до и после $match
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/08.rb
#   cd primery, затем ruby 08.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# Печатает у каждого документа поля fields в строку через « | »; вложенные — через точку.
def show(docs, *fields)
  count = 0
  docs.each do |doc|
    cells = fields.map do |path|
      value = path.split(".").reduce(doc) { |v, key| v.is_a?(Hash) ? v[key] : nil }
      value = value.utc.strftime("%Y-%m-%d %H:%M") if value.is_a?(Time)
      value.nil? ? "—" : value.to_s
    end
    puts cells.join(" | ")
    count += 1
  end
  puts "документов: #{count}"
end

# ── пример из главы ───────────────────────────────────────────
project_first = [
  { "$project" => { "number" => 1, "total" => 1 } },
  { "$match" => { "status" => "в пути" } },
]

match_first = [
  { "$match" => { "status" => "в пути" } },
  { "$project" => { "number" => 1, "total" => 1 } },
]

puts "$project до $match: #{orders.aggregate(project_first).to_a.size}"
puts "$match до $project: #{orders.aggregate(match_first).to_a.size}"
