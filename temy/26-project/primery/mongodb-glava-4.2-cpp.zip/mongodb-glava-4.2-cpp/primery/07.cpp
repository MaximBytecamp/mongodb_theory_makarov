// Глава 4.2 · $project: форма ответа
// Пример 7 из 8 · §7 Какие проекции сервер отклоняет · включение вместе с исключением
//
// Запуск из папки архива:
//   docker compose run --rm cpp primery/07.cpp
//   cd primery, затем g++ -std=c++17 07.cpp -o prog $(pkg-config --cflags --libs libmongocxx1) && ./prog
//   (так — на macOS с драйвером из Homebrew; на Windows и Linux — только в Docker)
// Что должно получиться — в README.md, раздел «Примеры и выводы».

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include <bsoncxx/builder/basic/array.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/json.hpp>
#include <bsoncxx/types.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>
#include <mongocxx/exception/operation_exception.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/options/find.hpp>
#include <mongocxx/options/insert.hpp>
#include <mongocxx/options/update.hpp>
#include <mongocxx/uri.hpp>

using bsoncxx::builder::basic::kvp;
using bsoncxx::builder::basic::make_array;
using bsoncxx::builder::basic::make_document;

// ── функции из примеров главы ─────────────────────────────────────

#include <ctime>
#include <mongocxx/pipeline.hpp>

// show — у каждого документа поля fields в строку через « | »; вложенные — через точку.
void show(mongocxx::cursor&& cursor, const std::vector<std::string>& fields) {
    int count = 0;
    for (auto&& doc : cursor) {
        std::string line;
        for (std::size_t i = 0; i < fields.size(); ++i) {
            bsoncxx::document::view level = doc;
            bsoncxx::document::element value;
            std::stringstream path(fields[i]);
            std::string key;
            while (std::getline(path, key, '.')) {
                value = level[key];
                if (!value) break;
                if (value.type() == bsoncxx::type::k_document) level = value.get_document().value;
            }
            std::string cell = "—";
            if (value) {
                switch (value.type()) {
                    case bsoncxx::type::k_string: cell = std::string(value.get_string().value); break;
                    case bsoncxx::type::k_int32: cell = std::to_string(value.get_int32().value); break;
                    case bsoncxx::type::k_int64: cell = std::to_string(value.get_int64().value); break;
                    case bsoncxx::type::k_double: {
                        std::ostringstream out;
                        out << value.get_double().value;
                        cell = out.str();
                        break;
                    }
                    case bsoncxx::type::k_bool: cell = value.get_bool().value ? "true" : "false"; break;
                    case bsoncxx::type::k_date: {
                        std::time_t t = value.get_date().to_int64() / 1000;
                        std::ostringstream out;
                        out << std::put_time(std::gmtime(&t), "%Y-%m-%d %H:%M");
                        cell = out.str();
                        break;
                    }
                    case bsoncxx::type::k_null: break;
                    default: cell = "{…}";
                }
            }
            line += (i ? " | " : "") + cell;
        }
        std::cout << line << std::endl;
        ++count;
    }
    std::cout << "документов: " << count << std::endl;
}


int main() {
    mongocxx::instance instance{};
    const char* env = std::getenv("MONGO_URI");
    mongocxx::client client{mongocxx::uri{env ? env : "mongodb://localhost:27017"}};

    auto db = client["shop"];
    auto orders = db["orders"];
    auto products = db["products"];
    auto customers = db["customers"];
    auto sandbox = client["sandbox"];

    {
        // ── пример из главы ──────────────────────────────────────
        mongocxx::pipeline keep_and_drop;
        keep_and_drop.match(make_document(kvp("status", "в пути")));
        keep_and_drop.sort(make_document(kvp("total", -1)));
        keep_and_drop.limit(3);
        keep_and_drop.project(make_document(kvp("number", 1), kvp("items", 0)));

        mongocxx::pipeline drop_and_compute;
        drop_and_compute.match(make_document(kvp("status", "в пути")));
        drop_and_compute.sort(make_document(kvp("total", -1)));
        drop_and_compute.limit(3);
        drop_and_compute.project(make_document(kvp("items", 0), kvp("sum", "$total")));

        std::cout << "── number: 1 и items: 0" << std::endl;
        try {
            for (auto&& doc : orders.aggregate(keep_and_drop)) {
                std::cout << bsoncxx::to_json(doc) << std::endl;
            }
        } catch (const mongocxx::operation_exception& e) {
            std::cout << "код " << e.code().value() << std::endl;
            std::cout << e.what() << std::endl;
        }

        std::cout << "── items: 0 и новое поле" << std::endl;
        try {
            for (auto&& doc : orders.aggregate(drop_and_compute)) {
                std::cout << bsoncxx::to_json(doc) << std::endl;
            }
        } catch (const mongocxx::operation_exception& e) {
            std::cout << "код " << e.code().value() << std::endl;
            std::cout << e.what() << std::endl;
        }
    }
}
