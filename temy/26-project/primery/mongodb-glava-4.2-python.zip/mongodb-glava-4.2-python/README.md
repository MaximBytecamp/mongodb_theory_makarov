# Глава 4.2 · $project: форма ответа — примеры на Python

Архив к «Справочнику по MongoDB»: все примеры главы готовыми программами, данные баз и стенд в Docker.
Глава: https://maximbytecamp.github.io/mongodb_theory_makarov/temy/26-project/index.html

Язык: **Python** · драйвер PyMongo · сервер MongoDB 7.

## Что в архиве

```text
mongodb-glava-4.2-python/
  README.md         эта инструкция
  primery/          примеры главы — по программе на пример
    01.py … 08.py
  compose.yaml      стенд в Docker: сервер, базы, mongo-express, Python
  docker/           образ с драйвером Python и скрипт запуска run.sh
  stend/seed/       данные баз: 12 файлов JSON
  stend/load.ps1    загрузка данных на установленный сервер — Windows
  stend/load.sh     то же — macOS и Linux
requirements.txt  драйвер PyMongo для pip и для образа Docker
```

## Порядок работы

1. **Базы.** Глава **только читает** данные — сбрасывать базы не нужно.
2. **Примеры — по порядку, каждый один раз.** Пример в главе рассчитан на данные, которые оставил
   предыдущий. Если запустить пример дважды или пропустить, числа разойдутся с книгой — тогда
   сбросьте базы и начните с `01.py`.
3. **Сверка.** Что должна напечатать каждая программа — в разделе «Примеры и выводы» ниже.
   Отличаться могут только `_id`, которые выдаёт сервер, текущие дата и время и порядок
   в списке коллекций: сервер отдаёт их имена в произвольном порядке. У документа, который
   создан обновлением с `upsert`, поля тоже могут идти в другом порядке — значения при этом те же.

Подойдёт любой из двух способов. Адрес сервера в обоих — `mongodb://localhost:27017`, код примеров
одинаковый.

| Способ | Что нужно | Когда подходит |
|---|---|---|
| **1. Docker** | Docker Desktop | Compass и сервер не установились или не подключаются; ничего, кроме Docker, ставить не нужно |
| **2. Сервер и Compass** | MongoDB Server, Compass, Python с драйвером | сервер и Compass уже стоят и подключаются |

## Способ 1. Docker

Docker Desktop — с [docker.com](https://www.docker.com/products/docker-desktop/); на Linux — Docker Engine.
Перед командами Docker Desktop должен быть запущен. Команды одинаковые в PowerShell, cmd и терминале
macOS/Linux; выполняйте их **из папки архива** — там, где лежит `compose.yaml`.

1. Поднять сервер и загрузить базы курса:

   ```bash
   docker compose up -d
   ```

2. Запустить пример — путь к файлу пишется от папки архива:

   ```bash
   docker compose run --rm python primery/01.py
   ```

   При первом запуске Docker соберёт образ с драйвером Python — это пара минут.
   Дальше запуск идёт за секунды.

3. Все примеры главы подряд, по порядку, одной командой:

   ```bash
   docker compose run --rm python primery
   ```

   Перед каждой программой печатается её имя: `── primery/01.py ──`.

**Смотреть данные.** Compass не нужен: в браузере откройте http://localhost:8081, логин `student`,
пароль `student` — это mongo-express, в нём видны базы, коллекции и документы. Если Compass
установлен, он подключается к этому же серверу по адресу `mongodb://localhost:27017`.

**Консоль сервера:** `docker compose exec mongo mongosh`.

**Остановить и удалить:**

```bash
docker compose stop        # остановить; данные останутся
docker compose down        # удалить контейнеры; данные останутся
docker compose down -v     # удалить всё вместе с данными
```

Архивы всех глав пользуются одним и тем же сервером и данными: после этой главы можно распаковать
архив следующей и работать там, не удаляя стенд.

## Способ 2. Установленный сервер MongoDB и Compass

Нужны MongoDB Server 7 или 8 и MongoDB Compass — установка по шагам в
[главе 1.0а](https://maximbytecamp.github.io/mongodb_theory_makarov/temy/00a-windows-10-mongodb-7/index.html).
Проверка: Compass подключается к `mongodb://localhost:27017`.

### Шаг 1. Загрузить базы курса

Windows, PowerShell, из папки архива — нужен `mongoimport` из MongoDB Command Line Database Tools:

```powershell
powershell -ExecutionPolicy Bypass -File stend\load.ps1
```

macOS и Linux (`mongoimport`: `brew tap mongodb/brew && brew install mongodb-database-tools`):

```bash
bash stend/load.sh
```

Скрипт пересоздаёт коллекции целиком, поэтому он же сбрасывает базы: повторный запуск ничего не двоит.

**Без `mongoimport` — через Compass.** Подключитесь к `mongodb://localhost:27017`, нажмите **Create database**,
затем в коллекции **Add data → Import JSON or CSV file** и выберите файл из `stend/seed`. Имя файла
подсказывает, куда класть: `shop.orders.json` — база `shop`, коллекция `orders`. Так загружаются все
12 файлов; пошагово с кадрами — [глава 1.0, §7](https://maximbytecamp.github.io/mongodb_theory_makarov/temy/00-uchebnye-bazy/index.html#s7).

После загрузки в Compass нажмите **Refresh**: в списке должны быть базы `shop`, `hh`, `logs`, `org`
и `sandbox`. В `shop.products` — 21 документ, в `shop.orders` — 120.

### Шаг 2. Драйвер Python и запуск

Python 3.10 или новее — с [python.org](https://www.python.org/downloads/). На Windows в установщике
отметьте **Add python.exe to PATH**.

Windows, PowerShell, из папки архива:

```powershell
python -m pip install -r requirements.txt
cd primery
python 01.py
```

macOS и Linux — драйвер ставится в виртуальное окружение: системный Python не даёт ставить пакеты напрямую.

```bash
python3 -m venv .venv
source .venv/bin/activate          # в каждом новом терминале снова
pip install -r requirements.txt
cd primery
python3 01.py
```

Если `venv` не найден на Linux: `sudo apt install python3-venv`.

Остальные примеры запускаются так же: `02.py`, `03.py` и далее. Если сервер слушает другой адрес,
задайте его переменной `MONGO_URI` — программы глав 1.2–1.8 читают её при подключении.

## Примеры и выводы

| Файл | Параграф главы | Что делает |
|---|---|---|
| `01.py` | §1 Стадия $project | включение полей |
| `02.py` | §2 Вложенное поле в $project | без _id, с вложенным полем |
| `03.py` | §3 Новое имя поля и путь к полю | новые имена полей |
| `04.py` | §4 Вычисляемые поля | вычисляемые поля |
| `05.py` | §5 Склейка строк: $concat и $toString | склейка строк |
| `06.py` | §6 Значение по условию: $cond | поле по условию |
| `07.py` | §7 Какие проекции сервер отклоняет | включение вместе с исключением |
| `08.py` | §8 Место $project в конвейере | $project до и после $match |

### 01.py · §1 Стадия $project

Включение полей.

```text
{'_id': 'o-0028', 'number': '2026-0028', 'total': 244460}
{'_id': 'o-0085', 'number': '2026-0085', 'total': 225320}
{'_id': 'o-0025', 'number': '2026-0025', 'total': 211760}
```

### 02.py · §2 Вложенное поле в $project

Без _id, с вложенным полем.

```text
{'number': '2026-0028', 'total': 244460, 'delivery': {'city': 'Екатеринбург'}}
{'number': '2026-0085', 'total': 225320, 'delivery': {'city': 'Новосибирск'}}
{'number': '2026-0025', 'total': 211760, 'delivery': {'city': 'Екатеринбург'}}
```

### 03.py · §3 Новое имя поля и путь к полю

Новые имена полей.

```text
{'order': '2026-0028', 'city': 'Екатеринбург', 'sum': 244460}
{'order': '2026-0085', 'city': 'Новосибирск', 'sum': 225320}
{'order': '2026-0025', 'city': 'Екатеринбург', 'sum': 211760}
```

### 04.py · §4 Вычисляемые поля

Вычисляемые поля.

```text
{'title': 'Ноутбук Apple MacBook Air 13', 'price': 114990, 'sale': 103491.0, 'saving': 11499.0}
{'title': 'Ноутбук Acer Nitro V15', 'price': 89990, 'sale': 80991.0, 'saving': 8999.0}
{'title': 'Ноутбук HP Pavilion 14', 'price': 67900, 'sale': 61110.0, 'saving': 6790.0}
{'title': 'Ноутбук ASUS VivoBook 15', 'price': 51490, 'sale': 46341.0, 'saving': 5149.0}
{'title': 'Ноутбук Lenovo IdeaPad 3', 'price': 42990, 'sale': 38691.0, 'saving': 4299.0}
```

### 05.py · §5 Склейка строк: $concat и $toString

Склейка строк.

```text
── $concat с числом
код 16702
PlanExecutor error during aggregation :: caused by :: $concat only supports strings, not int
── $concat с $toString
{'line': '2026-0028 — 244460 ₽'}
{'line': '2026-0085 — 225320 ₽'}
{'line': '2026-0025 — 211760 ₽'}
```

### 06.py · §6 Значение по условию: $cond

Поле по условию.

```text
{'title': 'Ноутбук Apple MacBook Air 13', 'price': 114990, 'segment': 'дорогой'}
{'title': 'Ноутбук Acer Nitro V15', 'price': 89990, 'segment': 'дорогой'}
{'title': 'Смартфон Apple iPhone 15', 'price': 79990, 'segment': 'дорогой'}
{'title': 'Ноутбук HP Pavilion 14', 'price': 67900, 'segment': 'дорогой'}
{'title': 'Ноутбук ASUS VivoBook 15', 'price': 51490, 'segment': 'дорогой'}
{'title': 'Ноутбук Lenovo IdeaPad 3', 'price': 42990, 'segment': 'доступный'}
{'title': 'Смартфон Samsung Galaxy A55', 'price': 32990, 'segment': 'доступный'}
{'title': 'Смартфон realme 12 Pro', 'price': 27490, 'segment': 'доступный'}
{'title': 'Смартфон Xiaomi Redmi Note 13', 'price': 18990, 'segment': 'доступный'}
```

### 07.py · §7 Какие проекции сервер отклоняет

Включение вместе с исключением.

```text
── number: 1 и items: 0
код 31254
Invalid $project :: caused by :: Cannot do exclusion on field items in inclusion projection
── items: 0 и новое поле
код 31310
Invalid $project :: caused by :: Cannot use an expression sum: "$total" in an exclusion projection
```

### 08.py · §8 Место $project в конвейере

$project до и после $match.

```text
$project до $match: 0
$match до $project: 13
```

## Частые ошибки

| Что видно | Причина | Что сделать |
|---|---|---|
| `port is already allocated`, `address already in use` на `docker compose up -d` | порт 27017 занят: уже работает установленный MongoDB или стенд `mongodb-practice` | остановите тот сервер или создайте рядом с `compose.yaml` файл `.env` со строкой `MONGO_PORT=27018`: в PowerShell — `Set-Content .env "MONGO_PORT=27018"`, в bash — `echo "MONGO_PORT=27018" > .env`. Программы в Docker это не затрагивает, Compass подключайте к `localhost:27018` |
| `Cannot connect to the Docker daemon`, `error during connect` | Docker Desktop не запущен | запустите Docker Desktop и дождитесь зелёного статуса Engine running |
| `ServerSelectionTimeoutError`, `Connection refused`, `No server available` | сервер не запущен | Docker: `docker compose up -d`; способ 2 — запустите службу MongoDB |
| `Файл не найден: …` | путь написан не от папки архива или команда выполнена в другой папке | перейдите в папку, где лежит `compose.yaml`, и пишите путь `primery/01.py` |
| числа в выводе не совпадают с README | пример запускали дважды, пропустили или базы не сброшены | сбросьте базы и запустите примеры с первого по порядку |

В PowerShell не используйте `echo … > .env`: Windows PowerShell 5 пишет такой файл в UTF-16, и Docker
Compose его не прочитает.
