# Глава 4.2 · $project: форма ответа
# Пример 7 из 8 · §7 Какие проекции сервер отклоняет · включение вместе с исключением
#
# Запуск из папки архива:
#   docker compose run --rm python primery/07.py
#   cd primery, затем python 07.py (Windows) или python3 07.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

from datetime import datetime


def show(docs, *fields):
    """Печатает у каждого документа поля fields в строку через « | »; вложенные — через точку."""
    count = 0
    for doc in docs:
        cells = []
        for path in fields:
            value = doc
            for key in path.split("."):
                value = value.get(key) if isinstance(value, dict) else None
            if isinstance(value, datetime):
                value = value.strftime("%Y-%m-%d %H:%M")
            if isinstance(value, bool):
                value = str(value).lower()
            cells.append("—" if value is None else str(value))
        print(" | ".join(cells))
        count += 1
    print("документов:", count)

# ── пример из главы ───────────────────────────────────────────
from pymongo.errors import OperationFailure

keep_and_drop = [
    {"$match": {"status": "в пути"}},
    {"$sort": {"total": -1}},
    {"$limit": 3},
    {"$project": {"number": 1, "items": 0}},
]

drop_and_compute = [
    {"$match": {"status": "в пути"}},
    {"$sort": {"total": -1}},
    {"$limit": 3},
    {"$project": {"items": 0, "sum": "$total"}},
]

print("── number: 1 и items: 0")
try:
    for doc in orders.aggregate(keep_and_drop):
        print(doc)
except OperationFailure as e:
    print("код", e.code)
    print(e.details["errmsg"])

print("── items: 0 и новое поле")
try:
    for doc in orders.aggregate(drop_and_compute):
        print(doc)
except OperationFailure as e:
    print("код", e.code)
    print(e.details["errmsg"])
