# Глава 4.2 · $project: форма ответа
# Пример 5 из 8 · §5 Склейка строк: $concat и $toString · склейка строк
#
# Запуск из папки архива:
#   docker compose run --rm python primery/05.py
#   cd primery, затем python 05.py (Windows) или python3 05.py (macOS, Linux)
# Что должно получиться — в README.md, раздел «Примеры и выводы».

import os
from pymongo import MongoClient

client = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))
db = client["shop"]
orders = db["orders"]
products = db["products"]
customers = db["customers"]
sandbox = client["sandbox"]

from datetime import datetime


def show(docs, *fields):
    """Печатает у каждого документа поля fields в строку через « | »; вложенные — через точку."""
    count = 0
    for doc in docs:
        cells = []
        for path in fields:
            value = doc
            for key in path.split("."):
                value = value.get(key) if isinstance(value, dict) else None
            if isinstance(value, datetime):
                value = value.strftime("%Y-%m-%d %H:%M")
            if isinstance(value, bool):
                value = str(value).lower()
            cells.append("—" if value is None else str(value))
        print(" | ".join(cells))
        count += 1
    print("документов:", count)

# ── пример из главы ───────────────────────────────────────────
from pymongo.errors import OperationFailure

with_number = [
    {"$match": {"status": "в пути"}},
    {"$sort": {"total": -1}},
    {"$limit": 3},
    {"$project": {"_id": 0, "line": {"$concat": ["$number", " — ", "$total"]}}},
]

with_string = [
    {"$match": {"status": "в пути"}},
    {"$sort": {"total": -1}},
    {"$limit": 3},
    {"$project": {
        "_id": 0,
        "line": {"$concat": ["$number", " — ", {"$toString": "$total"}, " ₽"]},
    }},
]

print("── $concat с числом")
try:
    for doc in orders.aggregate(with_number):
        print(doc)
except OperationFailure as e:
    print("код", e.code)
    print(e.details["errmsg"])

print("── $concat с $toString")
for doc in orders.aggregate(with_string):
    print(doc)
