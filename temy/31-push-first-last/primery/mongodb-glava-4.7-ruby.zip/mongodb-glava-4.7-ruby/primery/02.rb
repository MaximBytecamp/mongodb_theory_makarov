# Глава 4.7 · $push, $addToSet, $first и $last
# Пример 2 из 6 · §1 Аккумулятор $push · $push: документ из двух полей
#
# Запуск из папки архива:
#   docker compose run --rm ruby primery/02.rb
#   cd primery, затем ruby 02.rb
# Что должно получиться — в README.md, раздел «Примеры и выводы».

require "mongo"

Mongo::Logger.logger.level = Logger::WARN

client = Mongo::Client.new(ENV.fetch("MONGO_URI", "mongodb://localhost:27017/"))
db = client.use("shop").database
orders = db[:orders]
products = db[:products]
customers = db[:customers]
sandbox = client.use("sandbox").database

# Печатает у каждого документа поля fields в строку через « | »; вложенные — через точку.
def show(docs, *fields)
  count = 0
  docs.each do |doc|
    cells = fields.map do |path|
      value = path.split(".").reduce(doc) { |v, key| v.is_a?(Hash) ? v[key] : nil }
      value = value.utc.strftime("%Y-%m-%d %H:%M") if value.is_a?(Time)
      value.nil? ? "—" : value.to_s
    end
    puts cells.join(" | ")
    count += 1
  end
  puts "документов: #{count}"
end

# ── пример из главы ───────────────────────────────────────────
pipeline = [
  { "$match" => { "status" => "в пути", "delivery.city" => "Ярославль" } },
  { "$sort" => { "number" => 1 } },
  { "$group" => {
    "_id" => "$delivery.city",
    "orders" => { "$push" => { "number" => "$number", "total" => "$total" } },
  } },
]

orders.aggregate(pipeline).each { |doc| puts doc.inspect }
