# Глава 4.7 · $push, $addToSet, $first и $last — примеры на Ruby

Архив к «Справочнику по MongoDB»: все примеры главы готовыми программами, данные баз и стенд в Docker.
Глава: https://maximbytecamp.github.io/mongodb_theory_makarov/temy/31-push-first-last/index.html

Язык: **Ruby** · драйвер gem mongo 2.21 · сервер MongoDB 7.

## Что в архиве

```text
mongodb-glava-4.7-ruby/
  README.md         эта инструкция
  primery/          примеры главы — по программе на пример
    01.rb … 06.rb
  compose.yaml      стенд в Docker: сервер, базы, mongo-express, Ruby
  docker/           образ с драйвером Ruby и скрипт запуска run.sh
  stend/seed/       данные баз: 12 файлов JSON
  stend/load.ps1    загрузка данных на установленный сервер — Windows
  stend/load.sh     то же — macOS и Linux
```

## Порядок работы

1. **Базы.** Глава **только читает** данные — сбрасывать базы не нужно.
2. **Примеры — по порядку, каждый один раз.** Пример в главе рассчитан на данные, которые оставил
   предыдущий. Если запустить пример дважды или пропустить, числа разойдутся с книгой — тогда
   сбросьте базы и начните с `01.rb`.
3. **Сверка.** Что должна напечатать каждая программа — в разделе «Примеры и выводы» ниже.
   Отличаться могут только `_id`, которые выдаёт сервер, текущие дата и время и порядок
   в списке коллекций: сервер отдаёт их имена в произвольном порядке. У документа, который
   создан обновлением с `upsert`, поля тоже могут идти в другом порядке — значения при этом те же.

Подойдёт любой из двух способов. Адрес сервера в обоих — `mongodb://localhost:27017`, код примеров
одинаковый.

| Способ | Что нужно | Когда подходит |
|---|---|---|
| **1. Docker** | Docker Desktop | Compass и сервер не установились или не подключаются; ничего, кроме Docker, ставить не нужно |
| **2. Сервер и Compass** | MongoDB Server, Compass, Ruby с драйвером | сервер и Compass уже стоят и подключаются |

## Способ 1. Docker

Docker Desktop — с [docker.com](https://www.docker.com/products/docker-desktop/); на Linux — Docker Engine.
Перед командами Docker Desktop должен быть запущен. Команды одинаковые в PowerShell, cmd и терминале
macOS/Linux; выполняйте их **из папки архива** — там, где лежит `compose.yaml`.

1. Поднять сервер и загрузить базы курса:

   ```bash
   docker compose up -d
   ```

2. Запустить пример — путь к файлу пишется от папки архива:

   ```bash
   docker compose run --rm ruby primery/01.rb
   ```

   При первом запуске Docker соберёт образ с драйвером Ruby — это пара минут.
   Дальше запуск идёт за секунды.

3. Все примеры главы подряд, по порядку, одной командой:

   ```bash
   docker compose run --rm ruby primery
   ```

   Перед каждой программой печатается её имя: `── primery/01.rb ──`.

**Смотреть данные.** Compass не нужен: в браузере откройте http://localhost:8081, логин `student`,
пароль `student` — это mongo-express, в нём видны базы, коллекции и документы. Если Compass
установлен, он подключается к этому же серверу по адресу `mongodb://localhost:27017`.

**Консоль сервера:** `docker compose exec mongo mongosh`.

**Остановить и удалить:**

```bash
docker compose stop        # остановить; данные останутся
docker compose down        # удалить контейнеры; данные останутся
docker compose down -v     # удалить всё вместе с данными
```

Архивы всех глав пользуются одним и тем же сервером и данными: после этой главы можно распаковать
архив следующей и работать там, не удаляя стенд.

## Способ 2. Установленный сервер MongoDB и Compass

Нужны MongoDB Server 7 или 8 и MongoDB Compass — установка по шагам в
[главе 1.0а](https://maximbytecamp.github.io/mongodb_theory_makarov/temy/00a-windows-10-mongodb-7/index.html).
Проверка: Compass подключается к `mongodb://localhost:27017`.

### Шаг 1. Загрузить базы курса

Windows, PowerShell, из папки архива — нужен `mongoimport` из MongoDB Command Line Database Tools:

```powershell
powershell -ExecutionPolicy Bypass -File stend\load.ps1
```

macOS и Linux (`mongoimport`: `brew tap mongodb/brew && brew install mongodb-database-tools`):

```bash
bash stend/load.sh
```

Скрипт пересоздаёт коллекции целиком, поэтому он же сбрасывает базы: повторный запуск ничего не двоит.

**Без `mongoimport` — через Compass.** Подключитесь к `mongodb://localhost:27017`, нажмите **Create database**,
затем в коллекции **Add data → Import JSON or CSV file** и выберите файл из `stend/seed`. Имя файла
подсказывает, куда класть: `shop.orders.json` — база `shop`, коллекция `orders`. Так загружаются все
12 файлов; пошагово с кадрами — [глава 1.0, §7](https://maximbytecamp.github.io/mongodb_theory_makarov/temy/00-uchebnye-bazy/index.html#s7).

После загрузки в Compass нажмите **Refresh**: в списке должны быть базы `shop`, `hh`, `logs`, `org`
и `sandbox`. В `shop.products` — 21 документ, в `shop.orders` — 120.

### Шаг 2. Драйвер Ruby и запуск

Ruby 3.3. На Windows — с [rubyinstaller.org](https://rubyinstaller.org/downloads/), сборка
**with Devkit**: драйверу нужен компилятор для расширения `bson`. На последнем экране установщика оставьте
галочку **Run 'ridk install'** и в окне MSYS2 выберите пункт 3.

Windows, PowerShell:

```powershell
gem install mongo -v 2.21.0
cd primery
ruby 01.rb
```

macOS и Linux (на Linux сначала `sudo apt install ruby-full build-essential`):

```bash
gem install --user-install mongo -v 2.21.0
cd primery
ruby 01.rb
```

Остальные примеры запускаются так же: `02.rb`, `03.rb` и далее. Если сервер слушает другой адрес,
задайте его переменной `MONGO_URI` — программы глав 1.2–1.8 читают её при подключении.

## Примеры и выводы

| Файл | Параграф главы | Что делает |
|---|---|---|
| `01.rb` | §1 Аккумулятор $push | $push: номера заказов в пути по городам |
| `02.rb` | §1 Аккумулятор $push | $push: документ из двух полей |
| `03.rb` | §2 Аккумулятор $addToSet | $push и $addToSet: категории покупок |
| `04.rb` | §3 $first и $last | $first и $last после $sort |
| `05.rb` | §4 Порядок документов перед $group | $first и $last без $sort |
| `06.rb` | §5 Лучший документ в каждой группе | самый дорогой заказ города |

### 01.rb · §1 Аккумулятор $push

$push: номера заказов в пути по городам.

```text
{"_id"=>"Екатеринбург", "numbers"=>["2026-0025", "2026-0027", "2026-0028", "2026-0043"]}
{"_id"=>"Москва", "numbers"=>["2026-0023"]}
{"_id"=>"Новосибирск", "numbers"=>["2026-0055", "2026-0056", "2026-0085", "2026-0088", "2026-0119"]}
{"_id"=>"Ярославль", "numbers"=>["2026-0033", "2026-0054", "2026-0081"]}
```

### 02.rb · §1 Аккумулятор $push

$push: документ из двух полей.

```text
{"_id"=>"Ярославль", "orders"=>[{"number"=>"2026-0033", "total"=>9180}, {"number"=>"2026-0054", "total"=>55360}, {"number"=>"2026-0081", "total"=>150470}]}
```

### 03.rb · §2 Аккумулятор $addToSet

$push и $addToSet: категории покупок.

```text
{"_id"=>"c-007", "all"=>["ноутбуки", "периферия", "периферия", "ноутбуки", "периферия", "периферия", "ноутбуки", "периферия", "смартфоны", "смартфоны", "ноутбуки", "аксессуары", "комплектующие", "периферия", "периферия"], "unique"=>["аксессуары", "комплектующие", "ноутбуки", "периферия", "смартфоны"]}
```

### 04.rb · §3 $first и $last

$first и $last после $sort.

```text
{"_id"=>"c-007", "orders"=>8, "first"=>"2026-0036", "last"=>"2026-0064"}
{"_id"=>"c-011", "orders"=>9, "first"=>"2026-0062", "last"=>"2026-0051"}
{"_id"=>"c-018", "orders"=>9, "first"=>"2026-0116", "last"=>"2026-0033"}
```

### 05.rb · §4 Порядок документов перед $group

$first и $last без $sort.

```text
{"_id"=>"c-007", "first"=>"2026-0002", "last"=>"2026-0117"}
{"_id"=>"c-011", "first"=>"2026-0006", "last"=>"2026-0112"}
{"_id"=>"c-018", "first"=>"2026-0001", "last"=>"2026-0116"}
```

### 06.rb · §5 Лучший документ в каждой группе

Самый дорогой заказ города.

```text
{"_id"=>"Екатеринбург", "number"=>"2026-0120", "total"=>457930, "orders"=>28}
{"_id"=>"Москва", "number"=>"2026-0063", "total"=>413410, "orders"=>18}
{"_id"=>"Ярославль", "number"=>"2026-0115", "total"=>392660, "orders"=>21}
{"_id"=>"Новосибирск", "number"=>"2026-0091", "total"=>354960, "orders"=>35}
{"_id"=>"Санкт-Петербург", "number"=>"2026-0009", "total"=>320740, "orders"=>18}
```

## Частые ошибки

| Что видно | Причина | Что сделать |
|---|---|---|
| `port is already allocated`, `address already in use` на `docker compose up -d` | порт 27017 занят: уже работает установленный MongoDB или стенд `mongodb-practice` | остановите тот сервер или создайте рядом с `compose.yaml` файл `.env` со строкой `MONGO_PORT=27018`: в PowerShell — `Set-Content .env "MONGO_PORT=27018"`, в bash — `echo "MONGO_PORT=27018" > .env`. Программы в Docker это не затрагивает, Compass подключайте к `localhost:27018` |
| `Cannot connect to the Docker daemon`, `error during connect` | Docker Desktop не запущен | запустите Docker Desktop и дождитесь зелёного статуса Engine running |
| `ServerSelectionTimeoutError`, `Connection refused`, `No server available` | сервер не запущен | Docker: `docker compose up -d`; способ 2 — запустите службу MongoDB |
| `Файл не найден: …` | путь написан не от папки архива или команда выполнена в другой папке | перейдите в папку, где лежит `compose.yaml`, и пишите путь `primery/01.rb` |
| числа в выводе не совпадают с README | пример запускали дважды, пропустили или базы не сброшены | сбросьте базы и запустите примеры с первого по порядку |

В PowerShell не используйте `echo … > .env`: Windows PowerShell 5 пишет такой файл в UTF-16, и Docker
Compose его не прочитает.
